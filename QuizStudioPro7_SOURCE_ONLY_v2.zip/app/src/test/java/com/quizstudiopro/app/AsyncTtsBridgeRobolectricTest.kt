package com.quizstudiopro.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.concurrent.TimeUnit

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AsyncTtsBridgeRobolectricTest {

    @Test
    fun synthesizeSpeechAsyncReturnsImmediatelyWithoutBlockingCallerThread() {
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val activity = controller.get()
        val bridge = activity.AndroidBridge()

        val t0Ns = System.nanoTime()
        // Dispatch async synthesis off-thread; caller must return near-immediately without runBlocking
        bridge.synthesizeSpeechAsync("req_nonblock_1", "Hello world", "en-US-AriaNeural", 0)
        val elapsedMs = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - t0Ns)

        assertTrue(
            "synthesizeSpeechAsync must return immediately without blocking main/JS caller thread (took ${elapsedMs}ms)",
            elapsedMs < 250L
        )

        // Cancelling immediately should be safe and idempotent
        bridge.cancelSpeechRequests()
        bridge.cancelSpeechRequests()
        controller.pause().stop().destroy()
    }

    @Test
    fun androidBridgeExposesAsyncAndSyncTtsMethodsCleanly() {
        val methods = MainActivity.AndroidBridge::class.java.declaredMethods.map { it.name }.toSet()
        assertTrue("Expected synthesizeSpeechAsync on AndroidBridge", methods.contains("synthesizeSpeechAsync"))
        assertTrue("Expected cancelSpeechRequests on AndroidBridge", methods.contains("cancelSpeechRequests"))
        assertTrue("Expected legacy synthesizeSpeech preserved on AndroidBridge", methods.contains("synthesizeSpeech"))
        assertNotNull(MainActivity.AndroidBridge::class.java)
        assertFalse(methods.isEmpty())
    }
}
