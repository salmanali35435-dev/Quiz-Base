package com.quizstudiopro.app

import android.content.Context
import android.graphics.Bitmap
import androidx.test.core.app.ApplicationProvider
import com.quizstudiopro.app.audio.EdgeTtsClient
import com.quizstudiopro.app.video.NativeSceneRenderer
import com.quizstudiopro.app.video.StreamingVideoEncoderSession
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.nio.ByteBuffer
import java.nio.ByteOrder

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class PhasePipelineRobolectricTest {

    @Test
    fun verifyAppNameResourcePreserved() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("Quiz Studio Pro", ctx.getString(R.string.app_name))
    }

    @Test
    fun verifyStreamingEncoderCalculations() {
        assertEquals(0L, StreamingVideoEncoderSession.computePtsNs(0, 24))
        assertEquals(1_000_000_000L, StreamingVideoEncoderSession.computePtsNs(24, 24))
        assertEquals(500_000_000L, StreamingVideoEncoderSession.computePtsNs(15, 30))
        // Fallback invalid fps clamps to 24
        assertEquals(1_000_000_000L, StreamingVideoEncoderSession.computePtsNs(24, 0))

        assertEquals(16_000_000, StreamingVideoEncoderSession.computeBitRate(2560))
        assertEquals(10_000_000, StreamingVideoEncoderSession.computeBitRate(1920))
        assertEquals(6_000_000, StreamingVideoEncoderSession.computeBitRate(1280))
        assertEquals(3_500_000, StreamingVideoEncoderSession.computeBitRate(720))

        val modes = StreamingVideoEncoderSession.Mode.values().map { it.name }.toSet()
        assertTrue(modes.contains("NATIVE_SCENE_DIRECT"))
        assertTrue(modes.contains("NATIVE_RGBA_STREAM"))
        assertTrue(modes.contains("COMPATIBILITY_FALLBACK"))
    }

    @Test
    fun verifyEdgeTtsWordBoundaryParser() {
        val out = mutableListOf<EdgeTtsClient.WordBoundary>()

        val frame = "X-RequestId:abc\r\nContent-Type:application/json\r\nPath:audio.metadata\r\n\r\n" +
            """{"Metadata":[{"Type":"WordBoundary","Data":{"Offset":5000000,"Duration":2500000,"text":{"Text":"Saturn"}}}]}"""
        EdgeTtsClient.parseWordBoundaries(frame, out)

        assertEquals(1, out.size)
        assertEquals("Saturn", out[0].text)
        assertEquals(500.0, out[0].offsetMs, 0.01)
        assertEquals(250.0, out[0].durationMs, 0.01)

        // Malformed metadata does not throw
        EdgeTtsClient.parseWordBoundaries("Path:audio.metadata\r\n\r\n{invalid-json", out)
        assertEquals(1, out.size)
    }

    @Test
    fun verifyNativeSceneRendererReusesBitmapAndRespectsImportedMode() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val importedBundle = JSONObject().apply {
            put("timerDuration", 8)
            put("headerText", "SHOULD_NOT_APPEAR")
            put("scene", JSONObject().apply {
                put("mode", "IMPORTED_TEMPLATE_MODE")
                put("elements", JSONArray().apply {
                    put(JSONObject().apply {
                        put("id", "bg")
                        put("type", "background")
                        put("x", 0.0)
                        put("y", 0.0)
                        put("width", 1.0)
                        put("height", 1.0)
                        put("backgroundColor", "#102840")
                        put("layerOrder", 0)
                    })
                    put(JSONObject().apply {
                        put("id", "qtext")
                        put("type", "question_text")
                        put("x", 0.1)
                        put("y", 0.2)
                        put("width", 0.8)
                        put("height", 0.2)
                        put("text", "{question}")
                        put("textColor", "#ffffff")
                        put("fontSize", 0.06)
                        put("layerOrder", 1)
                    })
                })
            })
            put("questions", JSONArray().apply {
                put(JSONObject().apply {
                    put("question", "Which planet has the Great Red Spot?")
                    put("options", JSONArray(listOf("Mars", "Jupiter", "Venus", "Neptune")))
                    put("correct", 1)
                })
            })
            put("timeline", JSONObject().apply {
                put("total", 5.0)
                put("segs", JSONArray().apply {
                    put(JSONObject().apply {
                        put("type", "voice")
                        put("i", 0)
                        put("start", 0.0)
                        put("dur", 2.0)
                    })
                    put(JSONObject().apply {
                        put("type", "count")
                        put("i", 0)
                        put("start", 2.0)
                        put("dur", 3.0)
                    })
                })
            })
        }

        val renderer = NativeSceneRenderer(ctx, importedBundle.toString(), 320, 180, 24)
        val singleTarget = Bitmap.createBitmap(320, 180, Bitmap.Config.ARGB_8888)
        renderer.renderFrame(0, singleTarget)
        renderer.renderFrame(30, singleTarget)
        renderer.renderFrame(60, singleTarget)
        assertSame(singleTarget, singleTarget)
        assertEquals(320, singleTarget.width)
        assertEquals(180, singleTarget.height)
        assertTrue(!singleTarget.isRecycled)
        renderer.release()
        assertTrue(!singleTarget.isRecycled)
    }

    @Test
    fun verifyBinaryPacketHeaderProtocol() {
        val payload = ByteArray(16) { it.toByte() }
        val packet = ByteBuffer.allocate(8 + payload.size).order(ByteOrder.LITTLE_ENDIAN)
        packet.put('R'.code.toByte())
        packet.put('G'.code.toByte())
        packet.put('B'.code.toByte())
        packet.put('A'.code.toByte())
        packet.putInt(123)
        packet.put(payload)

        val raw = packet.array()
        val magic = String(raw, 0, 4, Charsets.US_ASCII)
        val frameIdx = ByteBuffer.wrap(raw, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
        assertEquals("RGBA", magic)
        assertEquals(123, frameIdx)
    }

    @Test
    fun verifyNativeSceneRendererHonorsCustomAnswerRevealAndQuestionNumberConfig() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val bundle = JSONObject().apply {
            put("timerDuration", 5)
            put("locale", "it-IT")
            put("questionNumberConfig", JSONObject().apply {
                put("preset", "question_01_of_20")
                put("prefix", "Question ")
                put("leadingZero", true)
                put("separator", " of ")
                put("showTotal", true)
            })
            put("answerRevealConfig", JSONObject().apply {
                put("style", "highlight-dim-others")
                put("highlightBg", "#7c3aed")
                put("badgeBg", "#06b6d4")
                put("dimBg", "#334155")
                put("dimOpacity", 0.35)
                put("glowEnabled", true)
                put("glowColor", "#c084fc")
            })
            put("scene", JSONObject().apply {
                put("mode", "DEFAULT_TEMPLATE_MODE")
                put("elements", JSONArray().apply {
                    put(JSONObject().apply {
                        put("id", "bg")
                        put("type", "background")
                        put("x", 0.0); put("y", 0.0); put("width", 1.0); put("height", 1.0)
                        put("backgroundColor", "#ffffff")
                        put("layerOrder", 0)
                    })
                    put(JSONObject().apply {
                        put("id", "qnum")
                        put("type", "question_number")
                        put("x", 0.05); put("y", 0.02); put("width", 0.5); put("height", 0.1)
                        put("backgroundColor", "#1e1b08")
                        put("textColor", "#ffff00")
                        put("layerOrder", 1)
                    })
                    put(JSONObject().apply {
                        put("id", "opt0")
                        put("type", "option_container")
                        put("optionIndex", 0)
                        put("x", 0.05); put("y", 0.50); put("width", 0.40); put("height", 0.20)
                        put("backgroundColor", "#050505")
                        put("borderRadius", 0.0)
                        put("layerOrder", 2)
                    })
                    put(JSONObject().apply {
                        put("id", "opt1")
                        put("type", "option_container")
                        put("optionIndex", 1)
                        put("x", 0.55); put("y", 0.50); put("width", 0.40); put("height", 0.20)
                        put("backgroundColor", "#050505")
                        put("borderRadius", 0.0)
                        put("layerOrder", 3)
                    })
                })
            })
            put("questions", JSONArray().apply {
                put(JSONObject().apply {
                    put("question", "Quale pianeta è rosso?")
                    put("options", JSONArray(listOf("Venere", "Marte", "Giove", "Saturno")))
                    put("correct", 1)
                    put("promptPrefixWords", 2)
                })
            })
            put("timeline", JSONObject().apply {
                put("total", 3.5)
                put("segs", JSONArray().apply {
                    put(JSONObject().apply { put("type", "voice"); put("i", 0); put("start", 0.0); put("dur", 1.0) })
                    put(JSONObject().apply { put("type", "count"); put("i", 0); put("start", 1.0); put("dur", 1.0) })
                    put(JSONObject().apply { put("type", "reveal"); put("i", 0); put("start", 2.0); put("dur", 0.5) })
                    put(JSONObject().apply { put("type", "answer"); put("i", 0); put("start", 2.5); put("dur", 1.0) })
                })
            })
        }

        val renderer = NativeSceneRenderer(ctx, bundle.toString(), 400, 200, 24)
        val bmp = Bitmap.createBitmap(400, 200, Bitmap.Config.ARGB_8888)

        // Frame during reveal segment (t = 2.25s -> frame 54)
        renderer.renderFrame(54, bmp)
        assertEquals("Question 01 of 01", renderer.lastRenderedQuestionNumber)

        val opt0State = renderer.lastOptionDrawStates[0]!!
        val opt1State = renderer.lastOptionDrawStates[1]!!
        // Correct option (opt1) uses custom purple #7c3aed (full alpha), wrong option (opt0) uses dimmed slate #334155 with ~35% alpha
        assertEquals(android.graphics.Color.parseColor("#7c3aed"), opt1State.fillColor)
        assertEquals(255, opt1State.alpha)
        assertEquals(android.graphics.Color.parseColor("#334155"), opt0State.fillColor)
        assertTrue("Wrong option alpha must be dimmed (~89)", opt0State.alpha in 80..95)
        renderer.release()
    }

    @Test
    fun verifyNativeSceneRendererSeparatesSlotFromTickBadgeAndStylesDimmedWrongOptions() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val elements = JSONArray().apply {
            put(JSONObject().apply {
                put("id", "bg")
                put("type", "background")
                put("x", 0.0); put("y", 0.0); put("width", 1.0); put("height", 1.0)
                put("backgroundColor", "#f8fafc")
                put("layerOrder", 0)
            })
            for (idx in 0..3) {
                val y = 0.45 + idx * 0.13
                put(JSONObject().apply {
                    put("id", "c_$idx"); put("type", "option_container"); put("optionIndex", idx)
                    put("x", 0.06); put("y", y); put("width", 0.88); put("height", 0.11)
                    put("backgroundColor", "#050505"); put("borderRadius", 0.4); put("layerOrder", 10 + idx * 3)
                })
                put(JSONObject().apply {
                    put("id", "l_$idx"); put("type", "option_label"); put("optionIndex", idx)
                    put("x", 0.07); put("y", y + 0.015); put("width", 0.06); put("height", 0.08)
                    put("backgroundColor", "#facc15"); put("textColor", "#000000"); put("borderRadius", 0.5); put("layerOrder", 11 + idx * 3)
                })
                put(JSONObject().apply {
                    put("id", "t_$idx"); put("type", "option_text"); put("optionIndex", idx)
                    put("x", 0.15); put("y", y + 0.015); put("width", 0.76); put("height", 0.08)
                    put("textColor", "#ffffff"); put("layerOrder", 12 + idx * 3)
                })
            }
        }

        for (correctIdx in 0..3) {
            val bundle = JSONObject().apply {
                put("timerDuration", 5)
                put("answerRevealConfig", JSONObject().apply {
                    put("style", "highlight-dim-others")
                    put("highlightBg", "#16a34a")
                    put("correctTextColor", "#ffffff")
                    put("badgeBg", "#000000")
                    put("badgeTickColor", "#facc15")
                    put("correctBorderColor", "#ffffff")
                    put("correctBorderWidth", 4)
                    put("dimBg", "#1e293b")
                    put("dimTextColor", "#94a3b8")
                    put("dimBadgeBg", "#334155")
                    put("dimBadgeTextColor", "#cbd5e1")
                    put("dimBorderColor", "#475569")
                    put("dimOpacity", 0.88)
                })
                put("scene", JSONObject().apply {
                    put("mode", "DEFAULT_TEMPLATE_MODE")
                    put("elements", JSONArray(elements.toString()))
                })
                put("questions", JSONArray().apply {
                    put(JSONObject().apply {
                        put("question", "Pick one")
                        put("options", JSONArray(listOf("One", "Two", "Three", "Four")))
                        put("correct", correctIdx)
                    })
                })
                put("timeline", JSONObject().apply {
                    put("total", 3.0)
                    put("segs", JSONArray().apply {
                        put(JSONObject().apply { put("type", "voice"); put("i", 0); put("start", 0.0); put("dur", 1.0) })
                        put(JSONObject().apply { put("type", "count"); put("i", 0); put("start", 1.0); put("dur", 1.0) })
                        put(JSONObject().apply { put("type", "reveal"); put("i", 0); put("start", 2.0); put("dur", 1.0) })
                    })
                })
            }

            val renderer = NativeSceneRenderer(ctx, bundle.toString(), 640, 360, 24)
            val bmp = Bitmap.createBitmap(640, 360, Bitmap.Config.ARGB_8888)
            renderer.renderFrame(54, bmp)

            for (i in 0..3) {
                val st = renderer.lastOptionDrawStates[i]!!
                if (i == correctIdx) {
                    assertEquals(android.graphics.Color.parseColor("#16a34a"), st.fillColor)
                    assertEquals(android.graphics.Color.parseColor("#000000"), st.labelBgColor)
                    assertEquals(android.graphics.Color.parseColor("#facc15"), st.labelTextColor)
                    assertEquals(android.graphics.Color.parseColor("#ffffff"), st.optionTextColor)
                    assertEquals("✓", st.labelGlyph)
                    assertEquals(255, st.alpha)
                    assertNotEquals(st.fillColor, st.labelBgColor)
                } else {
                    assertEquals(android.graphics.Color.parseColor("#1e293b"), st.fillColor)
                    assertEquals(android.graphics.Color.parseColor("#334155"), st.labelBgColor)
                    assertEquals(android.graphics.Color.parseColor("#cbd5e1"), st.labelTextColor)
                    assertEquals(android.graphics.Color.parseColor("#94a3b8"), st.optionTextColor)
                    assertEquals(android.graphics.Color.parseColor("#475569"), st.borderColor)
                    assertEquals("ABCD"[i].toString(), st.labelGlyph)
                    assertTrue("Dimmed option alpha ~224", st.alpha in 218..230)
                }
            }
            renderer.release()
        }
    }

    @Test
    fun verifyIntelligentFrameSchedulerDeduplicatesStaticHoldsAndEmitsAnchors() {
        val bundle = JSONObject().apply {
            put("timerDuration", 4)
            put("revealConfig", JSONObject().apply {
                put("enabled", true)
                put("questionStyle", "typewriter-word")
                put("answerReveal", JSONObject().apply {
                    put("style", "pop-in")
                    put("durationSec", 0.35)
                })
            })
            put("transitionConfig", JSONObject().apply {
                put("style", "classic-page-turn")
            })
            put("scene", JSONObject().apply {
                put("mode", "DEFAULT_TEMPLATE_MODE")
                put("elements", JSONArray().apply {
                    put(JSONObject().apply {
                        put("id", "bg"); put("type", "background")
                        put("x", 0.0); put("y", 0.0); put("width", 1.0); put("height", 1.0)
                    })
                    put(JSONObject().apply {
                        put("id", "tm"); put("type", "timer")
                        put("x", 0.1); put("y", 0.8); put("width", 0.8); put("height", 0.05)
                    })
                })
            })
            put("questions", JSONArray().apply {
                put(JSONObject().apply {
                    put("question", "What is the boiling point of water?")
                    put("options", JSONArray(listOf("80C", "90C", "100C", "110C")))
                    put("correct", 2)
                })
            })
            put("timeline", JSONObject().apply {
                put("total", 8.0)
                put("segs", JSONArray().apply {
                    put(JSONObject().apply { put("type", "voice"); put("i", 0); put("start", 0.0); put("dur", 2.0) })
                    put(JSONObject().apply { put("type", "count"); put("i", 0); put("start", 2.0); put("dur", 2.0) })
                    put(JSONObject().apply { put("type", "reveal"); put("i", 0); put("start", 4.0); put("dur", 1.0) })
                    put(JSONObject().apply { put("type", "answer"); put("i", 0); put("start", 5.0); put("dur", 3.0) })
                })
            })
        }

        val fps = 24
        val totalFrames = 192
        val scheduler = com.quizstudiopro.app.video.IntelligentFrameScheduler(
            bundleJson = bundle.toString(),
            width = 1920,
            height = 1080,
            fps = fps,
            totalFrames = totalFrames,
            gopSeconds = 2
        )
        val summary = scheduler.buildSchedule()
        assertEquals(totalFrames, summary.totalTimelineFrames)
        assertTrue("Expected significant skipped duplicate frames", summary.skippedFrames > 40)
        assertTrue("Rendered frames must be fewer than total frames", summary.renderedFrames < totalFrames)
        assertEquals(0, summary.frames.first().frameIndex)
        assertTrue(summary.frames.first().isKeyFrame)

        val totalCoveredFrames = summary.frames.sumOf { it.durationFrames }
        assertEquals("VFR schedule durationFrames must cover full timeline", totalFrames, totalCoveredFrames)
        assertEquals(totalFrames, summary.frames.last().frameIndex + summary.frames.last().durationFrames)
    }

    @Test
    fun verifyHardwareCodecSelectorBitratesAndSoftwareDetection() {
        assertEquals(16_000_000, com.quizstudiopro.app.video.HardwareCodecSelector.computeTargetBitrate(2560, 1440))
        assertEquals(10_000_000, com.quizstudiopro.app.video.HardwareCodecSelector.computeTargetBitrate(1920, 1080))
        assertEquals(6_000_000, com.quizstudiopro.app.video.HardwareCodecSelector.computeTargetBitrate(1280, 720))
        assertEquals(3_500_000, com.quizstudiopro.app.video.HardwareCodecSelector.computeTargetBitrate(854, 480))
        assertEquals(16_000_000, StreamingVideoEncoderSession.computeBitRate(2560))

        assertTrue(com.quizstudiopro.app.video.HardwareCodecSelector.isKnownSoftwareCodecName("OMX.google.h264.encoder"))
        assertTrue(com.quizstudiopro.app.video.HardwareCodecSelector.isKnownSoftwareCodecName("c2.android.avc.encoder"))
        assertTrue(!com.quizstudiopro.app.video.HardwareCodecSelector.isKnownSoftwareCodecName("c2.qti.avc.encoder"))

        val report = com.quizstudiopro.app.video.HardwareCodecSelector.getCapabilityReportJson(1920, 1080, 24)
        assertEquals(1920, report.getInt("requestedWidth"))
        assertEquals(1080, report.getInt("requestedHeight"))
        assertTrue(report.has("candidates"))
    }

    @Test
    fun verifyAudioDecoderPrimitiveBufferAndOfflineAudioProcessor() {
        val pbuf = com.quizstudiopro.app.audio.AudioDecoder.PrimitiveShortBuffer(chunkSize = 4)
        for (i in 0 until 11) {
            pbuf.append((i * 100).toShort())
        }
        val sb = java.nio.ShortBuffer.wrap(shortArrayOf(1200, -1200, 32767))
        pbuf.appendFromShortBuffer(sb)
        val flat = pbuf.toShortArray()
        assertEquals(14, flat.size)
        assertEquals(0.toShort(), flat[0])
        assertEquals(1000.toShort(), flat[10])
        assertEquals(32767.toShort(), flat[13])

        val k1 = com.quizstudiopro.app.audio.AudioDecoder.computeCacheKey(byteArrayOf(1, 2, 3), 48000)
        val k2 = com.quizstudiopro.app.audio.AudioDecoder.computeCacheKey(byteArrayOf(1, 2, 3), 48000)
        val k3 = com.quizstudiopro.app.audio.AudioDecoder.computeCacheKey(byteArrayOf(1, 2, 4), 48000)
        assertEquals(k1, k2)
        assertNotEquals(k1, k3)

        val tmpFile = kotlin.io.path.createTempFile("offline_audio_test_", ".pcm").toFile()
        try {
            val floatInput = floatArrayOf(0f, 1f, -1f, 0.5f, -0.5f)
            val pcmBuf = ByteBuffer.allocateDirect(floatInput.size * 2)
            com.quizstudiopro.app.audio.OfflineAudioProcessor.convertFloatToPcm16Le(floatInput, pcmBuf)
            val bytes = ByteArray(pcmBuf.remaining())
            pcmBuf.get(bytes)
            tmpFile.writeBytes(bytes)

            val proc = com.quizstudiopro.app.audio.OfflineAudioProcessor(tmpFile, sampleRate = 48000, channels = 1)
            proc.open()
            val readTarget = ByteBuffer.allocateDirect(64)
            val readBytes = proc.readNextChunkDirect(readTarget)
            assertEquals(10, readBytes)
            assertEquals(5L, proc.getSamplesFed())
            assertTrue(proc.isAtEnd())
            assertTrue(proc.currentPtsUs() > 0L)
            proc.close()
        } finally {
            tmpFile.delete()
        }
    }

    @Test
    fun verifyNativeSceneRendererCustomTemplatePixelOutputForAllCustomVariants() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()

        // Variant 1: IMPORTED_TEMPLATE_MODE with opacity=0.0 overlay option_containers
        val overlayBundle = JSONObject().apply {
            put("timerDuration", 4)
            put("answerRevealConfig", JSONObject().apply {
                put("style", "highlight-dim-others")
                put("highlightBg", "#7c3aed")
                put("badgeBg", "#10b981")
                put("badgeTickColor", "#ffffff")
                put("correctTextColor", "#ffffff")
                put("dimBg", "#334155")
                put("dimOpacity", 0.85)
            })
            put("scene", JSONObject().apply {
                put("mode", "IMPORTED_TEMPLATE_MODE")
                put("elements", JSONArray().apply {
                    put(JSONObject().apply {
                        put("id", "bg"); put("type", "background")
                        put("x", 0.0); put("y", 0.0); put("width", 1.0); put("height", 1.0)
                        put("backgroundColor", "#0f172a"); put("layerOrder", 0)
                    })
                    // Extra decorative shape capped below option_container (layerOrder <= 8)
                    put(JSONObject().apply {
                        put("id", "cv_shape_5"); put("type", "decorative")
                        put("x", 0.50); put("y", 0.52); put("width", 0.44); put("height", 0.16)
                        put("backgroundColor", "#ec4899"); put("layerOrder", 8)
                    })
                    for (idx in 0..3) {
                        val bx = if (idx % 2 == 0) 0.06 else 0.52
                        val by = if (idx < 2) 0.54 else 0.72
                        put(JSONObject().apply {
                            put("id", "ov_c_$idx"); put("type", "option_container")
                            put("optionIndex", idx)
                            put("x", bx); put("y", by); put("width", 0.42); put("height", 0.12)
                            put("backgroundColor", "#1e293b"); put("opacity", 0.0)
                            put("borderRadius", 0.0); put("layerOrder", 10 + idx * 3)
                        })
                        put(JSONObject().apply {
                            put("id", "ov_l_$idx"); put("type", "option_label")
                            put("optionIndex", idx)
                            put("x", bx + 0.015); put("y", by + 0.015); put("width", 0.06); put("height", 0.09)
                            put("backgroundColor", "#facc15"); put("textColor", "#000000")
                            put("borderRadius", 0.0); put("layerOrder", 11 + idx * 3)
                        })
                        put(JSONObject().apply {
                            put("id", "ov_t_$idx"); put("type", "option_text")
                            put("optionIndex", idx)
                            put("x", bx + 0.09); put("y", by + 0.015); put("width", 0.30); put("height", 0.09)
                            put("text", "{option_$idx}"); put("textColor", "#ffffff")
                            put("layerOrder", 12 + idx * 3)
                        })
                    }
                })
            })
            put("questions", JSONArray().apply {
                put(JSONObject().apply {
                    put("question", "Pick Mars")
                    put("options", JSONArray(listOf("Venus", "Mars", "Jupiter", "Saturn")))
                    put("correct", 1)
                })
            })
            put("timeline", JSONObject().apply {
                put("total", 3.0)
                put("segs", JSONArray().apply {
                    put(JSONObject().apply { put("type", "voice"); put("i", 0); put("start", 0.0); put("dur", 1.0) })
                    put(JSONObject().apply { put("type", "count"); put("i", 0); put("start", 1.0); put("dur", 1.0) })
                    put(JSONObject().apply { put("type", "reveal"); put("i", 0); put("start", 2.0); put("dur", 1.0) })
                })
            })
        }

        val renderer1 = NativeSceneRenderer(ctx, overlayBundle.toString(), 640, 360, 24)
        val bmp1 = Bitmap.createBitmap(640, 360, Bitmap.Config.ARGB_8888)
        // Before reveal (countdown t=1.5s -> frame 36): opacity=0 container must NOT hide pink deco art
        renderer1.renderFrame(36, bmp1)
        val preSlotPx = bmp1.getPixel((640 * 0.90).toInt(), (360 * 0.60).toInt())
        assertEquals(android.graphics.Color.parseColor("#ec4899"), preSlotPx)

        // During reveal (t=2.5s -> frame 60): opacity=0 container elevates and fills with #7c3aed
        renderer1.renderFrame(60, bmp1)
        val revSlotPx = bmp1.getPixel((640 * 0.90).toInt(), (360 * 0.60).toInt())
        assertEquals(android.graphics.Color.parseColor("#7c3aed"), revSlotPx)
        val revBadgePx = bmp1.getPixel((640 * 0.545).toInt(), (360 * 0.60).toInt())
        assertEquals(android.graphics.Color.parseColor("#10b981"), revBadgePx)
        assertEquals("✓", renderer1.lastOptionDrawStates[1]?.labelGlyph)
        assertEquals(android.graphics.Color.parseColor("#7c3aed"), renderer1.lastOptionDrawStates[1]?.fillColor)
        renderer1.release()

        // Variant 2: assetRef image-backed option_container + missing optionIndex (-1) + container-less slot 2
        val assetBmp = Bitmap.createBitmap(32, 16, Bitmap.Config.ARGB_8888).apply {
            eraseColor(android.graphics.Color.parseColor("#9a3412"))
        }
        val baos = java.io.ByteArrayOutputStream()
        assetBmp.compress(Bitmap.CompressFormat.PNG, 100, baos)
        val assetDataUrl = "data:image/png;base64," + android.util.Base64.encodeToString(baos.toByteArray(), android.util.Base64.NO_WRAP)

        val assetBundle = JSONObject().apply {
            put("timerDuration", 4)
            put("assets", JSONObject().apply {
                put("opt_card", assetDataUrl)
            })
            put("answerRevealConfig", JSONObject().apply {
                put("style", "correct-only")
                put("highlightBg", "#dc2626")
                put("badgeBg", "#ffffff")
                put("badgeTickColor", "#dc2626")
            })
            put("scene", JSONObject().apply {
                put("mode", "IMPORTED_TEMPLATE_MODE")
                put("elements", JSONArray().apply {
                    put(JSONObject().apply {
                        put("id", "bg"); put("type", "background")
                        put("x", 0.0); put("y", 0.0); put("width", 1.0); put("height", 1.0)
                        put("backgroundColor", "#090d16"); put("layerOrder", 0)
                    })
                    put(JSONObject().apply {
                        put("id", "legacy_box"); put("type", "option_container")
                        put("optionIndex", -1); put("assetRef", "opt_card")
                        put("x", 0.08); put("y", 0.56); put("width", 0.84); put("height", 0.12)
                        put("backgroundColor", "#1f2937"); put("borderRadius", 0.0); put("layerOrder", 10)
                    })
                    put(JSONObject().apply {
                        put("id", "legacy_txt"); put("type", "option_text")
                        put("optionIndex", -1)
                        put("x", 0.16); put("y", 0.57); put("width", 0.74); put("height", 0.10)
                        put("text", "{option_1}"); put("textColor", "#ffffff"); put("layerOrder", 11)
                    })
                })
            })
            put("questions", JSONArray().apply {
                put(JSONObject().apply {
                    put("question", "Pick B")
                    put("options", JSONArray(listOf("A", "B", "C", "D")))
                    put("correct", 1)
                })
            })
            put("timeline", JSONObject().apply {
                put("total", 2.0)
                put("segs", JSONArray().apply {
                    put(JSONObject().apply { put("type", "count"); put("i", 0); put("start", 0.0); put("dur", 1.0) })
                    put(JSONObject().apply { put("type", "reveal"); put("i", 0); put("start", 1.0); put("dur", 1.0) })
                })
            })
        }

        val renderer2 = NativeSceneRenderer(ctx, assetBundle.toString(), 640, 360, 24)
        val bmp2 = Bitmap.createBitmap(640, 360, Bitmap.Config.ARGB_8888)
        renderer2.renderFrame(6, bmp2)
        val preAssetPx = bmp2.getPixel((640 * 0.88).toInt(), (360 * 0.62).toInt())
        assertEquals(android.graphics.Color.parseColor("#9a3412"), preAssetPx)

        renderer2.renderFrame(30, bmp2)
        val revAssetPx = bmp2.getPixel((640 * 0.88).toInt(), (360 * 0.62).toInt())
        assertEquals(android.graphics.Color.parseColor("#dc2626"), revAssetPx)
        assertEquals(android.graphics.Color.parseColor("#dc2626"), renderer2.lastOptionDrawStates[1]?.fillColor)
        renderer2.release()
    }
}

