package com.quizstudiopro.app

import android.content.ContentProvider
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.ProviderInfo
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.Build
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import androidx.test.core.app.ApplicationProvider
import com.quizstudiopro.app.storage.MediaStoreVideoStorage
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowContentResolver
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import java.util.concurrent.atomic.AtomicLong

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class MediaStoreExportFixRobolectricTest {

    private lateinit var context: Context
    private lateinit var tempRoot: File
    private lateinit var fakeProvider: FakeMediaStoreContentProvider

    data class StoredMediaRow(
        val id: Long,
        val uri: Uri,
        val displayName: String,
        val mimeType: String,
        val relativePath: String,
        var isPending: Int,
        val backingFile: File
    )

    class FakeMediaStoreContentProvider(private val storageDir: File) : ContentProvider() {
        private val idSeq = AtomicLong(100L)
        val rows = LinkedHashMap<Uri, StoredMediaRow>()
        val deletedUris = mutableListOf<Uri>()
        var failInsertNamesWithUniqueError = mutableSetOf<String>()
        var returnNullInsertNames = mutableSetOf<String>()
        var failOpenStreamNames = mutableSetOf<String>()
        var throwEnospcOnInsertNames = mutableSetOf<String>()
        var hideFromQueryNames = mutableSetOf<String>()
        var failUpdateUris = mutableSetOf<Uri>()
        var failAllUpdates = false

        override fun onCreate(): Boolean = true

        fun seedExistingVideo(
            displayName: String,
            relativePath: String = "Movies/QuizStudioPro/",
            contentBytes: ByteArray = "existing-mp4-data".toByteArray(),
            hideFromQuery: Boolean = false
        ): StoredMediaRow {
            val id = idSeq.incrementAndGet()
            val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val uri = ContentUris.withAppendedId(collection, id)
            val file = File(storageDir, "seed_${id}_$displayName").apply {
                parentFile?.mkdirs()
                writeBytes(contentBytes)
            }
            val row = StoredMediaRow(
                id = id,
                uri = uri,
                displayName = displayName,
                mimeType = "video/mp4",
                relativePath = relativePath,
                isPending = 0,
                backingFile = file
            )
            rows[uri] = row
            if (hideFromQuery) {
                hideFromQueryNames.add(displayName.lowercase())
            }
            return row
        }

        override fun query(
            uri: Uri,
            projection: Array<out String>?,
            selection: String?,
            selectionArgs: Array<out String>?,
            sortOrder: String?
        ): Cursor {
            val cols = arrayOf(
                MediaStore.MediaColumns._ID,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.RELATIVE_PATH,
                MediaStore.MediaColumns.IS_PENDING
            )
            val cursor = MatrixCursor(cols)
            for (row in rows.values) {
                if (hideFromQueryNames.contains(row.displayName.lowercase())) continue
                if (selectionArgs != null && selectionArgs.isNotEmpty()) {
                    val matchesRel = selectionArgs.any { arg ->
                        row.relativePath.trimEnd('/').equals(arg.trimEnd('/'), ignoreCase = true)
                    }
                    if (!matchesRel) continue
                }
                cursor.addRow(arrayOf<Any?>(row.id, row.displayName, row.relativePath, row.isPending))
            }
            return cursor
        }

        override fun insert(uri: Uri, values: ContentValues?): Uri? {
            val v = values ?: ContentValues()
            val displayName = v.getAsString(MediaStore.MediaColumns.DISPLAY_NAME) ?: "unnamed"
            val mimeType = v.getAsString(MediaStore.MediaColumns.MIME_TYPE) ?: "application/octet-stream"
            val relPath = (v.getAsString(MediaStore.MediaColumns.RELATIVE_PATH) ?: "Movies/QuizStudioPro").trimEnd('/') + "/"
            val pending = v.getAsInteger(MediaStore.MediaColumns.IS_PENDING) ?: 0

            if (throwEnospcOnInsertNames.contains(displayName)) {
                throw IOException("ENOSPC: No space left on device")
            }
            if (failInsertNamesWithUniqueError.contains(displayName)) {
                throw IllegalStateException(
                    "Failed to build unique file: /storage/emulated/0/$relPath$displayName " +
                        "bucket_display_name=QuizStudioPro volume_name=external_primary _size=null is_pending=0"
                )
            }
            if (returnNullInsertNames.contains(displayName)) {
                return null
            }

            val id = idSeq.incrementAndGet()
            val itemUri = ContentUris.withAppendedId(uri, id)
            val backing = File(storageDir, "inserted_${id}_$displayName").apply {
                parentFile?.mkdirs()
                createNewFile()
            }
            rows[itemUri] = StoredMediaRow(
                id = id,
                uri = itemUri,
                displayName = displayName,
                mimeType = mimeType,
                relativePath = relPath,
                isPending = pending,
                backingFile = backing
            )
            return itemUri
        }

        override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor? {
            val row = rows[uri] ?: throw FileNotFoundException("Missing URI $uri")
            if (failOpenStreamNames.contains(row.displayName)) {
                return null
            }
            val pfdMode = if (mode.contains("w")) {
                ParcelFileDescriptor.MODE_WRITE_ONLY or ParcelFileDescriptor.MODE_TRUNCATE or ParcelFileDescriptor.MODE_CREATE
            } else {
                ParcelFileDescriptor.MODE_READ_ONLY
            }
            return ParcelFileDescriptor.open(row.backingFile, pfdMode)
        }

        override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int {
            if (failAllUpdates || failUpdateUris.contains(uri)) {
                throw IllegalStateException("Failed to build unique file during MediaStore publish update for $uri")
            }
            val row = rows[uri] ?: return 0
            if (values != null && values.containsKey(MediaStore.MediaColumns.IS_PENDING)) {
                row.isPending = values.getAsInteger(MediaStore.MediaColumns.IS_PENDING) ?: 0
            }
            return 1
        }

        override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int {
            deletedUris.add(uri)
            val removed = rows.remove(uri) ?: return 0
            removed.backingFile.delete()
            return 1
        }

        override fun getType(uri: Uri): String = "video/mp4"
    }

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        tempRoot = kotlin.io.path.createTempDirectory("qsp_mediastore_test_").toFile()
        fakeProvider = FakeMediaStoreContentProvider(File(tempRoot, "media_root").apply { mkdirs() })
        val providerInfo = ProviderInfo().apply {
            authority = MediaStore.AUTHORITY
            exported = true
        }
        fakeProvider.attachInfo(context, providerInfo)
        ShadowContentResolver.registerProviderInternal(MediaStore.AUTHORITY, fakeProvider)
    }

    @After
    fun tearDown() {
        tempRoot.deleteRecursively()
    }

    private fun createSyntheticMp4File(name: String, sizeBytes: Int = 16 * 1024): File {
        val f = File(tempRoot, name)
        val payload = ByteArray(sizeBytes) { i -> ((i * 31 + 7) and 0xFF).toByte() }
        // Put an authentic MP4 ftyp header at offset 0 for container signature realism
        val ftyp = byteArrayOf(0x00, 0x00, 0x00, 0x18, 'f'.code.toByte(), 't'.code.toByte(), 'y'.code.toByte(), 'p'.code.toByte())
        System.arraycopy(ftyp, 0, payload, 0, ftyp.size)
        f.writeBytes(payload)
        return f
    }

    @Test
    fun verifyFilenameSanitizationPreservesExtensionOnLongTitlesAndUnsafeChars() {
        val longTitle = "A".repeat(120) + "_Quiz_Title.mp4"
        val sanitized = MediaStoreVideoStorage.sanitizeFileName(longTitle)
        assertTrue(sanitized.fullName.endsWith(".mp4"))
        assertTrue(sanitized.base.length <= 64)

        val unsafe = MediaStoreVideoStorage.sanitizeFileName("../bad:folder/General Knowledge Quiz?.mp4")
        assertEquals("General_Knowledge_Quiz.mp4", unsafe.fullName)

        val blank = MediaStoreVideoStorage.sanitizeFileName("   .mp4")
        assertEquals("quiz-video.mp4", blank.fullName)
    }

    @Test
    fun firstExportCreatesAndPublishesMp4Cleanly() {
        val src = createSyntheticMp4File("export_src_1.mp4", 32 * 1024)
        val res = MediaStoreVideoStorage.saveVideoFile(
            context = context,
            sourceFile = src,
            requestedFileName = "General_Knowledge_Quiz.mp4"
        )

        assertEquals("General_Knowledge_Quiz.mp4", res.fileName)
        assertEquals("Movies/QuizStudioPro", res.relativePath)
        assertEquals(src.length(), res.bytesWritten)

        val row = fakeProvider.rows[res.uri]
        assertNotNull(row)
        assertEquals("video/mp4", row!!.mimeType)
        assertEquals(0, row.isPending)
        assertArrayEquals(src.readBytes(), row.backingFile.readBytes())
        assertTrue(fakeProvider.deletedUris.isEmpty())
    }

    @Test
    fun repeatExportsGenerateSequentialSuffixesAndPreserveExistingVideos() {
        val existingBytes = "original-unrelated-video-bytes".toByteArray()
        val seeded = fakeProvider.seedExistingVideo("General_Knowledge_Quiz.mp4", contentBytes = existingBytes)

        val src1 = createSyntheticMp4File("export_1.mp4", 12_000)
        val res1 = MediaStoreVideoStorage.saveVideoFile(context, src1, "General_Knowledge_Quiz.mp4")
        assertEquals("General_Knowledge_Quiz_1.mp4", res1.fileName)

        val src2 = createSyntheticMp4File("export_2.mp4", 18_000)
        val res2 = MediaStoreVideoStorage.saveVideoFile(context, src2, "General_Knowledge_Quiz.mp4")
        assertEquals("General_Knowledge_Quiz_2.mp4", res2.fileName)

        // Existing unrelated video must never be overwritten or deleted
        assertTrue(fakeProvider.rows.containsKey(seeded.uri))
        assertArrayEquals(existingBytes, seeded.backingFile.readBytes())
        assertArrayEquals(src1.readBytes(), fakeProvider.rows[res1.uri]!!.backingFile.readBytes())
        assertArrayEquals(src2.readBytes(), fakeProvider.rows[res2.uri]!!.backingFile.readBytes())
    }

    @Test
    fun mediaProviderFailedToBuildUniqueFileCollisionRetriesAndSucceeds() {
        // Simulate an orphaned/stale row hidden from MediaStore query that causes MediaProvider to throw
        // exact "Failed to build unique file" IllegalStateException on General_Knowledge_Quiz.mp4
        val orphan = fakeProvider.seedExistingVideo(
            displayName = "General_Knowledge_Quiz.mp4",
            contentBytes = ByteArray(0),
            hideFromQuery = true
        )
        fakeProvider.failInsertNamesWithUniqueError.add("General_Knowledge_Quiz.mp4")

        val src = createSyntheticMp4File("export_retry.mp4", 24_000)
        val res = MediaStoreVideoStorage.saveVideoFile(context, src, "General_Knowledge_Quiz.mp4")

        assertEquals("General_Knowledge_Quiz_1.mp4", res.fileName)
        assertEquals(0, fakeProvider.rows[res.uri]!!.isPending)
        assertArrayEquals(src.readBytes(), fakeProvider.rows[res.uri]!!.backingFile.readBytes())
        // Pre-existing row was never deleted
        assertFalse(fakeProvider.deletedUris.contains(orphan.uri))
    }

    @Test
    fun openOutputStreamFailureCleansUpOnlyNewlyInsertedPendingUriAndRetriesNextSuffix() {
        val existing = fakeProvider.seedExistingVideo("Existing_Quiz.mp4")
        fakeProvider.failOpenStreamNames.add("General_Knowledge_Quiz.mp4")

        val src = createSyntheticMp4File("export_open_retry.mp4", 10_000)
        val res = MediaStoreVideoStorage.saveVideoFile(context, src, "General_Knowledge_Quiz.mp4")

        assertEquals("General_Knowledge_Quiz_1.mp4", res.fileName)
        assertEquals(1, fakeProvider.deletedUris.size)
        assertFalse(fakeProvider.deletedUris.contains(existing.uri))
        assertTrue(fakeProvider.rows.containsKey(existing.uri))
        assertEquals(0, fakeProvider.rows[res.uri]!!.isPending)
    }

    @Test
    fun publishCollisionFailedToBuildUniqueFileRecoversCleanlyWithSequentialSuffix() {
        val existing = fakeProvider.seedExistingVideo("Important_Old_Video.mp4")
        val targetCollection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        // Next inserted ID after seed(101) will be 102 -> simulate MediaProvider IS_PENDING=0 throwing Failed to build unique file
        fakeProvider.failUpdateUris.add(ContentUris.withAppendedId(targetCollection, 102L))

        val src = createSyntheticMp4File("export_recover_publish.mp4", 12_288)
        val res = MediaStoreVideoStorage.saveVideoFile(
            context = context,
            sourceFile = src,
            requestedFileName = "General_Knowledge_Quiz.mp4",
            jobId = "job_recover_1"
        )

        assertEquals("General_Knowledge_Quiz_1.mp4", res.fileName)
        assertEquals(2, res.attemptsUsed)
        assertEquals(0, fakeProvider.rows[res.uri]!!.isPending)
        assertArrayEquals(src.readBytes(), fakeProvider.rows[res.uri]!!.backingFile.readBytes())
        // Only the failed pending row (102) was rolled back; unrelated existing video remains untouched
        assertEquals(1, fakeProvider.deletedUris.size)
        assertTrue(fakeProvider.deletedUris.contains(ContentUris.withAppendedId(targetCollection, 102L)))
        assertFalse(fakeProvider.deletedUris.contains(existing.uri))
        assertTrue(fakeProvider.rows.containsKey(existing.uri))
    }

    @Test
    fun exhaustPublishFailuresRollBackEveryPendingEntryAndReportPublishStage() {
        val existing = fakeProvider.seedExistingVideo("Important_Old_Video.mp4")
        fakeProvider.failAllUpdates = true

        val src = createSyntheticMp4File("export_fail_all_publish.mp4", 8_192)
        try {
            MediaStoreVideoStorage.saveVideoFile(
                context = context,
                sourceFile = src,
                requestedFileName = "General_Knowledge_Quiz.mp4",
                jobId = "job_fail_pub"
            )
            fail("Expected MediaStoreSaveException")
        } catch (ex: MediaStoreVideoStorage.MediaStoreSaveException) {
            assertEquals(MediaStoreVideoStorage.ExportStage.PUBLISH_PENDING, ex.stage)
            assertEquals("job_fail_pub", ex.jobId)
            assertFalse(ex.userMessage.contains("bucket_display_name"))
            assertFalse(ex.userMessage.contains("_size=null"))
            assertTrue(ex.diagnosticDetails.contains("jobId=job_fail_pub"))
            assertTrue(ex.diagnosticDetails.contains("stage=PUBLISH_PENDING"))
            assertTrue(ex.diagnosticDetails.contains("androidSdk="))
            assertTrue(ex.diagnosticDetails.contains("collectionUri="))
            assertTrue(ex.diagnosticDetails.contains("relativePath=Movies/QuizStudioPro"))
        }

        // Every failed pending URI was deleted cleanly across retries; existing video remains untouched
        assertEquals(6, fakeProvider.deletedUris.size)
        assertFalse(fakeProvider.deletedUris.contains(existing.uri))
        assertTrue(fakeProvider.rows.containsKey(existing.uri))
    }

    @Test
    fun preflightSpaceCheckFailsFastWithoutInsertingMediaStoreRow() {
        val src = createSyntheticMp4File("export_low_space.mp4", 32_768)
        try {
            MediaStoreVideoStorage.saveVideoFile(
                context = context,
                sourceFile = src,
                requestedFileName = "General_Knowledge_Quiz.mp4",
                jobId = "job_low_space",
                availableSpaceBytesProvider = { 16_384L }
            )
            fail("Expected MediaStoreSaveException for insufficient storage")
        } catch (ex: MediaStoreVideoStorage.MediaStoreSaveException) {
            assertEquals(MediaStoreVideoStorage.ExportStage.SPACE_CHECK, ex.stage)
            assertTrue(ex.userMessage.contains("storage space", ignoreCase = true))
            assertTrue(ex.diagnosticDetails.contains("stage=SPACE_CHECK"))
        }
        assertTrue(fakeProvider.rows.isEmpty())
    }

    @Test
    fun storageFullEnospcFailsFastWithFriendlyError() {
        fakeProvider.throwEnospcOnInsertNames.add("General_Knowledge_Quiz.mp4")
        val src = createSyntheticMp4File("export_enospc.mp4", 4_096)
        try {
            MediaStoreVideoStorage.saveVideoFile(context, src, "General_Knowledge_Quiz.mp4")
            fail("Expected MediaStoreSaveException for ENOSPC")
        } catch (ex: MediaStoreVideoStorage.MediaStoreSaveException) {
            assertTrue(ex.userMessage.contains("storage space", ignoreCase = true))
            assertTrue(ex.diagnosticDetails.contains("ENOSPC"))
        }
    }

    @Test
    fun streamingWebCodecsPendingEntryAndPublishWorkEndToEndWithMultiResolutionPayloads() {
        val resolutions = listOf("480p", "720p", "1080p")
        resolutions.forEachIndexed { idx, resLabel ->
            val pending = MediaStoreVideoStorage.createPendingVideoEntry(
                context = context,
                requestedFileName = "General_Knowledge_Quiz.mp4"
            )
            val expectedName = if (idx == 0) "General_Knowledge_Quiz.mp4" else "General_Knowledge_Quiz_${idx}.mp4"
            assertEquals(expectedName, pending.fileName)
            assertEquals(1, fakeProvider.rows[pending.uri]!!.isPending)

            val payload = "MP4_${resLabel}_VIDEO_AND_AAC_AUDIO_STREAM".toByteArray()
            pending.outputStream.use { out ->
                out.write(payload)
                out.flush()
            }
            MediaStoreVideoStorage.publishPendingEntry(context.contentResolver, pending.uri)
            assertEquals(0, fakeProvider.rows[pending.uri]!!.isPending)
            assertArrayEquals(payload, fakeProvider.rows[pending.uri]!!.backingFile.readBytes())
        }
    }

    @Test
    fun recentVideosStoreRegistersVerifiedSavesPersistsAndPrunesMissingUris() {
        com.quizstudiopro.app.storage.RecentVideosStore.clear(context)

        // Failed / non-existent URI must NEVER be registered as success
        val bogusEntry = com.quizstudiopro.app.storage.RecentVideosStore.RecentVideoEntry(
            jobId = "job_bogus",
            uri = "content://media/external_primary/video/media/99999",
            fileName = "NonExistent.mp4",
            relativePath = "Movies/QuizStudioPro",
            sizeBytes = 4096L
        )
        assertFalse(com.quizstudiopro.app.storage.RecentVideosStore.recordVerifiedExport(context, bogusEntry))
        assertTrue(com.quizstudiopro.app.storage.RecentVideosStore.listVerified(context).isEmpty())

        // Zero-byte entry rejected
        val zeroEntry = bogusEntry.copy(sizeBytes = 0L)
        assertFalse(com.quizstudiopro.app.storage.RecentVideosStore.recordVerifiedExport(context, zeroEntry))

        // Valid published exports are persisted and verified
        val src1 = createSyntheticMp4File("recent_1.mp4", 20_480)
        val res1 = MediaStoreVideoStorage.saveVideoFile(context, src1, "Quiz_One.mp4", jobId = "job_1")
        val src2 = createSyntheticMp4File("recent_2.mp4", 28_672)
        val res2 = MediaStoreVideoStorage.saveVideoFile(context, src2, "Quiz_Two.mp4", jobId = "job_2")

        assertTrue(
            com.quizstudiopro.app.storage.RecentVideosStore.recordVerifiedExport(
                context,
                com.quizstudiopro.app.storage.RecentVideosStore.RecentVideoEntry(
                    jobId = res1.jobId,
                    uri = res1.uri.toString(),
                    fileName = res1.fileName,
                    relativePath = res1.relativePath,
                    sizeBytes = res1.bytesWritten,
                    width = 1280,
                    height = 720,
                    fps = 24,
                    durationMs = 5000L
                )
            )
        )
        assertTrue(
            com.quizstudiopro.app.storage.RecentVideosStore.recordVerifiedExport(
                context,
                com.quizstudiopro.app.storage.RecentVideosStore.RecentVideoEntry(
                    jobId = res2.jobId,
                    uri = res2.uri.toString(),
                    fileName = res2.fileName,
                    relativePath = res2.relativePath,
                    sizeBytes = res2.bytesWritten,
                    width = 1920,
                    height = 1080,
                    fps = 15,
                    durationMs = 8000L
                )
            )
        )

        val listed = com.quizstudiopro.app.storage.RecentVideosStore.listVerified(context)
        assertEquals(2, listed.size)
        assertEquals("Quiz_Two.mp4", listed[0].fileName)
        assertEquals("Quiz_One.mp4", listed[1].fileName)
        assertTrue(listed[0].previewUrl().contains("uri="))

        // Simulate user deleting Quiz_Two.mp4 externally from Gallery/Files -> next load prunes missing row & falls back cleanly
        context.contentResolver.delete(res2.uri, null, null)
        val afterRestartList = com.quizstudiopro.app.storage.RecentVideosStore.listVerified(context)
        assertEquals(1, afterRestartList.size)
        assertEquals("Quiz_One.mp4", afterRestartList[0].fileName)
        assertEquals(res1.uri, com.quizstudiopro.app.storage.RecentVideosStore.findAuthorizedUri(context, null, "Quiz_One.mp4"))
    }

    @Test
    fun documentExportsResolveCollisionsWithoutError() {
        val bytes1 = "{\"q\":1}".toByteArray()
        val bytes2 = "{\"q\":2}".toByteArray()
        val d1 = MediaStoreVideoStorage.saveDocumentBytes(context, "quiz-questions.json", "application/json", bytes1)
        val d2 = MediaStoreVideoStorage.saveDocumentBytes(context, "quiz-questions.json", "application/json", bytes2)

        assertEquals("quiz-questions.json", d1.fileName)
        assertEquals("quiz-questions_1.json", d2.fileName)
        assertEquals("Download/QuizStudioPro", d2.relativePath)
    }

    @Test
    fun manifestUsesScopedStorageWithoutBroadLegacyStoragePermissions() {
        val pkgInfo = context.packageManager.getPackageInfo(
            context.packageName,
            PackageManager.GET_PERMISSIONS
        )
        val perms = pkgInfo.requestedPermissions?.toList() ?: emptyList()
        assertFalse(perms.contains(android.Manifest.permission.READ_EXTERNAL_STORAGE))
        assertFalse(perms.contains(android.Manifest.permission.WRITE_EXTERNAL_STORAGE))
        assertTrue(MediaStoreVideoStorage.defaultVideoCollectionUris(Build.VERSION_CODES.UPSIDE_DOWN_CAKE).isNotEmpty())
    }
}
