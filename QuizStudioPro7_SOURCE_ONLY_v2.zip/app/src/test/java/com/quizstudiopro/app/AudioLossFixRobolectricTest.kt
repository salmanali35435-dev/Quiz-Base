package com.quizstudiopro.app

import com.quizstudiopro.app.audio.OfflineAudioProcessor
import com.quizstudiopro.app.audio.PcmTransferCoordinator
import com.quizstudiopro.app.video.VideoEncoder
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AudioLossFixRobolectricTest {

    private fun buildPcm1Packet(
        token: Int,
        seq: Int,
        payload: ByteArray,
        expectedTotalBytes: Long,
        expectedTotalSamples: Long
    ): ByteArray {
        val bb = ByteBuffer.allocate(PcmTransferCoordinator.HEADER_SIZE_PCM1 + payload.size)
            .order(ByteOrder.LITTLE_ENDIAN)
        bb.put('P'.code.toByte())
        bb.put('C'.code.toByte())
        bb.put('M'.code.toByte())
        bb.put('1'.code.toByte())
        bb.putInt(token)
        bb.putInt(seq)
        bb.putInt(payload.size)
        bb.putLong(expectedTotalBytes)
        bb.putLong(expectedTotalSamples)
        bb.put(payload)
        return bb.array()
    }

    private fun buildPcmdPacket(
        token: Int,
        expectedPackets: Int,
        expectedTotalBytes: Long,
        expectedTotalSamples: Long
    ): ByteArray {
        val bb = ByteBuffer.allocate(PcmTransferCoordinator.HEADER_SIZE_PCM1)
            .order(ByteOrder.LITTLE_ENDIAN)
        bb.put('P'.code.toByte())
        bb.put('C'.code.toByte())
        bb.put('M'.code.toByte())
        bb.put('D'.code.toByte())
        bb.putInt(token)
        bb.putInt(expectedPackets)
        bb.putInt(0)
        bb.putLong(expectedTotalBytes)
        bb.putLong(expectedTotalSamples)
        return bb.array()
    }

    @Test
    fun verifyPcm1FullTransfer3Questions82sAndByteExactness() {
        val coord = PcmTransferCoordinator()
        val tmpFile = kotlin.io.path.createTempFile("pcm_82s_", ".pcm").toFile()
        try {
            // 82s @ 48kHz mono PCM16 = 3,936,000 samples = 7,872,000 bytes (~120.1 packets @ 64KB)
            val totalSamples = 82L * 48_000L
            val expectedBytes = totalSamples * 2L
            val chunkBytes = 65_536
            val totalPackets = ((expectedBytes + chunkBytes - 1) / chunkBytes).toInt()

            coord.prepareSession("sess_82s", 101, tmpFile, totalSamples)
            val begin = coord.bindTransferMetadata("sess_82s", 101, totalSamples, totalPackets)
            assertTrue(begin.ok)

            // Cannot encode before completion handshake even halfway or after packets
            assertTrue(coord.verifyReadyForEncoding(totalSamples).isFailure)

            var offset = 0L
            for (seq in 0 until totalPackets) {
                val len = minOf(chunkBytes.toLong(), expectedBytes - offset).toInt()
                val payload = ByteArray(len) { idx -> ((seq + idx) and 0xFF).toByte() }
                val acks = coord.handlePcm1Packet(
                    buildPcm1Packet(101, seq, payload, expectedBytes, totalSamples)
                )
                assertEquals(1, acks.size)
                assertTrue(acks[0].ok)
                assertEquals(seq, acks[0].seq)
                offset += len
            }

            // Still blocked until PCMD flushes & verifies
            assertTrue(coord.verifyReadyForEncoding(totalSamples).isFailure)

            val done = coord.handlePcmdPacket(buildPcmdPacket(101, totalPackets, expectedBytes, totalSamples))
            assertTrue(done.ok)
            assertEquals(totalPackets, done.ackedPackets)
            assertEquals(0, done.missingPackets)
            assertEquals(expectedBytes, done.actualBytes)

            val ready = coord.verifyReadyForEncoding(totalSamples)
            assertTrue(ready.isSuccess)
            assertEquals(expectedBytes, tmpFile.length())
        } finally {
            coord.cancelAndReset(deleteFile = true)
            tmpFile.delete()
        }
    }

    @Test
    fun verifyOutOfOrderDuplicateAndMissingPacketHandling() {
        val coord = PcmTransferCoordinator()
        val tmpFile = kotlin.io.path.createTempFile("pcm_ooo_", ".pcm").toFile()
        try {
            val totalSamples = 12L
            val expectedBytes = 24L // 3 packets of 8 bytes each
            coord.prepareSession("sess_ooo", 202, tmpFile, totalSamples, 3)

            val p0 = byteArrayOf(0, 1, 2, 3, 4, 5, 6, 7)
            val p1 = byteArrayOf(8, 9, 10, 11, 12, 13, 14, 15)
            val p2 = byteArrayOf(16, 17, 18, 19, 20, 21, 22, 23)

            // Send seq 0
            val ack0 = coord.handlePcm1Packet(buildPcm1Packet(202, 0, p0, expectedBytes, totalSamples))
            assertEquals(1, ack0.size)
            assertTrue(ack0[0].ok)

            // Send seq 2 out-of-order -> buffered, returns 0 immediate ACKs
            val ack2 = coord.handlePcm1Packet(buildPcm1Packet(202, 2, p2, expectedBytes, totalSamples))
            assertEquals(0, ack2.size)

            // Duplicate seq 0 -> acked as duplicate, file length stays 8
            val dup0 = coord.handlePcm1Packet(buildPcm1Packet(202, 0, p0, expectedBytes, totalSamples))
            assertEquals(1, dup0.size)
            assertTrue(dup0[0].ok)
            assertTrue(dup0[0].duplicate)
            assertEquals(8L, dup0[0].cumulativeBytes)

            // Send seq 1 -> drains both seq 1 and buffered seq 2 cleanly in order!
            val ack1And2 = coord.handlePcm1Packet(buildPcm1Packet(202, 1, p1, expectedBytes, totalSamples))
            assertEquals(2, ack1And2.size)
            assertEquals(1, ack1And2[0].seq)
            assertEquals(2, ack1And2[1].seq)
            assertEquals(24L, ack1And2[1].cumulativeBytes)

            val done = coord.handlePcmdPacket(buildPcmdPacket(202, 3, expectedBytes, totalSamples))
            assertTrue(done.ok)
            assertEquals(1, done.duplicatePackets)
            assertArrayEquals(p0 + p1 + p2, tmpFile.readBytes())

            // Missing packet scenario
            val tmpMissing = kotlin.io.path.createTempFile("pcm_miss_", ".pcm").toFile()
            try {
                coord.prepareSession("sess_miss", 203, tmpMissing, totalSamples, 3)
                coord.handlePcm1Packet(buildPcm1Packet(203, 0, p0, expectedBytes, totalSamples))
                coord.handlePcm1Packet(buildPcm1Packet(203, 2, p2, expectedBytes, totalSamples))
                val failDone = coord.handlePcmdPacket(buildPcmdPacket(203, 3, expectedBytes, totalSamples))
                assertFalse(failDone.ok)
                assertTrue(failDone.missingPackets >= 1)
                assertTrue(coord.verifyReadyForEncoding(totalSamples).isFailure)
            } finally {
                tmpMissing.delete()
            }
        } finally {
            coord.cancelAndReset(deleteFile = true)
            tmpFile.delete()
        }
    }

    @Test
    fun verifySessionTokenIsolationAcrossConsecutiveExportsAndRetryAfterFailure() {
        val coord = PcmTransferCoordinator()
        val f1 = kotlin.io.path.createTempFile("pcm_s1_", ".pcm").toFile()
        val f2 = kotlin.io.path.createTempFile("pcm_s2_", ".pcm").toFile()
        try {
            // Session 1 starts and gets cancelled mid-transfer
            coord.prepareSession("s1", 10, f1, 8L, 2)
            val p0 = byteArrayOf(1, 2, 3, 4, 5, 6, 7, 8)
            assertTrue(coord.handlePcm1Packet(buildPcm1Packet(10, 0, p0, 16L, 8L))[0].ok)
            coord.cancelAndReset(deleteFile = true)

            // Session 2 starts with token 11
            val s2Bytes = byteArrayOf(9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24)
            coord.prepareSession("s2", 11, f2, 8L, 2)

            // Stale packet from session token 10 arrives! Must be rejected and MUST NOT pollute f2!
            val staleAck = coord.handlePcm1Packet(buildPcm1Packet(10, 1, p0, 16L, 8L))
            assertEquals(1, staleAck.size)
            assertFalse(staleAck[0].ok)
            assertEquals(0L, coord.getTelemetrySnapshot().cumulativeWrittenBytes)

            // Valid packets for token 11 succeed
            assertTrue(coord.handlePcm1Packet(buildPcm1Packet(11, 0, s2Bytes.copyOfRange(0, 8), 16L, 8L))[0].ok)
            assertTrue(coord.handlePcm1Packet(buildPcm1Packet(11, 1, s2Bytes.copyOfRange(8, 16), 16L, 8L))[0].ok)
            val done2 = coord.handlePcmdPacket(buildPcmdPacket(11, 2, 16L, 8L))
            assertTrue(done2.ok)
            assertArrayEquals(s2Bytes, f2.readBytes())
        } finally {
            coord.cancelAndReset(deleteFile = true)
            f1.delete()
            f2.delete()
        }
    }

    @Test
    fun verifyZeroAudioDisabledExportAndTenRepeatedSessions() {
        val coord = PcmTransferCoordinator()
        val f0 = kotlin.io.path.createTempFile("pcm_zero_", ".pcm").toFile()
        try {
            // Audio disabled (0 samples)
            coord.prepareSession("zero_audio", 500, f0, 0L, 0)
            val doneZero = coord.handlePcmdPacket(buildPcmdPacket(500, 0, 0L, 0L))
            assertTrue(doneZero.ok)
            assertTrue(coord.verifyReadyForEncoding(0L).isSuccess)
        } finally {
            coord.cancelAndReset(deleteFile = true)
            f0.delete()
        }

        // 10 consecutive repeated export cycles must leave 0 stale state or leaks
        for (run in 1..10) {
            val f = kotlin.io.path.createTempFile("pcm_repeat_${run}_", ".pcm").toFile()
            try {
                val samples = 1600L
                val bytes = samples * 2L
                val payload = ByteArray(bytes.toInt()) { ((run + it) and 0x7F).toByte() }
                coord.prepareSession("repeat_$run", 600 + run, f, samples, 1)
                val acks = coord.handlePcm1Packet(buildPcm1Packet(600 + run, 0, payload, bytes, samples))
                assertTrue(acks.single().ok)
                val done = coord.handlePcmdPacket(buildPcmdPacket(600 + run, 1, bytes, samples))
                assertTrue("Run $run must verify clean", done.ok)
                assertTrue(coord.verifyReadyForEncoding(samples).isSuccess)
                assertArrayEquals(payload, f.readBytes())
            } finally {
                coord.cancelAndReset(deleteFile = true)
                f.delete()
            }
        }
    }

    @Test
    fun verifyOfflineAudioProcessorFailClosedOnCorruptedOrPartialFiles() {
        val missing = File("/tmp/definitely_missing_qsp_${System.nanoTime()}.pcm")
        var missingThrew = false
        try {
            OfflineAudioProcessor(missing, 48000, 1, 100L).open()
        } catch (_: IllegalStateException) {
            missingThrew = true
        }
        assertTrue("Missing PCM must fail closed", missingThrew)

        val empty = kotlin.io.path.createTempFile("pcm_empty_", ".pcm").toFile()
        val truncated = kotlin.io.path.createTempFile("pcm_trunc_", ".pcm").toFile()
        val unaligned = kotlin.io.path.createTempFile("pcm_odd_", ".pcm").toFile()
        try {
            empty.writeBytes(ByteArray(0))
            var emptyThrew = false
            try { OfflineAudioProcessor(empty, 48000, 1, 100L).open() } catch (_: IllegalStateException) { emptyThrew = true }
            assertTrue("Empty PCM must fail closed when audio expected", emptyThrew)

            truncated.writeBytes(ByteArray(100))
            var truncThrew = false
            try { OfflineAudioProcessor(truncated, 48000, 1, 200L).open() } catch (_: IllegalStateException) { truncThrew = true }
            assertTrue("Truncated PCM must fail closed on size mismatch", truncThrew)

            unaligned.writeBytes(ByteArray(9))
            var oddThrew = false
            try { OfflineAudioProcessor(unaligned, 48000, 1, null).open() } catch (_: IllegalStateException) { oddThrew = true }
            assertTrue("Unaligned odd byte count must fail closed", oddThrew)
        } finally {
            empty.delete()
            truncated.delete()
            unaligned.delete()
        }
    }

    @Test
    fun verifyEvaluateAudioDurationIntegrityDetectsSilentAndTruncatedExports() {
        // Complete silence: expectedAudio=true, audioTrackPresent=false
        val silentErr = VideoEncoder.evaluateAudioDurationIntegrity(
            expectedAudio = true,
            expectedAudioDurationMs = 82_000L,
            audioTrackPresent = false,
            audioSampleCount = 0,
            actualAudioDurationMs = 0L
        )
        assertNotNull(silentErr)

        // Zero AAC frames
        val zeroFramesErr = VideoEncoder.evaluateAudioDurationIntegrity(
            expectedAudio = true,
            expectedAudioDurationMs = 82_000L,
            audioTrackPresent = true,
            audioSampleCount = 0,
            actualAudioDurationMs = 0L
        )
        assertNotNull(zeroFramesErr)

        // Q1-only cutoff (12s out of 82s)
        val cutoffErr = VideoEncoder.evaluateAudioDurationIntegrity(
            expectedAudio = true,
            expectedAudioDurationMs = 82_000L,
            audioTrackPresent = true,
            audioSampleCount = 560,
            actualAudioDurationMs = 12_000L
        )
        assertNotNull(cutoffErr)
        assertTrue(cutoffErr!!.contains("mismatch", ignoreCase = true))

        // Valid full 82s export (exact or within tolerance)
        assertNull(
            VideoEncoder.evaluateAudioDurationIntegrity(
                expectedAudio = true,
                expectedAudioDurationMs = 82_000L,
                audioTrackPresent = true,
                audioSampleCount = 3844,
                actualAudioDurationMs = 81_920L
            )
        )

        // Audio disabled -> valid even without audio track
        assertNull(
            VideoEncoder.evaluateAudioDurationIntegrity(
                expectedAudio = false,
                expectedAudioDurationMs = 0L,
                audioTrackPresent = false,
                audioSampleCount = 0,
                actualAudioDurationMs = 0L
            )
        )
    }
}
