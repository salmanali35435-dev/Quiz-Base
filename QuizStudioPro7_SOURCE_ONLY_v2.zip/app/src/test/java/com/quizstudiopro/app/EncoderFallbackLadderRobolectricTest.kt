package com.quizstudiopro.app

import android.media.MediaCodecInfo
import android.media.MediaFormat
import com.quizstudiopro.app.video.HardwareCodecSelector
import com.quizstudiopro.app.video.StreamingVideoEncoderSession
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class EncoderFallbackLadderRobolectricTest {

    @Test
    fun buildEncoderAttemptLadderPreservesExactResolutionAndFpsAcrossTiers() {
        val widthsHeightsFps = listOf(
            Triple(1920, 1080, 24),
            Triple(1080, 1920, 30),
            Triple(1280, 720, 24)
        )

        for ((w, h, fps) in widthsHeightsFps) {
            val ladder = HardwareCodecSelector.buildEncoderAttemptLadder(w, h, fps, MediaFormat.MIMETYPE_VIDEO_AVC)
            assertTrue("Fallback ladder must not be empty for ${w}x$h@${fps}fps", ladder.isNotEmpty())

            // Tier 3 (SW_SURFACE) and Tier 4 (SW_BYTEBUFFER_YUV420) must always be present
            assertTrue(
                "Ladder must include SW_SURFACE tier",
                ladder.any { it.tier == HardwareCodecSelector.CodecTier.SW_SURFACE && it.inputMode == HardwareCodecSelector.InputMode.SURFACE }
            )
            assertTrue(
                "Ladder must include SW_BYTEBUFFER_YUV420 CPU fallback tier",
                ladder.any {
                    it.tier == HardwareCodecSelector.CodecTier.SW_BYTEBUFFER_YUV420 &&
                        it.inputMode == HardwareCodecSelector.InputMode.BYTE_BUFFER_YUV420
                }
            )

            // Verify ordering: HW tiers precede SW_SURFACE, which precedes SW_BYTEBUFFER_YUV420
            val lastHwIdx = ladder.indexOfLast {
                it.tier == HardwareCodecSelector.CodecTier.HW_SURFACE_PRIMARY ||
                    it.tier == HardwareCodecSelector.CodecTier.HW_SURFACE_ALT_PROFILE
            }
            val firstSwSurfaceIdx = ladder.indexOfFirst { it.tier == HardwareCodecSelector.CodecTier.SW_SURFACE }
            val firstCpuIdx = ladder.indexOfFirst { it.tier == HardwareCodecSelector.CodecTier.SW_BYTEBUFFER_YUV420 }
            if (lastHwIdx >= 0 && firstSwSurfaceIdx >= 0) {
                assertTrue("HW tiers must run before SW Surface", lastHwIdx < firstSwSurfaceIdx)
            }
            assertTrue("SW Surface must run before SW ByteBuffer CPU", firstSwSurfaceIdx < firstCpuIdx)

            // Verify EVERY MediaFormat preserves exact requested width, height, and fps (never downscales 1080p -> 720p)
            for (spec in ladder) {
                val fmt = HardwareCodecSelector.configureVideoFormat(spec, w, h, fps, gopSeconds = 2)
                assertEquals("Exact requested width must be preserved", w, fmt.getInteger(MediaFormat.KEY_WIDTH))
                assertEquals("Exact requested height must be preserved", h, fmt.getInteger(MediaFormat.KEY_HEIGHT))
                assertEquals("Exact requested fps must be preserved", fps, fmt.getInteger(MediaFormat.KEY_FRAME_RATE))
                val cf = fmt.getInteger(MediaFormat.KEY_COLOR_FORMAT)
                if (spec.inputMode == HardwareCodecSelector.InputMode.SURFACE) {
                    assertEquals(MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface, cf)
                } else {
                    assertTrue(
                        "CPU ByteBuffer tier must select valid YUV420 color format",
                        cf == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible ||
                            cf == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar ||
                            cf == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar
                    )
                    assertFalse("CPU ByteBuffer tier must omit KEY_PROFILE to avoid vendor rejection", fmt.containsKey(MediaFormat.KEY_PROFILE))
                }
            }
        }
    }

    @Test
    fun capabilityReportIncludesAttemptLadderCountAndSessionStatsTracksAttemptedPaths() {
        val report = HardwareCodecSelector.getCapabilityReportJson(1920, 1080, 24)
        assertEquals(1920, report.getInt("requestedWidth"))
        assertEquals(1080, report.getInt("requestedHeight"))
        assertEquals(24, report.getInt("requestedFps"))
        assertTrue(report.getInt("attemptLadderCount") >= 2)

        val stats = StreamingVideoEncoderSession.SessionStats(
            mode = "NATIVE_SCENE_DIRECT",
            codecName = "c2.android.avc.encoder",
            isHardwareCodec = false,
            width = 1920,
            height = 1080,
            fps = 24,
            framesProcessed = 120,
            expectedFrames = 120,
            droppedFrames = 0,
            encodeDurationMs = 500L,
            finalizationMs = 50L,
            outputBytes = 102400L,
            usedJpegFallback = false,
            attemptedPaths = listOf("HW_SURFACE_PRIMARY", "SW_SURFACE"),
            selectedTier = "SW_SURFACE"
        )
        assertEquals(listOf("HW_SURFACE_PRIMARY", "SW_SURFACE"), stats.attemptedPaths)
        assertEquals("SW_SURFACE", stats.selectedTier)
    }
}
