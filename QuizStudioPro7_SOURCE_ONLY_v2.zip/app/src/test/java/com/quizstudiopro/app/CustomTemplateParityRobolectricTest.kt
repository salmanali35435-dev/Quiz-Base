package com.quizstudiopro.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import androidx.test.core.app.ApplicationProvider
import com.quizstudiopro.app.video.NativeSceneRenderer
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import kotlin.math.abs

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class CustomTemplateParityRobolectricTest {

    private fun colorDistance(c1: Int, c2: Int): Int {
        return abs(Color.red(c1) - Color.red(c2)) +
            abs(Color.green(c1) - Color.green(c2)) +
            abs(Color.blue(c1) - Color.blue(c2))
    }

    private fun countNonMatchingPixels(
        bmp: Bitmap,
        x0: Int,
        y0: Int,
        x1: Int,
        y1: Int,
        expectedBg: Int,
        tolerance: Int = 24
    ): Int {
        var count = 0
        val sx0 = x0.coerceIn(0, bmp.width - 1)
        val sy0 = y0.coerceIn(0, bmp.height - 1)
        val sx1 = x1.coerceIn(sx0, bmp.width)
        val sy1 = y1.coerceIn(sy0, bmp.height)
        for (y in sy0 until sy1) {
            for (x in sx0 until sx1) {
                if (colorDistance(bmp.getPixel(x, y), expectedBg) > tolerance) {
                    count++
                }
            }
        }
        return count
    }

    private fun buildScreenshotParityBundle(
        timerLook: String = "stopwatch",
        includeSceneThemeEmpty: Boolean = true
    ): JSONObject {
        val headerBg = "#c81010"
        val bodyBg = "#0b2e9b"
        val qBoxBg = "#ffffff"
        val optBoxBg = "#ffffff"
        val sceneTheme = JSONObject().apply {
            if (!includeSceneThemeEmpty) {
                put("timerLook", timerLook)
            }
        }
        val elements = JSONArray().apply {
            put(JSONObject().apply {
                put("id", "bg"); put("type", "background")
                put("x", 0.0); put("y", 0.0); put("width", 1.0); put("height", 1.0)
                put("backgroundColor", bodyBg); put("borderRadius", 0.0); put("layerOrder", 0)
            })
            put(JSONObject().apply {
                put("id", "hdr_bg"); put("type", "header")
                put("x", 0.0); put("y", 0.0); put("width", 1.0); put("height", 0.165)
                put("backgroundColor", headerBg); put("borderRadius", 0.0); put("layerOrder", 1)
            })
            // Oversized header text fontSize (0.28) simulating imported custom template scale
            put(JSONObject().apply {
                put("id", "hdr_txt"); put("type", "text")
                put("x", 0.18); put("y", 0.02); put("width", 0.60); put("height", 0.125)
                put("text", "GK QUIZ"); put("fontSize", 0.28); put("fontWeight", 800)
                put("textColor", "#ffffff"); put("alignment", "center"); put("layerOrder", 2)
            })
            // Oversized question_number {num2} inside compact left badge box
            put(JSONObject().apply {
                put("id", "q_num"); put("type", "question_number")
                put("x", 0.025); put("y", 0.03); put("width", 0.07); put("height", 0.105)
                put("text", "{num2}"); put("fontSize", 0.22); put("fontWeight", 800)
                put("backgroundColor", "#fde047"); put("borderColor", "#ffffff"); put("borderWidth", 2.0)
                put("borderRadius", 0.5); put("textColor", "#000000"); put("alignment", "center")
                put("layerOrder", 3)
            })
            // Top-right stopwatch timer (intentionally without element-level timerLook when testing empty scene.theme merge)
            put(JSONObject().apply {
                put("id", "top_timer"); put("type", "timer")
                put("x", 0.82); put("y", 0.085); put("width", 0.10); put("height", 0.046)
                if (!includeSceneThemeEmpty) {
                    put("timerLook", timerLook)
                }
                put("textColor", "#ef4444"); put("backgroundColor", "#111827"); put("borderColor", "#f8fafc")
                put("layerOrder", 4)
            })
            put(JSONObject().apply {
                put("id", "q_box"); put("type", "question_container")
                put("x", 0.04); put("y", 0.19); put("width", 0.92); put("height", 0.22)
                put("backgroundColor", qBoxBg); put("borderColor", "#facc15"); put("borderWidth", 3.0)
                put("borderRadius", 0.14); put("layerOrder", 5)
            })
            put(JSONObject().apply {
                put("id", "q_txt"); put("type", "question_text")
                put("x", 0.07); put("y", 0.21); put("width", 0.86); put("height", 0.18)
                put("text", "{question}"); put("fontSize", 0.14); put("fontWeight", 800)
                put("textColor", "#000000"); put("alignment", "center"); put("layerOrder", 6)
            })
            val optTexts = listOf("ÁGUILA REAL", "ALBATROS", "FRAGATA GRANDE", "PINGÜINO")
            for (idx in 0..3) {
                val col = idx % 2
                val row = idx / 2
                val bx = 0.05 + col * 0.46
                val by = 0.48 + row * 0.20
                put(JSONObject().apply {
                    put("id", "opt_${idx}_c"); put("type", "option_container"); put("optionIndex", idx)
                    put("x", bx); put("y", by); put("width", 0.44); put("height", 0.13)
                    put("backgroundColor", optBoxBg); put("borderRadius", 0.45); put("layerOrder", 10 + idx * 3)
                })
                put(JSONObject().apply {
                    put("id", "opt_${idx}_l"); put("type", "option_label"); put("optionIndex", idx)
                    put("x", bx + 0.015); put("y", by + 0.02); put("width", 0.06); put("height", 0.09)
                    put("text", "ABCD"[idx].toString()); put("fontSize", 0.12); put("fontWeight", 800)
                    put("backgroundColor", "#facc15"); put("textColor", "#000000")
                    put("borderRadius", 0.5); put("layerOrder", 11 + idx * 3)
                })
                // Oversized fontSize 0.14 inside 0.10-height box (previously wrapped REAL & GRANDE outside pills)
                put(JSONObject().apply {
                    put("id", "opt_${idx}_t"); put("type", "option_text"); put("optionIndex", idx)
                    put("x", bx + 0.09); put("y", by + 0.015); put("width", 0.33); put("height", 0.10)
                    put("text", optTexts[idx]); put("fontSize", 0.14); put("fontWeight", 800)
                    put("textColor", "#000000"); put("alignment", "center"); put("layerOrder", 12 + idx * 3)
                })
            }
        }

        return JSONObject().apply {
            put("timerDuration", 10)
            put("questionNumberConfig", JSONObject().apply {
                put("preset", "1_slash_20"); put("prefix", ""); put("leadingZero", false); put("separator", "/"); put("showTotal", true)
            })
            put("theme", JSONObject().apply {
                put("timerLook", timerLook)
                put("timerA", "#ef4444")
                put("timerB", "#dc2626")
                put("timerTrack", "#111827")
                put("timerBorder", "#f8fafc")
            })
            put("scene", JSONObject().apply {
                put("mode", "IMPORTED_TEMPLATE_MODE")
                put("theme", sceneTheme)
                put("elements", elements)
            })
            put("questions", JSONArray().apply {
                put(JSONObject().apply {
                    put("question", "Pick one")
                    put("options", JSONArray(listOf("One", "Two", "Three", "Four")))
                    put("correct", 1)
                })
                put(JSONObject().apply {
                    put("question", "¿QUÉ AVE PUEDE DORMIR MIENTRAS VUELA?")
                    put("options", JSONArray(listOf("ÁGUILA REAL", "ALBATROS", "FRAGATA GRANDE", "PINGÜINO")))
                    put("correct", 1)
                })
            })
            put("timeline", JSONObject().apply {
                put("total", 6.0)
                put("segs", JSONArray().apply {
                    put(JSONObject().apply { put("type", "voice"); put("i", 1); put("start", 0.0); put("dur", 2.0) })
                    put(JSONObject().apply { put("type", "count"); put("i", 1); put("start", 2.0); put("dur", 3.0) })
                    put(JSONObject().apply { put("type", "reveal"); put("i", 1); put("start", 5.0); put("dur", 1.0) })
                })
            })
        }
    }

    @Test
    fun customTemplateTextNeverLeaksAndStopwatchRendersAcross480p720p1080p() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val resolutions = listOf(854 to 480, 1280 to 720, 1920 to 1080)

        for ((w, h) in resolutions) {
            val bundle = buildScreenshotParityBundle(timerLook = "stopwatch", includeSceneThemeEmpty = true)
            val renderer = NativeSceneRenderer(ctx, bundle.toString(), w, h, 24)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)

            // Frame during countdown: t = 2.2s -> frame 53 -> rem = 2.8s out of 3.0s seg (still countdown)
            renderer.renderFrame(53, bmp)

            // 1. Question number token "{num2}" must resolve to "02" (question index 1), NOT "2/2" or "0\n2"
            assertEquals("Expected {num2} to render 02 at ${w}x$h", "02", renderer.lastRenderedQuestionNumber)

            val blueBg = Color.parseColor("#0b2e9b")

            // 2. Gap strictly between header bottom (0.165*h) and question box top (0.19*h) must be pure blue background (zero GK QUIZ or "02" bleed!)
            val gapHdrToQLeak = countNonMatchingPixels(
                bmp,
                (w * 0.01).toInt(), (h * 0.168).toInt(),
                (w * 0.99).toInt(), (h * 0.184).toInt(),
                blueBg
            )
            assertEquals("Header/QNum leaked into gap below header at ${w}x$h", 0, gapHdrToQLeak)

            // 3. Gap strictly between question box bottom (0.41*h) and top option row (0.48*h) must be pure blue background
            val gapQToOptLeak = countNonMatchingPixels(
                bmp,
                (w * 0.02).toInt(), (h * 0.425).toInt(),
                (w * 0.98).toInt(), (h * 0.472).toInt(),
                blueBg
            )
            assertEquals("Header/Question leaked between question box and options at ${w}x$h", 0, gapQToOptLeak)

            // 4. Gap between row 1 option pills (bottom = 0.61*h) and row 2 option pills (top = 0.68*h) must be pure blue background (zero "REAL" overflow!)
            val gapRow1ToRow2Leak = countNonMatchingPixels(
                bmp,
                (w * 0.02).toInt(), (h * 0.620).toInt(),
                (w * 0.98).toInt(), (h * 0.672).toInt(),
                blueBg
            )
            assertEquals("Row 1 option text (ÁGUILA REAL) overflowed pill bottom at ${w}x$h", 0, gapRow1ToRow2Leak)

            // 5. Area below row 2 option pills (bottom = 0.81*h) must be pure blue background (zero "GRANDE" overflow!)
            val belowRow2Leak = countNonMatchingPixels(
                bmp,
                (w * 0.02).toInt(), (h * 0.822).toInt(),
                (w * 0.98).toInt(), (h * 0.980).toInt(),
                blueBg
            )
            assertEquals("Row 2 option text (FRAGATA GRANDE) overflowed pill bottom at ${w}x$h", 0, belowRow2Leak)

            // 6. Verify actual text pixels ARE drawn inside header & option boxes (not silently invisible!)
            val headerRed = Color.parseColor("#c81010")
            val headerInkPixels = countNonMatchingPixels(
                bmp,
                (w * 0.25).toInt(), (h * 0.03).toInt(),
                (w * 0.72).toInt(), (h * 0.14).toInt(),
                headerRed
            )
            assertTrue("GK QUIZ header text must visibly render inside header at ${w}x$h", headerInkPixels > (w * 0.02).toInt())

            val whiteBox = Color.parseColor("#ffffff")
            val row1OptInk = countNonMatchingPixels(
                bmp,
                (w * 0.14).toInt(), (h * 0.495).toInt(),
                (w * 0.46).toInt(), (h * 0.595).toInt(),
                whiteBox
            )
            assertTrue("Option A text must visibly render inside pill at ${w}x$h", row1OptInk > 20)

            // 7. Verify stopwatch timer renders dark dial + white ticks/digit + metallic rim inside its overlay bounds (NOT flat orange circle)
            val bounds = renderer.computeTimerOverlayBoundsPx()
            assertTrue("Timer overlay bounds must be non-empty", bounds.width() > 20 && bounds.height() > 20)
            var darkDialCount = 0
            var brightTextOrRimCount = 0
            for (y in bounds.top until bounds.bottom) {
                for (x in bounds.left until bounds.right) {
                    val px = bmp.getPixel(x, y)
                    val luma = (Color.red(px) * 299 + Color.green(px) * 587 + Color.blue(px) * 114) / 1000
                    if (colorDistance(px, headerRed) > 40) {
                        if (luma < 65) darkDialCount++
                        else if (luma > 200) brightTextOrRimCount++
                    }
                }
            }
            assertTrue("Stopwatch must have dark dial face pixels at ${w}x$h (found $darkDialCount)", darkDialCount > 30)
            assertTrue("Stopwatch must have bright ticks/rim/digit pixels at ${w}x$h (found $brightTextOrRimCount)", brightTextOrRimCount > 20)

            renderer.release()
        }
    }

    @Test
    fun allTenTimerLooksRenderDistinctlyInOverlayAndHideCleanlyWhenHideTimerTrue() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val looks = listOf("capsule", "segments", "ring", "neon", "pie", "clock", "stopwatch", "orb", "flatbar", "bold")
        val w = 854
        val h = 480

        for (look in looks) {
            val bundle = buildScreenshotParityBundle(timerLook = look, includeSceneThemeEmpty = false)
            val renderer = NativeSceneRenderer(ctx, bundle.toString(), w, h, 24)
            assertTrue("Visible timer expected for $look", renderer.hasVisibleTimer())
            assertFalse("No layer overlaps timer for $look", renderer.hasVisibleLayerOverTimer())

            val bounds: Rect = renderer.computeTimerOverlayBoundsPx()
            assertTrue("Bounds for $look must be positive", bounds.width() > 10 && bounds.height() > 10)

            // Base frame with hideTimer = true must show only solid #c81010 header behind top-right corner
            val baseBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            renderer.renderSettledQuestionForCache(1, reveal = false, targetBitmap = baseBmp, hideTimer = true)
            val staleTimerPixels = countNonMatchingPixels(
                baseBmp,
                (w * 0.75).toInt(), (h * 0.01).toInt(),
                (w * 0.99).toInt(), (h * 0.16).toInt(),
                Color.parseColor("#c81010")
            )
            assertEquals("hideTimer=true left timer pixels behind for $look", 0, staleTimerPixels)

            // Overlay render must draw non-transparent pixels inside overlay sub-bitmap
            val overlayBmp = Bitmap.createBitmap(bounds.width(), bounds.height(), Bitmap.Config.ARGB_8888)
            renderer.renderTimerOverlay(overlayBmp, bounds, 7.5)
            var opaqueCount = 0
            for (y in 0 until overlayBmp.height) {
                for (x in 0 until overlayBmp.width) {
                    if (Color.alpha(overlayBmp.getPixel(x, y)) > 128) opaqueCount++
                }
            }
            assertTrue("Timer overlay for $look must draw visible pixels (got $opaqueCount)", opaqueCount > 50)

            overlayBmp.recycle()
            baseBmp.recycle()
            renderer.release()
        }
    }

    @Test
    fun defaultTemplateAnswerRevealPreservedWithoutRegression() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val bundle = JSONObject().apply {
            put("timerDuration", 10)
            put("theme", JSONObject().apply {
                put("bg", "#e6e6e6")
                put("headerBg", "#1e1b08")
                put("timerLook", "capsule")
                put("correctFill", "#16a34a")
            })
            put("answerRevealConfig", JSONObject().apply {
                put("style", "correct-only")
                put("highlightBg", "#16a34a")
                put("badgeBg", "#22c55e")
                put("badgeTickColor", "#ffffff")
                put("correctTextColor", "#ffffff")
            })
            put("scene", JSONObject().apply {
                put("mode", "DEFAULT_TEMPLATE_MODE")
                put("elements", JSONArray().apply {
                    put(JSONObject().apply {
                        put("id", "bg"); put("type", "background")
                        put("x", 0.0); put("y", 0.0); put("width", 1.0); put("height", 1.0)
                        put("backgroundColor", "#e6e6e6"); put("layerOrder", 0)
                    })
                    put(JSONObject().apply {
                        put("id", "opt0_c"); put("type", "option_container"); put("optionIndex", 0)
                        put("x", 0.05); put("y", 0.62); put("width", 0.43); put("height", 0.12)
                        put("backgroundColor", "#050505"); put("borderRadius", 0.5); put("layerOrder", 5)
                    })
                    put(JSONObject().apply {
                        put("id", "opt0_l"); put("type", "option_label"); put("optionIndex", 0)
                        put("x", 0.065); put("y", 0.635); put("width", 0.06); put("height", 0.09)
                        put("backgroundColor", "#ffff00"); put("textColor", "#000000"); put("borderRadius", 0.5); put("layerOrder", 6)
                    })
                    put(JSONObject().apply {
                        put("id", "opt0_t"); put("type", "option_text"); put("optionIndex", 0)
                        put("x", 0.14); put("y", 0.635); put("width", 0.32); put("height", 0.09)
                        put("text", "{option_0}"); put("textColor", "#ffffff"); put("layerOrder", 7)
                    })
                })
            })
            put("questions", JSONArray().apply {
                put(JSONObject().apply {
                    put("question", "Capital of France?")
                    put("options", JSONArray(listOf("Paris", "Lyon", "Nice", "Marseille")))
                    put("correct", 0)
                })
            })
            put("timeline", JSONObject().apply {
                put("total", 2.0)
                put("segs", JSONArray().apply {
                    put(JSONObject().apply { put("type", "reveal"); put("i", 0); put("start", 0.0); put("dur", 2.0) })
                })
            })
        }

        val renderer = NativeSceneRenderer(ctx, bundle.toString(), 640, 360, 24)
        val bmp = Bitmap.createBitmap(640, 360, Bitmap.Config.ARGB_8888)
        renderer.renderFrame(10, bmp)

        val state0 = renderer.lastOptionDrawStates[0]!!
        assertEquals("✓", state0.labelGlyph)
        assertEquals(Color.parseColor("#16a34a"), state0.fillColor)
        assertEquals(Color.parseColor("#22c55e"), state0.labelBgColor)
        assertEquals(Color.parseColor("#16a34a"), bmp.getPixel((640 * 0.44).toInt(), (360 * 0.68).toInt()))
        bmp.recycle()
        renderer.release()
    }

    @Test
    fun customTemplateIconCircleHeaderStripeAndComposerBitmapParity() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val bundle = buildScreenshotParityBundle(timerLook = "stopwatch", includeSceneThemeEmpty = false)
        val scene = bundle.getJSONObject("scene")
        val elements = scene.getJSONArray("elements")

        // Upgrade header to stripe design and add circle badge + icon element matching scene-renderer.js
        for (i in 0 until elements.length()) {
            val el = elements.getJSONObject(i)
            if (el.optString("id") == "hdr_bg") {
                el.put("headerDesign", "stripe")
                el.put("borderColor", "#fde047")
            }
            if (el.optString("id") == "q_num") {
                el.put("shapeKind", "circle")
            }
        }
        elements.put(JSONObject().apply {
            put("id", "trophy_icon"); put("type", "icon")
            put("x", 0.10); put("y", 0.03); put("width", 0.06); put("height", 0.10)
            put("iconGlyph", "★"); put("textColor", "#fde047")
            put("backgroundColor", "#111827"); put("shapeKind", "circle")
            put("borderColor", "#ffffff"); put("borderWidth", 2.0)
            put("layerOrder", 4)
        })

        for ((w, h) in listOf(854 to 480, 1280 to 720, 1920 to 1080)) {
            val composer = com.quizstudiopro.app.video.DirectEglSceneComposer(ctx, bundle.toString(), w, h, 24)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            composer.renderBitmapFrame(0, bmp)
            composer.recordRepeatedBitmapFrame()
            assertEquals(1, composer.metrics.bitmapUploadedFrames)
            assertEquals(1, composer.metrics.repeatedSwapFrames)

            // Icon element should have bright gold glyph ink inside its dark circular badge
            val iconInk = countNonMatchingPixels(
                bmp,
                (w * 0.11).toInt(), (h * 0.04).toInt(),
                (w * 0.15).toInt(), (h * 0.12).toInt(),
                Color.parseColor("#111827")
            )
            assertTrue("Expected icon glyph to render visibly at ${w}x$h", iconInk > 12)

            // Stripe header bottom accent line draws from rect.bottom (0.165*h) to rect.bottom + max(3, 0.008*h)
            val stripeY = (h * 0.167).toInt().coerceIn(0, h - 1)
            val stripePx = bmp.getPixel((w * 0.5).toInt(), stripeY)
            assertTrue(
                "Expected stripe accent color #fde047 below header at ${w}x$h",
                colorDistance(stripePx, Color.parseColor("#fde047")) < 25
            )

            bmp.recycle()
            composer.release()
        }
    }
}
