/* Quiz Studio Pro Direct Native Edge TTS + Zero-JPEG MediaCodec Export Bridge */
(function () {
  'use strict';
  window.__MOBILE_APP = true;
  window.__qspBinaryPort = null;

  // Reliable PCM transfer ACK tracker state (per-session isolated)
  const pcmAckState = {
    activeToken: 0,
    inFlight: new Map(),      // seq -> { resolve, reject, timer, bytes, sentAt }
    completeWaiter: null,     // { resolve, reject, timer }
    maxInFlight: 4,
    windowWaiters: []
  };

  function wakeWindowWaiters() {
    while (pcmAckState.windowWaiters.length && pcmAckState.inFlight.size < pcmAckState.maxInFlight) {
      const w = pcmAckState.windowWaiters.shift();
      try { w(); } catch (_) {}
    }
  }

  function rejectAllPendingPcm(errMsg) {
    const err = new Error(errMsg || 'PCM transfer aborted');
    for (const [, entry] of pcmAckState.inFlight.entries()) {
      clearTimeout(entry.timer);
      try { entry.reject(err); } catch (_) {}
    }
    pcmAckState.inFlight.clear();
    if (pcmAckState.completeWaiter) {
      clearTimeout(pcmAckState.completeWaiter.timer);
      try { pcmAckState.completeWaiter.reject(err); } catch (_) {}
      pcmAckState.completeWaiter = null;
    }
    while (pcmAckState.windowWaiters.length) {
      const w = pcmAckState.windowWaiters.shift();
      try { w(); } catch (_) {}
    }
  }

  function handlePortJsonMessage(rawText) {
    if (typeof rawText !== 'string' || !rawText || rawText[0] !== '{') return;
    let msg;
    try { msg = JSON.parse(rawText); } catch (_) { return; }
    if (!msg || typeof msg !== 'object') return;

    if (msg.type === 'PCM_ACK') {
      if (pcmAckState.activeToken && msg.sessionToken !== pcmAckState.activeToken) {
        return; // Ignore stale ACK from previous cancelled/finished session
      }
      const entry = pcmAckState.inFlight.get(msg.seq);
      if (entry) {
        clearTimeout(entry.timer);
        pcmAckState.inFlight.delete(msg.seq);
        wakeWindowWaiters();
        if (msg.ok) entry.resolve(msg);
        else entry.reject(new Error(msg.error || `PCM packet ${msg.seq} ACK failed`));
      } else if (!msg.ok) {
        rejectAllPendingPcm(msg.error || 'PCM transfer rejected by Android');
      }
    } else if (msg.type === 'PCM_COMPLETE_ACK') {
      if (pcmAckState.activeToken && msg.sessionToken !== pcmAckState.activeToken) {
        return;
      }
      const waiter = pcmAckState.completeWaiter;
      if (waiter) {
        clearTimeout(waiter.timer);
        pcmAckState.completeWaiter = null;
        if (msg.ok) waiter.resolve(msg);
        else waiter.reject(new Error(msg.error || 'PCM transfer verification failed'));
      }
    }
  }

  function attachBinaryPortHandlers(port) {
    if (!port) return;
    try {
      port.onmessage = function (msgEv) {
        if (msgEv && typeof msgEv.data === 'string') {
          handlePortJsonMessage(msgEv.data);
        }
      };
      if (port.start) port.start();
    } catch (_) {}
  }

  window.addEventListener('message', function (ev) {
    if (ev && ev.data === '__QSP_BINARY_PORT__' && ev.ports && ev.ports[0]) {
      window.__qspBinaryPort = ev.ports[0];
      attachBinaryPortHandlers(window.__qspBinaryPort);
      if (window.onQuizLog) window.onQuizLog('Binary ArrayBuffer transport channel ready.', 'info');
    }
  });

  function writeUint64LE(view, byteOffset, value) {
    const v = Math.max(0, Number(value) || 0);
    const lo = v >>> 0;
    const hi = Math.floor(v / 0x100000000) >>> 0;
    view.setUint32(byteOffset, lo, true);
    view.setUint32(byteOffset + 4, hi, true);
  }

  /**
   * Sends an 8-byte-header binary packet over WebMessagePortCompat ("RGBA" or legacy "PCM0").
   */
  function sendBinaryPacket(magic4, frameIndex, uint8Payload) {
    const port = window.__qspBinaryPort;
    if (!port) return false;
    const buf = new ArrayBuffer(8 + uint8Payload.byteLength);
    const view = new DataView(buf);
    view.setUint8(0, magic4.charCodeAt(0));
    view.setUint8(1, magic4.charCodeAt(1));
    view.setUint8(2, magic4.charCodeAt(2));
    view.setUint8(3, magic4.charCodeAt(3));
    view.setInt32(4, frameIndex | 0, true);
    new Uint8Array(buf, 8).set(uint8Payload);
    port.postMessage(buf, [buf]);
    return true;
  }

  function buildPcm1Packet(sessionToken, seq, uint8Payload, expectedTotalBytes, expectedTotalSamples) {
    const buf = new ArrayBuffer(32 + uint8Payload.byteLength);
    const view = new DataView(buf);
    view.setUint8(0, 80); // 'P'
    view.setUint8(1, 67); // 'C'
    view.setUint8(2, 77); // 'M'
    view.setUint8(3, 49); // '1'
    view.setInt32(4, sessionToken | 0, true);
    view.setInt32(8, seq | 0, true);
    view.setInt32(12, uint8Payload.byteLength | 0, true);
    writeUint64LE(view, 16, expectedTotalBytes);
    writeUint64LE(view, 24, expectedTotalSamples);
    new Uint8Array(buf, 32).set(uint8Payload);
    return buf;
  }

  function buildPcmdPacket(sessionToken, expectedPackets, expectedTotalBytes, expectedTotalSamples) {
    const buf = new ArrayBuffer(32);
    const view = new DataView(buf);
    view.setUint8(0, 80); // 'P'
    view.setUint8(1, 67); // 'C'
    view.setUint8(2, 77); // 'M'
    view.setUint8(3, 68); // 'D'
    view.setInt32(4, sessionToken | 0, true);
    view.setInt32(8, expectedPackets | 0, true);
    view.setInt32(12, 0, true);
    writeUint64LE(view, 16, expectedTotalBytes);
    writeUint64LE(view, 24, expectedTotalSamples);
    return buf;
  }

  function uint8ToBase64(u8) {
    let binary = '';
    const step = 8192;
    for (let i = 0; i < u8.length; i += step) {
      const sub = u8.subarray(i, Math.min(i + step, u8.length));
      binary += String.fromCharCode.apply(null, sub);
    }
    return btoa(binary);
  }

  window.__hasBinaryChannel = function () {
    return !!window.__qspBinaryPort;
  };

  window.__sendBinaryPcm = function (pcm16Int16Array) {
    if (!window.__qspBinaryPort || !pcm16Int16Array) return false;
    const chunkSamples = 32768; // 64KB PCM packets
    const bytes = new Uint8Array(pcm16Int16Array.buffer, pcm16Int16Array.byteOffset, pcm16Int16Array.byteLength);
    for (let off = 0; off < bytes.length; off += chunkSamples * 2) {
      const slice = bytes.subarray(off, Math.min(off + chunkSamples * 2, bytes.length));
      sendBinaryPacket('PCM0', 0, slice);
    }
    return true;
  };

  /**
   * Reliable, bounded-window, acknowledged PCM16 delivery handshake over WebMessagePort ("PCM1"/"PCMD")
   * with tracked AndroidBridge fallback ("writePcmChunkTracked").
   */
  window.__sendPcmReliable = async function (channelFloatOrPcmBytes, options) {
    const opts = options || {};
    const bridge = opts.bridge || (typeof window !== 'undefined' ? window.AndroidBridge : null);
    if (!bridge) throw new Error('AndroidBridge unavailable for PCM transfer');

    const sessMeta = opts.sessionId && opts.sessionToken
      ? opts
      : JSON.parse((bridge.getActivePcmSessionJson && bridge.getActivePcmSessionJson()) || '{}');
    const sessionId = String(sessMeta.sessionId || '');
    const sessionToken = sessMeta.sessionToken | 0;
    if (!sessionId || !sessionToken) {
      throw new Error('No active PCM export session initialized');
    }

    const isFloat = channelFloatOrPcmBytes instanceof Float32Array;
    const expectedSamples = isFloat
      ? channelFloatOrPcmBytes.length
      : (opts.expectedSamples !== undefined ? Number(opts.expectedSamples) : Math.floor(channelFloatOrPcmBytes.byteLength / 2));
    const expectedTotalBytes = expectedSamples * 2;
    const chunkSamples = Math.max(512, Math.min(65536, ((opts.chunkSamples || 32768) | 0))); // 64KB default
    const chunkBytes = chunkSamples * 2;
    const totalPackets = expectedTotalBytes === 0 ? 0 : Math.ceil(expectedTotalBytes / chunkBytes);
    const maxInFlight = Math.max(1, Math.min(8, (opts.maxInFlight || 4) | 0));
    const ackTimeoutMs = Math.max(2000, Number(opts.ackTimeoutMs) || 15000);
    const shouldCancel = typeof opts.shouldCancel === 'function' ? opts.shouldCancel : null;
    const onProgress = typeof opts.onProgress === 'function' ? opts.onProgress : null;
    const useBinaryPort = !opts.forceBridgeFallback && !!(window.__qspBinaryPort && typeof window.__qspBinaryPort.postMessage === 'function');

    rejectAllPendingPcm('Superseded by new PCM transfer session');
    pcmAckState.activeToken = sessionToken;
    pcmAckState.maxInFlight = maxInFlight;

    const beginResRaw = bridge.beginPcmTransfer(sessionId, sessionToken, expectedSamples, totalPackets);
    const beginRes = JSON.parse(beginResRaw || '{}');
    if (!beginRes.ok) {
      throw new Error(beginRes.error || 'Failed to begin PCM transfer handshake');
    }

    const t0 = performance.now();
    const packetPromises = [];
    let packetsSent = 0;
    let ackedPackets = 0;
    let duplicateAcks = 0;
    let lastAckedBytes = 0;
    let transferFailed = null;

    const int16Scratch = isFloat ? new Int16Array(Math.min(chunkSamples, Math.max(1, expectedSamples))) : null;
    const rawBytes = !isFloat
      ? new Uint8Array(channelFloatOrPcmBytes.buffer, channelFloatOrPcmBytes.byteOffset, channelFloatOrPcmBytes.byteLength)
      : null;

    function encodeSliceForPacket(seq) {
      const sampleOffset = seq * chunkSamples;
      const sampleCount = Math.min(chunkSamples, expectedSamples - sampleOffset);
      if (isFloat) {
        for (let i = 0; i < sampleCount; i++) {
          let s = channelFloatOrPcmBytes[sampleOffset + i];
          if (s > 1) s = 1;
          else if (s < -1) s = -1;
          int16Scratch[i] = s < 0 ? (s * 0x8000) : (s * 0x7FFF);
        }
        const sub = sampleCount === int16Scratch.length ? int16Scratch : int16Scratch.subarray(0, sampleCount);
        return new Uint8Array(sub.buffer, sub.byteOffset, sub.byteLength);
      }
      const byteOff = seq * chunkBytes;
      return rawBytes.subarray(byteOff, Math.min(byteOff + chunkBytes, expectedTotalBytes));
    }

    try {
      for (let seq = 0; seq < totalPackets; seq++) {
        if (transferFailed) throw transferFailed;
        if (shouldCancel && shouldCancel()) {
          try { bridge.cancelNativeExport && bridge.cancelNativeExport(); } catch (_) {}
          throw new Error('Export cancelled');
        }

        while (pcmAckState.inFlight.size >= maxInFlight && !transferFailed) {
          if (shouldCancel && shouldCancel()) {
            try { bridge.cancelNativeExport && bridge.cancelNativeExport(); } catch (_) {}
            throw new Error('Export cancelled');
          }
          await new Promise(resolve => pcmAckState.windowWaiters.push(resolve));
        }
        if (transferFailed) throw transferFailed;

        const slice = encodeSliceForPacket(seq);
        packetsSent++;

        if (useBinaryPort) {
          const port = window.__qspBinaryPort;
          const pktBuf = buildPcm1Packet(sessionToken, seq, slice, expectedTotalBytes, expectedSamples);
          const p = new Promise((resolve, reject) => {
            const timer = setTimeout(() => {
              pcmAckState.inFlight.delete(seq);
              wakeWindowWaiters();
              reject(new Error(`PCM packet ${seq}/${totalPackets} ACK timed out after ${ackTimeoutMs}ms`));
            }, ackTimeoutMs);
            pcmAckState.inFlight.set(seq, { resolve, reject, timer, bytes: slice.byteLength, sentAt: performance.now() });
          }).then(ack => {
            ackedPackets++;
            if (ack.duplicate) duplicateAcks++;
            if (typeof ack.cumulativeBytes === 'number') lastAckedBytes = Math.max(lastAckedBytes, ack.cumulativeBytes);
            if (onProgress && (ackedPackets % 8 === 0 || ackedPackets === totalPackets)) {
              onProgress({ packetsSent, ackedPackets, totalPackets, cumulativeBytes: lastAckedBytes, expectedTotalBytes });
            }
            return ack;
          }, err => {
            if (!transferFailed) transferFailed = err;
            wakeWindowWaiters();
            throw err;
          });
          packetPromises.push(p);
          port.postMessage(pktBuf, [pktBuf]);
        } else {
          const b64 = uint8ToBase64(slice);
          const ackRaw = bridge.writePcmChunkTracked(
            sessionId,
            sessionToken,
            seq,
            slice.byteLength,
            expectedTotalBytes,
            expectedSamples,
            b64
          );
          const ack = JSON.parse(ackRaw || '{}');
          if (!ack.ok) {
            throw new Error(ack.error || `Tracked PCM chunk ${seq} failed`);
          }
          ackedPackets++;
          if (ack.duplicate) duplicateAcks++;
          lastAckedBytes = ack.cumulativeBytes || (lastAckedBytes + slice.byteLength);
          if (onProgress && (ackedPackets % 8 === 0 || ackedPackets === totalPackets)) {
            onProgress({ packetsSent, ackedPackets, totalPackets, cumulativeBytes: lastAckedBytes, expectedTotalBytes });
          }
        }
      }

      if (packetPromises.length > 0) {
        await Promise.all(packetPromises);
      }

      if (shouldCancel && shouldCancel()) {
        try { bridge.cancelNativeExport && bridge.cancelNativeExport(); } catch (_) {}
        throw new Error('Export cancelled');
      }

      let completeRes;
      if (useBinaryPort && window.__qspBinaryPort) {
        const donePkt = buildPcmdPacket(sessionToken, totalPackets, expectedTotalBytes, expectedSamples);
        const completePromise = new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            pcmAckState.completeWaiter = null;
            reject(new Error(`PCM completion handshake timed out after ${ackTimeoutMs}ms`));
          }, ackTimeoutMs);
          pcmAckState.completeWaiter = { resolve, reject, timer };
        });
        window.__qspBinaryPort.postMessage(donePkt, [donePkt]);
        completeRes = await completePromise;
      } else {
        const finRaw = bridge.finishPcmTransfer(sessionId, sessionToken, totalPackets, expectedTotalBytes, expectedSamples);
        completeRes = JSON.parse(finRaw || '{}');
      }

      if (!completeRes || !completeRes.ok || completeRes.actualBytes !== expectedTotalBytes) {
        throw new Error(
          (completeRes && completeRes.error) ||
          `PCM file size mismatch: expected=${expectedTotalBytes}, actual=${completeRes ? completeRes.actualBytes : 0}`
        );
      }

      const elapsedMs = Math.round(performance.now() - t0);
      return {
        ok: true,
        transport: useBinaryPort ? 'webmessage_pcm1_ack' : 'android_bridge_tracked',
        sessionId,
        sessionToken,
        packetsSent,
        ackedPackets: completeRes.ackedPackets || ackedPackets,
        missingPackets: completeRes.missingPackets || 0,
        duplicatePackets: completeRes.duplicatePackets || duplicateAcks,
        expectedBytes: expectedTotalBytes,
        actualBytes: completeRes.actualBytes,
        expectedSamples,
        transferDurationMs: completeRes.transferDurationMs || elapsedMs
      };
    } catch (err) {
      for (let i = 0; i < packetPromises.length; i++) {
        try { packetPromises[i].catch(() => {}); } catch (_) {}
      }
      rejectAllPendingPcm(err && err.message ? err.message : String(err));
      throw err;
    } finally {
      if (pcmAckState.activeToken === sessionToken) {
        pcmAckState.activeToken = 0;
      }
    }
  };

  window.__qspHandlePortJsonForTest = handlePortJsonMessage;

  window.__sendBinaryRgbaFrame = function (frameIndex, rgbaUint8ClampedArray) {
    if (!window.__qspBinaryPort || !rgbaUint8ClampedArray) return false;
    const u8 = new Uint8Array(
      rgbaUint8ClampedArray.buffer,
      rgbaUint8ClampedArray.byteOffset,
      rgbaUint8ClampedArray.byteLength
    );
    return sendBinaryPacket('RGBA', frameIndex, u8);
  };

  window.__downloadDocument = function (filename, mimeType, content, isBase64) {
    if (window.AndroidBridge && window.AndroidBridge.saveDocumentFile) {
      try {
        const raw = AndroidBridge.saveDocumentFile(filename, mimeType, content, !!isBase64);
        const res = JSON.parse(raw || '{}');
        if (res.ok) {
          if (AndroidBridge.toast) AndroidBridge.toast('Saved: ' + res.path);
          if (window.onQuizLog) window.onQuizLog('Saved file to ' + res.path, 'success');
          return { ok: true, path: res.path };
        }
        return { ok: false, error: res.error || 'Failed to save file' };
      } catch (e) {
        return { ok: false, error: e.message || String(e) };
      }
    }
    try {
      const blob = isBase64
        ? new Blob([Uint8Array.from(atob(content), c => c.charCodeAt(0))], { type: mimeType })
        : new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 30000);
      return { ok: true, path: filename };
    } catch (e) {
      return { ok: false, error: e.message || String(e) };
    }
  };

  window.__saveBlobToPhone = async function (blob, name) {
    if (!window.AndroidBridge || !AndroidBridge.saveBegin || !blob) return false;
    try {
      if (AndroidBridge.notifyExportStarted) AndroidBridge.notifyExportStarted('Saving video to device…');
      if (!AndroidBridge.saveBegin(name)) {
        const nativeErr = AndroidBridge.getLastSaveError ? AndroidBridge.getLastSaveError() : '';
        throw new Error(nativeErr || 'Could not create Gallery video entry');
      }
      const buffer = await blob.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      const chunkSize = 65536;
      for (let offset = 0; offset < bytes.length; offset += chunkSize) {
        const slice = bytes.subarray(offset, Math.min(offset + chunkSize, bytes.length));
        let binary = '';
        for (let i = 0; i < slice.length; i++) binary += String.fromCharCode(slice[i]);
        if (!AndroidBridge.saveChunk(btoa(binary))) throw new Error('Writing video chunk failed');
      }
      if (!AndroidBridge.saveEnd()) {
        const nativeErr = AndroidBridge.getLastSaveError ? AndroidBridge.getLastSaveError() : '';
        throw new Error(nativeErr || 'Finalizing the video failed');
      }
      return true;
    } catch (e) {
      try { AndroidBridge.saveFailed(String(e.message || e)); } catch (_) {}
      return true;
    }
  };

  window.onFileSaved = function (message, previewUrl) {
    const el = document.getElementById('exportStatus');
    const lastErr = (window.AndroidBridge && AndroidBridge.getLastSaveError) ? AndroidBridge.getLastSaveError() : '';
    if (el) {
      el.textContent = message
        ? ('✓ ' + message)
        : ('❌ Saving failed' + (lastErr ? ': ' + lastErr : ' — could not save MP4 to device.'));
    }
    const details = document.getElementById('videoPreviewDetails');
    if (details && message) details.textContent = message;
    if (message && previewUrl) {
      const panel = document.getElementById('videoPreviewPanel');
      const player = document.getElementById('exportedVideoPlayer');
      if (player) {
        player.src = previewUrl;
        player.load();
      }
      if (panel) panel.style.display = 'block';
    }
    if (message && window.refreshRecentVideos) {
      try { window.refreshRecentVideos(); } catch (_) {}
    }
    if (window.onQuizLog) window.onQuizLog(message || (lastErr ? ('Video save failed: ' + lastErr) : 'Video save failed'), message ? 'success' : 'error');
  };

  window.onExportProgress = function (percent, status) {
    const el = document.getElementById('exportStatus');
    if (el) el.textContent = `[Native Encoder ${percent}%] ${status}`;
    const fill = document.getElementById('exportProgressFill');
    const pctEl = document.getElementById('exportPercent');
    const opEl = document.getElementById('exportOpStatus');
    if (fill) fill.style.width = `${percent}%`;
    if (pctEl) pctEl.textContent = `${percent}%`;
    if (opEl) opEl.textContent = status || 'Encoding…';
  };
})();
