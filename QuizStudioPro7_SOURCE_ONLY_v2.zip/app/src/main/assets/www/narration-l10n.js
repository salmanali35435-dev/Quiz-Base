/* Quiz Studio Pro 7 — Localized Question Number & Answer Narration Engine */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.QuizNarrationL10n = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const NARRATION_FORMAT_VERSION = 'v2-l10n';

  function resolveLocaleFromVoice(voiceId, voicesInventory) {
    const vid = String(voiceId || '').trim();
    if (Array.isArray(voicesInventory) && vid) {
      const hit = voicesInventory.find(v => v && v.shortName === vid);
      if (hit && hit.locale) return String(hit.locale).trim();
    }
    const m = /^([a-z]{2,3})[-_]([A-Za-z0-9]{2,4})/.exec(vid);
    if (m) return `${m[1].toLowerCase()}-${m[2].toUpperCase()}`;
    const mLang = /^([a-z]{2,3})\b/i.exec(vid);
    if (mLang) return mLang[1].toLowerCase();
    return 'en-US';
  }

  function baseLang(locale) {
    return String(locale || 'en-US').toLowerCase().split(/[-_]/)[0] || 'en';
  }

  // ---- Cardinal Number-to-Words Converters ----
  function numEn(n) {
    const ones = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine',
      'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
    const tens = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
    if (n < 20) return ones[n];
    if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 ? '-' + ones[n % 10] : '');
    if (n < 1000) {
      const rem = n % 100;
      return ones[Math.floor(n / 100)] + ' hundred' + (rem ? ' ' + numEn(rem) : '');
    }
    if (n < 10000) {
      const rem = n % 1000;
      return numEn(Math.floor(n / 1000)) + ' thousand' + (rem ? ' ' + numEn(rem) : '');
    }
    return String(n);
  }

  function numIt(n) {
    const ones = ['zero', 'uno', 'due', 'tre', 'quattro', 'cinque', 'sei', 'sette', 'otto', 'nove',
      'dieci', 'undici', 'dodici', 'tredici', 'quattordici', 'quindici', 'sedici', 'diciassette', 'diciotto', 'diciannove'];
    const tens = ['', '', 'venti', 'trenta', 'quaranta', 'cinquanta', 'sessanta', 'settanta', 'ottanta', 'novanta'];
    if (n < 20) return ones[n];
    if (n < 100) {
      const t = Math.floor(n / 10), u = n % 10;
      let prefix = tens[t];
      if (u === 1 || u === 8) prefix = prefix.slice(0, -1);
      const unitStr = u === 0 ? '' : (u === 3 && t >= 2 ? 'tré' : ones[u]);
      return prefix + unitStr;
    }
    if (n < 1000) {
      const h = Math.floor(n / 100), rem = n % 100;
      const hStr = h === 1 ? 'cento' : ones[h] + 'cento';
      return hStr + (rem ? numIt(rem) : '');
    }
    if (n < 10000) {
      const th = Math.floor(n / 1000), rem = n % 1000;
      const thStr = th === 1 ? 'mille' : numIt(th) + 'mila';
      return thStr + (rem ? numIt(rem) : '');
    }
    return String(n);
  }

  function numEs(n) {
    const ones = ['cero', 'uno', 'dos', 'tres', 'cuatro', 'cinco', 'seis', 'siete', 'ocho', 'nueve',
      'diez', 'once', 'doce', 'trece', 'catorce', 'quince', 'dieciséis', 'diecisiete', 'dieciocho', 'diecinueve'];
    const twenties = ['veinte', 'veintiuno', 'veintidós', 'veintitrés', 'veinticuatro', 'veinticinco', 'veintiséis', 'veintisiete', 'veintiocho', 'veintinueve'];
    const tens = ['', '', '', 'treinta', 'cuarenta', 'cincuenta', 'sesenta', 'setenta', 'ochenta', 'noventa'];
    const hundreds = ['', 'ciento', 'doscientos', 'trescientos', 'cuatrocientos', 'quinientos', 'seiscientos', 'setecientos', 'ochocientos', 'novecientos'];
    if (n < 20) return ones[n];
    if (n < 30) return twenties[n - 20];
    if (n < 100) {
      const t = Math.floor(n / 10), u = n % 10;
      return tens[t] + (u ? ' y ' + ones[u] : '');
    }
    if (n === 100) return 'cien';
    if (n < 1000) {
      const h = Math.floor(n / 100), rem = n % 100;
      return hundreds[h] + (rem ? ' ' + numEs(rem) : '');
    }
    if (n < 10000) {
      const th = Math.floor(n / 1000), rem = n % 1000;
      const thStr = th === 1 ? 'mil' : numEs(th) + ' mil';
      return thStr + (rem ? ' ' + numEs(rem) : '');
    }
    return String(n);
  }

  function numFr(n) {
    const ones = ['zéro', 'un', 'deux', 'trois', 'quatre', 'cinq', 'six', 'sept', 'huit', 'neuf',
      'dix', 'onze', 'douze', 'treize', 'quatorze', 'quinze', 'seize', 'dix-sept', 'dix-huit', 'dix-neuf'];
    const tens = ['', '', 'vingt', 'trente', 'quarante', 'cinquante', 'soixante'];
    if (n < 20) return ones[n];
    if (n < 70) {
      const t = Math.floor(n / 10), u = n % 10;
      if (u === 0) return tens[t];
      if (u === 1) return tens[t] + ' et un';
      return tens[t] + '-' + ones[u];
    }
    if (n < 80) {
      const rem = n - 60;
      return rem === 11 ? 'soixante et onze' : 'soixante-' + numFr(rem);
    }
    if (n < 100) {
      if (n === 80) return 'quatre-vingts';
      return 'quatre-vingt-' + numFr(n - 80);
    }
    if (n < 1000) {
      const h = Math.floor(n / 100), rem = n % 100;
      const hStr = h === 1 ? 'cent' : ones[h] + ' cent' + (rem === 0 ? 's' : '');
      return hStr + (rem ? ' ' + numFr(rem) : '');
    }
    if (n < 10000) {
      const th = Math.floor(n / 1000), rem = n % 1000;
      const thStr = th === 1 ? 'mille' : numFr(th) + ' mille';
      return thStr + (rem ? ' ' + numFr(rem) : '');
    }
    return String(n);
  }

  function numDe(n) {
    const ones = ['null', 'eins', 'zwei', 'drei', 'vier', 'fünf', 'sechs', 'sieben', 'acht', 'neun',
      'zehn', 'elf', 'zwölf', 'dreizehn', 'vierzehn', 'fünfzehn', 'sechzehn', 'siebzehn', 'achtzehn', 'neunzehn'];
    const tens = ['', '', 'zwanzig', 'dreißig', 'vierzig', 'fünfzig', 'sechzig', 'siebzig', 'achtzig', 'neunzig'];
    if (n < 20) return ones[n];
    if (n < 100) {
      const t = Math.floor(n / 10), u = n % 10;
      if (u === 0) return tens[t];
      return (u === 1 ? 'ein' : ones[u]) + 'und' + tens[t];
    }
    if (n < 1000) {
      const h = Math.floor(n / 100), rem = n % 100;
      const hStr = (h === 1 ? 'ein' : ones[h]) + 'hundert';
      return hStr + (rem ? numDe(rem) : '');
    }
    return String(n);
  }

  function numPt(n) {
    const ones = ['zero', 'um', 'dois', 'três', 'quatro', 'cinco', 'seis', 'sete', 'oito', 'nove',
      'dez', 'onze', 'doze', 'treze', 'catorze', 'quinze', 'dezesseis', 'dezessete', 'dezoito', 'dezenove'];
    const tens = ['', '', 'vinte', 'trinta', 'quarenta', 'cinquenta', 'sessenta', 'setenta', 'oitenta', 'noventa'];
    const hundreds = ['', 'cento', 'duzentos', 'trezentos', 'quatrocentos', 'quinhentos', 'seiscentos', 'setecentos', 'oitocentos', 'novecentos'];
    if (n < 20) return ones[n];
    if (n < 100) {
      const t = Math.floor(n / 10), u = n % 10;
      return tens[t] + (u ? ' e ' + ones[u] : '');
    }
    if (n === 100) return 'cem';
    if (n < 1000) {
      const h = Math.floor(n / 100), rem = n % 100;
      return hundreds[h] + (rem ? ' e ' + numPt(rem) : '');
    }
    return String(n);
  }

  function numberToWords(num, locale = 'en-US') {
    const n = Math.max(0, Math.floor(Number(num) || 0));
    const lang = baseLang(locale);
    switch (lang) {
      case 'en': return numEn(n);
      case 'it': return numIt(n);
      case 'es': return numEs(n);
      case 'fr': return numFr(n);
      case 'de': return numDe(n);
      case 'pt': return numPt(n);
      default: return String(n);
    }
  }

  const QUESTION_LABELS = {
    en: w => `Question ${w}.`,
    it: w => `Domanda ${w}.`,
    es: w => `Pregunta ${w}.`,
    fr: w => `Question ${w}.`,
    de: w => `Frage ${w}.`,
    pt: w => `Pergunta ${w}.`,
    hi: w => `प्रश्न ${w}.`,
    ar: w => `السؤال ${w}.`,
    ja: w => `第${w}問。`,
    zh: w => `第${w}题。`,
    ko: w => `문제 ${w}.`,
    nl: w => `Vraag ${w}.`,
    tr: w => `Soru ${w}.`,
    pl: w => `Pytanie ${w}.`,
    ru: w => `Вопрос ${w}.`
  };

  const ANSWER_INTRO_LABELS = {
    en: 'The answer is',
    it: 'La risposta è',
    es: 'La respuesta es',
    fr: 'La réponse est',
    de: 'Die Antwort ist',
    pt: 'A resposta é',
    hi: 'सही उत्तर है',
    ar: 'الإجابة هي',
    ja: '正解は',
    zh: '正确答案是',
    ko: '정답은',
    nl: 'Het antwoord is',
    tr: 'Doğru cevap',
    pl: 'Prawidłowa odpowiedź to',
    ru: 'Правильный ответ'
  };

  function buildQuestionNumberPhrase(qNum1Based, locale = 'en-US') {
    const lang = baseLang(locale);
    const word = numberToWords(Math.max(1, Number(qNum1Based) || 1), locale);
    const fn = QUESTION_LABELS[lang] || QUESTION_LABELS.en;
    return fn(word);
  }

  function buildAnswerIntroPhrase(locale = 'en-US') {
    const lang = baseLang(locale);
    return ANSWER_INTRO_LABELS[lang] || ANSWER_INTRO_LABELS.en;
  }

  function buildNarrationTexts(q, qIndex0Based, options = {}) {
    const locale = options.locale || resolveLocaleFromVoice(options.voiceId, options.voicesInventory);
    const lang = baseLang(locale);
    const speakNum = options.speakQuestionNumber !== undefined ? !!options.speakQuestionNumber : true;
    const qNum = Math.max(1, (Number(qIndex0Based) || 0) + 1);
    const prefix = speakNum ? buildQuestionNumberPhrase(qNum, locale) : '';
    const prefixWords = prefix ? prefix.trim().split(/\s+/).filter(Boolean).length : 0;

    const opts = Array.isArray(q && q.options) ? q.options : [];
    const optCount = options.optCount ? Math.min(opts.length, Number(options.optCount) || 4) : opts.length;
    const optionsPart = opts.slice(0, optCount).map((v, i) => `${'ABCD'[i]}, ${v}`).join('. ');
    const questionBody = `${String((q && q.question) || '').trim()} ${optionsPart ? optionsPart + '.' : ''}`.trim();
    const promptFull = prefix ? `${prefix} ${questionBody}` : questionBody;

    const intro = buildAnswerIntroPhrase(locale);
    const correctIdx = Math.max(0, Math.min(opts.length - 1, Number(q && q.correct) || 0));
    const correctVal = String(opts[correctIdx] || '');
    const answerFull = `${intro} ${correctVal}.`.trim();

    return {
      version: NARRATION_FORMAT_VERSION,
      locale,
      lang,
      qNum,
      speakQuestionNumber: speakNum,
      prefix,
      prefixWords,
      questionBody,
      promptText: promptFull,
      answerIntro: intro,
      answerText: answerFull
    };
  }

  function buildTtsCacheKey(q, qIndex0Based, voiceId, speed, options = {}) {
    const built = buildNarrationTexts(q, qIndex0Based, { ...options, voiceId });
    return [
      NARRATION_FORMAT_VERSION,
      voiceId || '',
      built.locale,
      Number(speed) || 1,
      built.qNum,
      built.speakQuestionNumber ? 'num1' : 'num0',
      built.promptText,
      built.answerText,
      q ? q.correct : 0
    ].join('|');
  }

  return {
    NARRATION_FORMAT_VERSION,
    resolveLocaleFromVoice,
    baseLang,
    numberToWords,
    buildQuestionNumberPhrase,
    buildAnswerIntroPhrase,
    buildNarrationTexts,
    buildTtsCacheKey
  };
});
