/* Quiz Studio Pro 7 — Phase 7, 8, 9, 10, 11, 13, 14 + Features 2, 4, 5: Universal Inspector, Question Pill Presets, Answer Reveal Styles, Live Animation Preview & Save, Canva OAuth & Benchmark UI */
(function (root) {
  'use strict';

  const $ = id => document.getElementById(id);

  const ANIM_TARGETS = [
    { id: 'questionNumber', label: 'Question Number' },
    { id: 'questionText', label: 'Question Text' },
    { id: 'optionLabel', label: 'Option Badges' },
    { id: 'optionText', label: 'Option Texts' },
    { id: 'answerIntro', label: 'Answer Intro' },
    { id: 'answerReveal', label: 'Answer Reveal' }
  ];

  const state = {
    scene: null,
    selectedId: null,
    revealConfig: null,
    transitionConfig: null,
    questionNumberConfig: null,
    answerRevealConfig: null,
    activeAnimTarget: 'questionText',
    hasUnsavedAnimChanges: false,
    demoRunToken: 0,
    demoRafId: 0,
    cvAnalysis: null,
    dragging: null,
    rendererCtx: null,
    nudgeStep: 0.01
  };

  function getDeps() {
    return {
      SceneModel: root.QuizSceneModel,
      SceneRenderer: root.QuizSceneRenderer,
      TextReveal: root.QuizTextReveal,
      Transitions: root.QuizTransitions,
      Timeline: root.QuizTimeline,
      CvDetector: root.QuizCvDetector,
      TemplateStore: root.QuizTemplateStore,
      CanvaConnect: root.QuizCanvaConnect,
      Diagnostics: root.QuizWebCodecsDiagnostics,
      NarrationL10n: root.QuizNarrationL10n
    };
  }

  function ensureInitialized() {
    const { SceneModel, SceneRenderer, TextReveal, Transitions } = getDeps();
    if (!state.rendererCtx && SceneRenderer) {
      state.rendererCtx = SceneRenderer.createRendererContext();
    }
    if (!state.revealConfig && TextReveal) {
      state.revealConfig = TextReveal.normalizeRevealConfig({});
    }
    if (!state.transitionConfig && Transitions) {
      state.transitionConfig = Transitions.normalizeTransitionConfig({});
    }
    if (!state.questionNumberConfig && SceneModel && SceneModel.normalizeQuestionNumberConfig) {
      state.questionNumberConfig = SceneModel.normalizeQuestionNumberConfig({});
    }
    if (!state.answerRevealConfig && SceneModel && SceneModel.normalizeAnswerRevealConfig) {
      const themeCorrect = (typeof root.THEME !== 'undefined' && root.THEME.correctFill) ? root.THEME.correctFill : undefined;
      state.answerRevealConfig = SceneModel.normalizeAnswerRevealConfig(themeCorrect ? { highlightBg: themeCorrect } : {});
    }
    if (!state.scene && SceneModel && typeof root.THEME !== 'undefined') {
      const ratio = ($('ratio') && $('ratio').value) || '16/9';
      state.scene = SceneModel.fromThemeToScene(root.THEME, {
        ratio,
        questionNumberConfig: state.questionNumberConfig,
        answerRevealConfig: state.answerRevealConfig
      });
    }
  }

  function findQuestionNumberElement(scene) {
    if (!scene || !Array.isArray(scene.elements)) return null;
    return scene.elements.find(e => e.type === 'question_number') || null;
  }

  function syncSceneFromTheme(correctFillChanged = false) {
    const { SceneModel } = getDeps();
    if (!SceneModel || typeof root.THEME === 'undefined') return;
    ensureInitialized();
    if (correctFillChanged && root.THEME.correctFill && SceneModel.normalizeAnswerRevealConfig) {
      state.answerRevealConfig = SceneModel.normalizeAnswerRevealConfig({
        ...(state.answerRevealConfig || {}),
        highlightBg: root.THEME.correctFill
      });
      syncAnswerRevealUi();
    }
    const ratio = ($('ratio') && $('ratio').value) || '16/9';
    if (!state.scene || state.scene.mode === SceneModel.RENDER_MODES.DEFAULT) {
      const prevCustom = state.scene && Array.isArray(state.scene.elements)
        ? state.scene.elements.filter(e => e.isUserAdded)
        : [];
      const prevNumEl = findQuestionNumberElement(state.scene);
      state.scene = SceneModel.fromThemeToScene(root.THEME, {
        ratio,
        questionNumberConfig: state.questionNumberConfig,
        answerRevealConfig: state.answerRevealConfig
      });
      if (prevNumEl) {
        const curNumEl = findQuestionNumberElement(state.scene);
        if (curNumEl) {
          state.scene = SceneModel.updateElement(state.scene, curNumEl.id, {
            backgroundColor: prevNumEl.backgroundColor,
            borderColor: prevNumEl.borderColor,
            borderWidth: prevNumEl.borderWidth,
            borderRadius: prevNumEl.borderRadius,
            alignment: prevNumEl.alignment,
            qNumPreset: prevNumEl.qNumPreset,
            qNumPrefix: prevNumEl.qNumPrefix,
            qNumLeadingZero: prevNumEl.qNumLeadingZero,
            qNumSeparator: prevNumEl.qNumSeparator,
            qNumShowTotal: prevNumEl.qNumShowTotal,
            qNumUppercase: prevNumEl.qNumUppercase
          });
        }
      }
      prevCustom.forEach(customEl => {
        state.scene = SceneModel.addElement(state.scene, customEl).scene;
      });
    } else {
      const aspect = SceneModel.parseAspectRatio(ratio);
      state.scene.ratio = aspect.ratio;
      state.scene.baseWidth = aspect.width;
      state.scene.baseHeight = aspect.height;
      state.scene.questionNumberConfig = state.questionNumberConfig;
      state.scene.answerRevealConfig = state.answerRevealConfig;
      if (root.THEME && typeof root.THEME === 'object') {
        const th = root.THEME;
        const prev = state._lastThemeTimerSnapshot || {};
        const timerKeys = ['timerLook', 'timerA', 'timerB', 'timerTrack', 'timerBorder'];
        const timerChanged = timerKeys.some(k => prev[k] !== undefined && prev[k] !== th[k]);
        state.scene.theme = {
          ...(state.scene.theme || {}),
          timerLook: th.timerLook || (state.scene.theme && state.scene.theme.timerLook) || 'capsule',
          timerA: th.timerA || (state.scene.theme && state.scene.theme.timerA) || '#ff4a14',
          timerB: th.timerB || (state.scene.theme && state.scene.theme.timerB) || '#f02a00',
          timerTrack: th.timerTrack || (state.scene.theme && state.scene.theme.timerTrack) || '#d9d9d9',
          timerBorder: th.timerBorder || (state.scene.theme && state.scene.theme.timerBorder) || '#ffffff'
        };
        if (timerChanged && Array.isArray(state.scene.elements)) {
          state.scene.elements.forEach(el => {
            if (el && el.type === 'timer') {
              el.timerLook = th.timerLook || el.timerLook;
              el.textColor = th.timerA || el.textColor;
              el.backgroundColor = th.timerTrack || el.backgroundColor;
              el.borderColor = th.timerBorder || el.borderColor;
            }
          });
        }
        state._lastThemeTimerSnapshot = {
          timerLook: th.timerLook,
          timerA: th.timerA,
          timerB: th.timerB,
          timerTrack: th.timerTrack,
          timerBorder: th.timerBorder
        };
      }
    }
    refreshInspectorLists();
  }

  function setImportedScene(scene, cvAnalysis = null, opts = {}) {
    ensureInitialized();
    const { SceneModel } = getDeps();
    const normalizedScene = (scene && SceneModel && typeof SceneModel.assignOptionIndicesForScene === 'function')
      ? SceneModel.assignOptionIndicesForScene(scene)
      : scene;
    state.scene = normalizedScene;
    if (root.THEME && typeof root.THEME === 'object') {
      state._lastThemeTimerSnapshot = {
        timerLook: root.THEME.timerLook,
        timerA: root.THEME.timerA,
        timerB: root.THEME.timerB,
        timerTrack: root.THEME.timerTrack,
        timerBorder: root.THEME.timerBorder
      };
    }
    state.cvAnalysis = cvAnalysis;
    const preserve = !!(opts && opts.preserveConfigs) || !!cvAnalysis;
    if (!preserve) {
      if (normalizedScene && normalizedScene.questionNumberConfig && SceneModel && SceneModel.normalizeQuestionNumberConfig) {
        state.questionNumberConfig = SceneModel.normalizeQuestionNumberConfig(normalizedScene.questionNumberConfig);
      }
      if (normalizedScene && normalizedScene.answerRevealConfig && SceneModel && SceneModel.normalizeAnswerRevealConfig) {
        state.answerRevealConfig = SceneModel.normalizeAnswerRevealConfig(normalizedScene.answerRevealConfig);
      }
    } else if (normalizedScene) {
      if (state.questionNumberConfig && SceneModel && SceneModel.normalizeQuestionNumberConfig) {
        normalizedScene.questionNumberConfig = SceneModel.normalizeQuestionNumberConfig(state.questionNumberConfig);
      }
      if (state.answerRevealConfig && SceneModel && SceneModel.normalizeAnswerRevealConfig) {
        normalizedScene.answerRevealConfig = SceneModel.normalizeAnswerRevealConfig(state.answerRevealConfig);
      }
    }
    state.selectedId = (normalizedScene && normalizedScene.elements && normalizedScene.elements.length > 1)
      ? normalizedScene.elements[1].id
      : (normalizedScene && normalizedScene.elements && normalizedScene.elements[0] ? normalizedScene.elements[0].id : null);
    refreshInspectorLists();
    syncQuestionNumberUi();
    syncAnswerRevealUi();
    syncAnimTargetUi();
    if (typeof root.renderPreview === 'function') root.renderPreview();
  }

  function setConfigs(cfg = {}) {
    ensureInitialized();
    const { SceneModel, TextReveal, Transitions } = getDeps();
    if (cfg.revealConfig && TextReveal) {
      state.revealConfig = TextReveal.normalizeRevealConfig(cfg.revealConfig);
    }
    if (cfg.transitionConfig && Transitions) {
      state.transitionConfig = Transitions.normalizeTransitionConfig(cfg.transitionConfig);
    }
    if (cfg.questionNumberConfig && SceneModel && SceneModel.normalizeQuestionNumberConfig) {
      state.questionNumberConfig = SceneModel.normalizeQuestionNumberConfig(cfg.questionNumberConfig);
      if (state.scene) state.scene.questionNumberConfig = state.questionNumberConfig;
    }
    if (cfg.answerRevealConfig && SceneModel && SceneModel.normalizeAnswerRevealConfig) {
      state.answerRevealConfig = SceneModel.normalizeAnswerRevealConfig(cfg.answerRevealConfig);
      if (state.scene) state.scene.answerRevealConfig = state.answerRevealConfig;
    }
    syncQuestionNumberUi();
    syncAnswerRevealUi();
    syncAnimTargetUi();
    syncTransitionUi();
  }

  function switchToDefaultMode() {
    const { SceneModel } = getDeps();
    if (!SceneModel) return;
    ensureInitialized();
    const ratio = ($('ratio') && $('ratio').value) || '16/9';
    state.scene = SceneModel.fromThemeToScene(root.THEME || {}, {
      ratio,
      questionNumberConfig: state.questionNumberConfig,
      answerRevealConfig: state.answerRevealConfig
    });
    state.cvAnalysis = null;
    state.selectedId = null;
    refreshInspectorLists();
    if (typeof root.renderPreview === 'function') root.renderPreview();
  }

  function switchToBlankCanvas() {
    const { SceneModel } = getDeps();
    if (!SceneModel) return;
    ensureInitialized();
    const ratio = ($('ratio') && $('ratio').value) || '16/9';
    state.scene = SceneModel.createBlankScene({
      ratio,
      bg: '#0f172a',
      questionNumberConfig: state.questionNumberConfig,
      answerRevealConfig: state.answerRevealConfig
    });
    state.cvAnalysis = null;
    state.selectedId = state.scene.elements[0] ? state.scene.elements[0].id : null;
    refreshInspectorLists();
    if (typeof root.renderPreview === 'function') root.renderPreview();
  }

  function applyQuestionNumberConfig(cfgPatch, opts = {}) {
    const { SceneModel } = getDeps();
    if (!SceneModel) return;
    ensureInitialized();
    const nextCfg = SceneModel.normalizeQuestionNumberConfig({
      ...state.questionNumberConfig,
      ...cfgPatch
    });
    state.questionNumberConfig = nextCfg;
    if (state.scene) {
      state.scene.questionNumberConfig = nextCfg;
      const numEl = findQuestionNumberElement(state.scene);
      if (numEl) {
        const elPatch = {
          qNumPreset: nextCfg.preset,
          qNumPrefix: nextCfg.prefix,
          qNumLeadingZero: nextCfg.leadingZero,
          qNumSeparator: nextCfg.separator,
          qNumShowTotal: nextCfg.showTotal,
          qNumUppercase: nextCfg.uppercase
        };
        if (opts.textColor) elPatch.textColor = opts.textColor;
        if (opts.backgroundColor !== undefined) elPatch.backgroundColor = opts.backgroundColor;
        if (opts.borderColor !== undefined) elPatch.borderColor = opts.borderColor;
        if (opts.borderWidth !== undefined) elPatch.borderWidth = opts.borderWidth;
        if (opts.borderRadius !== undefined) elPatch.borderRadius = opts.borderRadius;
        if (opts.fontSize !== undefined) elPatch.fontSize = opts.fontSize;
        if (opts.alignment !== undefined) elPatch.alignment = opts.alignment;
        if (numEl.id === 'hdr_num') {
          const isWide = nextCfg.prefix.length > 2 || nextCfg.separator.length > 2;
          elPatch.width = isWide ? 0.34 : 0.16;
          const titleEl = SceneModel.findElement(state.scene, 'hdr_title');
          if (titleEl && !titleEl.isUserAdded) {
            state.scene = SceneModel.updateElement(state.scene, 'hdr_title', {
              x: isWide ? 0.39 : 0.21,
              width: isWide ? 0.57 : 0.75
            });
          }
        }
        state.scene = SceneModel.updateElement(state.scene, numEl.id, elPatch);
      }
    }
    syncQuestionNumberUi();
    refreshInspectorFields();
    if (typeof root.renderPreview === 'function') root.renderPreview();
    if (typeof root.scheduleSave === 'function') root.scheduleSave();
  }

  function syncQuestionNumberUi() {
    const { SceneModel } = getDeps();
    if (!SceneModel || !state.questionNumberConfig) return;
    const c = state.questionNumberConfig;
    if ($('qNumPreset')) $('qNumPreset').value = c.preset || '1_slash_20';
    if ($('qNumPrefix')) $('qNumPrefix').value = c.prefix || '';
    if ($('qNumSeparator')) $('qNumSeparator').value = c.separator || '';
    if ($('qNumLeadingZero')) $('qNumLeadingZero').checked = !!c.leadingZero;
    if ($('qNumShowTotal')) $('qNumShowTotal').checked = !!c.showTotal;
    if ($('qNumUppercase')) $('qNumUppercase').checked = !!c.uppercase;
    const total = Math.max(1, (root.questions && root.questions.length) || 20);
    const cur = Math.max(0, root.current || 0);
    if ($('qNumLivePreview')) {
      $('qNumLivePreview').textContent = 'Preview: ' + SceneModel.formatQuestionNumber(cur, total, c);
    }
    const numEl = findQuestionNumberElement(state.scene);
    if (numEl) {
      if ($('qNumTextCol') && /^#[0-9a-f]{6}$/i.test(numEl.textColor || '')) $('qNumTextCol').value = numEl.textColor;
      if ($('qNumBgCol') && /^#[0-9a-f]{6}$/i.test(numEl.backgroundColor || '')) $('qNumBgCol').value = numEl.backgroundColor;
      if ($('qNumBorderCol') && /^#[0-9a-f]{6}$/i.test(numEl.borderColor || '')) $('qNumBorderCol').value = numEl.borderColor;
      if ($('qNumRadius')) $('qNumRadius').value = numEl.borderRadius !== undefined ? numEl.borderRadius : 0.15;
      if ($('qNumFontSize')) $('qNumFontSize').value = ((numEl.fontSize || 0.055) * 100).toFixed(1);
      if ($('qNumAlign')) $('qNumAlign').value = numEl.alignment || 'left';
    }
  }

  function buildQuestionNumberSectionHtml(SceneModel) {
    const presets = (SceneModel && SceneModel.QUESTION_NUMBER_PRESETS) || [];
    const presetOpts = presets.map(p => `<option value="${p.id}">${p.label}</option>`).join('');
    return `
      <div id="qspQuestionNumberSection" style="background:#161a24;border:1px solid #2d3748;border-radius:10px;padding:12px;margin-bottom:12px">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:8px">
          <strong style="font-size:13px;color:#fbbf24">🏷 Question Number / Pill Style</strong>
          <span id="qNumLivePreview" class="badge" style="font-size:11px;background:#262b38;color:#fde047">Preview: 1 / 20</span>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:8px;margin-bottom:8px">
          <div>
            <label class="hint" style="margin:0 0 3px;display:block">Preset Format</label>
            <select id="qNumPreset" style="min-height:44px">${presetOpts}</select>
          </div>
          <div>
            <label class="hint" style="margin:0 0 3px;display:block">Prefix (e.g. Question , Q)</label>
            <input id="qNumPrefix" placeholder="e.g. Question " style="min-height:44px">
          </div>
          <div>
            <label class="hint" style="margin:0 0 3px;display:block">Separator (e.g. / , of , —)</label>
            <input id="qNumSeparator" placeholder="e.g. /" style="min-height:44px">
          </div>
        </div>
        <div class="row" style="gap:14px;flex-wrap:wrap;margin-bottom:8px">
          <label class="hint" style="margin:0;display:inline-flex;align-items:center;gap:6px;min-height:44px;cursor:pointer"><input type="checkbox" id="qNumLeadingZero" style="width:auto"> Leading Zero (01)</label>
          <label class="hint" style="margin:0;display:inline-flex;align-items:center;gap:6px;min-height:44px;cursor:pointer"><input type="checkbox" id="qNumShowTotal" checked style="width:auto"> Show Total (/20)</label>
          <label class="hint" style="margin:0;display:inline-flex;align-items:center;gap:6px;min-height:44px;cursor:pointer"><input type="checkbox" id="qNumUppercase" style="width:auto"> UPPERCASE</label>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(115px,1fr));gap:8px;align-items:end">
          <div><label class="hint" style="margin:0 0 3px;display:block">Text Color</label><input type="color" id="qNumTextCol" value="#ffd400" style="height:40px;padding:2px"></div>
          <div><label class="hint" style="margin:0 0 3px;display:block">Pill Fill</label><input type="color" id="qNumBgCol" value="#1e1b08" style="height:40px;padding:2px"></div>
          <div><label class="hint" style="margin:0 0 3px;display:block">Pill Border</label><input type="color" id="qNumBorderCol" value="#fbbf24" style="height:40px;padding:2px"></div>
          <div><label class="hint" style="margin:0 0 3px;display:block">Radius</label><input type="number" id="qNumRadius" min="0" max="0.5" step="0.05" value="0.2" style="min-height:40px"></div>
          <div><label class="hint" style="margin:0 0 3px;display:block">Size (% H)</label><input type="number" id="qNumFontSize" min="1.5" max="18" step="0.3" value="5.5" style="min-height:40px"></div>
          <div>
            <label class="hint" style="margin:0 0 3px;display:block">Align</label>
            <select id="qNumAlign" style="min-height:40px"><option value="left">Left</option><option value="center">Center</option><option value="right">Right</option></select>
          </div>
        </div>
        <div class="row" style="gap:8px;margin-top:8px">
          <button type="button" class="btn mini" id="qNumTransparentBg" style="min-height:40px">Transparent Pill Bg</button>
          <button type="button" class="btn mini" id="qNumSelectPillBtn" style="min-height:40px">Select Pill Layer (Position/Size)</button>
        </div>
      </div>
    `;
  }

  function buildInspectorPanelDom() {
    const tplMgr = $('templateManager');
    if (!tplMgr || $('qspInspectorPanel')) return;

    const content = tplMgr.querySelector('.content');
    if (!content) return;
    const { SceneModel } = getDeps();

    const panel = document.createElement('div');
    panel.id = 'qspInspectorPanel';
    panel.className = 'section';
    panel.style.cssText = 'margin-top:16px;padding:14px;background:#13151b;border:1px solid #2b3240;border-radius:12px';
    panel.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:10px">
        <label class="label" style="margin:0;color:#38bdf8">🎛 Universal Layer &amp; Element Inspector</label>
        <span id="inspModeBadge" class="badge" style="font-size:11px">DEFAULT_TEMPLATE_MODE</span>
      </div>
      ${buildQuestionNumberSectionHtml(SceneModel)}
      <div class="row" style="gap:6px;margin-bottom:10px">
        <button type="button" class="btn mini" id="inspUseDefault">Use Default Template Mode</button>
        <button type="button" class="btn mini" id="inspBlankCanvas">New Blank Scene</button>
        <button type="button" class="btn mini" id="inspAddText">+ Text</button>
        <button type="button" class="btn mini" id="inspAddShape">+ Shape</button>
        <button type="button" class="btn mini" id="inspAddIcon">+ Icon</button>
        <label class="btn mini" for="inspAddImageInput" style="cursor:pointer">+ Image</label>
        <input id="inspAddImageInput" type="file" accept="image/*" class="hidden">
      </div>
      <div style="display:grid;grid-template-columns:1fr;gap:10px">
        <div>
          <label class="hint" style="margin:0 0 4px;display:block">Layers (tap canvas or choose below)</label>
          <div id="inspLayerList" class="q-list" style="max-height:170px;margin-top:0"></div>
        </div>
        <div id="inspPropsBox" style="background:#181b22;border:1px solid #2c3342;border-radius:10px;padding:12px">
          <div id="inspNoSel" class="hint" style="margin:0">Tap any element in Preview or select a layer above to move, nudge, resize, recolor, reorder, or restyle it.</div>
          <div id="inspControls" class="hidden">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:6px;margin-bottom:8px;flex-wrap:wrap">
              <strong id="inspSelTitle" style="font-size:13px;color:#fff">Element</strong>
              <div class="row" style="gap:4px">
                <button type="button" class="btn mini" id="inspLayerUp" title="Bring Forward">↑ Layer</button>
                <button type="button" class="btn mini" id="inspLayerDown" title="Send Backward">↓ Layer</button>
                <button type="button" class="btn mini" id="inspDupEl">Duplicate</button>
                <button type="button" class="btn mini ghost" id="inspLockEl">🔓</button>
                <button type="button" class="btn mini ghost" id="inspDelEl">🗑</button>
              </div>
            </div>
            <div style="display:flex;gap:14px;flex-wrap:wrap;align-items:center;margin-bottom:10px">
              <div>
                <div class="hint" style="margin:0 0 4px">4-Dir Nudge (<select id="inspStep" style="width:auto;padding:2px 4px;font-size:11px"><option value="0.005">0.5%</option><option value="0.01" selected>1%</option><option value="0.025">2.5%</option></select>)</div>
                <div style="display:grid;grid-template-columns:repeat(3,40px);gap:4px">
                  <span></span><button type="button" class="btn mini" data-el-nudge="up">▲</button><span></span>
                  <button type="button" class="btn mini" data-el-nudge="left">◀</button>
                  <button type="button" class="btn mini ghost" id="inspResetPos" title="Reset Position">⟲</button>
                  <button type="button" class="btn mini" data-el-nudge="right">▶</button>
                  <span></span><button type="button" class="btn mini" data-el-nudge="down">▼</button><span></span>
                </div>
              </div>
              <div style="flex:1;min-width:190px;display:grid;grid-template-columns:1fr 1fr;gap:6px">
                <div><label class="hint" style="margin:0">X (%)</label><input type="number" step="0.5" id="inspX"></div>
                <div><label class="hint" style="margin:0">Y (%)</label><input type="number" step="0.5" id="inspY"></div>
                <div><label class="hint" style="margin:0">Width (%)</label><input type="number" step="0.5" id="inspW"></div>
                <div><label class="hint" style="margin:0">Height (%)</label><input type="number" step="0.5" id="inspH"></div>
              </div>
            </div>
            <div class="grid2" style="gap:8px;margin-bottom:8px">
              <div><label class="hint" style="margin:0">Element Type</label><select id="inspType"></select></div>
              <div><label class="hint" style="margin:0">Rotation (deg)</label><input type="number" step="1" min="-180" max="180" id="inspRot"></div>
              <div><label class="hint" style="margin:0">Text Color</label><input type="color" id="inspTextCol" style="height:34px;padding:2px"></div>
              <div><label class="hint" style="margin:0">Background Color</label><input type="color" id="inspBgCol" style="height:34px;padding:2px"></div>
              <div><label class="hint" style="margin:0">Border Color</label><input type="color" id="inspBorderCol" style="height:34px;padding:2px"></div>
              <div><label class="hint" style="margin:0">Opacity (<span id="inspOpV">100%</span>)</label><input type="range" min="0" max="1" step="0.05" id="inspOp" style="padding:0"></div>
              <div><label class="hint" style="margin:0">Font Size (% H)</label><input type="number" step="0.2" min="1" max="25" id="inspFontSize"></div>
              <div><label class="hint" style="margin:0">Border Radius</label><input type="number" step="0.05" min="0" max="0.5" id="inspRadius"></div>
            </div>
            <div style="margin-bottom:8px"><label class="hint" style="margin:0">Text / Token ({question}, {option_0}, {header}, {num}/{total}, {answer_intro}, {correct_answer})</label><input id="inspText"></div>
            <div class="row" style="gap:6px">
              <button type="button" class="btn mini" id="inspResetSize">Reset Size</button>
              <button type="button" class="btn mini" id="inspTransparentBg">Transparent Bg</button>
              <button type="button" class="btn mini" id="inspToggleVis">Hide / Show</button>
            </div>
          </div>
        </div>
      </div>
    `;

    const tplList = $('templateList');
    if (tplList && tplList.parentNode === content) content.insertBefore(panel, tplList);
    else content.appendChild(panel);

    wireInspectorEvents();
    wireQuestionNumberEvents();
    syncQuestionNumberUi();
  }

  function wireQuestionNumberEvents() {
    const { SceneModel } = getDeps();
    if ($('qNumPreset')) {
      $('qNumPreset').addEventListener('change', e => {
        const presetId = e.target.value;
        if (SceneModel && SceneModel.normalizeQuestionNumberConfig) {
          const norm = SceneModel.normalizeQuestionNumberConfig({
            preset: presetId,
            uppercase: state.questionNumberConfig ? state.questionNumberConfig.uppercase : false,
            fromPreset: true
          });
          applyQuestionNumberConfig(norm);
        }
      });
    }
    if ($('qNumPrefix')) {
      $('qNumPrefix').addEventListener('input', e => applyQuestionNumberConfig({ preset: 'custom', prefix: e.target.value }));
    }
    if ($('qNumSeparator')) {
      $('qNumSeparator').addEventListener('input', e => applyQuestionNumberConfig({ preset: 'custom', separator: e.target.value }));
    }
    if ($('qNumLeadingZero')) {
      $('qNumLeadingZero').addEventListener('change', e => applyQuestionNumberConfig({ leadingZero: e.target.checked }));
    }
    if ($('qNumShowTotal')) {
      $('qNumShowTotal').addEventListener('change', e => applyQuestionNumberConfig({ showTotal: e.target.checked }));
    }
    if ($('qNumUppercase')) {
      $('qNumUppercase').addEventListener('change', e => applyQuestionNumberConfig({ uppercase: e.target.checked }));
    }
    if ($('qNumTextCol')) {
      $('qNumTextCol').addEventListener('input', e => applyQuestionNumberConfig({}, { textColor: e.target.value }));
    }
    if ($('qNumBgCol')) {
      $('qNumBgCol').addEventListener('input', e => applyQuestionNumberConfig({}, { backgroundColor: e.target.value }));
    }
    if ($('qNumBorderCol')) {
      $('qNumBorderCol').addEventListener('input', e => {
        const numEl = findQuestionNumberElement(state.scene);
        applyQuestionNumberConfig({}, { borderColor: e.target.value, borderWidth: Math.max(2, (numEl && numEl.borderWidth) || 2) });
      });
    }
    if ($('qNumRadius')) {
      $('qNumRadius').addEventListener('input', e => applyQuestionNumberConfig({}, { borderRadius: Number(e.target.value) || 0 }));
    }
    if ($('qNumFontSize')) {
      $('qNumFontSize').addEventListener('input', e => applyQuestionNumberConfig({}, { fontSize: Math.max(0.015, (Number(e.target.value) || 5) / 100) }));
    }
    if ($('qNumAlign')) {
      $('qNumAlign').addEventListener('change', e => applyQuestionNumberConfig({}, { alignment: e.target.value }));
    }
    if ($('qNumTransparentBg')) {
      $('qNumTransparentBg').addEventListener('click', () => applyQuestionNumberConfig({}, { backgroundColor: 'transparent', borderWidth: 0 }));
    }
    if ($('qNumSelectPillBtn')) {
      $('qNumSelectPillBtn').addEventListener('click', () => {
        ensureInitialized();
        const numEl = findQuestionNumberElement(state.scene);
        if (numEl) {
          state.selectedId = numEl.id;
          refreshInspectorLists();
          if (typeof root.renderPreview === 'function') root.renderPreview();
          const box = $('inspPropsBox');
          if (box && box.scrollIntoView) box.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      });
    }
  }

  function buildAnswerRevealUi(vsContent, anchorNode) {
    if ($('qspAnswerRevealSection')) return;
    const { SceneModel, TextReveal } = getDeps();
    const styles = (SceneModel && SceneModel.ANSWER_REVEAL_STYLES) || [];
    const styleOpts = styles.map(s => `<option value="${s.id}">${s.label}</option>`).join('');
    const revOpts = (TextReveal ? TextReveal.REVEAL_STYLES : []).map(s => `<option value="${s.id}">${s.label}</option>`).join('');

    const sec = document.createElement('div');
    sec.id = 'qspAnswerRevealSection';
    sec.className = 'section';
    sec.style.cssText = 'margin:14px 0;padding:12px;background:#14171f;border:1px solid #2b3344;border-radius:10px';
    sec.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:8px">
        <label class="label" style="color:#4ade80;margin:0">✅ Answer Reveal Style &amp; Colors</label>
        <button type="button" class="btn mini" id="btnPreviewAnswerReveal" style="min-height:48px">👁 Preview Answer Reveal</button>
      </div>
      <div style="margin-bottom:10px">
        <label class="hint" style="margin:0 0 3px;display:block">Reveal Visual Mode</label>
        <select id="ansRevStyle" style="min-height:48px">${styleOpts}</select>
      </div>
      <div style="margin-bottom:6px;font-size:11px;font-weight:700;color:#86efac;letter-spacing:0.3px">CORRECT ANSWER SLOT &amp; TICK BADGE (INDEPENDENT)</div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:8px;margin-bottom:10px">
        <div><label class="hint" style="margin:0 0 3px;display:block">Correct Answer Slot Background</label><input type="color" id="ansRevHighlightBg" value="#16a34a" style="height:48px;padding:2px"></div>
        <div><label class="hint" style="margin:0 0 3px;display:block">Correct Answer Text Color</label><input type="color" id="ansRevTextColor" value="#ffffff" style="height:48px;padding:2px"></div>
        <div><label class="hint" style="margin:0 0 3px;display:block">Tick Badge Background</label><input type="color" id="ansRevBadgeBg" value="#22c55e" style="height:48px;padding:2px"></div>
        <div><label class="hint" style="margin:0 0 3px;display:block">Tick Icon Color</label><input type="color" id="ansRevTickColor" value="#ffffff" style="height:48px;padding:2px"></div>
        <div><label class="hint" style="margin:0 0 3px;display:block">Correct Answer Border Color</label><input type="color" id="ansRevBorderColor" value="#ffffff" style="height:48px;padding:2px"></div>
        <div><label class="hint" style="margin:0 0 3px;display:block">Border Width (px)</label><input type="number" id="ansRevBorderWidth" min="0" max="16" step="0.5" value="3" style="min-height:48px"></div>
        <div><label class="hint" style="margin:0 0 3px;display:block">Glow Color</label><input type="color" id="ansRevGlowColor" value="#22c55e" style="height:48px;padding:2px"></div>
      </div>
      <div style="margin:8px 0 6px;padding-top:8px;border-top:1px solid #262c3a;font-size:11px;font-weight:700;color:#94a3b8;letter-spacing:0.3px">DIMMED WRONG OPTIONS STYLING</div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:8px;margin-bottom:10px">
        <div><label class="hint" style="margin:0 0 3px;display:block">Dimmed Option Background</label><input type="color" id="ansRevDimBg" value="#1e293b" style="height:48px;padding:2px"></div>
        <div><label class="hint" style="margin:0 0 3px;display:block">Dimmed Option Text Color</label><input type="color" id="ansRevDimTextColor" value="#94a3b8" style="height:48px;padding:2px"></div>
        <div><label class="hint" style="margin:0 0 3px;display:block">Dimmed Badge Background</label><input type="color" id="ansRevDimBadgeBg" value="#334155" style="height:48px;padding:2px"></div>
        <div><label class="hint" style="margin:0 0 3px;display:block">Dimmed Badge Text Color</label><input type="color" id="ansRevDimBadgeTextColor" value="#cbd5e1" style="height:48px;padding:2px"></div>
        <div><label class="hint" style="margin:0 0 3px;display:block">Dimmed Border Color</label><input type="color" id="ansRevDimBorderColor" value="#475569" style="height:48px;padding:2px"></div>
        <div>
          <label class="hint" style="margin:0 0 3px;display:block">Dimmed Option Opacity: <b id="ansRevDimOpacityV">88%</b></label>
          <input type="range" id="ansRevDimOpacity" min="0.25" max="1" step="0.05" value="0.88" style="padding:0;min-height:48px">
        </div>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;align-items:center">
        <div>
          <label class="hint" style="margin:0 0 3px;display:block">Highlight Scale Boost: <b id="ansRevScaleBoostV">1.03x</b></label>
          <input type="range" id="ansRevScaleBoost" min="1.0" max="1.15" step="0.01" value="1.03" style="padding:0;min-height:48px">
        </div>
        <div>
          <label class="hint" style="margin:0 0 3px;display:block">Answer Animation</label>
          <select id="ansRevAnimStyle" style="min-height:48px">${revOpts}</select>
        </div>
        <div>
          <label class="hint" style="margin:0 0 3px;display:block">Reveal Duration (s)</label>
          <input type="number" id="ansRevDurationSec" min="0.1" max="2.5" step="0.05" value="0.40" style="min-height:48px">
        </div>
      </div>
      <div class="row" style="gap:14px;flex-wrap:wrap;margin-top:8px">
        <label class="hint" style="margin:0;display:inline-flex;align-items:center;gap:6px;min-height:48px;cursor:pointer"><input type="checkbox" id="ansRevGlowEnabled" checked style="width:auto"> Enable Highlight Glow</label>
        <label class="hint" style="margin:0;display:inline-flex;align-items:center;gap:6px;min-height:48px;cursor:pointer"><input type="checkbox" id="ansRevDimBgEnabled" style="width:auto"> Dim Wrong Options (All Modes)</label>
      </div>
    `;

    if (anchorNode && anchorNode.parentNode === vsContent) vsContent.insertBefore(sec, anchorNode);
    else vsContent.appendChild(sec);

    wireAnswerRevealEvents();
    syncAnswerRevealUi();
  }

  function syncAnswerRevealUi() {
    ensureInitialized();
    const c = state.answerRevealConfig;
    if (!c) return;
    if ($('ansRevStyle')) $('ansRevStyle').value = c.style || 'correct-only';
    if ($('ansRevHighlightBg')) $('ansRevHighlightBg').value = c.highlightBg || '#16a34a';
    if ($('ansRevBadgeBg')) $('ansRevBadgeBg').value = c.badgeBg || '#22c55e';
    if ($('ansRevTickColor')) $('ansRevTickColor').value = c.badgeTickColor || '#ffffff';
    if ($('ansRevTextColor')) $('ansRevTextColor').value = c.correctTextColor || '#ffffff';
    if ($('ansRevBorderColor')) $('ansRevBorderColor').value = c.correctBorderColor || '#ffffff';
    if ($('ansRevBorderWidth')) $('ansRevBorderWidth').value = c.correctBorderWidth !== undefined ? c.correctBorderWidth : 3;
    if ($('ansRevDimBg')) $('ansRevDimBg').value = c.dimBg || '#1e293b';
    if ($('ansRevDimTextColor')) $('ansRevDimTextColor').value = c.dimTextColor || '#94a3b8';
    if ($('ansRevDimBadgeBg')) $('ansRevDimBadgeBg').value = c.dimBadgeBg || '#334155';
    if ($('ansRevDimBadgeTextColor')) $('ansRevDimBadgeTextColor').value = c.dimBadgeTextColor || '#cbd5e1';
    if ($('ansRevDimBorderColor')) $('ansRevDimBorderColor').value = c.dimBorderColor || '#475569';
    if ($('ansRevDimBgEnabled')) $('ansRevDimBgEnabled').checked = !!c.dimWrongBgEnabled;
    if ($('ansRevDimOpacity')) $('ansRevDimOpacity').value = c.dimOpacity !== undefined ? c.dimOpacity : 0.88;
    if ($('ansRevDimOpacityV')) $('ansRevDimOpacityV').textContent = Math.round((c.dimOpacity !== undefined ? c.dimOpacity : 0.88) * 100) + '%';
    if ($('ansRevGlowEnabled')) $('ansRevGlowEnabled').checked = !!c.glowEnabled;
    if ($('ansRevGlowColor')) $('ansRevGlowColor').value = c.glowColor || '#22c55e';
    if ($('ansRevScaleBoost')) $('ansRevScaleBoost').value = c.scaleBoost !== undefined ? c.scaleBoost : 1.03;
    if ($('ansRevScaleBoostV')) $('ansRevScaleBoostV').textContent = Number(c.scaleBoost !== undefined ? c.scaleBoost : 1.03).toFixed(2) + 'x';
    if ($('ansRevAnimStyle')) $('ansRevAnimStyle').value = c.animationStyle || 'pop-in';
    if ($('ansRevDurationSec')) $('ansRevDurationSec').value = c.durationSec !== undefined ? c.durationSec : 0.40;
  }

  function updateAnswerRevealFromUi(triggerAnimDemo = false) {
    const { SceneModel } = getDeps();
    if (!SceneModel || !SceneModel.normalizeAnswerRevealConfig) return;
    ensureInitialized();
    const raw = {
      style: $('ansRevStyle') ? $('ansRevStyle').value : state.answerRevealConfig.style,
      highlightBg: $('ansRevHighlightBg') ? $('ansRevHighlightBg').value : state.answerRevealConfig.highlightBg,
      badgeBg: $('ansRevBadgeBg') ? $('ansRevBadgeBg').value : state.answerRevealConfig.badgeBg,
      badgeTickColor: $('ansRevTickColor') ? $('ansRevTickColor').value : state.answerRevealConfig.badgeTickColor,
      correctTextColor: $('ansRevTextColor') ? $('ansRevTextColor').value : state.answerRevealConfig.correctTextColor,
      correctBorderColor: $('ansRevBorderColor') ? $('ansRevBorderColor').value : state.answerRevealConfig.correctBorderColor,
      correctBorderWidth: $('ansRevBorderWidth') ? Number($('ansRevBorderWidth').value) : state.answerRevealConfig.correctBorderWidth,
      dimBg: $('ansRevDimBg') ? $('ansRevDimBg').value : state.answerRevealConfig.dimBg,
      dimTextColor: $('ansRevDimTextColor') ? $('ansRevDimTextColor').value : state.answerRevealConfig.dimTextColor,
      dimBadgeBg: $('ansRevDimBadgeBg') ? $('ansRevDimBadgeBg').value : state.answerRevealConfig.dimBadgeBg,
      dimBadgeTextColor: $('ansRevDimBadgeTextColor') ? $('ansRevDimBadgeTextColor').value : state.answerRevealConfig.dimBadgeTextColor,
      dimBorderColor: $('ansRevDimBorderColor') ? $('ansRevDimBorderColor').value : state.answerRevealConfig.dimBorderColor,
      dimWrongBgEnabled: $('ansRevDimBgEnabled') ? $('ansRevDimBgEnabled').checked : state.answerRevealConfig.dimWrongBgEnabled,
      dimOpacity: $('ansRevDimOpacity') ? Number($('ansRevDimOpacity').value) : state.answerRevealConfig.dimOpacity,
      glowEnabled: $('ansRevGlowEnabled') ? $('ansRevGlowEnabled').checked : state.answerRevealConfig.glowEnabled,
      glowColor: $('ansRevGlowColor') ? $('ansRevGlowColor').value : state.answerRevealConfig.glowColor,
      scaleBoost: $('ansRevScaleBoost') ? Number($('ansRevScaleBoost').value) : state.answerRevealConfig.scaleBoost,
      animationStyle: $('ansRevAnimStyle') ? $('ansRevAnimStyle').value : state.answerRevealConfig.animationStyle,
      durationSec: $('ansRevDurationSec') ? Number($('ansRevDurationSec').value) : state.answerRevealConfig.durationSec
    };
    state.answerRevealConfig = SceneModel.normalizeAnswerRevealConfig(raw);
    if (state.scene) state.scene.answerRevealConfig = state.answerRevealConfig;
    if (state.revealConfig && state.revealConfig.answerReveal) {
      state.revealConfig.answerReveal.style = state.answerRevealConfig.animationStyle;
      state.revealConfig.answerReveal.durationSec = state.answerRevealConfig.durationSec;
    }
    if (typeof root.THEME !== 'undefined') {
      root.THEME.correctFill = state.answerRevealConfig.highlightBg;
      if ($('th_correctFill')) $('th_correctFill').value = state.answerRevealConfig.highlightBg;
    }
    if ($('ansRevDimOpacityV')) $('ansRevDimOpacityV').textContent = Math.round(state.answerRevealConfig.dimOpacity * 100) + '%';
    if ($('ansRevScaleBoostV')) $('ansRevScaleBoostV').textContent = Number(state.answerRevealConfig.scaleBoost).toFixed(2) + 'x';
    if (state.activeAnimTarget === 'answerReveal') syncAnimTargetUi();
    if (typeof root.renderPreview === 'function') root.renderPreview(true, 0);
    if (triggerAnimDemo) playAnimLiveDemo('answerReveal');
    if (typeof root.scheduleSave === 'function') root.scheduleSave();
  }

  function wireAnswerRevealEvents() {
    [
      ['ansRevStyle', 'change', true],
      ['ansRevHighlightBg', 'input', false],
      ['ansRevHighlightBg', 'change', true],
      ['ansRevBadgeBg', 'input', false],
      ['ansRevBadgeBg', 'change', true],
      ['ansRevTickColor', 'input', false],
      ['ansRevTickColor', 'change', true],
      ['ansRevTextColor', 'input', false],
      ['ansRevTextColor', 'change', true],
      ['ansRevBorderColor', 'input', false],
      ['ansRevBorderColor', 'change', true],
      ['ansRevBorderWidth', 'input', false],
      ['ansRevBorderWidth', 'change', true],
      ['ansRevDimBg', 'input', false],
      ['ansRevDimBg', 'change', true],
      ['ansRevDimTextColor', 'input', false],
      ['ansRevDimTextColor', 'change', true],
      ['ansRevDimBadgeBg', 'input', false],
      ['ansRevDimBadgeBg', 'change', true],
      ['ansRevDimBadgeTextColor', 'input', false],
      ['ansRevDimBadgeTextColor', 'change', true],
      ['ansRevDimBorderColor', 'input', false],
      ['ansRevDimBorderColor', 'change', true],
      ['ansRevDimBgEnabled', 'change', true],
      ['ansRevDimOpacity', 'input', false],
      ['ansRevDimOpacity', 'change', true],
      ['ansRevGlowEnabled', 'change', true],
      ['ansRevGlowColor', 'input', false],
      ['ansRevGlowColor', 'change', true],
      ['ansRevScaleBoost', 'input', false],
      ['ansRevAnimStyle', 'change', true],
      ['ansRevDurationSec', 'input', true]
    ].forEach(([id, evt, demo]) => {
      const el = $(id);
      if (el) el.addEventListener(evt, () => updateAnswerRevealFromUi(demo));
    });

    if ($('btnPreviewAnswerReveal')) {
      $('btnPreviewAnswerReveal').onclick = async () => {
        ensureInitialized();
        if (typeof root.renderPreview === 'function') root.renderPreview(true, 0);
        await playAnimLiveDemo('answerReveal');
      };
    }
  }

  function buildRevealAndTransitionUi() {
    const vs = $('videoSettings');
    if (!vs || $('qspAnimSection')) return;
    const content = vs.querySelector('.content');
    if (!content) return;

    const ttsPanel = $('ttsPanel');
    buildAnswerRevealUi(content, ttsPanel);

    const { TextReveal, Transitions } = getDeps();
    const sec = document.createElement('div');
    sec.id = 'qspAnimSection';
    sec.className = 'section';
    sec.style.cssText = 'margin:14px 0;padding:12px;background:#14161d;border:1px solid #2b3240;border-radius:10px';

    const revOpts = (TextReveal ? TextReveal.REVEAL_STYLES : []).map(s => `<option value="${s.id}">${s.label}</option>`).join('');
    const pageOpts = (Transitions ? Transitions.PAGE_TURN_TRANSITIONS : []).map(t => `<option value="${t.id}">${t.label}</option>`).join('');
    const qOpts = (Transitions ? Transitions.QUESTION_TRANSITIONS : []).map(t => `<option value="${t.id}">${t.label}</option>`).join('');
    const targetTabs = ANIM_TARGETS.map(t => `
      <button type="button" class="btn mini" data-anim-target="${t.id}" style="min-height:40px;font-weight:700">${t.label}</button>
    `).join('');

    sec.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:8px">
        <label class="label" style="color:#a78bfa;margin:0">✨ Live Text Reveal &amp; Transition Animation Editor</label>
        <span id="animSaveStatus" class="hint" style="margin:0;color:#4ade80;font-weight:700">✓ Animations ready</span>
      </div>
      <div id="animTargetTabs" class="row" style="gap:6px;flex-wrap:wrap;margin-bottom:10px">
        ${targetTabs}
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:8px;margin-bottom:8px">
        <div>
          <label class="hint" style="margin:0 0 3px;display:block">Animation Style (16)</label>
          <select id="animStyle" style="min-height:44px">${revOpts}</select>
        </div>
        <div>
          <label class="hint" style="margin:0 0 3px;display:block">Duration (s)</label>
          <input type="number" id="animDuration" min="0.1" max="4.0" step="0.05" value="0.50" style="min-height:44px">
        </div>
        <div>
          <label class="hint" style="margin:0 0 3px;display:block">Delay (s)</label>
          <input type="number" id="animDelay" min="0" max="2.5" step="0.05" value="0.00" style="min-height:44px">
        </div>
        <div>
          <label class="hint" style="margin:0 0 3px;display:block">Stagger (s)</label>
          <input type="number" id="animStagger" min="0" max="0.5" step="0.02" value="0.05" style="min-height:44px">
        </div>
        <div>
          <label class="hint" style="margin:0 0 3px;display:block">Easing</label>
          <select id="animEasing" style="min-height:44px">
            <option value="ease-out">Ease Out</option>
            <option value="ease-in-out">Ease In-Out</option>
            <option value="linear">Linear</option>
            <option value="spring">Spring Bounce</option>
          </select>
        </div>
        <div>
          <label class="hint" style="margin:0 0 3px;display:block">Direction</label>
          <select id="animDirection" style="min-height:44px">
            <option value="auto">Auto</option>
            <option value="left">From Left</option>
            <option value="right">From Right</option>
            <option value="top">From Top</option>
            <option value="bottom">From Bottom</option>
          </select>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:8px;margin-bottom:10px;padding-top:8px;border-top:1px solid #262c3a">
        <div>
          <label class="hint" style="margin:0 0 3px;display:block">Question Transition (24)</label>
          <select id="transStyle" style="min-height:44px">
            <optgroup label="Page-Turn Transitions (10)">${pageOpts}</optgroup>
            <optgroup label="Question Transitions (14)">${qOpts}</optgroup>
          </select>
        </div>
        <div>
          <label class="hint" style="margin:0 0 3px;display:block">Transition Duration (s)</label>
          <input type="number" id="transDur" min="0.3" max="2.0" step="0.05" value="0.72" style="min-height:44px">
        </div>
        <div>
          <label class="hint" style="margin:0 0 3px;display:block">Transition Easing</label>
          <select id="transEase" style="min-height:44px"><option value="ease-in-out" selected>Ease In-Out</option><option value="ease-out">Ease Out</option><option value="linear">Linear</option></select>
        </div>
      </div>

      <div class="row" style="gap:12px;align-items:center;flex-wrap:wrap;margin-bottom:8px">
        <label class="hint" style="margin:0;display:inline-flex;align-items:center;gap:6px;min-height:40px;cursor:pointer"><input type="checkbox" id="revSyncEnabled" checked style="width:auto"> Voice-Synced Reveal</label>
        <label class="hint" style="margin:0;display:inline-flex;align-items:center;gap:6px;min-height:40px;cursor:pointer"><input type="checkbox" id="transShadows" checked style="width:auto"> Page Shadows</label>
      </div>

      <div style="background:#0b0f17;border:1px solid #283244;border-radius:10px;padding:10px;margin-bottom:10px">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px">
          <span id="animDemoCaption" class="hint" style="margin:0;color:#93c5fd;font-weight:700">Live Engine Demo Preview</span>
          <div class="row" style="gap:6px">
            <button type="button" class="btn mini" id="btnReplayAnimDemo" style="min-height:40px">↻ Replay Demo</button>
            <button type="button" class="btn mini" id="btnPreviewReveal" style="min-height:40px">▶ Full Stage Reveal</button>
            <button type="button" class="btn mini" id="btnPreviewTransition" style="min-height:40px">▶ Preview Transition</button>
          </div>
        </div>
        <canvas id="animLiveDemoCanvas" width="640" height="220" style="width:100%;max-width:640px;height:auto;border-radius:8px;display:block;margin:0 auto;background:#090d14"></canvas>
      </div>

      <div class="row" style="gap:10px;align-items:center;flex-wrap:wrap">
        <button type="button" class="btn primary" id="btnSaveAnimChanges" style="min-height:48px;font-weight:800;padding:0 18px">💾 Save Animation Changes</button>
        <span id="animTargetSummary" class="hint" style="margin:0;font-size:11px"></span>
      </div>
    `;

    if (ttsPanel && ttsPanel.parentNode === content) content.insertBefore(sec, ttsPanel);
    else content.appendChild(sec);

    const diagBox = document.createElement('div');
    diagBox.id = 'qspDiagnosticsBox';
    diagBox.style.cssText = 'margin-top:12px;padding:10px;background:#111318;border:1px solid #262c38;border-radius:8px';
    diagBox.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap">
        <span style="font-size:12px;font-weight:700;color:#93c5fd">⚙ Hardware &amp; Encoder Diagnostics</span>
        <button type="button" class="btn mini" id="btnRunEncoderDiag">Run Capability &amp; Speed Benchmark</button>
      </div>
      <pre id="diagOutput" class="hint" style="margin:6px 0 0;white-space:pre-wrap;font-family:monospace;font-size:11px;max-height:140px;overflow:auto"></pre>
    `;
    content.appendChild(diagBox);

    wireAnimationAndDiagEvents();
    syncAnimTargetUi();
    syncTransitionUi();
  }

  function syncAnimTargetUi() {
    ensureInitialized();
    const target = state.activeAnimTarget || 'questionText';
    const roleCfg = (state.revealConfig && state.revealConfig[target]) || {
      style: 'typewriter-word', durationSec: 0.5, delaySec: 0, staggerSec: 0.05, easing: 'ease-out', direction: 'auto'
    };

    document.querySelectorAll('[data-anim-target]').forEach(btn => {
      const active = btn.dataset.animTarget === target;
      btn.style.background = active ? '#7c3aed' : '';
      btn.style.color = active ? '#ffffff' : '';
      btn.style.borderColor = active ? '#a78bfa' : '';
    });

    if ($('animStyle')) $('animStyle').value = roleCfg.style || 'typewriter-word';
    if ($('animDuration')) $('animDuration').value = roleCfg.durationSec !== undefined ? roleCfg.durationSec : 0.5;
    if ($('animDelay')) $('animDelay').value = roleCfg.delaySec !== undefined ? roleCfg.delaySec : 0;
    if ($('animStagger')) $('animStagger').value = roleCfg.staggerSec !== undefined ? roleCfg.staggerSec : 0.05;
    if ($('animEasing')) $('animEasing').value = roleCfg.easing || 'ease-out';
    if ($('animDirection')) $('animDirection').value = roleCfg.direction || 'auto';
    if ($('revSyncEnabled') && state.revealConfig) $('revSyncEnabled').checked = !!state.revealConfig.enabled;

    if ($('animTargetSummary') && state.revealConfig) {
      $('animTargetSummary').textContent = ANIM_TARGETS
        .map(t => `${t.label.split(' ')[0]}:${(state.revealConfig[t.id] && state.revealConfig[t.id].style) || 'none'}`)
        .join(' · ');
    }
  }

  function syncTransitionUi() {
    ensureInitialized();
    const tc = state.transitionConfig;
    if (!tc) return;
    if ($('transStyle')) $('transStyle').value = tc.style || 'classic-page-turn';
    if ($('transDur')) $('transDur').value = tc.durationSec !== undefined ? tc.durationSec : 0.72;
    if ($('transEase')) $('transEase').value = tc.easing || 'ease-in-out';
    if ($('transShadows')) $('transShadows').checked = tc.shadows !== false;
  }

  function markAnimUnsaved(unsaved) {
    state.hasUnsavedAnimChanges = !!unsaved;
    const stEl = $('animSaveStatus');
    if (stEl) {
      if (unsaved) {
        stEl.textContent = '● Unsaved animation changes';
        stEl.style.color = '#fbbf24';
      } else {
        stEl.textContent = '✓ Animation changes saved!';
        stEl.style.color = '#4ade80';
      }
    }
  }

  function saveAnimationChanges() {
    ensureInitialized();
    const { TextReveal, Transitions } = getDeps();
    if (TextReveal && state.revealConfig) {
      state.revealConfig = TextReveal.normalizeRevealConfig(state.revealConfig);
    }
    if (Transitions && state.transitionConfig) {
      state.transitionConfig = Transitions.normalizeTransitionConfig(state.transitionConfig);
    }
    if (state.answerRevealConfig && state.revealConfig && state.revealConfig.answerReveal) {
      state.answerRevealConfig.animationStyle = state.revealConfig.answerReveal.style;
      state.answerRevealConfig.durationSec = state.revealConfig.answerReveal.durationSec;
      syncAnswerRevealUi();
    }
    if (state.scene) {
      state.scene.answerRevealConfig = state.answerRevealConfig;
      state.scene.questionNumberConfig = state.questionNumberConfig;
    }
    markAnimUnsaved(false);
    if (typeof root.renderPreview === 'function') root.renderPreview();
    if (typeof root.__qspSaveProjectNow === 'function') root.__qspSaveProjectNow();
    else if (typeof root.scheduleSave === 'function') root.scheduleSave();
    return {
      revealConfig: state.revealConfig,
      transitionConfig: state.transitionConfig,
      answerRevealConfig: state.answerRevealConfig
    };
  }

  async function playAnimLiveDemo(targetOverride, demoMode = 'reveal') {
    ensureInitialized();
    const { TextReveal, SceneModel, Transitions } = getDeps();
    const canvas = $('animLiveDemoCanvas');
    if (!canvas || !TextReveal) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (state.demoRafId) {
      cancelAnimationFrame(state.demoRafId);
      state.demoRafId = 0;
    }
    const token = ++state.demoRunToken;
    const target = targetOverride || state.activeAnimTarget || 'questionText';
    const targetMeta = ANIM_TARGETS.find(t => t.id === target) || { label: target };
    const roleCfg = (state.revealConfig && state.revealConfig[target]) || TextReveal.normalizeRevealConfig({}).questionText;
    const W = canvas.width, H = canvas.height;
    const q = (root.questions && root.questions[Math.max(0, root.current || 0)]) || {
      question: 'Which planet is known as the Red Planet?',
      options: ['Venus', 'Mars', 'Jupiter', 'Saturn'],
      correct: 1
    };

    const caption = $('animDemoCaption');
    if (demoMode === 'transition' && Transitions) {
      if (caption) caption.textContent = `Transition Demo: ${state.transitionConfig.style} (${state.transitionConfig.durationSec}s)`;
      const prevSnap = document.createElement('canvas');
      prevSnap.width = W; prevSnap.height = H;
      const pCtx = prevSnap.getContext('2d');
      pCtx.fillStyle = '#1e293b';
      pCtx.fillRect(0, 0, W, H);
      pCtx.fillStyle = '#94a3b8';
      pCtx.font = '800 28px sans-serif';
      pCtx.textAlign = 'center';
      pCtx.textBaseline = 'middle';
      pCtx.fillText('PREVIOUS QUESTION · 01 / 10', W / 2, H / 2);

      const durMs = Math.max(300, (state.transitionConfig.durationSec || 0.72) * 1000);
      const t0 = performance.now();
      return new Promise(resolve => {
        const tick = now => {
          if (token !== state.demoRunToken) { resolve(); return; }
          const p = Math.min(1, (now - t0) / durMs);
          ctx.fillStyle = '#0f172a';
          ctx.fillRect(0, 0, W, H);
          ctx.fillStyle = '#f8fafc';
          ctx.font = '800 28px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('NEXT QUESTION · 02 / 10', W / 2, H / 2);
          Transitions.drawTransition(ctx, W, H, p, prevSnap, state.transitionConfig);
          if (p < 1) {
            state.demoRafId = requestAnimationFrame(tick);
          } else {
            state.demoRafId = 0;
            resolve();
          }
        };
        state.demoRafId = requestAnimationFrame(tick);
      });
    }

    if (caption) caption.textContent = `Live Demo · ${targetMeta.label} (${roleCfg.style}, ${roleCfg.durationSec}s, ${roleCfg.easing})`;

    const durSec = Math.max(0.35, Number(roleCfg.durationSec) || 0.6);
    const delaySec = Math.max(0, Number(roleCfg.delaySec) || 0);
    const totalSec = delaySec + durSec + 0.35;
    const t0 = performance.now();

    const locale = (root.QuizNarrationL10n && typeof root.ttsVoiceId === 'function')
      ? root.QuizNarrationL10n.resolveLocaleFromVoice(root.ttsVoiceId(), (root.TTS && root.TTS.voices) || [])
      : 'en-US';
    const answerIntroPhrase = root.QuizNarrationL10n
      ? root.QuizNarrationL10n.buildAnswerIntroPhrase(locale)
      : 'The answer is';
    const sampleQNum = SceneModel && SceneModel.formatQuestionNumber
      ? SceneModel.formatQuestionNumber(Math.max(0, root.current || 0), Math.max(1, (root.questions || []).length || 20), state.questionNumberConfig)
      : '01 / 20';

    const sampleText = target === 'questionNumber'
      ? sampleQNum
      : target === 'optionLabel'
        ? 'A'
        : target === 'optionText'
          ? (q.options[0] || 'Mars')
          : target === 'answerIntro'
            ? answerIntroPhrase
            : target === 'answerReveal'
              ? `✓ ${(q.options[q.correct] || 'Mars')}`
              : q.question;

    return new Promise(resolve => {
      const renderDemoFrame = now => {
        if (token !== state.demoRunToken) { resolve(); return; }
        const elapsed = (now - t0) / 1000;
        const rev = TextReveal.evaluateReveal(target, sampleText, 0, Math.max(0.15, durSec), elapsed, {
          ...state.revealConfig,
          enabled: true
        }, false);

        ctx.clearRect(0, 0, W, H);
        ctx.fillStyle = '#090d14';
        ctx.fillRect(0, 0, W, H);

        // Subtle grid guide
        ctx.strokeStyle = 'rgba(148,163,184,0.10)';
        ctx.lineWidth = 1;
        ctx.strokeRect(16, 16, W - 32, H - 32);

        if (rev.visible) {
          ctx.save();
          ctx.globalAlpha = Math.max(0, Math.min(1, rev.opacity));
          if (rev.blurPx > 0.2 && typeof ctx.filter === 'string') {
            ctx.filter = `blur(${rev.blurPx.toFixed(1)}px)`;
          }
          const cx = W / 2 + (rev.offsetXFrac || 0) * W;
          const cy = H / 2 + (rev.offsetYFrac || 0) * H;
          ctx.translate(cx, cy);
          const sc = rev.scale || 1;
          ctx.scale(sc, sc);
          ctx.translate(-cx, -cy);

          if (rev.clipFrac !== undefined && rev.clipFrac < 0.999) {
            ctx.beginPath();
            ctx.rect(24, 24, (W - 48) * rev.clipFrac, H - 48);
            ctx.clip();
          }

          if (target === 'answerReveal') {
            const ansCfg = state.answerRevealConfig || {};
            const drawSlot = (bx, by, bw, bh, rad, bgCol, bCol, bWidth, badgeCol, badgeGlyph, badgeGlyphCol, txt, txtCol, alphaMul, useGlow) => {
              ctx.save();
              ctx.globalAlpha *= alphaMul;
              ctx.fillStyle = bgCol;
              if (useGlow) {
                ctx.shadowColor = ansCfg.glowColor || ansCfg.highlightBg || '#22c55e';
                ctx.shadowBlur = 16;
              }
              ctx.beginPath();
              if (ctx.roundRect) ctx.roundRect(bx, by, bw, bh, rad);
              else ctx.rect(bx, by, bw, bh);
              ctx.fill();
              ctx.shadowBlur = 0;
              if (bWidth > 0 && bCol) {
                ctx.strokeStyle = bCol;
                ctx.lineWidth = bWidth;
                ctx.stroke();
              }
              const br = bh * 0.36;
              const badgeCx = bx + bh * 0.55;
              const badgeCy = by + bh / 2;
              ctx.fillStyle = badgeCol;
              ctx.beginPath();
              ctx.arc(badgeCx, badgeCy, br, 0, Math.PI * 2);
              ctx.fill();
              ctx.fillStyle = badgeGlyphCol;
              ctx.font = '800 18px sans-serif';
              ctx.textAlign = 'center';
              ctx.textBaseline = 'middle';
              ctx.fillText(badgeGlyph, badgeCx, badgeCy + 1);
              ctx.fillStyle = txtCol;
              ctx.font = '800 22px sans-serif';
              ctx.fillText(txt, bx + bh + (bw - bh - 12) / 2, badgeCy, bw - bh - 24);
              ctx.restore();
            };

            const bw = 420;
            const bh = 58;
            const bx = cx - bw / 2;
            const correctY = H / 2 - bh - 6 + (rev.offsetYFrac || 0) * H;
            const wrongY = H / 2 + 12;
            const ansTxt = String((q.options && q.options[q.correct]) || 'MARS').toUpperCase();
            const wrongIdx = q.correct === 0 ? 1 : 0;
            const wrongTxt = String((q.options && q.options[wrongIdx]) || 'VENUS').toUpperCase();
            const isDim = ansCfg.style === 'highlight-dim-others' || !!ansCfg.dimWrongBgEnabled;

            drawSlot(
              bx, correctY, bw, bh, bh / 2,
              ansCfg.highlightBg || '#16a34a',
              ansCfg.correctBorderColor || '#ffffff',
              ansCfg.correctBorderWidth || 0,
              ansCfg.badgeBg || '#22c55e',
              '✓',
              ansCfg.badgeTickColor || '#ffffff',
              ansTxt,
              ansCfg.correctTextColor || '#ffffff',
              1,
              !!ansCfg.glowEnabled && ansCfg.style === 'strong-highlight'
            );

            drawSlot(
              bx, wrongY, bw, bh * 0.92, (bh * 0.92) / 2,
              isDim ? (ansCfg.dimBg || '#1e293b') : '#050505',
              isDim ? (ansCfg.dimBorderColor || '#475569') : '#000000',
              isDim ? 1.5 : 0,
              isDim ? (ansCfg.dimBadgeBg || '#334155') : '#ffff00',
              'ABCD'[wrongIdx],
              isDim ? (ansCfg.dimBadgeTextColor || '#cbd5e1') : '#000000',
              wrongTxt,
              isDim ? (ansCfg.dimTextColor || '#94a3b8') : '#ffffff',
              isDim ? Math.max(0.1, Math.min(1, Number(ansCfg.dimOpacity !== undefined ? ansCfg.dimOpacity : 0.88))) : 1,
              false
            );
            ctx.filter = 'none';
            ctx.restore();
          } else {
            if (target === 'questionNumber' || target === 'optionLabel') {
              const bw = target === 'optionLabel' ? 74 : 360;
              const bh = target === 'optionLabel' ? 74 : 84;
              const bx = cx - bw / 2;
              const by = cy - bh / 2;
              ctx.fillStyle = target === 'optionLabel' ? '#facc15' : '#1e1b08';
              ctx.beginPath();
              if (ctx.roundRect) ctx.roundRect(bx, by, bw, bh, 18);
              else ctx.rect(bx, by, bw, bh);
              ctx.fill();
            }

            const shown = rev.shownText !== null && rev.shownText !== undefined ? String(rev.shownText) : sampleText;
            ctx.fillStyle = target === 'optionLabel'
              ? '#111827'
              : target === 'questionNumber'
                ? '#ffd400'
                : '#f8fafc';
            ctx.font = '800 28px sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(shown, cx, cy, W - 72);
            ctx.filter = 'none';
            ctx.restore();
          }
        }

        if (elapsed < totalSec) {
          state.demoRafId = requestAnimationFrame(renderDemoFrame);
        } else {
          state.demoRafId = 0;
          resolve();
        }
      };
      state.demoRafId = requestAnimationFrame(renderDemoFrame);
    });
  }

  function wireAnimationAndDiagEvents() {
    const { TextReveal, Transitions, Diagnostics } = getDeps();

    document.querySelectorAll('[data-anim-target]').forEach(btn => {
      btn.addEventListener('click', () => {
        state.activeAnimTarget = btn.dataset.animTarget;
        syncAnimTargetUi();
        playAnimLiveDemo(state.activeAnimTarget);
      });
    });

    const syncActiveRole = () => {
      ensureInitialized();
      if (!TextReveal) return;
      const target = state.activeAnimTarget || 'questionText';
      const rolePatch = {
        style: $('animStyle') ? $('animStyle').value : 'typewriter-word',
        durationSec: $('animDuration') ? Number($('animDuration').value) : 0.5,
        delaySec: $('animDelay') ? Number($('animDelay').value) : 0,
        staggerSec: $('animStagger') ? Number($('animStagger').value) : 0.05,
        easing: $('animEasing') ? $('animEasing').value : 'ease-out',
        direction: $('animDirection') ? $('animDirection').value : 'auto'
      };
      const next = {
        ...state.revealConfig,
        enabled: $('revSyncEnabled') ? $('revSyncEnabled').checked : true,
        [target]: rolePatch
      };
      if (target === 'questionText') next.questionStyle = rolePatch.style;
      state.revealConfig = TextReveal.normalizeRevealConfig(next);
      if (target === 'answerReveal' && state.answerRevealConfig) {
        state.answerRevealConfig.animationStyle = state.revealConfig.answerReveal.style;
        state.answerRevealConfig.durationSec = state.revealConfig.answerReveal.durationSec;
        syncAnswerRevealUi();
      }
      syncAnimTargetUi();
      markAnimUnsaved(true);
      playAnimLiveDemo(target, 'reveal');
    };

    const syncTrans = () => {
      ensureInitialized();
      if (!Transitions) return;
      state.transitionConfig = Transitions.normalizeTransitionConfig({
        style: $('transStyle') ? $('transStyle').value : 'classic-page-turn',
        durationSec: $('transDur') ? (Number($('transDur').value) || 0.72) : 0.72,
        easing: $('transEase') ? $('transEase').value : 'ease-in-out',
        shadows: $('transShadows') ? $('transShadows').checked : true
      });
      markAnimUnsaved(true);
      playAnimLiveDemo(state.activeAnimTarget, 'transition');
    };

    ['animStyle', 'animDuration', 'animDelay', 'animStagger', 'animEasing', 'animDirection', 'revSyncEnabled'].forEach(id => {
      if ($(id)) $(id).addEventListener('change', syncActiveRole);
    });
    ['transStyle', 'transDur', 'transEase', 'transShadows'].forEach(id => {
      if ($(id)) $(id).addEventListener('change', syncTrans);
    });

    if ($('btnReplayAnimDemo')) {
      $('btnReplayAnimDemo').onclick = () => playAnimLiveDemo(state.activeAnimTarget, 'reveal');
    }

    if ($('btnSaveAnimChanges')) {
      $('btnSaveAnimChanges').onclick = () => {
        saveAnimationChanges();
        playAnimLiveDemo(state.activeAnimTarget, 'reveal');
      };
    }

    if ($('btnPreviewReveal')) {
      $('btnPreviewReveal').onclick = async () => {
        ensureInitialized();
        const { SceneRenderer, Timeline } = getDeps();
        const cv = $('pvCanvas');
        if (!cv || !SceneRenderer || !Timeline) return;
        const q = (root.questions && root.questions[Math.max(0, root.current || 0)]) || {
          question: 'Preview reveal animation sample question?',
          options: ['Alpha', 'Beta', 'Gamma', 'Delta'],
          correct: 1
        };
        const schedule = Timeline.buildRevealSchedule(q, 2.4, {
          timerDuration: 10,
          promptPrefixWords: q.promptPrefixWords || 0
        });
        const ctx = cv.getContext('2d');
        const start = performance.now();
        while (true) {
          const elapsed = (performance.now() - start) / 1000;
          if (elapsed > 2.6) break;
          const revStage = elapsed > 1.9;
          SceneRenderer.renderSceneFrame(ctx, cv.width, cv.height, state.scene, q, Math.max(0, root.current || 0), Math.max(1, (root.questions || []).length), {
            reveal: revStage,
            remaining: revStage ? 0 : 10,
            timerDuration: 10,
            revealConfig: state.revealConfig,
            answerRevealConfig: state.answerRevealConfig,
            questionNumberConfig: state.questionNumberConfig,
            revealSchedule: schedule,
            voiceElapsedSec: elapsed,
            revealElapsedSec: revStage ? (elapsed - 1.9) : null,
            isPostVoice: revStage,
            rendererCtx: state.rendererCtx
          });
          await new Promise(r => setTimeout(r, 32));
        }
        if (typeof root.renderPreview === 'function') root.renderPreview();
      };
    }

    if ($('btnPreviewTransition')) {
      $('btnPreviewTransition').onclick = async () => {
        ensureInitialized();
        const { Transitions, SceneRenderer } = getDeps();
        const cv = $('pvCanvas');
        if (!cv || !Transitions || !SceneRenderer) return;
        const snap = document.createElement('canvas');
        snap.width = cv.width; snap.height = cv.height;
        snap.getContext('2d').drawImage(cv, 0, 0);
        const ctx = cv.getContext('2d');
        const nextQ = (root.questions && root.questions[(Math.max(0, root.current || 0) + 1) % Math.max(1, (root.questions || []).length)]) || {
          question: 'Next question transition preview',
          options: ['One', 'Two', 'Three', 'Four'],
          correct: 0
        };
        const durMs = (state.transitionConfig.durationSec || 0.72) * 1000;
        const t0 = performance.now();
        while (true) {
          const p = Math.min(1, (performance.now() - t0) / durMs);
          SceneRenderer.renderSceneFrame(ctx, cv.width, cv.height, state.scene, nextQ, 1, Math.max(1, (root.questions || []).length), {
            reveal: false,
            remaining: 10,
            answerRevealConfig: state.answerRevealConfig,
            questionNumberConfig: state.questionNumberConfig,
            rendererCtx: state.rendererCtx
          });
          Transitions.drawTransition(ctx, cv.width, cv.height, p, snap, state.transitionConfig);
          if (p >= 1) break;
          await new Promise(r => setTimeout(r, 20));
        }
        if (typeof root.renderPreview === 'function') root.renderPreview();
      };
    }

    if ($('btnRunEncoderDiag') && Diagnostics) {
      $('btnRunEncoderDiag').onclick = async () => {
        const out = $('diagOutput');
        if (out) out.textContent = 'Probing WebCodecs / Android MediaCodec capabilities & running micro-benchmark…';
        try {
          const probe = await Diagnostics.probeCapabilities(1920, 1080, 24);
          let bench = null;
          if (probe.webcodecsAvailable) {
            bench = await Diagnostics.runComparativeBenchmark(1280, 720, 24, 24);
          }
          const bridgeMode = (root.AndroidBridge && root.AndroidBridge.prepareNativeSceneExport)
            ? 'NATIVE_SCENE_DIRECT + NATIVE_RGBA_STREAM (Kotlin EGL+MediaCodec)'
            : 'Browser Only';
          const summary = {
            androidBridge: bridgeMode,
            webcodecsProbe: probe,
            microBenchmark720p: bench || 'WebCodecs VideoEncoder unavailable in this WebView; using Native Kotlin MediaCodec direct pipeline.'
          };
          if (out) out.textContent = JSON.stringify(summary, null, 2);
        } catch (err) {
          if (out) out.textContent = 'Diagnostics error: ' + err.message;
        }
      };
    }
  }

  function enhanceCanvaOAuthUi() {
    const canvaInput = $('canvaUrlInput');
    if (!canvaInput || $('canvaOAuthRow')) return;
    const parent = canvaInput.closest('.section');
    if (!parent) return;

    const { CanvaConnect } = getDeps();
    const row = document.createElement('div');
    row.id = 'canvaOAuthRow';
    row.style.cssText = 'display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:8px';
    const currentId = CanvaConnect ? CanvaConnect.getConfiguredClientId() : '';
    const hasTok = CanvaConnect ? !!CanvaConnect.getStoredToken() : false;
    row.innerHTML = `
      <input id="canvaClientIdInput" placeholder="Canva OAuth Client ID (optional if built-in)" value="${currentId}" style="flex:1;min-width:190px;font-size:12px">
      <button type="button" class="btn mini" id="canvaAuthBtn">${hasTok ? '✓ Canva Connected (Reconnect)' : '🔗 Connect Canva OAuth'}</button>
    `;
    const statusEl = $('canvaStatus');
    parent.insertBefore(row, statusEl);

    if ($('canvaAuthBtn')) {
      $('canvaAuthBtn').onclick = async () => {
        if (!CanvaConnect) return;
        const cid = ($('canvaClientIdInput') && $('canvaClientIdInput').value.trim()) || '';
        if (cid) CanvaConnect.setClientId(cid);
        const res = await CanvaConnect.startOAuthFlow(cid);
        if (!res.ok) {
          if (statusEl) { statusEl.textContent = res.message; statusEl.style.color = '#f59e0b'; }
          return;
        }
        if (statusEl) {
          statusEl.textContent = res.launched
            ? 'Canva sign-in opened in browser. Complete authorization to return to Quiz Studio Pro.'
            : 'Open Canva authorization URL: ' + res.authUrl;
          statusEl.style.color = '#60a5fa';
        }
      };
    }

    root.onCanvaAuthCallback = async (payload) => {
      if (!CanvaConnect) return;
      try {
        await CanvaConnect.exchangeAuthCallback(payload);
        if ($('canvaAuthBtn')) $('canvaAuthBtn').textContent = '✓ Canva Connected';
        if (statusEl) { statusEl.textContent = '✓ Canva OAuth connected! Click Import Canva Project.'; statusEl.style.color = '#3ddc84'; }
      } catch (err) {
        if (statusEl) { statusEl.textContent = 'Canva OAuth failed: ' + err.message; statusEl.style.color = '#ff6b6b'; }
      }
    };

    try {
      if (root.AndroidBridge && root.AndroidBridge.consumePendingCanvaCallback) {
        const pending = root.AndroidBridge.consumePendingCanvaCallback();
        if (pending && pending !== '{}') {
          const parsed = JSON.parse(pending);
          if (parsed && (parsed.code || parsed.error)) root.onCanvaAuthCallback(parsed);
        }
      }
    } catch (_) {}
  }

  function wireInspectorEvents() {
    const { SceneModel } = getDeps();
    if (!SceneModel) return;

    const typeSel = $('inspType');
    if (typeSel) {
      typeSel.innerHTML = SceneModel.ELEMENT_TYPES.map(t => `<option value="${t}">${t}</option>`).join('');
      typeSel.onchange = () => mutateSelected({ type: typeSel.value });
    }

    if ($('inspUseDefault')) $('inspUseDefault').onclick = switchToDefaultMode;
    if ($('inspBlankCanvas')) $('inspBlankCanvas').onclick = switchToBlankCanvas;

    if ($('inspAddText')) {
      $('inspAddText').onclick = () => {
        ensureInitialized();
        const res = SceneModel.addElement(state.scene, {
          type: 'text',
          name: 'Custom Text',
          text: 'YOUR TEXT HERE',
          x: 0.25, y: 0.42, width: 0.50, height: 0.12,
          fontSize: 0.05, textColor: '#ffffff', backgroundColor: 'transparent', isUserAdded: true
        });
        state.scene = res.scene;
        state.selectedId = res.element.id;
        refreshInspectorLists();
        if (typeof root.renderPreview === 'function') root.renderPreview();
      };
    }
    if ($('inspAddShape')) {
      $('inspAddShape').onclick = () => {
        ensureInitialized();
        const res = SceneModel.addElement(state.scene, {
          type: 'shape',
          name: 'Accent Shape',
          x: 0.30, y: 0.38, width: 0.40, height: 0.16,
          backgroundColor: '#2563eb', borderColor: '#ffffff', borderWidth: 2, borderRadius: 0.2, isUserAdded: true
        });
        state.scene = res.scene;
        state.selectedId = res.element.id;
        refreshInspectorLists();
        if (typeof root.renderPreview === 'function') root.renderPreview();
      };
    }
    if ($('inspAddIcon')) {
      $('inspAddIcon').onclick = () => {
        ensureInitialized();
        const res = SceneModel.addElement(state.scene, {
          type: 'icon',
          name: 'Star Badge Icon',
          iconGlyph: '★',
          x: 0.84, y: 0.18, width: 0.09, height: 0.12,
          textColor: '#facc15', backgroundColor: 'transparent', isUserAdded: true
        });
        state.scene = res.scene;
        state.selectedId = res.element.id;
        refreshInspectorLists();
        if (typeof root.renderPreview === 'function') root.renderPreview();
      };
    }
    if ($('inspAddImageInput')) {
      $('inspAddImageInput').onchange = e => {
        const f = e.target.files && e.target.files[0];
        e.target.value = '';
        if (!f) return;
        const fr = new FileReader();
        fr.onload = ev => {
          ensureInitialized();
          const key = 'user_img_' + Date.now();
          state.scene.assets = state.scene.assets || {};
          state.scene.assets[key] = ev.target.result;
          const res = SceneModel.addElement(state.scene, {
            type: 'image',
            name: f.name.slice(0, 24),
            assetRef: key,
            x: 0.35, y: 0.30, width: 0.30, height: 0.30, borderRadius: 0.08, isUserAdded: true
          });
          state.scene = res.scene;
          state.selectedId = res.element.id;
          refreshInspectorLists();
          if (typeof root.renderPreview === 'function') root.renderPreview();
        };
        fr.readAsDataURL(f);
      };
    }

    document.querySelectorAll('[data-el-nudge]').forEach(btn => {
      btn.onclick = () => {
        if (!state.selectedId || !state.scene) return;
        const step = Number($('inspStep') ? $('inspStep').value : 0.01) || 0.01;
        state.scene = SceneModel.nudgeElement4Dir(state.scene, state.selectedId, btn.dataset.elNudge, step);
        refreshInspectorFields();
        if (typeof root.renderPreview === 'function') root.renderPreview();
      };
    });

    const numBind = (id, fn) => {
      const el = $(id);
      if (!el) return;
      el.addEventListener('change', () => fn(Number(el.value)));
    };
    numBind('inspX', v => mutateSelected({ x: v / 100 }));
    numBind('inspY', v => mutateSelected({ y: v / 100 }));
    numBind('inspW', v => mutateSelected({ width: Math.max(1, v) / 100 }));
    numBind('inspH', v => mutateSelected({ height: Math.max(1, v) / 100 }));
    numBind('inspRot', v => mutateSelected({ rotation: v }));
    numBind('inspFontSize', v => mutateSelected({ fontSize: Math.max(1, v) / 100 }));
    numBind('inspRadius', v => mutateSelected({ borderRadius: v }));

    if ($('inspTextCol')) $('inspTextCol').oninput = e => mutateSelected({ textColor: e.target.value });
    if ($('inspBgCol')) $('inspBgCol').oninput = e => mutateSelected({ backgroundColor: e.target.value });
    if ($('inspBorderCol')) $('inspBorderCol').oninput = e => mutateSelected({ borderColor: e.target.value, borderWidth: Math.max(1, (selectedEl() && selectedEl().borderWidth) || 2) });
    if ($('inspOp')) $('inspOp').oninput = e => { if ($('inspOpV')) $('inspOpV').textContent = Math.round(e.target.value * 100) + '%'; mutateSelected({ opacity: Number(e.target.value) }); };
    if ($('inspText')) $('inspText').oninput = e => mutateSelected({ text: e.target.value });

    if ($('inspLayerUp')) $('inspLayerUp').onclick = () => { if (!state.selectedId) return; state.scene = SceneModel.reorderLayer(state.scene, state.selectedId, 'up'); refreshInspectorLists(); if (root.renderPreview) root.renderPreview(); };
    if ($('inspLayerDown')) $('inspLayerDown').onclick = () => { if (!state.selectedId) return; state.scene = SceneModel.reorderLayer(state.scene, state.selectedId, 'down'); refreshInspectorLists(); if (root.renderPreview) root.renderPreview(); };
    if ($('inspDupEl')) $('inspDupEl').onclick = () => { if (!state.selectedId) return; const r = SceneModel.duplicateElement(state.scene, state.selectedId); state.scene = r.scene; if (r.element) state.selectedId = r.element.id; refreshInspectorLists(); if (root.renderPreview) root.renderPreview(); };
    if ($('inspLockEl')) $('inspLockEl').onclick = () => { const el = selectedEl(); if (!el) return; state.scene = SceneModel.updateElement(state.scene, el.id, { locked: !el.locked }); refreshInspectorFields(); };
    if ($('inspDelEl')) $('inspDelEl').onclick = () => { if (!state.selectedId) return; state.scene = SceneModel.deleteElement(state.scene, state.selectedId); state.selectedId = null; refreshInspectorLists(); if (root.renderPreview) root.renderPreview(); };
    if ($('inspResetPos')) $('inspResetPos').onclick = () => { if (!state.selectedId) return; state.scene = SceneModel.resetElementPosition(state.scene, state.selectedId); refreshInspectorFields(); if (root.renderPreview) root.renderPreview(); };
    if ($('inspResetSize')) $('inspResetSize').onclick = () => { if (!state.selectedId) return; state.scene = SceneModel.resetElementSize(state.scene, state.selectedId); refreshInspectorFields(); if (root.renderPreview) root.renderPreview(); };
    if ($('inspTransparentBg')) $('inspTransparentBg').onclick = () => mutateSelected({ backgroundColor: 'transparent' });
    if ($('inspToggleVis')) $('inspToggleVis').onclick = () => { const el = selectedEl(); if (el) mutateSelected({ visible: !el.visible }); };
  }

  function selectedEl() {
    const { SceneModel } = getDeps();
    return (SceneModel && state.scene && state.selectedId) ? SceneModel.findElement(state.scene, state.selectedId) : null;
  }

  function mutateSelected(patch) {
    const { SceneModel } = getDeps();
    if (!SceneModel || !state.scene || !state.selectedId) return;
    state.scene = SceneModel.updateElement(state.scene, state.selectedId, patch);
    refreshInspectorFields();
    if (patch.textColor || patch.backgroundColor || patch.borderColor || patch.fontSize || patch.alignment || patch.borderRadius) {
      syncQuestionNumberUi();
    }
    if (typeof root.renderPreview === 'function') root.renderPreview();
  }

  function refreshInspectorLists() {
    ensureInitialized();
    const badge = $('inspModeBadge');
    if (badge && state.scene) {
      badge.textContent = state.scene.mode;
      badge.style.color = state.scene.mode === 'IMPORTED_TEMPLATE_MODE' ? '#38bdf8' : '#ffb8b3';
    }
    const list = $('inspLayerList');
    if (list && state.scene) {
      list.innerHTML = '';
      const els = [...state.scene.elements].sort((a, b) => (b.layerOrder || 0) - (a.layerOrder || 0));
      els.forEach(el => {
        const row = document.createElement('div');
        row.className = 'q-item' + (el.id === state.selectedId ? ' active' : '');
        row.style.cursor = 'pointer';
        const conf = el.confidence !== null && el.confidence !== undefined ? ` (${Math.round(el.confidence * 100)}%)` : '';
        row.innerHTML = `<span class="num">${el.layerOrder}</span><span class="qtext">${el.visible ? '' : '🚫 '}${el.locked ? '🔒 ' : ''}${el.name}${conf}</span><span class="hint" style="margin:0;font-size:10px">${el.type}</span>`;
        row.onclick = () => {
          state.selectedId = el.id;
          refreshInspectorLists();
          if (typeof root.renderPreview === 'function') root.renderPreview();
        };
        list.appendChild(row);
      });
    }
    refreshInspectorFields();
  }

  function refreshInspectorFields() {
    const el = selectedEl();
    const noSel = $('inspNoSel');
    const ctrls = $('inspControls');
    if (!noSel || !ctrls) return;
    if (!el) {
      noSel.classList.remove('hidden');
      ctrls.classList.add('hidden');
      return;
    }
    noSel.classList.add('hidden');
    ctrls.classList.remove('hidden');

    if ($('inspSelTitle')) $('inspSelTitle').textContent = `${el.name} [${el.type}]` + (el.editable === false ? ' · Flattened' : '');
    if ($('inspLockEl')) $('inspLockEl').textContent = el.locked ? '🔒' : '🔓';
    if ($('inspX')) $('inspX').value = (el.x * 100).toFixed(1);
    if ($('inspY')) $('inspY').value = (el.y * 100).toFixed(1);
    if ($('inspW')) $('inspW').value = (el.width * 100).toFixed(1);
    if ($('inspH')) $('inspH').value = (el.height * 100).toFixed(1);
    if ($('inspRot')) $('inspRot').value = Math.round(el.rotation || 0);
    if ($('inspType')) $('inspType').value = el.type;
    if ($('inspTextCol') && /^#[0-9a-f]{6}$/i.test(el.textColor || '')) $('inspTextCol').value = el.textColor;
    if ($('inspBgCol') && /^#[0-9a-f]{6}$/i.test(el.backgroundColor || '')) $('inspBgCol').value = el.backgroundColor;
    if ($('inspBorderCol') && /^#[0-9a-f]{6}$/i.test(el.borderColor || '')) $('inspBorderCol').value = el.borderColor;
    if ($('inspOp')) $('inspOp').value = el.opacity !== undefined ? el.opacity : 1;
    if ($('inspOpV')) $('inspOpV').textContent = Math.round((el.opacity !== undefined ? el.opacity : 1) * 100) + '%';
    if ($('inspFontSize')) $('inspFontSize').value = ((el.fontSize || 0.045) * 100).toFixed(1);
    if ($('inspRadius')) $('inspRadius').value = el.borderRadius || 0;
    if ($('inspText')) $('inspText').value = el.text || '';
  }

  function wireCanvasPointerSelection() {
    const cv = $('pvCanvas');
    const { SceneModel } = getDeps();
    if (!cv || !SceneModel || cv.__qspPointerWired) return;
    cv.__qspPointerWired = true;

    const normCoords = e => {
      const r = cv.getBoundingClientRect();
      return {
        nx: Math.max(0, Math.min(1, (e.clientX - r.left) / Math.max(1, r.width))),
        ny: Math.max(0, Math.min(1, (e.clientY - r.top) / Math.max(1, r.height)))
      };
    };

    cv.addEventListener('pointerdown', e => {
      ensureInitialized();
      if (!state.scene) return;
      const { nx, ny } = normCoords(e);
      const hit = SceneModel.hitTest(state.scene, nx, ny, false);
      state.selectedId = hit ? hit.id : null;
      if (hit && !hit.locked && document.body.classList.contains('studio')) {
        state.dragging = { id: hit.id, startNx: nx, startNy: ny, origX: hit.x, origY: hit.y };
        try { cv.setPointerCapture(e.pointerId); } catch (_) {}
      }
      refreshInspectorLists();
      if (typeof root.renderPreview === 'function') root.renderPreview();
    });

    cv.addEventListener('pointermove', e => {
      if (!state.dragging || !state.scene) return;
      const { nx, ny } = normCoords(e);
      const dx = nx - state.dragging.startNx;
      const dy = ny - state.dragging.startNy;
      state.scene = SceneModel.moveElement(state.scene, state.dragging.id, state.dragging.origX + dx, state.dragging.origY + dy);
      refreshInspectorFields();
      if (typeof root.renderPreview === 'function') root.renderPreview();
    });

    const endDrag = () => { state.dragging = null; };
    cv.addEventListener('pointerup', endDrag);
    cv.addEventListener('pointercancel', endDrag);
  }

  function init() {
    ensureInitialized();
    buildInspectorPanelDom();
    buildRevealAndTransitionUi();
    enhanceCanvaOAuthUi();
    wireCanvasPointerSelection();
    refreshInspectorLists();
    setTimeout(() => playAnimLiveDemo(state.activeAnimTarget, 'reveal'), 120);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();

  root.QuizInspectorUI = {
    getState: () => state,
    setConfigs,
    syncSceneFromTheme,
    setImportedScene,
    switchToDefaultMode,
    switchToBlankCanvas,
    refreshInspectorLists,
    syncQuestionNumberUi,
    syncAnswerRevealUi,
    syncAnimTargetUi,
    playAnimLiveDemo,
    saveAnimationChanges
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
