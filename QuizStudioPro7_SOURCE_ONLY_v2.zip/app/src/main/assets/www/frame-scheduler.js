/* Quiz Studio Pro 7 — Export Engine V2: Intelligent Frame Deduplication & VFR Scheduler */
(function (root, factory) {
  const api = factory(
    root.QuizTimeline || (typeof require === 'function' ? require('./timeline-engine.js') : null)
  );
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.QuizFrameScheduler = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (Timeline) {
  'use strict';

  function findSegFast(segs, gt, ptrState) {
    if (Timeline && typeof Timeline.findSegmentAt === 'function') {
      const hit = Timeline.findSegmentAt(segs, gt, ptrState.ptr || 0);
      ptrState.ptr = hit.ptr;
      return hit.seg;
    }
    for (let i = 0; i < segs.length; i++) {
      const s = segs[i];
      if (gt >= s.start && gt < s.start + s.dur) return s;
    }
    return segs[segs.length - 1] || null;
  }

  function isDiscreteTextStyle(style) {
    return style === 'typewriter-word' ||
      style === 'word-by-word' ||
      style === 'typewriter-char' ||
      style === 'letter-by-letter' ||
      style === 'line-by-line' ||
      style === 'none';
  }

  function progressiveStepCount(text, frac, style) {
    const str = String(text || '');
    if (!str || frac <= 0) return 0;
    if (frac >= 0.999 || style === 'none') return str.length;
    if (style === 'typewriter-char' || style === 'letter-by-letter') {
      return Math.max(0, Math.min(str.length, Math.ceil(str.length * frac)));
    }
    const words = str.trim().split(/\s+/).filter(Boolean);
    return words.length ? Math.max(0, Math.min(words.length, Math.ceil(words.length * frac))) : 0;
  }

  function hasVisibleTimerElement(scene) {
    if (!scene || !Array.isArray(scene.elements) || !scene.elements.length) return true;
    return scene.elements.some(el => el && el.visible !== false && el.type === 'timer');
  }

  function resolveRoleStyle(revealConfig, roleName) {
    if (!revealConfig || revealConfig.enabled === false) return 'none';
    const role = revealConfig[roleName];
    if (role && role.style) return role.style;
    return revealConfig.questionStyle || 'typewriter-word';
  }

  function getScheduleCached(cacheMap, q, qIdx, seg, timerD) {
    const key = `${qIdx}|${seg.type}|${seg.dur.toFixed(4)}`;
    if (cacheMap.has(key)) return cacheMap.get(key);
    const sched = (Timeline && typeof Timeline.buildRevealSchedule === 'function')
      ? Timeline.buildRevealSchedule(q, seg.dur, { timerDuration: timerD, promptPrefixWords: (q && q.promptPrefixWords) || 0 })
      : null;
    cacheMap.set(key, sched);
    return sched;
  }

  /**
   * Determines if frame `f` has continuous per-frame motion (transitions, active non-discrete animations,
   * or moving timer bar), versus static holds / discrete text steps captured cleanly by `sigAt`.
   */
  function isDynAt(timeline, questions, fps, f, opts = {}, ptrState = { ptr: 0 }, schedCache = new Map()) {
    const segs = timeline && Array.isArray(timeline.segs) ? timeline.segs : [];
    if (!segs.length || !questions || !questions.length) return false;
    const gt = f / Math.max(1, fps);
    const seg = findSegFast(segs, gt, ptrState);
    if (!seg) return false;
    const lt = Math.max(0, gt - seg.start);
    const q = questions[seg.i] || questions[0];

    if (seg.type === 'page') {
      const tStyle = (opts.transitionConfig && opts.transitionConfig.style) || 'classic-page-turn';
      return tStyle !== 'none';
    }

    if (seg.type === 'count') {
      return hasVisibleTimerElement(opts.scene);
    }

    const revCfg = opts.revealConfig || {};
    const revEnabled = revCfg.enabled !== undefined ? !!revCfg.enabled : true;

    if (seg.type === 'reveal') {
      if (!revEnabled) return false;
      const ansCfg = opts.answerRevealConfig || {};
      const animStyle = ansCfg.animationStyle || (revCfg.answerReveal && revCfg.answerReveal.style) || 'pop-in';
      const animDur = Number(ansCfg.durationSec || (revCfg.answerReveal && revCfg.answerReveal.durationSec) || 0.4);
      if (animStyle === 'none') return false;
      return lt <= animDur + (1 / Math.max(1, fps));
    }

    if (seg.type === 'answer') {
      // Answer segment starts after reveal (`revealElapsed = 0.52 + lt`), so reveal animation has already settled.
      return false;
    }

    if (seg.type === 'voice') {
      if (!revEnabled) return false;
      const sched = getScheduleCached(schedCache, q, seg.i, seg, opts.timerDuration || 10);
      const qStyle = resolveRoleStyle(revCfg, 'questionText');
      const oStyle = resolveRoleStyle(revCfg, 'optionText');
      const lblStyle = resolveRoleStyle(revCfg, 'optionLabel');
      const numStyle = resolveRoleStyle(revCfg, 'questionNumber');

      // Check continuous (non-discrete) role animations currently active at local time `lt`
      if (!isDiscreteTextStyle(numStyle)) {
        const ns = sched ? sched.questionNumberStart : 0;
        const ne = Math.min(sched ? sched.questionNumberEnd : 0.45, ns + ((revCfg.questionNumber && revCfg.questionNumber.durationSec) || 0.35));
        if (lt >= ns && lt <= ne + (1 / fps)) return true;
      }
      if (!isDiscreteTextStyle(qStyle) && sched) {
        const qs = sched.questionStart || 0;
        const qe = Math.min(sched.questionEnd || seg.dur * 0.45, qs + ((revCfg.questionText && revCfg.questionText.durationSec) || 0.9));
        if (lt >= qs && lt <= qe + (1 / fps)) return true;
      }
      if (sched && Array.isArray(sched.options)) {
        for (let oi = 0; oi < sched.options.length; oi++) {
          const slot = sched.options[oi];
          if (!isDiscreteTextStyle(lblStyle)) {
            const ls = slot.labelStart || 0;
            const le = Math.min(slot.labelEnd || ls + 0.3, ls + ((revCfg.optionLabel && revCfg.optionLabel.durationSec) || 0.28));
            if (lt >= ls && lt <= le + (1 / fps)) return true;
          }
          if (!isDiscreteTextStyle(oStyle)) {
            const ts = slot.textStart || 0;
            const te = Math.min(slot.textEnd || ts + 0.5, ts + ((revCfg.optionText && revCfg.optionText.durationSec) || 0.45));
            if (lt >= ts && lt <= te + (1 / fps)) return true;
          }
        }
      }
      return false;
    }

    return false;
  }

  /**
   * Produces a deterministic state signature for frame `f`.
   * Any two consecutive frames in a static segment or between word/char steps with matching signatures
   * produce identical pixels.
   */
  function sigAt(timeline, questions, fps, f, opts = {}, ptrState = { ptr: 0 }, schedCache = new Map()) {
    const segs = timeline && Array.isArray(timeline.segs) ? timeline.segs : [];
    if (!segs.length || !questions || !questions.length) return 'empty';
    const gt = f / Math.max(1, fps);
    const seg = findSegFast(segs, gt, ptrState);
    if (!seg) return 'empty';
    const lt = Math.max(0, gt - seg.start);
    const qIdx = seg.i | 0;
    const q = questions[qIdx] || questions[0];
    const width = opts.width || 1920;

    if (seg.type === 'page') {
      const tStyle = (opts.transitionConfig && opts.transitionConfig.style) || 'classic-page-turn';
      if (tStyle === 'none') return `page_cut|${qIdx}`;
      const p = Math.max(0, Math.min(1, lt / Math.max(0.001, seg.dur)));
      return `page|${qIdx}|${tStyle}|${Math.round(p * width)}`;
    }

    if (seg.type === 'count') {
      if (!hasVisibleTimerElement(opts.scene)) return `count_static|${qIdx}`;
      const timerD = Math.max(1, Number(opts.timerDuration) || 10);
      const rem = Math.max(0, seg.dur - lt);
      const frac = Math.max(0, Math.min(1, rem / timerD));
      const barPx = Math.round(frac * (width * 0.6));
      const secShown = Math.ceil(rem - 1e-6);
      return `count|${qIdx}|${barPx}|${secShown}`;
    }

    const revCfg = opts.revealConfig || {};
    const revEnabled = revCfg.enabled !== undefined ? !!revCfg.enabled : true;

    if (seg.type === 'reveal' || seg.type === 'answer') {
      const ansCfg = opts.answerRevealConfig || {};
      const animStyle = ansCfg.animationStyle || (revCfg.answerReveal && revCfg.answerReveal.style) || 'pop-in';
      const animDur = Number(ansCfg.durationSec || (revCfg.answerReveal && revCfg.answerReveal.durationSec) || 0.4);
      const revElapsed = seg.type === 'reveal' ? lt : (0.52 + lt);
      if (!revEnabled || animStyle === 'none' || revElapsed >= animDur) {
        return `answer_settled|${qIdx}`;
      }
      return `answer_anim|${qIdx}|${Math.round((revElapsed / Math.max(0.05, animDur)) * 60)}`;
    }

    if (seg.type === 'voice') {
      if (!revEnabled) return `voice_instant|${qIdx}`;
      const sched = getScheduleCached(schedCache, q, qIdx, seg, opts.timerDuration || 10);
      const qStyle = resolveRoleStyle(revCfg, 'questionText');
      const oStyle = resolveRoleStyle(revCfg, 'optionText');
      const lblStyle = resolveRoleStyle(revCfg, 'optionLabel');
      const numStyle = resolveRoleStyle(revCfg, 'questionNumber');

      const qStart = sched ? sched.questionStart : 0;
      const qEnd = sched ? sched.questionEnd : seg.dur * 0.42;
      const qSpan = Math.max(0.05, qEnd - qStart);
      const qFrac = Math.max(0, Math.min(1, (lt - qStart) / qSpan));
      const qSig = isDiscreteTextStyle(qStyle)
        ? progressiveStepCount(q && q.question, qFrac, qStyle)
        : Math.round(qFrac * 30);

      const nStart = sched ? sched.questionNumberStart : 0;
      const nEnd = sched ? sched.questionNumberEnd : 0.45;
      const nVisible = lt >= nStart ? (isDiscreteTextStyle(numStyle) ? 1 : Math.round(Math.min(1, (lt - nStart) / Math.max(0.05, nEnd - nStart)) * 20)) : 0;

      const optSigs = [];
      const slots = (sched && Array.isArray(sched.options)) ? sched.options : [];
      for (let oi = 0; oi < 4; oi++) {
        const sl = slots[oi];
        const optTxt = (q && q.options && q.options[oi]) || '';
        const lStart = sl ? sl.labelStart : 0;
        const lEnd = sl ? sl.labelEnd : 0.3;
        const lVis = lt >= lStart ? (isDiscreteTextStyle(lblStyle) ? 1 : Math.round(Math.min(1, (lt - lStart) / Math.max(0.05, lEnd - lStart)) * 20)) : 0;
        const tStart = sl ? sl.textStart : 0.2;
        const tEnd = sl ? sl.textEnd : 0.8;
        const oFrac = Math.max(0, Math.min(1, (lt - tStart) / Math.max(0.05, tEnd - tStart)));
        const oStep = lt < tStart ? -1 : (isDiscreteTextStyle(oStyle) ? progressiveStepCount(optTxt, oFrac, oStyle) : Math.round(oFrac * 24));
        optSigs.push(`${lVis}:${oStep}`);
      }
      return `voice|${qIdx}|n${nVisible}|q${qSig}|${optSigs.join('|')}`;
    }

    return `other|${seg.type}|${qIdx}`;
  }

  /**
   * Builds a deduplicated VFR frame emission schedule with `prevDyn`, `prevSig`, `lastSub`,
   * GOP keyframe cadence, exact closing duration frame, and summary metrics.
   */
  function buildFrameSchedule(timeline, questions, fps, opts = {}) {
    const safeFps = Math.max(10, Math.min(60, fps | 0 || 24));
    const totalSec = Math.max(0, Number(timeline && timeline.total) || 0);
    const totalFrames = Math.max(1, opts.totalFrames || Math.round(totalSec * safeFps));
    const gopSec = Math.max(1, Math.min(5, Number(opts.gopSec) || 3));
    const maxHoldFrames = Math.max(safeFps, Math.round((Number(opts.maxHoldSec) || gopSec) * safeFps));

    const ptrDyn = { ptr: 0 };
    const ptrSig = { ptr: 0 };
    const schedCache = new Map();

    const raw = [];
    let prevDyn = true;
    let prevSig = '';
    let lastEmitted = -1;
    let lastKeyCandidate = 0;

    for (let f = 0; f < totalFrames; f++) {
      const dyn = isDynAt(timeline, questions, safeFps, f, opts, ptrDyn, schedCache);
      const sig = sigAt(timeline, questions, safeFps, f, opts, ptrSig, schedCache);
      const isFirst = f === 0;
      const isLast = f === totalFrames - 1;
      const sigChanged = sig !== prevSig;
      const holdExpired = (f - lastKeyCandidate) >= maxHoldFrames;

      if (isFirst) {
        raw.push({ frameIndex: f, reusePrevious: false, isDynamic: dyn, signature: sig, isAnchor: false });
        lastEmitted = f;
        lastKeyCandidate = f;
        prevDyn = dyn;
        prevSig = sig;
        continue;
      }

      if (dyn || sigChanged) {
        const lastSub = f - 1;
        if (lastSub > lastEmitted && (!prevDyn || sigChanged)) {
          raw.push({ frameIndex: lastSub, reusePrevious: true, isDynamic: false, signature: prevSig, isAnchor: true });
          lastEmitted = lastSub;
          if ((lastSub - lastKeyCandidate) >= maxHoldFrames) lastKeyCandidate = lastSub;
        }
        raw.push({ frameIndex: f, reusePrevious: !sigChanged, isDynamic: dyn, signature: sig, isAnchor: false });
        lastEmitted = f;
        if ((f - lastKeyCandidate) >= maxHoldFrames) lastKeyCandidate = f;
      } else if (holdExpired || isLast) {
        raw.push({ frameIndex: f, reusePrevious: true, isDynamic: false, signature: sig, isAnchor: isLast && !sigChanged });
        lastEmitted = f;
        if (holdExpired) lastKeyCandidate = f;
      }

      prevDyn = dyn;
      prevSig = sig;
    }

    let lastKeyIdx = -maxHoldFrames;
    const schedule = raw.map((item, i) => {
      const nextIdx = i + 1 < raw.length ? raw[i + 1].frameIndex : totalFrames;
      const durFrames = Math.max(1, nextIdx - item.frameIndex);
      const timestampUs = Math.round((item.frameIndex * 1e6) / safeFps);
      const durationUs = Math.max(1, Math.round((durFrames * 1e6) / safeFps));
      const isKeyFrame = item.frameIndex === 0 || (item.frameIndex - lastKeyIdx) >= maxHoldFrames;
      if (isKeyFrame) lastKeyIdx = item.frameIndex;
      return {
        frameIndex: item.frameIndex,
        timestampUs,
        durationUs,
        durationFrames: durFrames,
        isKeyFrame,
        reusePrevious: item.reusePrevious,
        isDynamic: item.isDynamic,
        isAnchor: item.isAnchor,
        signature: item.signature
      };
    });

    schedule.totalTimelineFrames = totalFrames;
    schedule.renderedFrames = schedule.reduce((acc, s) => acc + (s.reusePrevious ? 0 : 1), 0);
    schedule.encodedFrames = schedule.length;
    schedule.skippedFrames = Math.max(0, totalFrames - schedule.length);
    schedule.fps = safeFps;
    return schedule;
  }

  function validateSchedule(schedule, expectedTotalFrames, fps) {
    if (!Array.isArray(schedule) || !schedule.length) {
      return { valid: false, reason: 'Empty schedule' };
    }
    let prevTs = -1;
    let totalDurFrames = 0;
    for (let i = 0; i < schedule.length; i++) {
      const s = schedule[i];
      if (s.timestampUs <= prevTs) {
        return { valid: false, reason: `Non-monotonic timestamp at index ${i}: ${s.timestampUs} <= ${prevTs}` };
      }
      prevTs = s.timestampUs;
      totalDurFrames += s.durationFrames;
    }
    const last = schedule[schedule.length - 1];
    const coveredFrames = last.frameIndex + last.durationFrames;
    if (coveredFrames !== expectedTotalFrames || totalDurFrames !== expectedTotalFrames) {
      return { valid: false, reason: `Duration mismatch: covered=${coveredFrames}, sum=${totalDurFrames}, expected=${expectedTotalFrames}` };
    }
    return {
      valid: true,
      expectedDurationSec: expectedTotalFrames / Math.max(1, fps),
      actualDurationSec: totalDurFrames / Math.max(1, fps),
      renderedFrames: schedule.renderedFrames,
      encodedFrames: schedule.encodedFrames,
      skippedFrames: schedule.skippedFrames
    };
  }

  return {
    isDynAt,
    sigAt,
    buildFrameSchedule,
    validateSchedule
  };
});
