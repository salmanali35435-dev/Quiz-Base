/* Quiz Studio Pro 7 — Phase 4, 5, 8, 10, 11: Unified Scene Canvas Renderer + Performance Caches */
(function (root, factory) {
  const api = factory(
    root.QuizSceneModel || (typeof require === 'function' ? require('./scene-model.js') : null),
    root.QuizTextReveal || (typeof require === 'function' ? require('./text-reveal-engine.js') : null),
    root.QuizTimeline || (typeof require === 'function' ? require('./timeline-engine.js') : null),
    root.QuizTransitions || (typeof require === 'function' ? require('./transitions-library.js') : null),
    root.QuizNarrationL10n || (typeof require === 'function' ? require('./narration-l10n.js') : null)
  );
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.QuizSceneRenderer = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (SceneModel, TextReveal, Timeline, Transitions, NarrationL10n) {
  'use strict';

  function createRendererContext() {
    return {
      textWrapCache: new Map(),
      imageCache: new Map(),
      staticCanvas: null,
      staticCtx: null,
      staticCacheKey: '',
      snapCanvas: null,
      snapCtx: null,
      snappedQuestionIdx: -99,
      lastSeg: null,
      segPtr: 0,
      metrics: {
        framesRendered: 0,
        staticCacheHits: 0,
        textCacheHits: 0
      }
    };
  }

  function makeOffscreenCanvas(w, h) {
    if (typeof OffscreenCanvas !== 'undefined') return new OffscreenCanvas(w, h);
    if (typeof document !== 'undefined' && document.createElement) {
      const c = document.createElement('canvas');
      c.width = w;
      c.height = h;
      return c;
    }
    return null;
  }

  function roundRectPath(ctx, x, y, w, h, r) {
    const rad = Math.max(0, Math.min(r, Math.min(w, h) / 2));
    ctx.beginPath();
    ctx.moveTo(x + rad, y);
    ctx.arcTo(x + w, y, x + w, y + h, rad);
    ctx.arcTo(x + w, y + h, x, y + h, rad);
    ctx.arcTo(x, y + h, x, y, rad);
    ctx.arcTo(x, y, x + w, y, rad);
    ctx.closePath();
  }

  function resolveAssetImage(assets, assetRef, rendererCtx, onReady) {
    if (!assetRef || !assets || !assets[assetRef]) return null;
    const src = assets[assetRef];
    if (typeof src !== 'string') return src; // Allows passing preloaded bitmap/canvas in Node tests
    const cached = rendererCtx.imageCache.get(assetRef);
    if (cached && cached.src === src) return cached.complete ? cached.img : null;
    if (typeof Image === 'undefined') return null;
    const img = new Image();
    const rec = { src, img, complete: false };
    rendererCtx.imageCache.set(assetRef, rec);
    img.onload = () => { rec.complete = true; if (onReady) onReady(); };
    img.src = src;
    return img.complete ? img : null;
  }

  function wrapTextCached(ctx, text, font, maxW, rendererCtx) {
    const key = font + '|' + Math.round(maxW) + '|' + text;
    if (rendererCtx && rendererCtx.textWrapCache.has(key)) {
      rendererCtx.metrics.textCacheHits++;
      return rendererCtx.textWrapCache.get(key);
    }
    ctx.font = font;
    const words = String(text || '').split(/\s+/).filter(Boolean);
    const lines = [];
    let line = '';
    for (let i = 0; i < words.length; i++) {
      const candidate = line ? line + ' ' + words[i] : words[i];
      if (ctx.measureText(candidate).width > maxW && line) {
        lines.push(line);
        line = words[i];
      } else {
        line = candidate;
      }
    }
    if (line) lines.push(line);
    if (!lines.length && text) lines.push(text);
    if (rendererCtx) {
      if (rendererCtx.textWrapCache.size > 1500) rendererCtx.textWrapCache.clear();
      rendererCtx.textWrapCache.set(key, lines);
    }
    return lines;
  }

  function wrapTextHard(ctx, text, font, maxW, rendererCtx) {
    const lines = wrapTextCached(ctx, text, font, maxW, rendererCtx);
    ctx.font = font;
    const out = [];
    for (let i = 0; i < lines.length; i++) {
      const ln = lines[i];
      if (ctx.measureText(ln).width <= maxW * 1.005 || ln.length <= 1) {
        out.push(ln);
        continue;
      }
      // Split single oversized token strictly when even at minimum font size it exceeds box width
      let cur = '';
      for (let c = 0; c < ln.length; c++) {
        const next = cur + ln[c];
        if (ctx.measureText(next).width > maxW && cur) {
          out.push(cur);
          cur = ln[c];
        } else {
          cur = next;
        }
      }
      if (cur) out.push(cur);
    }
    return out;
  }

  function drawWrappedText(ctx, text, rect, el, h, revealState, rendererCtx) {
    const family = `'${el.fontFamily || 'League Spartan'}','Arial Black',Arial,sans-serif`;
    const weight = el.fontWeight || 700;
    const minFs = Math.max(7, Math.min(12, rect.h * 0.42));
    let fs = Math.max(minFs, (el.fontSize || 0.045) * h);
    let lines = [];
    const maxW = Math.max(8, rect.w * 0.94);

    // Auto-fit font size when text overflows container vertically OR any token/line exceeds horizontal box width
    for (let step = 0; step < 36; step++) {
      const font = `${weight} ${Math.round(fs * 10) / 10}px ${family}`;
      lines = wrapTextCached(ctx, text, font, maxW, rendererCtx);
      ctx.font = font;
      const totalH = lines.length * fs * 1.15;
      let widestLine = 0;
      for (let i = 0; i < lines.length; i++) {
        const lw = ctx.measureText(lines[i]).width;
        if (lw > widestLine) widestLine = lw;
      }
      if ((totalH <= rect.h * 0.95 && widestLine <= maxW * 1.005) || fs <= minFs) break;
      const nextFs = Math.max(minFs, Math.min(fs - 0.5, fs * 0.86));
      if (nextFs >= fs - 0.01) break;
      fs = nextFs;
    }

    const finalFont = `${weight} ${Math.round(fs * 10) / 10}px ${family}`;
    lines = wrapTextHard(ctx, text, finalFont, maxW, rendererCtx);

    ctx.font = finalFont;
    ctx.textAlign = el.alignment === 'left' ? 'left' : el.alignment === 'right' ? 'right' : 'center';
    ctx.textBaseline = 'alphabetic';

    const lh = fs * 1.15;
    const totalH = lines.length * lh;
    const startY = rect.y + (rect.h - totalH) / 2 + fs * 0.86;
    const anchorX = el.alignment === 'left'
      ? rect.x + rect.w * 0.03
      : el.alignment === 'right'
        ? rect.x + rect.w * 0.97
        : rect.x + rect.w / 2;

    const strokeCol = el.strokeEnabled ? (el.strokeColor || '#000000') : null;
    const lw = Math.max(1.5, fs * 0.06);

    ctx.save();
    ctx.beginPath();
    ctx.rect(rect.x, rect.y, rect.w, rect.h);
    ctx.clip();
    for (let i = 0; i < lines.length; i++) {
      const ly = startY + i * lh;
      if (strokeCol) {
        ctx.lineJoin = 'round';
        ctx.lineWidth = lw;
        ctx.strokeStyle = strokeCol;
        ctx.strokeText(lines[i], anchorX, ly, maxW);
      }
      ctx.fillStyle = el.textColor || '#ffffff';
      ctx.fillText(lines[i], anchorX, ly, maxW);
    }
    ctx.restore();
  }

  function resolveAnswerIntro(runtime) {
    if (runtime && runtime.answerIntroText) return runtime.answerIntroText;
    if (NarrationL10n && typeof NarrationL10n.buildAnswerIntroPhrase === 'function') {
      return NarrationL10n.buildAnswerIntroPhrase((runtime && runtime.locale) || 'en-US');
    }
    return 'The answer is';
  }

  function substituteTokens(str, q, qIdx, totalQ, runtime) {
    const opts = (q && Array.isArray(q.options)) ? q.options : ['', '', '', ''];
    const cIdx = q && Number.isInteger(q.correct) ? q.correct : 0;
    const num1 = qIdx + 1;
    const tot1 = Math.max(1, totalQ || 1);
    return String(str || '')
      .replace(/\{header\}/gi, ((runtime && runtime.headerText) || 'GUESS THE ANSWER').toUpperCase())
      .replace(/\{channel\}/gi, ((runtime && (runtime.channelName || runtime.projectTitle)) || '').toUpperCase())
      .replace(/\{counter\}/gi, `${num1} / ${tot1}`)
      .replace(/\{num2\}/gi, String(num1).padStart(2, '0'))
      .replace(/\{total2\}/gi, String(tot1).padStart(2, '0'))
      .replace(/\{num\}/gi, String(num1))
      .replace(/\{total\}/gi, String(tot1))
      .replace(/\{answer_intro\}/gi, resolveAnswerIntro(runtime))
      .replace(/\{correct_answer\}/gi, String(opts[cIdx] || '').toUpperCase())
      .replace(/\{question\}/gi, (q && q.question ? q.question : '').toUpperCase())
      .replace(/\{option_0\}/gi, String(opts[0] || '').toUpperCase())
      .replace(/\{option_1\}/gi, String(opts[1] || '').toUpperCase())
      .replace(/\{option_2\}/gi, String(opts[2] || '').toUpperCase())
      .replace(/\{option_3\}/gi, String(opts[3] || '').toUpperCase());
  }

  function formatQuestionNumberText(el, q, qIdx, totalQ, runtime) {
    const rawText = el && el.text ? String(el.text) : '';
    const hasExplicitFmt = el && (
      el.qNumPreset ||
      el.qNumPrefix !== undefined ||
      el.qNumLeadingZero !== undefined ||
      el.qNumSeparator !== undefined ||
      el.qNumShowTotal !== undefined
    );
    if (rawText && !hasExplicitFmt && /\{|\d/.test(rawText) && rawText !== '{num}/{total}') {
      return substituteTokens(rawText, q, qIdx, totalQ, runtime);
    }
    if (SceneModel && typeof SceneModel.formatQuestionNumber === 'function') {
      const baseCfg = (runtime && runtime.questionNumberConfig) || {};
      const merged = {
        ...baseCfg,
        ...(el && el.qNumPreset ? { qNumPreset: el.qNumPreset } : {}),
        ...(el && el.qNumPrefix !== undefined ? { qNumPrefix: el.qNumPrefix } : {}),
        ...(el && el.qNumLeadingZero !== undefined ? { qNumLeadingZero: el.qNumLeadingZero } : {}),
        ...(el && el.qNumSeparator !== undefined ? { qNumSeparator: el.qNumSeparator } : {}),
        ...(el && el.qNumShowTotal !== undefined ? { qNumShowTotal: el.qNumShowTotal } : {}),
        ...(el && el.qNumUppercase !== undefined ? { qNumUppercase: el.qNumUppercase } : {})
      };
      return SceneModel.formatQuestionNumber(qIdx, totalQ, merged);
    }
    return `${qIdx + 1}/${Math.max(1, totalQ || 1)}`;
  }

  function drawGenericTimer(ctx, rect, remaining, total, el, runtime) {
    const dur = Math.max(1, Number(total) || 10);
    const hasRem = !(remaining === null || remaining === undefined);
    const sec = hasRem ? Math.max(0, remaining) : dur;
    const frac = Math.max(0, Math.min(1, sec / dur));
    const shown = hasRem ? Math.min(dur, Math.ceil(sec - 1e-6)) : dur;
    const th = (runtime && runtime.theme) || {};
    const look = (el && el.timerLook && String(el.timerLook).trim()) || th.timerLook || 'capsule';
    const timerA = (el && el.textColor && el.textColor !== '#ffffff') ? el.textColor : (th.timerA || '#ff4a14');
    const timerB = th.timerB || '#f02a00';
    const timerTrack = (el && el.backgroundColor && el.backgroundColor !== 'transparent') ? el.backgroundColor : (th.timerTrack || '#d9d9d9');
    const timerBorder = (el && el.borderColor && el.borderColor !== '#000000') ? el.borderColor : (th.timerBorder || '#ffffff');
    const defaultW = ctx.canvas ? ctx.canvas.width : 1280;
    const defaultH = ctx.canvas ? ctx.canvas.height : 720;

    // Delegate to page's rich 10-style drawTimerLook when available in browser
    if (typeof globalThis !== 'undefined' && typeof globalThis.drawTimerLook === 'function') {
      const gt = globalThis.THEME;
      const oldLook = gt && gt.timerLook;
      const oldTx = gt && gt.timerX;
      const oldTy = gt && gt.timerY;
      const oldTs = gt && gt.timerSize;
      const oldA = gt && gt.timerA;
      const oldB = gt && gt.timerB;
      const oldTrack = gt && gt.timerTrack;
      const oldBorder = gt && gt.timerBorder;
      const prevCustomBarW = globalThis.__customTimerBoxW;
      if (gt) {
        gt.timerLook = look;
        gt.timerX = 0;
        gt.timerY = 0;
        gt.timerSize = 1;
        gt.timerA = timerA;
        gt.timerB = timerB;
        gt.timerTrack = timerTrack;
        gt.timerBorder = timerBorder;
      }
      if (runtime && runtime.sceneMode === 'IMPORTED_TEMPLATE_MODE' && rect.w > 0 && rect.w < defaultW * 0.55) {
        globalThis.__customTimerBoxW = rect.w;
      }
      try {
        ctx.save();
        const cx = rect.x + rect.w / 2;
        const dx = cx - defaultW / 2;
        if (Math.abs(dx) > 1) ctx.translate(dx, 0);
        globalThis.drawTimerLook(ctx, defaultW, defaultH, rect.y, rect.h, remaining);
        ctx.restore();
        return;
      } finally {
        globalThis.__customTimerBoxW = prevCustomBarW;
        if (gt) {
          gt.timerLook = oldLook;
          gt.timerX = oldTx;
          gt.timerY = oldTy;
          gt.timerSize = oldTs;
          gt.timerA = oldA;
          gt.timerB = oldB;
          gt.timerTrack = oldTrack;
          gt.timerBorder = oldBorder;
        }
      }
    }

    // Portable Canvas fallback for headless / standalone rendering (all 10 timer looks)
    const urgent = hasRem && sec > 0 && sec <= 3;
    const colA = urgent ? '#ff3b1f' : timerA;
    const tY = rect.y;
    const tH = Math.max(8, rect.h);
    const barW = (runtime && runtime.sceneMode === 'IMPORTED_TEMPLATE_MODE' && rect.w > 0 && rect.w < defaultW * 0.55) ? rect.w : defaultW * 0.6;
    const cx = rect.x + rect.w / 2;

    if (look === 'ring' || look === 'neon' || look === 'pie' || look === 'clock' || look === 'stopwatch' || look === 'orb' || look === 'bold') {
      const mul = look === 'bold' ? 1.45 : (look === 'ring' || look === 'clock') ? 1.35 : (look === 'neon' || look === 'pie') ? 1.3 : look === 'stopwatch' ? 1.25 : 1.05;
      const R = tH * mul;
      const cy = look === 'orb' ? (tY + tH - R * 1.2) : look === 'bold' ? (tY + tH - R + R * 0.12) : (tY + tH - R);
      if (look === 'stopwatch' || look === 'bold') {
        ctx.fillStyle = look === 'bold' ? colA : '#bdbdbd';
        roundRectPath(ctx, cx - R * 0.17, cy - R * 1.3, R * 0.34, R * 0.3, R * 0.06);
        ctx.fill();
        roundRectPath(ctx, cx - R * 0.28, cy - R * 1.36, R * 0.56, R * 0.12, R * 0.05);
        ctx.fill();
      }
      ctx.fillStyle = look === 'neon' ? '#080b14' : timerBorder;
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.fill();
      const dR = R * 0.88;
      ctx.fillStyle = look === 'clock' ? '#f3f3f3' : (look === 'pie' ? timerTrack : (look === 'orb' ? colA : '#181818'));
      ctx.beginPath();
      ctx.arc(cx, cy, dR, 0, Math.PI * 2);
      ctx.fill();
      if (frac > 0) {
        if (look === 'pie' || look === 'bold') {
          ctx.fillStyle = colA;
          ctx.beginPath();
          ctx.moveTo(cx, cy);
          ctx.arc(cx, cy, dR * 0.9, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * frac);
          ctx.closePath();
          ctx.fill();
        } else {
          ctx.strokeStyle = colA;
          ctx.lineWidth = Math.max(2, R * 0.14);
          ctx.beginPath();
          ctx.arc(cx, cy, dR * 0.8, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * frac);
          ctx.stroke();
        }
      }
      if (look === 'stopwatch' || look === 'clock') {
        const ang = -Math.PI / 2 + Math.PI * 2 * (1 - frac);
        ctx.strokeStyle = colA;
        ctx.lineWidth = Math.max(2, dR * 0.06);
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(cx + Math.cos(ang) * dR * 0.72, cy + Math.sin(ang) * dR * 0.72);
        ctx.stroke();
      }
      ctx.fillStyle = look === 'clock' ? '#222222' : '#ffffff';
      ctx.font = `900 ${Math.round(dR * 0.55)}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(String(shown), cx, (look === 'stopwatch' || look === 'clock') ? cy + dR * 0.42 : cy);
      return;
    }

    if (look === 'segments') {
      const boxW = Math.min(barW * 0.28, tH * 1.7);
      const gap = tH * 0.4;
      const hW = Math.max(tH * 1.5, barW - boxW - gap);
      const gX = cx - (hW + gap + boxW) / 2;
      const hH = tH * 1.1;
      const hY = tY + tH / 2 - hH / 2;
      ctx.fillStyle = '#181818';
      roundRectPath(ctx, gX, hY, hW, hH, hH * 0.3);
      ctx.fill();
      roundRectPath(ctx, gX + hW + gap, hY, boxW, hH, hH * 0.3);
      ctx.fill();
      const N = 20;
      const lit = Math.ceil(frac * N - 1e-6);
      const pad = hH * 0.16;
      const sg = hH * 0.06;
      const sw = Math.max(2, (hW - pad * 2 - sg * (N - 1)) / N);
      for (let i = 0; i < N; i++) {
        ctx.fillStyle = i < lit ? colA : '#333333';
        roundRectPath(ctx, gX + pad + i * (sw + sg), hY + pad, sw, hH - pad * 2, sw * 0.25);
        ctx.fill();
      }
      ctx.fillStyle = '#ffffff';
      ctx.font = `900 ${Math.round(hH * 0.7)}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(String(shown), gX + hW + gap + boxW / 2, hY + hH / 2);
      return;
    }

    // capsule & flatbar
    const bR = look === 'flatbar' ? 0 : Math.min(tH * 0.88, barW * 0.22);
    const gapB = look === 'flatbar' ? 0 : tH * 0.45;
    const tW = Math.max(tH, barW - (bR > 0 ? bR * 2 + gapB : 0));
    const gW = (bR > 0 ? bR * 2 + gapB : 0) + tW;
    const gX = cx - gW / 2;
    const tX = gX + (bR > 0 ? bR * 2 + gapB : 0);
    const r = Math.min(tH / 2, 24);
    ctx.fillStyle = timerTrack;
    roundRectPath(ctx, tX, tY, tW, tH, r);
    ctx.fill();
    if (frac > 0) {
      ctx.fillStyle = colA;
      roundRectPath(ctx, tX, tY, Math.min(tW, Math.max(tH, tW * frac)), tH, r);
      ctx.fill();
    }
    if (look !== 'flatbar' && bR > 0) {
      const bcx = gX + bR;
      const bcy = tY + tH / 2;
      ctx.fillStyle = timerBorder;
      ctx.beginPath();
      ctx.arc(bcx, bcy, bR, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#181818';
      ctx.beginPath();
      ctx.arc(bcx, bcy, bR * 0.84, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.font = `900 ${Math.round(bR * 0.9)}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(String(shown), bcx, bcy);
    }
  }

  function buildOptionResolution(scene) {
    const indexMap = new Map();
    const hasContainerForOpt = [false, false, false, false];
    if (!scene || !Array.isArray(scene.elements)) return { indexMap, hasContainerForOpt };
    const optTypes = new Set(['option_container', 'option_label', 'option_text']);
    for (const el of scene.elements) {
      if (!el || !optTypes.has(el.type)) continue;
      let idx = Number(el.optionIndex);
      if (!Number.isInteger(idx) || idx < 0 || idx > 3) {
        if (SceneModel && typeof SceneModel.inferOptionIndex === 'function') {
          idx = SceneModel.inferOptionIndex(scene.elements, el);
        } else {
          const tok = /\{option_([0-3])\}/i.exec(String(el.text || ''));
          idx = tok ? Number(tok[1]) : -1;
        }
      }
      if (Number.isInteger(idx) && idx >= 0 && idx < 4) {
        indexMap.set(el.id, idx);
        if (el.type === 'option_container' && el.visible !== false) {
          hasContainerForOpt[idx] = true;
        }
      }
    }
    return { indexMap, hasContainerForOpt };
  }

  function getResolvedOptionIndex(el, runtime) {
    if (!el) return -1;
    if (runtime && runtime.resolvedOptionIndices && runtime.resolvedOptionIndices.has(el.id)) {
      return runtime.resolvedOptionIndices.get(el.id);
    }
    const raw = Number(el.optionIndex);
    return Number.isInteger(raw) ? raw : -1;
  }

  function resolveElementReveal(el, revealSchedule, revealState, revealConfig, elapsedSec, isPostVoice, q, qIdx, totalQ, runtime) {
    const neutral = { visible: true, opacity: 1, offsetXFrac: 0, offsetYFrac: 0, scale: 1, blurPx: 0, clipFrac: 1, shownText: null, progress: 1 };
    if (!TextReveal || !revealConfig || !revealConfig.enabled) {
      return neutral;
    }

    const optIdx = getResolvedOptionIndex(el, runtime);

    // Answer reveal & Answer intro animations evaluate when answer reveal flag is active
    if (revealState && (runtime && runtime.revealElapsedSec !== undefined && runtime.revealElapsedSec !== null)) {
      const rSec = Math.max(0, Number(runtime.revealElapsedSec) || 0);
      const isCorrectOpt = optIdx >= 0 && optIdx === (q ? q.correct : -1);
      if (isCorrectOpt && (el.type === 'option_container' || el.type === 'option_label' || el.type === 'option_text')) {
        const dur = (runtime.answerRevealConfig && runtime.answerRevealConfig.durationSec) ||
          (revealConfig.answerReveal && revealConfig.answerReveal.durationSec) || 0.4;
        const revRoleCfg = (runtime.answerRevealConfig && runtime.answerRevealConfig.animationStyle)
          ? {
              ...revealConfig,
              answerReveal: {
                ...(revealConfig.answerReveal || {}),
                style: runtime.answerRevealConfig.animationStyle,
                durationSec: dur
              }
            }
          : revealConfig;
        const fullTxt = el.type === 'option_label' ? '✓' : ((q && q.options && q.options[optIdx]) || '');
        return TextReveal.evaluateReveal('answerReveal', fullTxt, 0, Math.max(0.15, dur), rSec, revRoleCfg, false);
      }
      if (el.type === 'text' && /\{answer_intro\}|\{correct_answer\}/i.test(el.text || '')) {
        const dur = (revealConfig.answerIntro && revealConfig.answerIntro.durationSec) || 0.4;
        const fullTxt = substituteTokens(el.text, q, qIdx || 0, totalQ || 1, runtime);
        return TextReveal.evaluateReveal('answerIntro', fullTxt, 0, Math.max(0.15, dur), rSec, revealConfig, false);
      }
    }

    if (!revealSchedule || isPostVoice) {
      return neutral;
    }
    const t = elapsedSec;
    const qText = (q && q.question) || (revealSchedule.question && revealSchedule.question.text) || '';
    if (el.type === 'question_number') {
      const qnStart = revealSchedule.questionNumberStart !== undefined ? revealSchedule.questionNumberStart : 0;
      const qnEnd = revealSchedule.questionNumberEnd !== undefined ? revealSchedule.questionNumberEnd : 0.45;
      const formattedNum = formatQuestionNumberText(el, q, qIdx || 0, totalQ || 1, runtime);
      return TextReveal.evaluateReveal('questionNumber', formattedNum, qnStart, Math.max(qnStart + 0.1, qnEnd), t, revealConfig, false);
    }
    if (el.type === 'question_text') {
      const startSec = revealSchedule.questionStart !== undefined ? revealSchedule.questionStart : ((revealSchedule.question && revealSchedule.question.startSec) || 0);
      const endSec = revealSchedule.questionEnd !== undefined ? revealSchedule.questionEnd : ((revealSchedule.question && revealSchedule.question.endSec) || Math.max(0.5, revealSchedule.durationSec ? revealSchedule.durationSec * 0.4 : 1.2));
      return TextReveal.evaluateReveal('questionText', qText, startSec, endSec, t, revealConfig, false);
    }
    if ((el.type === 'option_label' || el.type === 'option_container' || el.type === 'option_text') && optIdx >= 0 && optIdx < 4) {
      const slots = Array.isArray(revealSchedule.options) ? revealSchedule.options : [];
      const slot = slots[optIdx];
      const opts = (q && Array.isArray(q.options)) ? q.options : [];
      const optText = (slot && slot.text) || opts[optIdx] || el.text || '';
      const labelText = (slot && slot.label) || ('ABCD'[optIdx] || 'A');

      if (el.type === 'option_label') {
        const lStart = slot ? (slot.labelStart !== undefined ? slot.labelStart : (slot.textStart !== undefined ? slot.textStart - 0.15 : 0)) : 0;
        const lEnd = slot ? (slot.labelEnd !== undefined ? slot.labelEnd : (slot.textStart !== undefined ? slot.textStart : 0.3)) : 0.3;
        return TextReveal.evaluateReveal('optionLabel', labelText, lStart, lEnd, t, revealConfig, false);
      } else {
        const tStart = slot ? (slot.textStart !== undefined ? slot.textStart : (slot.startSec !== undefined ? slot.startSec : 0.2)) : 0.2;
        const tEnd = slot ? (slot.textEnd !== undefined ? slot.textEnd : (slot.endSec !== undefined ? slot.endSec : 0.8)) : 0.8;
        return TextReveal.evaluateReveal('optionText', optText, tStart, tEnd, t, revealConfig, false);
      }
    }
    if (el.type === 'header') {
      return TextReveal.evaluateReveal('header', el.text || '', 0, 0.35, t, revealConfig, false);
    }
    return neutral;
  }

  /**
   * Renders one single element with geometry, fill, border, image asset, icon, timer, progress, and text.
   */
  function drawSceneElement(ctx, el, w, h, q, qIdx, totalQ, runtime, revealFlag, remaining, animState, rendererCtx) {
    if (!el.visible) return;
    if (runtime.sceneMode === 'IMPORTED_TEMPLATE_MODE' && el.isDefaultTemplateOnly) return;

    const rev = resolveElementReveal(el, runtime.revealSchedule, revealFlag, runtime.revealConfig, runtime.voiceElapsedSec || 0, runtime.isPostVoice !== false, q, qIdx, totalQ, runtime);
    if (!rev.visible) return;

    const baseRect = {
      x: el.x * w + (rev.offsetXFrac || 0) * w,
      y: el.y * h + (rev.offsetYFrac || 0) * h,
      w: el.width * w,
      h: el.height * h
    };

    const ansCfg = runtime.answerRevealConfig || (SceneModel ? SceneModel.normalizeAnswerRevealConfig({}) : { style: 'correct-only', highlightBg: '#16a34a' });
    const ansStyle = ansCfg.style || 'correct-only';
    const optIdx = getResolvedOptionIndex(el, runtime);
    const hasOptIdx = optIdx >= 0 && optIdx < 4;
    const isCorrectOpt = revealFlag && hasOptIdx && optIdx === (q ? q.correct : -1);
    const isWrongOpt = revealFlag && hasOptIdx && optIdx !== (q ? q.correct : -1);
    const dimWrong = isWrongOpt && (ansStyle === 'highlight-dim-others' || !!ansCfg.dimWrongBgEnabled);

    // Custom templates with baked-in option art often use opacity:0 on overlay option_container boxes before reveal.
    // On Answer Reveal, elevate container opacity so the selected Answer Reveal slot fill & dim colors visibly apply.
    const rawElOpacity = el.opacity !== undefined ? el.opacity : 1;
    const revealTransparentContainer = el.type === 'option_container' && (isCorrectOpt || dimWrong) && rawElOpacity < 0.05;
    const effectiveElOpacity = revealTransparentContainer ? 1 : rawElOpacity;
    let alpha = Math.max(0, Math.min(1, effectiveElOpacity * (rev.opacity !== undefined ? rev.opacity : 1)));
    if (dimWrong) {
      const dimAlpha = ansCfg.dimOpacity !== undefined ? Number(ansCfg.dimOpacity) : 0.88;
      alpha *= Math.max(0.1, Math.min(1, isNaN(dimAlpha) ? 0.88 : dimAlpha));
    }

    let scale = rev.scale !== undefined ? rev.scale : 1;
    if (isCorrectOpt && ansStyle === 'strong-highlight' && (ansCfg.scaleBoost || 1) > 1) {
      const pBoost = rev.progress !== undefined ? Math.min(1, rev.progress) : 1;
      scale *= (1 + ((ansCfg.scaleBoost || 1.03) - 1) * pBoost);
    }

    const rad = Math.max(0, (el.borderRadius || 0) * Math.min(baseRect.w, baseRect.h));

    ctx.save();
    ctx.globalAlpha *= alpha;

    if (rev.blurPx > 0.2 && typeof ctx.filter === 'string') {
      ctx.filter = `blur(${rev.blurPx.toFixed(1)}px)`;
    }

    if ((el.rotation && el.rotation !== 0) || Math.abs(scale - 1) > 0.002) {
      const cx = baseRect.x + baseRect.w / 2;
      const cy = baseRect.y + baseRect.h / 2;
      ctx.translate(cx, cy);
      if (el.rotation) ctx.rotate((el.rotation * Math.PI) / 180);
      if (Math.abs(scale - 1) > 0.002) ctx.scale(scale, scale);
      ctx.translate(-cx, -cy);
    }

    if (rev.clipFrac !== undefined && rev.clipFrac < 0.999) {
      ctx.beginPath();
      if (rev.clipDir === 'top-to-bottom') {
        ctx.rect(baseRect.x, baseRect.y, baseRect.w, baseRect.h * rev.clipFrac);
      } else if (rev.clipDir === 'right-to-left') {
        const cw = baseRect.w * rev.clipFrac;
        ctx.rect(baseRect.x + baseRect.w - cw, baseRect.y, cw, baseRect.h);
      } else {
        ctx.rect(baseRect.x, baseRect.y, baseRect.w * rev.clipFrac, baseRect.h);
      }
      ctx.clip();
    }

    // Glow effect for strong-highlight answer reveal
    const applyStrongGlow = isCorrectOpt && el.type === 'option_container' && ansStyle === 'strong-highlight' && ansCfg.glowEnabled;
    if (applyStrongGlow) {
      ctx.shadowColor = ansCfg.glowColor || ansCfg.highlightBg || '#22c55e';
      ctx.shadowBlur = Math.max(10, h * 0.025);
    }

    // Draw background / container fill
    // When Answer Reveal is active on an image-backed option_container (assetRef), draw the selected
    // Answer Reveal slot background / dimmed fill instead of letting the static card image hide the highlight.
    const img = el.assetRef ? resolveAssetImage(runtime.assets, el.assetRef, rendererCtx, runtime.onAssetReady) : null;
    const revealOverridesSlotBg = el.type === 'option_container' && (isCorrectOpt || dimWrong);
    const hasOptionContainerSibling = hasOptIdx && !!(runtime.hasContainerForOpt && runtime.hasContainerForOpt[optIdx]);
    const drawFallbackTextSlotBg = el.type === 'option_text' && hasOptIdx && !hasOptionContainerSibling && (isCorrectOpt || dimWrong) && (!el.backgroundColor || el.backgroundColor === 'transparent');
    if (img && !revealOverridesSlotBg) {
      if (rad > 0) {
        ctx.save();
        roundRectPath(ctx, baseRect.x, baseRect.y, baseRect.w, baseRect.h, rad);
        ctx.clip();
        ctx.drawImage(img, baseRect.x, baseRect.y, baseRect.w, baseRect.h);
        ctx.restore();
      } else {
        ctx.drawImage(img, baseRect.x, baseRect.y, baseRect.w, baseRect.h);
      }
    } else {
      let fill = el.backgroundColor;
      if (el.type === 'option_container' && isCorrectOpt) {
        fill = ansCfg.highlightBg || (runtime.theme && runtime.theme.correctFill) || '#16a34a';
      } else if (el.type === 'option_container' && dimWrong) {
        fill = ansCfg.dimBg || '#1e293b';
      } else if (el.type === 'option_label' && isCorrectOpt) {
        fill = ansCfg.badgeBg || '#22c55e';
      } else if (el.type === 'option_label' && dimWrong) {
        fill = ansCfg.dimBadgeBg || '#334155';
      } else if (el.type === 'option_text' && ((fill && fill !== 'transparent') || drawFallbackTextSlotBg)) {
        if (isCorrectOpt) fill = ansCfg.highlightBg || fill;
        else if (dimWrong) fill = ansCfg.dimBg || '#1e293b';
      }
      if (fill && fill !== 'transparent') {
        ctx.fillStyle = fill;
        if (el.shapeKind === 'circle') {
          ctx.beginPath();
          ctx.ellipse(baseRect.x + baseRect.w / 2, baseRect.y + baseRect.h / 2, baseRect.w / 2, baseRect.h / 2, 0, 0, Math.PI * 2);
          ctx.fill();
        } else if (rad > 0) {
          roundRectPath(ctx, baseRect.x, baseRect.y, baseRect.w, baseRect.h, rad);
          ctx.fill();
        } else {
          ctx.fillRect(baseRect.x, baseRect.y, baseRect.w, baseRect.h);
        }
        if (el.type === 'header' && el.headerDesign === 'stripe' && el.borderColor) {
          ctx.fillStyle = el.borderColor;
          ctx.fillRect(baseRect.x, baseRect.y + baseRect.h, baseRect.w, Math.max(3, h * 0.008));
        }
      }
    }

    if (applyStrongGlow) {
      ctx.shadowBlur = 0;
      ctx.shadowColor = 'transparent';
    }

    // Border outline (honors Answer Reveal custom border on correct container & muted border on dimmed wrong options)
    let effBorderWidth = el.borderWidth || 0;
    let effBorderColor = el.borderColor;
    if (el.type === 'option_container' && isCorrectOpt) {
      if ((ansCfg.correctBorderWidth || 0) > 0 && ansCfg.correctBorderColor) {
        effBorderWidth = ansCfg.correctBorderWidth;
        effBorderColor = ansCfg.correctBorderColor;
      }
    } else if (el.type === 'option_container' && dimWrong) {
      effBorderColor = ansCfg.dimBorderColor || '#475569';
      effBorderWidth = Math.max(1.5, el.borderWidth || 1.5);
    } else if (el.type === 'option_label' && dimWrong && effBorderWidth > 0) {
      effBorderColor = ansCfg.dimBorderColor || '#475569';
    }
    if (effBorderWidth > 0 && effBorderColor && effBorderColor !== 'transparent') {
      ctx.lineWidth = effBorderWidth * (w / 1280);
      ctx.strokeStyle = effBorderColor;
      if (el.shapeKind === 'circle') {
        ctx.beginPath();
        ctx.ellipse(baseRect.x + baseRect.w / 2, baseRect.y + baseRect.h / 2, baseRect.w / 2, baseRect.h / 2, 0, 0, Math.PI * 2);
        ctx.stroke();
      } else if (rad > 0) {
        roundRectPath(ctx, baseRect.x, baseRect.y, baseRect.w, baseRect.h, rad);
        ctx.stroke();
      } else {
        ctx.strokeRect(baseRect.x, baseRect.y, baseRect.w, baseRect.h);
      }
    }

    // Foreground content by element type
    switch (el.type) {
      case 'timer':
        drawGenericTimer(ctx, baseRect, remaining, runtime.timerDuration || 10, el, runtime);
        break;
      case 'progress_bar': {
        const prog = (qIdx + 1) / Math.max(1, totalQ);
        ctx.fillStyle = el.textColor || '#ff4a14';
        roundRectPath(ctx, baseRect.x, baseRect.y, Math.max(baseRect.h, baseRect.w * prog), baseRect.h, rad);
        ctx.fill();
        break;
      }
      case 'icon': {
        const glyph = el.iconGlyph || el.text || '★';
        ctx.fillStyle = el.textColor || '#ffd700';
        ctx.font = `700 ${Math.round(Math.min(baseRect.w, baseRect.h) * 0.72)}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(glyph, baseRect.x + baseRect.w / 2, baseRect.y + baseRect.h / 2);
        break;
      }
      case 'question_text': {
        const full = q && q.question ? String(q.question).toUpperCase() : substituteTokens(el.text, q, qIdx, totalQ, runtime);
        const textToDraw = (rev.shownText !== null && rev.shownText !== undefined) ? String(rev.shownText).toUpperCase() : full;
        if (textToDraw) drawWrappedText(ctx, textToDraw, baseRect, el, h, rev, rendererCtx);
        break;
      }
      case 'option_label': {
        const idx = optIdx;
        const lbl = isCorrectOpt ? '✓' : (idx >= 0 && idx < 4 ? 'ABCD'[idx] : (el.text || 'A'));
        const drawEl = isCorrectOpt
          ? { ...el, textColor: ansCfg.badgeTickColor || '#ffffff', strokeEnabled: false }
          : dimWrong
            ? { ...el, textColor: ansCfg.dimBadgeTextColor || '#cbd5e1', strokeEnabled: false }
            : el;
        drawWrappedText(ctx, lbl, baseRect, drawEl, h, rev, rendererCtx);
        break;
      }
      case 'option_text': {
        const idx = optIdx;
        const opts = q && Array.isArray(q.options) ? q.options : [];
        const full = (idx >= 0 && idx < opts.length) ? String(opts[idx]).toUpperCase() : substituteTokens(el.text, q, qIdx, totalQ, runtime);
        const textToDraw = (rev.shownText !== null && rev.shownText !== undefined) ? String(rev.shownText).toUpperCase() : full;
        const drawEl = isCorrectOpt
          ? { ...el, textColor: ansCfg.correctTextColor || '#ffffff', strokeEnabled: false }
          : dimWrong
            ? { ...el, textColor: ansCfg.dimTextColor || '#94a3b8', strokeEnabled: false }
            : el;
        if (textToDraw) drawWrappedText(ctx, textToDraw, baseRect, drawEl, h, rev, rendererCtx);
        break;
      }
      case 'question_number': {
        const fullNum = formatQuestionNumberText(el, q, qIdx, totalQ, runtime);
        const textToDraw = (rev.shownText !== null && rev.shownText !== undefined) ? String(rev.shownText) : fullNum;
        if (textToDraw) drawWrappedText(ctx, textToDraw, baseRect, el, h, rev, rendererCtx);
        break;
      }
      case 'text': {
        const full = substituteTokens(el.text, q, qIdx, totalQ, runtime);
        const textToDraw = (rev.shownText !== null && rev.shownText !== undefined) ? String(rev.shownText) : full;
        if (textToDraw) drawWrappedText(ctx, textToDraw, baseRect, el, h, rev, rendererCtx);
        break;
      }
      default:
        break;
    }

    if (typeof ctx.filter === 'string' && rev.blurPx > 0.2) {
      ctx.filter = 'none';
    }
    ctx.restore();
  }

  /**
   * Draws selection box + handles around currently selected element during interactive preview only.
   */
  function drawSelectionOverlay(ctx, w, h, scene, selectedId) {
    if (!selectedId || !scene || !Array.isArray(scene.elements)) return;
    const el = scene.elements.find(e => e.id === selectedId);
    if (!el || !el.visible) return;
    const x = el.x * w;
    const y = el.y * h;
    const bw = el.width * w;
    const bh = el.height * h;

    ctx.save();
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = Math.max(2, w * 0.0025);
    ctx.setLineDash([8, 5]);
    ctx.strokeRect(x, y, bw, bh);
    ctx.setLineDash([]);

    const hs = Math.max(8, w * 0.01);
    ctx.fillStyle = '#38bdf8';
    const corners = [[x, y], [x + bw, y], [x, y + bh], [x + bw, y + bh]];
    corners.forEach(([cx, cy]) => {
      ctx.fillRect(cx - hs / 2, cy - hs / 2, hs, hs);
    });
    ctx.restore();
  }

  /**
   * Renders a full frame from `scene` at given question/timing state.
   */
  function renderSceneFrame(ctx, w, h, scene, q, qIdx, totalQ, options = {}) {
    const rCtx = options.rendererCtx || createRendererContext();
    rCtx.metrics.framesRendered++;

    if (!scene || !Array.isArray(scene.elements) || !scene.elements.length) {
      ctx.fillStyle = '#111827';
      ctx.fillRect(0, 0, w, h);
      return;
    }

    const revealFlag = !!options.reveal;
    const remaining = options.remaining !== undefined ? options.remaining : null;
    const rawAnsRev = options.answerRevealConfig || scene.answerRevealConfig || (scene.theme && scene.theme.correctFill ? { highlightBg: scene.theme.correctFill } : {});
    const ansRevCfg = SceneModel ? SceneModel.normalizeAnswerRevealConfig(rawAnsRev) : rawAnsRev;
    const rawQNum = options.questionNumberConfig || scene.questionNumberConfig || {};
    const qNumCfg = SceneModel ? SceneModel.normalizeQuestionNumberConfig(rawQNum) : rawQNum;

    const optResolution = buildOptionResolution(scene);
    const runtime = {
      sceneMode: scene.mode || 'DEFAULT_TEMPLATE_MODE',
      theme: { ...(options.theme || {}), ...(scene.theme || {}) },
      assets: scene.assets || {},
      resolvedOptionIndices: optResolution.indexMap,
      hasContainerForOpt: optResolution.hasContainerForOpt,
      timerDuration: options.timerDuration || 10,
      headerText: options.headerText || 'GUESS THE ANSWER',
      channelName: options.channelName || '',
      projectTitle: options.projectTitle || '',
      locale: options.locale || 'en-US',
      answerIntroText: options.answerIntroText || '',
      questionNumberConfig: qNumCfg,
      answerRevealConfig: ansRevCfg,
      revealConfig: options.revealConfig || null,
      revealSchedule: options.revealSchedule || null,
      voiceElapsedSec: options.voiceElapsedSec || 0,
      revealElapsedSec: options.revealElapsedSec !== undefined ? options.revealElapsedSec : null,
      isPostVoice: options.isPostVoice !== undefined ? options.isPostVoice : true,
      onAssetReady: options.onAssetReady || null
    };

    // Strict isolation: IMPORTED_TEMPLATE_MODE clears with neutral black and NEVER draws default template bars
    ctx.clearRect(0, 0, w, h);
    if (runtime.sceneMode === 'DEFAULT_TEMPLATE_MODE' && runtime.theme && runtime.theme.bg) {
      ctx.fillStyle = runtime.theme.bg;
      ctx.fillRect(0, 0, w, h);
    } else {
      ctx.fillStyle = '#0a0a0a';
      ctx.fillRect(0, 0, w, h);
    }

    const sorted = [...scene.elements].sort((a, b) => (a.layerOrder || 0) - (b.layerOrder || 0));
    for (let i = 0; i < sorted.length; i++) {
      drawSceneElement(ctx, sorted[i], w, h, q, qIdx, totalQ, runtime, revealFlag, remaining, options.anim || null, rCtx);
    }

    if (options.interactiveOverlay && options.selectedElementId) {
      drawSelectionOverlay(ctx, w, h, scene, options.selectedElementId);
    }
  }

  /**
   * Renders an exact video timeline frame `gt` (seconds) using cached snapshots & reusable transition buffer.
   */
  function renderTimelineFrame(ctx, w, h, scene, timeline, questions, gt, options = {}) {
    const rCtx = options.rendererCtx || createRendererContext();
    if (!timeline || !timeline.segs || !timeline.segs.length || !questions || !questions.length) {
      renderSceneFrame(ctx, w, h, scene, null, 0, 1, { ...options, rendererCtx: rCtx });
      return;
    }

    let seg;
    if (Timeline && Timeline.findSegmentAt) {
      const hit = Timeline.findSegmentAt(timeline.segs, gt, rCtx.segPtr || 0);
      rCtx.segPtr = hit.ptr;
      seg = hit.seg;
    } else {
      seg = timeline.segs.find(s => gt >= s.start && gt < s.start + s.dur) || timeline.segs[timeline.segs.length - 1];
    }

    const q = questions[seg.i] || questions[0];
    const lt = Math.max(0, gt - seg.start);
    const totalQ = questions.length;
    const timerD = options.timerDuration || 10;

    if (seg.type === 'page') {
      if (rCtx.lastSeg && (rCtx.lastSeg.type === 'reveal' || rCtx.lastSeg.type === 'answer') && rCtx.snappedQuestionIdx !== rCtx.lastSeg.i) {
        if (!rCtx.snapCanvas || rCtx.snapCanvas.width !== w || rCtx.snapCanvas.height !== h) {
          rCtx.snapCanvas = makeOffscreenCanvas(w, h);
          rCtx.snapCtx = rCtx.snapCanvas ? rCtx.snapCanvas.getContext('2d') : null;
        }
        if (rCtx.snapCtx) {
          rCtx.snapCtx.clearRect(0, 0, w, h);
          rCtx.snapCtx.drawImage(ctx.canvas, 0, 0, w, h);
          rCtx.snappedQuestionIdx = rCtx.lastSeg.i;
        }
      }
      const p = Math.max(0, Math.min(1, lt / Math.max(0.001, seg.dur)));
      const schedule = Timeline && Timeline.buildRevealSchedule
        ? Timeline.buildRevealSchedule(q, seg.dur, { timerDuration: timerD, promptPrefixWords: q && q.promptPrefixWords })
        : null;
      renderSceneFrame(ctx, w, h, scene, q, seg.i, totalQ, {
        ...options,
        remaining: timerD,
        reveal: false,
        voiceElapsedSec: 0,
        revealElapsedSec: null,
        isPostVoice: false,
        revealSchedule: schedule,
        rendererCtx: rCtx
      });
      if (Transitions && Transitions.drawTransition && rCtx.snapCanvas) {
        Transitions.drawTransition(ctx, w, h, p, rCtx.snapCanvas, options.transitionConfig);
      }
      rCtx.lastSeg = seg;
      return;
    }

    const schedule = Timeline && Timeline.buildRevealSchedule
      ? Timeline.buildRevealSchedule(q, seg.dur, { timerDuration: timerD, promptPrefixWords: q && q.promptPrefixWords })
      : null;
    if (seg.type === 'voice') {
      renderSceneFrame(ctx, w, h, scene, q, seg.i, totalQ, {
        ...options,
        remaining: timerD,
        reveal: false,
        voiceElapsedSec: lt,
        revealElapsedSec: null,
        isPostVoice: false,
        revealSchedule: schedule,
        rendererCtx: rCtx
      });
    } else if (seg.type === 'count') {
      renderSceneFrame(ctx, w, h, scene, q, seg.i, totalQ, {
        ...options,
        remaining: Math.max(0, seg.dur - lt),
        reveal: false,
        voiceElapsedSec: seg.dur,
        revealElapsedSec: null,
        isPostVoice: true,
        revealSchedule: schedule,
        rendererCtx: rCtx
      });
    } else {
      const revealElapsed = seg.type === 'reveal' ? lt : (0.52 + lt);
      renderSceneFrame(ctx, w, h, scene, q, seg.i, totalQ, {
        ...options,
        remaining: 0,
        reveal: true,
        voiceElapsedSec: seg.dur,
        revealElapsedSec: revealElapsed,
        isPostVoice: true,
        revealSchedule: schedule,
        rendererCtx: rCtx
      });
    }
    rCtx.lastSeg = seg;
  }

  function buildExportSceneBundle(scene, questions, timeline, opts = {}) {
    return {
      width: opts.width || 1920,
      height: opts.height || 1080,
      fps: opts.fps || 24,
      scene: scene || null,
      assets: (scene && scene.assets) || {},
      theme: { ...(opts.theme || {}), ...(scene && scene.theme ? scene.theme : {}) },
      questions: (questions || []).map(q => ({
        question: q.question,
        options: q.options,
        correct: q.correct,
        promptWordBoundaries: q.promptWordBoundaries || [],
        promptPrefixWords: q.promptPrefixWords || 0
      })),
      timeline,
      revealConfig: opts.revealConfig || { enabled: true, questionStyle: 'typewriter-word' },
      answerRevealConfig: opts.answerRevealConfig || (scene && scene.answerRevealConfig) || (SceneModel ? SceneModel.DEFAULT_ANSWER_REVEAL_CONFIG : {}),
      questionNumberConfig: opts.questionNumberConfig || (scene && scene.questionNumberConfig) || (SceneModel ? SceneModel.DEFAULT_QUESTION_NUMBER_CONFIG : {}),
      transitionConfig: opts.transitionConfig || { style: 'classic-page-turn' },
      timerDuration: opts.timerDuration || 10,
      locale: opts.locale || 'en-US',
      projectTitle: opts.projectTitle || '',
      channelName: opts.channelName || '',
      headerText: opts.headerText || 'GUESS THE ANSWER'
    };
  }

  return {
    createRendererContext,
    wrapTextCached,
    formatQuestionNumberText,
    renderSceneFrame,
    renderTimelineFrame,
    buildExportSceneBundle
  };
});
