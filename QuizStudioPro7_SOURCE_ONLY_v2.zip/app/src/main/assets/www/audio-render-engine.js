/* Quiz Studio Pro 7 — High-Speed Chunked Stereo 48kHz PCM Audio Render Engine */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.QuizAudioRenderEngine = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const DEFAULT_SAMPLE_RATE = 48000;

  function makeStereoContainer(left, right, sr) {
    const channels = [left, right];
    if (typeof AudioBuffer === 'function') {
      try {
        const ab = new AudioBuffer({ length: left.length, numberOfChannels: 2, sampleRate: sr });
        ab.getChannelData(0).set(left);
        ab.getChannelData(1).set(right);
        return ab;
      } catch (_) {
        // Fallback cleanly if environment restricts standalone AudioBuffer construction
      }
    }
    return {
      sampleRate: sr,
      numberOfChannels: 2,
      length: left.length,
      duration: left.length / sr,
      getChannelData(ch) {
        return channels[ch === 1 ? 1 : 0];
      }
    };
  }

  function computeSourceHashKey(srcUrl) {
    const str = String(srcUrl || '');
    let h = 2166136261;
    const step = str.length > 512 ? Math.max(1, Math.floor(str.length / 256)) : 1;
    for (let i = 0; i < str.length; i += step) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return `${str.length}:${(h >>> 0).toString(16)}`;
  }

  function createDecodedAudioCache(maxEntries = 128) {
    const map = new Map();
    const inFlight = new Map();
    return {
      maxEntries,
      hits: 0,
      misses: 0,
      get(key) {
        if (!map.has(key)) return null;
        const val = map.get(key);
        map.delete(key);
        map.set(key, val);
        this.hits++;
        return val;
      },
      set(key, val) {
        if (map.has(key)) map.delete(key);
        else if (map.size >= maxEntries) {
          const oldest = map.keys().next().value;
          map.delete(oldest);
        }
        map.set(key, val);
      },
      getInFlight(key) {
        return inFlight.get(key) || null;
      },
      setInFlight(key, promise) {
        inFlight.set(key, promise);
      },
      clearInFlight(key) {
        inFlight.delete(key);
      },
      clear() {
        map.clear();
        inFlight.clear();
        this.hits = 0;
        this.misses = 0;
      },
      size() {
        return map.size;
      }
    };
  }

  const sharedDecodedCache = createDecodedAudioCache(128);

  /**
   * Decodes an audio source (data URL or remote URL) cleanly with direct Base64 decoding fast-path
   * and optional deduplicated LRU caching to avoid redundant Chromium decodeAudioData() calls.
   */
  async function decodeAudioSourceFast(decodeCtx, srcUrl, cache = null) {
    if (!srcUrl || typeof srcUrl !== 'string') throw new Error('Missing audio source');
    const activeCache = cache || sharedDecodedCache;
    const key = computeSourceHashKey(srcUrl);
    const hasInFlightApi = !!(activeCache && typeof activeCache.getInFlight === 'function');
    if (activeCache) {
      const hit = activeCache.get(key);
      if (hit) return hit;
      if (hasInFlightApi) {
        const inflight = activeCache.getInFlight(key);
        if (inflight) return inflight;
      }
      if (typeof activeCache.misses === 'number') activeCache.misses++;
    }

    const work = (async () => {
      let arrayBuf = null;
      if (srcUrl.startsWith('data:')) {
        const comma = srcUrl.indexOf(',');
        if (comma > 0 && srcUrl.slice(0, comma).includes(';base64')) {
          const b64 = srcUrl.slice(comma + 1);
          const bin = typeof atob === 'function'
            ? atob(b64)
            : Buffer.from(b64, 'base64').toString('binary');
          const bytes = new Uint8Array(bin.length);
          for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
          arrayBuf = bytes.buffer;
        }
      }
      if (!arrayBuf) {
        const resp = await fetch(srcUrl);
        arrayBuf = await resp.arrayBuffer();
      }
      const decoded = await decodeCtx.decodeAudioData(arrayBuf);
      if (activeCache) activeCache.set(key, decoded);
      return decoded;
    })();

    if (hasInFlightApi && typeof activeCache.setInFlight === 'function') activeCache.setInFlight(key, work);
    try {
      return await work;
    } finally {
      if (hasInFlightApi && typeof activeCache.clearInFlight === 'function') activeCache.clearInFlight(key);
    }
  }

  /**
   * Decodes an array of audio URLs in bounded parallel batches with shared cache deduplication.
   */
  async function decodeAudioBatch(decodeCtx, srcUrls, options = {}) {
    const urls = Array.isArray(srcUrls) ? srcUrls : [];
    const concurrency = Math.max(1, Math.min(8, options.concurrency || 4));
    const cache = options.cache || createDecodedAudioCache(128);
    const shouldCancel = typeof options.shouldCancel === 'function' ? options.shouldCancel : null;
    const onProgress = typeof options.onProgress === 'function' ? options.onProgress : null;
    const results = new Array(urls.length);
    let cursor = 0;
    let completed = 0;

    async function worker() {
      while (true) {
        if (shouldCancel && shouldCancel()) throw new Error('Export cancelled');
        const idx = cursor++;
        if (idx >= urls.length) break;
        results[idx] = await decodeAudioSourceFast(decodeCtx, urls[idx], cache);
        completed++;
        if (onProgress) onProgress(completed, urls.length);
      }
    }

    const workers = [];
    const n = Math.min(concurrency, Math.max(1, urls.length));
    for (let i = 0; i < n; i++) workers.push(worker());
    await Promise.all(workers);

    return {
      buffers: results,
      cacheHits: cache.hits,
      cacheMisses: cache.misses
    };
  }

  function makeMonoContainer(mono, sr) {
    return {
      sampleRate: sr,
      numberOfChannels: 1,
      length: mono.length,
      duration: mono.length / sr,
      getChannelData() {
        return mono;
      }
    };
  }

  function streamFloatToPcm16Chunks(channelData, chunkSamples, onChunk) {
    const len = channelData ? channelData.length : 0;
    const step = Math.max(1024, chunkSamples || 65536);
    const tmp = new Int16Array(Math.min(step, Math.max(1, len)));
    for (let off = 0; off < len; off += step) {
      const n = Math.min(step, len - off);
      for (let i = 0; i < n; i++) {
        let s = channelData[off + i];
        if (s > 1) s = 1;
        else if (s < -1) s = -1;
        tmp[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
      }
      const view = n === tmp.length ? tmp : tmp.subarray(0, n);
      onChunk(new Uint8Array(view.buffer, view.byteOffset, view.byteLength), off, n);
    }
  }

  /**
   * Direct oscillator note mixer (matches WebAudio toneNodes / cdNote frequency sweeps & envelopes).
   */
  function mixOscNote(left, right, sr, type, fStart, startSec, lenSec, vol, fEnd, lpfHz) {
    const startIdx = Math.max(0, Math.floor(startSec * sr));
    const noteSamples = Math.max(1, Math.floor((lenSec + 0.03) * sr));
    const endIdx = Math.min(left.length, startIdx + noteSamples);
    if (endIdx <= startIdx) return;

    const attackSamples = Math.max(1, Math.floor(0.012 * sr));
    const decaySamples = Math.max(1, noteSamples - attackSamples);
    const hasSweep = fEnd && fEnd > 0 && fEnd !== fStart;
    const freqRatio = hasSweep ? Math.pow(fEnd / Math.max(1, fStart), 1 / Math.max(1, lenSec * sr)) : 1;

    // 1-pole IIR lowpass approximation when lpfHz is specified
    const rc = lpfHz ? 1 / (2 * Math.PI * lpfHz) : 0;
    const dt = 1 / sr;
    const alphaLpf = lpfHz ? dt / (rc + dt) : 1;
    let lpfState = 0;

    let phase = 0;
    let freq = fStart;
    let envDecay = 1;
    const expDecayStep = Math.pow(0.001, 1 / decaySamples);

    for (let i = startIdx; i < endIdx; i++) {
      const rel = i - startIdx;
      let env;
      if (rel < attackSamples) {
        env = (rel / attackSamples) * vol;
      } else {
        env = vol * envDecay;
        envDecay *= expDecayStep;
      }

      phase += (freq / sr);
      phase -= Math.floor(phase);

      let wave = 0;
      if (type === 'square') {
        wave = phase < 0.5 ? 1 : -1;
      } else if (type === 'triangle') {
        wave = 1 - 4 * Math.abs(Math.round(phase - 0.25) - (phase - 0.25));
      } else {
        wave = Math.sin(phase * Math.PI * 2);
      }

      if (lpfHz) {
        lpfState += alphaLpf * (wave - lpfState);
        wave = lpfState;
      }

      const sample = wave * env;
      left[i] += sample;
      right[i] += sample;
      if (hasSweep) freq *= freqRatio;
    }
  }

  function buildRevealChimeStamp(sr) {
    const len = Math.ceil(0.8 * sr);
    const l = new Float32Array(len);
    const r = new Float32Array(len);
    mixOscNote(l, r, sr, 'triangle', 392, 0.00, 0.18, 0.19, 0, 0);
    mixOscNote(l, r, sr, 'triangle', 311, 0.11, 0.28, 0.17, 0, 0);
    mixOscNote(l, r, sr, 'sine', 880, 0.22, 0.14, 0.20, 0, 0);
    mixOscNote(l, r, sr, 'sine', 1175, 0.31, 0.20, 0.17, 0, 0);
    mixOscNote(l, r, sr, 'sine', 1568, 0.40, 0.26, 0.10, 0, 0);
    return { left: l, right: r, length: len };
  }

  function applyFadeOutWindow(left, right, sr, durSec) {
    const fadeSamples = Math.min(left.length, Math.floor(0.15 * sr));
    const startFade = Math.max(0, Math.floor(durSec * sr) - fadeSamples);
    for (let i = startFade; i < left.length; i++) {
      const k = Math.max(0, 1 - (i - startFade) / Math.max(1, fadeSamples));
      left[i] *= k;
      right[i] *= k;
    }
  }

  function buildSynthCountdownStamp(soundId, durSec, sr) {
    const dur = Math.max(0.2, Number(durSec) || 10);
    const len = Math.ceil((dur + 0.35) * sr);
    const l = new Float32Array(len);
    const r = new Float32Array(len);
    const levels = { clock: 1.15, pulse: 0.6, drums: 0.62, digital: 0.55, keys: 0.5 };
    const lv = levels[soundId] || 0.55;

    if (soundId === 'clock') {
      let t = 0, i = 0;
      while (t < dur - 0.05) {
        const fast = t > dur - 3.2;
        const iv = fast ? 0.5 : 1;
        mixOscNote(l, r, sr, 'square', i % 2 ? 1350 : 1850, t, 0.035, 0.35 * lv, 0, 5200);
        mixOscNote(l, r, sr, 'sine', i % 2 ? 620 : 880, t, 0.09, 0.5 * lv, 0, 0);
        if (fast) mixOscNote(l, r, sr, 'sine', 2400, t + 0.01, 0.05, 0.12 * lv, 0, 0);
        t += iv; i++;
      }
    } else if (soundId === 'pulse') {
      let t = 0;
      while (t < dur - 0.05) {
        const fast = t > dur - 3;
        const iv = fast ? 0.5 : 1;
        mixOscNote(l, r, sr, 'sine', 130, t, 0.28, 0.95 * lv, 44, 0);
        mixOscNote(l, r, sr, 'triangle', 260, t, 0.12, 0.25 * lv, 90, 0);
        mixOscNote(l, r, sr, 'square', 1900, t, 0.03, 0.18 * lv, 0, 5200);
        t += iv;
      }
    } else if (soundId === 'drums') {
      let t = 0, i = 0;
      while (t < dur - 0.05) {
        const fast = t > dur - 3;
        const iv = fast ? 0.5 : 1;
        const k = t / dur;
        mixOscNote(l, r, sr, 'sine', 160, t, 0.32, 1.0 * lv, 40, 0);
        mixOscNote(l, r, sr, 'sine', 90, t, 0.3, 0.6 * lv, 36, 0);
        if (i % 2 === 1 || fast) mixOscNote(l, r, sr, 'triangle', 420, t + iv * 0.5, 0.09, 0.16 * lv, 180, 0);
        if (k > 0.55) mixOscNote(l, r, sr, 'sine', 220, t, 0.2, 0.3 * lv, 60, 0);
        t += iv; i++;
      }
    } else if (soundId === 'digital') {
      let t = 0;
      while (t < dur - 0.05) {
        const last = t >= dur - 1;
        mixOscNote(l, r, sr, 'sine', last ? 1318 : 880, t, last ? 0.3 : 0.08, 0.6 * lv, 0, 0);
        if (!last) mixOscNote(l, r, sr, 'sine', 1760, t, 0.04, 0.12 * lv, 0, 0);
        t += 1;
      }
    } else if (soundId === 'keys') {
      const seq = [110, 110, 130.81, 110, 110, 164.81, 146.83, 130.81];
      let t = 0, i = 0;
      while (t < dur - 0.05) {
        const k = t / dur;
        const iv = 0.5 * Math.pow(0.45, k) + 0.14;
        const f = seq[i % seq.length] * (i >= seq.length ? 2 : 1);
        mixOscNote(l, r, sr, 'triangle', f, t, Math.min(0.3, iv * 1.15), 0.8 * lv, 0, 0);
        mixOscNote(l, r, sr, 'sine', f * 2, t, Math.min(0.2, iv), 0.18 * lv, 0, 0);
        t += iv; i++;
      }
    }
    applyFadeOutWindow(l, r, sr, dur);
    return { left: l, right: r, length: len };
  }

  /**
   * Mixes a source AudioBuffer or channel pair directly into stereo target Float32Arrays.
   */
  function mixBufferIntoStereo(outL, outR, outSr, srcBuf, startSec, gain = 1, trimStartSec = 0, maxOutDurSec = null, playbackRate = 1) {
    if (!srcBuf) return;
    const srcSr = srcBuf.sampleRate || outSr;
    const chCount = srcBuf.numberOfChannels || 1;
    const srcL = srcBuf.getChannelData(0);
    const srcR = chCount > 1 ? srcBuf.getChannelData(1) : srcL;
    if (!srcL || !srcL.length) return;

    const dstStart = Math.max(0, Math.floor(startSec * outSr));
    const srcStart = Math.max(0, trimStartSec * srcSr);
    const srcRatePerOutSample = (srcSr * Math.max(0.25, playbackRate)) / outSr;
    const maxSrcAvailOut = Math.floor((srcL.length - srcStart) / srcRatePerOutSample);
    const desiredOut = maxOutDurSec !== null && maxOutDurSec !== undefined
      ? Math.min(maxSrcAvailOut, Math.ceil(maxOutDurSec * outSr))
      : maxSrcAvailOut;
    const dstEnd = Math.min(outL.length, dstStart + Math.max(0, desiredOut));
    if (dstEnd <= dstStart) return;

    const sameBufferMono = outL === outR;
    const exactCopy = Math.abs(srcRatePerOutSample - 1) < 1e-6 && Math.abs(srcStart - Math.round(srcStart)) < 1e-6;
    if (exactCopy) {
      const sOff = Math.round(srcStart);
      const count = Math.min(dstEnd - dstStart, srcL.length - sOff);
      if (sameBufferMono) {
        const isSrcMono = srcL === srcR || chCount === 1;
        if (isSrcMono) {
          for (let k = 0; k < count; k++) outL[dstStart + k] += srcL[sOff + k] * gain;
        } else {
          for (let k = 0; k < count; k++) outL[dstStart + k] += 0.5 * (srcL[sOff + k] + srcR[sOff + k]) * gain;
        }
      } else if (gain === 1) {
        for (let k = 0; k < count; k++) {
          outL[dstStart + k] += srcL[sOff + k];
          outR[dstStart + k] += srcR[sOff + k];
        }
      } else {
        for (let k = 0; k < count; k++) {
          outL[dstStart + k] += srcL[sOff + k] * gain;
          outR[dstStart + k] += srcR[sOff + k] * gain;
        }
      }
      return;
    }

    const lastIdx = srcL.length - 1;
    for (let dstIdx = dstStart, step = 0; dstIdx < dstEnd; dstIdx++, step++) {
      const pos = srcStart + step * srcRatePerOutSample;
      const i0 = Math.floor(pos);
      if (i0 >= srcL.length) break;
      const i1 = i0 < lastIdx ? i0 + 1 : lastIdx;
      const frac = pos - i0;
      const sL = srcL[i0] + (srcL[i1] - srcL[i0]) * frac;
      const sR = srcR[i0] + (srcR[i1] - srcR[i0]) * frac;
      if (sameBufferMono) {
        outL[dstIdx] += 0.5 * (sL + sR) * gain;
      } else {
        outL[dstIdx] += sL * gain;
        outR[dstIdx] += sR * gain;
      }
    }
  }

  function findTrimWindow(buf) {
    if (buf._trim) return buf._trim;
    const sr = buf.sampleRate || DEFAULT_SAMPLE_RATE;
    const chCount = buf.numberOfChannels || 1;
    let a = 0, b = buf.length;
    outer: for (let c = 0; c < chCount; c++) {
      const d = buf.getChannelData(c);
      for (let i = 0; i < d.length; i++) { if (Math.abs(d[i]) > 0.02) { a = i; break outer; } }
    }
    outer2: for (let c = 0; c < chCount; c++) {
      const d = buf.getChannelData(c);
      for (let i = d.length - 1; i > 0; i--) { if (Math.abs(d[i]) > 0.02) { b = i + 1; break outer2; } }
    }
    buf._trim = { start: Math.max(0, a / sr - 0.03), end: Math.min(buf.length / sr, b / sr + 0.05) };
    return buf._trim;
  }

  /**
   * Renders the full stereo 48kHz audio track directly in chunked question-by-question passes
   * with live progress callbacks, event-loop yields, and responsive cancellation.
   */
  async function renderQuizAudioTrack(timeline, voiceBufs, answerBufs, options = {}) {
    const t0 = typeof performance !== 'undefined' && performance.now ? performance.now() : Date.now();
    const sr = options.sampleRate || DEFAULT_SAMPLE_RATE;
    const withNarration = options.withNarration !== undefined ? !!options.withNarration : true;
    const cdSound = options.cdSound || 'clock';
    const customCdBuf = options.customCdBuf
      || (cdSound === 'file' ? options.countdownBuf : (options.customBufs && options.customBufs[cdSound]))
      || null;
    const hasCdSound = options.hasCdSound !== undefined ? !!options.hasCdSound : cdSound !== 'none';
    const onProgress = typeof options.onProgress === 'function' ? options.onProgress : null;
    const shouldCancel = typeof options.shouldCancel === 'function' ? options.shouldCancel : null;
    const yieldFn = typeof options.yieldFn === 'function'
      ? options.yieldFn
      : () => new Promise(resolve => setTimeout(resolve, 0));

    const segs = Array.isArray(timeline && timeline.segs) ? timeline.segs : [];
    const totalSec = Math.max(0.05, Number(timeline && timeline.total) || 0.05);
    const totalSamples = Math.max(1, Math.ceil(totalSec * sr));

    const monoOnly = !!options.monoOnly;
    const outL = new Float32Array(totalSamples);
    const outR = monoOnly ? outL : new Float32Array(totalSamples);

    // Group segments by question index so UI advances strictly question-by-question
    const groupsMap = new Map();
    let maxQIdx = -1;
    for (let sIdx = 0; sIdx < segs.length; sIdx++) {
      const seg = segs[sIdx];
      const qi = seg.i || 0;
      if (qi > maxQIdx) maxQIdx = qi;
      if (!groupsMap.has(qi)) groupsMap.set(qi, []);
      groupsMap.get(qi).push(seg);
    }
    const qIndices = Array.from(groupsMap.keys()).sort((a, b) => a - b);
    const totalQuestions = Math.max(1, options.totalQuestions || (maxQIdx + 1) || qIndices.length);

    // Cache deterministic SFX stamps once across the entire quiz
    const revealStamp = buildRevealChimeStamp(sr);
    const synthCountdownCache = new Map();
    const getSynthCountdown = dur => {
      const key = cdSound + '|' + Math.round((Number(dur) || 0) * 100);
      if (!synthCountdownCache.has(key)) {
        synthCountdownCache.set(key, buildSynthCountdownStamp(cdSound, dur, sr));
      }
      return synthCountdownCache.get(key);
    };

    let customCdGain = 1;
    let customCdTrim = null;
    if (customCdBuf) {
      customCdTrim = findTrimWindow(customCdBuf);
      if (customCdBuf._pk === undefined) {
        let p = 0;
        const chs = customCdBuf.numberOfChannels || 1;
        for (let c = 0; c < chs; c++) {
          const d = customCdBuf.getChannelData(c);
          for (let i = 0; i < d.length; i += 2) p = Math.max(p, Math.abs(d[i]));
        }
        customCdBuf._pk = p;
      }
      customCdGain = customCdBuf._pk > 0.9 ? 0.9 / customCdBuf._pk : 1;
    }

    for (let idx = 0; idx < qIndices.length; idx++) {
      if (shouldCancel && shouldCancel()) {
        throw new Error('Export cancelled');
      }
      const qi = qIndices[idx];
      const qSegs = groupsMap.get(qi) || [];

      if (onProgress) {
        const fraction = (idx / Math.max(1, qIndices.length)) * 0.95;
        onProgress({
          stage: 'rendering_question',
          questionIndex: qi,
          questionNumber: qi + 1,
          completedQuestions: idx,
          totalQuestions,
          fraction,
          percent: Math.min(95, Math.round(fraction * 100)),
          message: `Rendering audio — Question ${qi + 1} of ${totalQuestions}`
        });
      }

      for (let s = 0; s < qSegs.length; s++) {
        const seg = qSegs[s];
        if (seg.type === 'voice' && withNarration && voiceBufs && voiceBufs[seg.i]) {
          mixBufferIntoStereo(outL, outR, sr, voiceBufs[seg.i], seg.start, 1);
        } else if (seg.type === 'answer' && withNarration && answerBufs && answerBufs[seg.i]) {
          mixBufferIntoStereo(outL, outR, sr, answerBufs[seg.i], seg.start, 1);
        } else if (seg.type === 'count' && cdSound !== 'none') {
          if (customCdBuf && (cdSound === 'file' || /^(custom[1-3]|pack1)$/.test(cdSound))) {
            const tr = customCdTrim;
            const eff = Math.max(0.2, tr.end - tr.start);
            const rate = Math.min(2, Math.max(0.5, eff / Math.max(0.2, seg.dur)));
            mixBufferIntoStereo(outL, outR, sr, customCdBuf, seg.start, customCdGain, tr.start, seg.dur + 0.05, rate);
          } else if (['clock', 'pulse', 'drums', 'digital', 'keys'].includes(cdSound)) {
            const stamp = getSynthCountdown(seg.dur);
            mixBufferIntoStereo(
              outL,
              outR,
              sr,
              { sampleRate: sr, numberOfChannels: 2, length: stamp.length, getChannelData: c => (c === 1 ? stamp.right : stamp.left) },
              seg.start,
              1
            );
          }
        } else if (seg.type === 'reveal') {
          mixBufferIntoStereo(
            outL,
            outR,
            sr,
            { sampleRate: sr, numberOfChannels: 2, length: revealStamp.length, getChannelData: c => (c === 1 ? revealStamp.right : revealStamp.left) },
            seg.start,
            1
          );
        }
      }

      // Yield cleanly every question (or batch) so DOM progress updates & Stop button remain responsive
      await yieldFn();
    }

    if (shouldCancel && shouldCancel()) {
      throw new Error('Export cancelled');
    }

    if (onProgress) {
      onProgress({
        stage: 'finalizing_audio',
        questionIndex: totalQuestions - 1,
        questionNumber: totalQuestions,
        completedQuestions: totalQuestions,
        totalQuestions,
        fraction: 0.95,
        percent: 95,
        message: 'Mixing background music…'
      });
    }

    const bgmBuf = options.bgmBuf || null;
    const bgmVolume = options.bgmVolume !== undefined ? Number(options.bgmVolume) : 0.25;
    const bgmLoop = options.bgmLoop !== undefined ? !!options.bgmLoop : true;
    const autoDuck = options.autoDuck !== undefined ? !!options.autoDuck : true;

    if (bgmBuf && bgmVolume > 0) {
      const duckFactor = new Float32Array(totalSamples);
      duckFactor.fill(1.0);
      if (autoDuck) {
        for (let sIdx = 0; sIdx < segs.length; sIdx++) {
          const seg = segs[sIdx];
          if (seg.type === 'voice' || seg.type === 'answer') {
            const startSample = Math.max(0, Math.floor(seg.start * sr));
            const endSample = Math.min(totalSamples, Math.ceil((seg.start + seg.dur) * sr));
            for (let i = startSample; i < endSample; i++) {
              duckFactor[i] = 0.35;
            }
          }
        }
      }
      const bgmL = bgmBuf.getChannelData(0);
      const bgmR = bgmBuf.numberOfChannels > 1 ? bgmBuf.getChannelData(1) : bgmL;
      const bgmLen = bgmL.length;
      if (bgmLen > 0) {
        for (let i = 0; i < totalSamples; i++) {
          const bgmIdx = bgmLoop ? (i % bgmLen) : i;
          if (bgmIdx < bgmLen) {
            const duck = autoDuck ? duckFactor[i] : 1.0;
            const vol = bgmVolume * duck;
            outL[i] += bgmL[bgmIdx] * vol;
            outR[i] += bgmR[bgmIdx] * vol;
          }
        }
      }
    }

    // Clamp peaks cleanly to avoid hard integer wrap during PCM16 conversion
    if (monoOnly) {
      for (let i = 0; i < totalSamples; i++) {
        if (outL[i] > 1) outL[i] = 1;
        else if (outL[i] < -1) outL[i] = -1;
      }
    } else {
      for (let i = 0; i < totalSamples; i++) {
        if (outL[i] > 1) outL[i] = 1;
        else if (outL[i] < -1) outL[i] = -1;
        if (outR[i] > 1) outR[i] = 1;
        else if (outR[i] < -1) outR[i] = -1;
      }
    }

    // Verify countdown RMS presence if countdown sound enabled (mirrors original check)
    let ok = null;
    const cs = segs.find(s => s.type === 'count');
    if (cs && hasCdSound) {
      const a = Math.max(0, Math.floor(cs.start * sr));
      const cdDur = customCdBuf ? Math.min(cs.dur, customCdBuf.length / (customCdBuf.sampleRate || sr)) : cs.dur;
      const b = Math.min(outL.length, Math.floor((cs.start + cdDur) * sr));
      let sum = 0, n = 0;
      for (let i = a; i < b; i += 8) {
        sum += outL[i] * outL[i];
        n++;
      }
      ok = Math.sqrt(sum / Math.max(1, n)) > 0.002;
    }

    const buf = monoOnly ? makeMonoContainer(outL, sr) : makeStereoContainer(outL, outR, sr);
    const t1 = typeof performance !== 'undefined' && performance.now ? performance.now() : Date.now();

    if (onProgress) {
      onProgress({
        stage: 'audio_complete',
        questionIndex: totalQuestions - 1,
        questionNumber: totalQuestions,
        completedQuestions: totalQuestions,
        totalQuestions,
        fraction: 1,
        percent: 100,
        message: 'Audio rendering complete'
      });
    }

    return {
      buf,
      ok,
      metrics: {
        engine: 'direct-stereo-pcm',
        sampleRate: sr,
        totalSamples,
        totalDurationSec: totalSec,
        questionCount: qIndices.length,
        renderTimeMs: Math.round((t1 - t0) * 100) / 100
      }
    };
  }

  return {
    DEFAULT_SAMPLE_RATE,
    createDecodedAudioCache,
    decodeAudioSourceFast,
    decodeAudioBatch,
    streamFloatToPcm16Chunks,
    mixBufferIntoStereo,
    buildSynthCountdownStamp,
    buildRevealChimeStamp,
    renderQuizAudioTrack
  };
});
