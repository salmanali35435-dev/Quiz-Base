package com.quizstudiopro.app.storage

import android.content.Context
import android.net.Uri
import com.quizstudiopro.app.logging.QuizLogger
import org.json.JSONArray
import org.json.JSONObject

/**
 * Persistent registry of verified, successfully published MediaStore quiz video exports.
 *
 * Ensures:
 * 1. Only verified, non-zero, readable `content://` MediaStore URIs are ever registered.
 * 2. History survives app restarts via `SharedPreferences`.
 * 3. Every listed entry is re-checked live against `ContentResolver` so missing/deleted videos
 *    are pruned and never break Recent Videos / Preview controls.
 */
object RecentVideosStore {
    private const val TAG = "RecentVideosStore"
    private const val PREFS_NAME = "qsp_recent_videos_prefs"
    private const val KEY_ENTRIES = "recent_videos_json"
    private const val MAX_ENTRIES = 25

    data class RecentVideoEntry(
        val jobId: String,
        val uri: String,
        val fileName: String,
        val relativePath: String,
        val sizeBytes: Long,
        val width: Int = 0,
        val height: Int = 0,
        val fps: Int = 0,
        val durationMs: Long = 0L,
        val createdAtMs: Long = System.currentTimeMillis()
    ) {
        fun previewUrl(): String {
            return "https://appassets.androidplatform.net/exported/${Uri.encode(fileName)}?uri=${Uri.encode(uri)}"
        }

        fun toJson(): JSONObject = JSONObject().apply {
            put("jobId", jobId)
            put("uri", uri)
            put("fileName", fileName)
            put("relativePath", relativePath)
            put("sizeBytes", sizeBytes)
            put("width", width)
            put("height", height)
            put("fps", fps)
            put("durationMs", durationMs)
            put("createdAtMs", createdAtMs)
            put("previewUrl", previewUrl())
        }

        companion object {
            fun fromJson(obj: JSONObject): RecentVideoEntry? {
                val uriStr = obj.optString("uri", "").trim()
                val fileName = obj.optString("fileName", "").trim()
                if (uriStr.isEmpty() || fileName.isEmpty()) return null
                return RecentVideoEntry(
                    jobId = obj.optString("jobId", ""),
                    uri = uriStr,
                    fileName = fileName,
                    relativePath = obj.optString("relativePath", MediaStoreVideoStorage.VIDEO_RELATIVE_PATH),
                    sizeBytes = obj.optLong("sizeBytes", 0L),
                    width = obj.optInt("width", 0),
                    height = obj.optInt("height", 0),
                    fps = obj.optInt("fps", 0),
                    durationMs = obj.optLong("durationMs", 0L),
                    createdAtMs = obj.optLong("createdAtMs", 0L)
                )
            }
        }
    }

    @Synchronized
    fun recordVerifiedExport(
        context: Context,
        entry: RecentVideoEntry,
        verifyReadable: Boolean = true
    ): Boolean {
        if (entry.uri.isBlank() || entry.fileName.isBlank() || entry.sizeBytes <= 0L) {
            QuizLogger.warn(TAG, "Refused to register incomplete export entry: uri=${entry.uri} size=${entry.sizeBytes}")
            return false
        }
        if (verifyReadable && !isUriReadable(context, entry.uri)) {
            QuizLogger.warn(TAG, "Refused to register unreadable MediaStore URI: ${entry.uri}")
            return false
        }
        val current = loadRaw(context).filterNot { it.uri == entry.uri }
        val updated = (listOf(entry) + current).take(MAX_ENTRIES)
        saveRaw(context, updated)
        QuizLogger.info(TAG, "Registered verified export: ${entry.relativePath}/${entry.fileName} (${entry.sizeBytes} B, uri=${entry.uri})")
        return true
    }

    @Synchronized
    fun listVerified(context: Context, pruneMissing: Boolean = true): List<RecentVideoEntry> {
        val raw = loadRaw(context)
        if (raw.isEmpty()) return emptyList()
        val live = ArrayList<RecentVideoEntry>(raw.size)
        var pruned = false
        for (entry in raw) {
            if (isUriReadable(context, entry.uri)) {
                live.add(entry)
            } else {
                pruned = true
            }
        }
        if (pruneMissing && pruned) {
            saveRaw(context, live)
        }
        return live
    }

    @Synchronized
    fun latestVerified(context: Context): RecentVideoEntry? = listVerified(context, pruneMissing = true).firstOrNull()

    @Synchronized
    fun findAuthorizedUri(context: Context, candidateUri: String?, candidateFileName: String?): Uri? {
        val verified = listVerified(context, pruneMissing = true)
        if (!candidateUri.isNullOrBlank()) {
            val match = verified.firstOrNull { it.uri == candidateUri }
            if (match != null) return Uri.parse(match.uri)
        }
        if (!candidateFileName.isNullOrBlank()) {
            val match = verified.firstOrNull { it.fileName == candidateFileName }
            if (match != null) return Uri.parse(match.uri)
        }
        return null
    }

    @Synchronized
    fun clear(context: Context) {
        context.applicationContext
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_ENTRIES)
            .apply()
    }

    fun isUriReadable(context: Context, uriString: String): Boolean {
        return try {
            val uri = Uri.parse(uriString)
            val bytes = MediaStoreVideoStorage.verifyPublishedUriReadable(
                contentResolver = context.contentResolver,
                uri = uri,
                expectedMinBytes = 1L
            )
            bytes > 0L
        } catch (_: Throwable) {
            false
        }
    }

    private fun loadRaw(context: Context): List<RecentVideoEntry> {
        val jsonStr = context.applicationContext
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_ENTRIES, null)
            ?.trim()
            ?: return emptyList()
        if (jsonStr.isEmpty()) return emptyList()
        return try {
            val arr = JSONArray(jsonStr)
            val out = ArrayList<RecentVideoEntry>(arr.length())
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                RecentVideoEntry.fromJson(obj)?.let { out.add(it) }
            }
            out
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun saveRaw(context: Context, entries: List<RecentVideoEntry>) {
        val arr = JSONArray()
        for (e in entries) {
            arr.put(e.toJson())
        }
        context.applicationContext
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ENTRIES, arr.toString())
            .apply()
    }
}
