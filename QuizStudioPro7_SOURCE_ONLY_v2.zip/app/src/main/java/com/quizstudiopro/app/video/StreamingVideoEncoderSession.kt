package com.quizstudiopro.app.video

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Build
import android.os.Bundle
import android.view.Surface
import com.quizstudiopro.app.audio.OfflineAudioProcessor
import com.quizstudiopro.app.logging.QuizLogger
import java.io.File
import java.nio.ByteBuffer
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * Asynchronous Producer-Consumer Video + Audio Hardware Encoder Session (V2).
 *
 * Pipeline stages execute concurrently with bounded backpressure queues:
 * - VideoEglThread: Renders via [DirectEglSceneComposer] GPU shaders/FBOs or reusable Bitmap/RGBA -> EGL Surface
 * - VideoDrainThread: Drains encoded H.264/AVC NAL units concurrently without blocking EGL
 * - AudioEncoderThread: Streams PCM16 chunks via [OfflineAudioProcessor] -> AAC MediaCodec in parallel
 * - MuxerWriterThread: Single serialized owner of [MediaMuxer] writing video + audio tracks safely
 *
 * Supports [IntelligentFrameScheduler] frame deduplication (rendering & uploading only changed frames,
 * swapping repeated GPU textures for anchor/GOP/closing frames with exact VFR PTS timestamps).
 */
class StreamingVideoEncoderSession(
    private val outputFile: File,
    private val width: Int,
    private val height: Int,
    private val fps: Int,
    private val totalFrames: Int,
    private val audioPcmFile: File?,
    private val totalAudioSamplesOverride: Long?,
    private val listener: VideoEncoder.ProgressListener?,
    private val mode: Mode = Mode.NATIVE_RGBA_STREAM,
    private val sceneFrameProducer: ((frameIndex: Int, targetBitmap: Bitmap) -> Unit)? = null,
    private val frameScheduler: IntelligentFrameScheduler? = null,
    private val directComposer: DirectEglSceneComposer? = null,
    private val exportJobId: String = "job_${System.currentTimeMillis()}"
) {
    enum class Mode {
        NATIVE_SCENE_DIRECT,
        NATIVE_RGBA_STREAM,
        COMPATIBILITY_FALLBACK
    }

    data class SessionStats(
        val mode: String,
        val codecName: String,
        val isHardwareCodec: Boolean?,
        val width: Int,
        val height: Int,
        val fps: Int,
        val framesProcessed: Int,
        val expectedFrames: Int,
        val droppedFrames: Int,
        val encodeDurationMs: Long,
        val finalizationMs: Long,
        val outputBytes: Long,
        val usedJpegFallback: Boolean,
        val renderedFrames: Int = framesProcessed,
        val skippedDuplicateFrames: Int = 0,
        val directGpuFrames: Int = 0,
        val bitmapFallbackFrames: Int = framesProcessed,
        val textureUploads: Int = framesProcessed,
        val audioEncodeMs: Long = 0L,
        val muxDurationMs: Long = 0L,
        val peakHeapBytes: Long = 0L,
        val fallbackReason: String? = null,
        val expectedAudioSamples: Long = 0L,
        val actualPcmBytes: Long = 0L,
        val aacInputSamples: Long = 0L,
        val aacOutputSamples: Int = 0,
        val firstAudioPtsUs: Long = -1L,
        val lastAudioPtsUs: Long = -1L,
        val audioTrackRegistered: Boolean = false,
        val expectedAudioDurationMs: Long = 0L,
        val actualAudioDurationMs: Long = 0L,
        val mp4DurationMs: Long = 0L,
        val audioError: String? = null,
        val exportJobId: String = "",
        val pipelineStage: String = "COMPLETED",
        val videoTrackRegistered: Boolean = false,
        val writtenVideoSamples: Int = 0,
        val lastVideoPtsUs: Long = -1L,
        val muxerStarted: Boolean = false,
        val attemptedPaths: List<String> = emptyList(),
        val selectedTier: String = ""
    )

    companion object {
        private const val TAG = "StreamingEncoder"
        private const val FRAME_QUEUE_CAPACITY = 8
        private const val MUXER_QUEUE_CAPACITY = 32

        fun computePtsNs(frameIndex: Int, fps: Int): Long {
            val safeFps = if (fps in 10..60) fps else 24
            return frameIndex.toLong() * 1_000_000_000L / safeFps
        }

        fun computeBitRate(width: Int): Int = when {
            width >= 2560 -> 16_000_000
            width >= 1920 -> 10_000_000
            width >= 1280 -> 6_000_000
            else -> 3_500_000
        }
    }

    private data class FrameItem(
        val frameIndex: Int,
        val frameBytes: ByteArray,
        val isRgba: Boolean = false,
        val isEos: Boolean = false,
        val ptsNsOverride: Long? = null,
        val reusePrevious: Boolean = false
    )

    private sealed class MuxerEvent {
        data class TrackFormatReady(val isVideo: Boolean, val format: MediaFormat) : MuxerEvent()
        data class Sample(
            val isVideo: Boolean,
            val data: ByteBuffer,
            val size: Int,
            val ptsUs: Long,
            val flags: Int
        ) : MuxerEvent()
        data class TrackCompleted(val isVideo: Boolean) : MuxerEvent()
    }

    private val frameQueue = ArrayBlockingQueue<FrameItem>(FRAME_QUEUE_CAPACITY)
    private val muxerQueue = ArrayBlockingQueue<MuxerEvent>(MUXER_QUEUE_CAPACITY)
    private val isAborted = AtomicBoolean(false)
    private val isUserCancelled = AtomicBoolean(false)
    private val isFinished = AtomicBoolean(false)
    private val nextExpectedQueueFrame = AtomicInteger(0)

    @Volatile
    private var workerException: Throwable? = null

    @Volatile
    private var lastStats: SessionStats? = null

    private var workerThread: Thread? = null

    fun start() {
        if (outputFile.exists()) {
            outputFile.delete()
        }
        isUserCancelled.set(false)
        isAborted.set(false)
        val t = Thread({
            runPipeline()
        }, "VideoEglCoordinator")
        workerThread = t
        t.start()
    }

    fun getStats(): SessionStats? = lastStats

    fun submitFrameBytes(frameIndex: Int, jpegBytes: ByteArray): Boolean {
        if (mode != Mode.COMPATIBILITY_FALLBACK) {
            QuizLogger.warn(TAG, "[COMPATIBILITY_FALLBACK] JPEG frame submitted on $mode session")
        }
        return submitFrameRaw(frameIndex, jpegBytes, isRgba = false)
    }

    fun submitFrameRaw(
        frameIndex: Int,
        rawBytes: ByteArray,
        isRgba: Boolean = true,
        ptsNsOverride: Long? = null,
        reusePrevious: Boolean = false
    ): Boolean {
        if (isAborted.get()) {
            throw IllegalStateException("Encoder worker aborted: ${workerException?.message ?: "cancelled"}")
        }
        workerException?.let { throw RuntimeException("Encoder worker failed: ${it.message}", it) }

        val expected = nextExpectedQueueFrame.get()
        if (frameIndex < expected) {
            QuizLogger.warn(TAG, "Frame order check: received $frameIndex < expected $expected")
        }
        nextExpectedQueueFrame.set(frameIndex + 1)

        try {
            var offered = false
            while (!offered && !isAborted.get()) {
                workerException?.let { throw RuntimeException("Encoder worker failed: ${it.message}", it) }
                offered = frameQueue.offer(
                    FrameItem(frameIndex, rawBytes, isRgba = isRgba, isEos = false, ptsNsOverride = ptsNsOverride, reusePrevious = reusePrevious),
                    500,
                    TimeUnit.MILLISECONDS
                )
            }
            return offered
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
            return false
        }
    }

    fun finishAndAwait(timeoutMs: Long = 300_000L): Boolean {
        if (isAborted.get()) return false
        if (mode != Mode.NATIVE_SCENE_DIRECT) {
            try {
                frameQueue.offer(FrameItem(totalFrames, ByteArray(0), isEos = true), 15, TimeUnit.SECONDS)
            } catch (_: Exception) {}
        }

        workerThread?.join(timeoutMs)
        workerException?.let { throw RuntimeException("Encoder pipeline error: ${it.message}", it) }
        return isFinished.get() && outputFile.exists() && outputFile.length() > 0
    }

    fun abort() {
        isUserCancelled.set(true)
        isAborted.set(true)
        frameQueue.clear()
        muxerQueue.clear()
        workerThread?.interrupt()
    }

    fun abortAndAwait(timeoutMs: Long = 2000L) {
        abort()
        try {
            workerThread?.join(timeoutMs)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        }
    }

    fun getFailureMessage(): String? = workerException?.message
    fun isAbortedState(): Boolean = isUserCancelled.get() || isAborted.get()
    fun isFinishedSuccessfully(): Boolean = isFinished.get()

    private fun pushMuxerEvent(ev: MuxerEvent) {
        while (!isAborted.get() && !isUserCancelled.get()) {
            if (muxerQueue.offer(ev, 250, TimeUnit.MILLISECONDS)) return
        }
    }

    private fun runPipeline() {
        val selectedFps = if (fps in 10..60) fps else 24
        val attemptLadder = HardwareCodecSelector.buildEncoderAttemptLadder(
            width = width,
            height = height,
            fps = selectedFps,
            mimeType = MediaFormat.MIMETYPE_VIDEO_AVC
        )
        val attemptedPaths = ArrayList<String>()
        var finalFailure: Throwable? = null

        for ((attemptIdx, spec) in attemptLadder.withIndex()) {
            if (isUserCancelled.get()) break

            if (outputFile.exists()) {
                try { outputFile.delete() } catch (_: Exception) {}
            }
            muxerQueue.clear()
            isAborted.set(false)

            val attemptDesc = spec.shortDescriptor()
            attemptedPaths.add(attemptDesc)
            if (attemptIdx > 0) {
                QuizLogger.warn(TAG, "[$exportJobId] Retrying video export with fallback ($attemptDesc)")
                listener?.onProgress(
                    0,
                    totalFrames,
                    "Switching encoder tier: ${spec.label} (${width}x${height}@${selectedFps}fps)",
                    12f
                )
            }

            val hasConsumedQueuedFrame = AtomicBoolean(false)
            val attemptOutcome = runSingleAttempt(
                spec = spec,
                selectedFps = selectedFps,
                attemptedPathsSnapshot = attemptedPaths.toList(),
                isFallbackAttempt = attemptIdx > 0,
                previousFallbackNote = if (attemptIdx > 0) "Fallback after prior encoder failure -> ${spec.label}" else null,
                hasConsumedQueuedFrame = hasConsumedQueuedFrame
            )

            if (attemptOutcome.succeeded) {
                isFinished.set(true)
                return
            }

            finalFailure = attemptOutcome.error
            QuizLogger.warn(
                TAG,
                "[$exportJobId] Encoder attempt failed ($attemptDesc): ${finalFailure?.message}"
            )

            // In JS-streamed frameQueue modes, retrying after frames were already dequeued would drop frames.
            if (mode != Mode.NATIVE_SCENE_DIRECT && hasConsumedQueuedFrame.get()) {
                QuizLogger.warn(TAG, "[$exportJobId] Stopping native retry because frameQueue already consumed frames in $mode")
                break
            }
        }

        isAborted.set(true)
        frameQueue.clear()
        muxerQueue.clear()
        if (outputFile.exists()) {
            try { outputFile.delete() } catch (_: Exception) {}
        }

        val errObj = finalFailure ?: IllegalStateException(
            if (isUserCancelled.get()) "Export cancelled"
            else "All native video encoder tiers failed for ${width}x${height}@${selectedFps}fps (attempted: ${attemptedPaths.joinToString("; ")})"
        )
        workerException = errObj
        val prev = lastStats
        if (prev != null) {
            lastStats = prev.copy(
                attemptedPaths = attemptedPaths.toList(),
                selectedTier = attemptLadder.lastOrNull()?.tier?.name ?: prev.selectedTier,
                audioError = prev.audioError ?: errObj.message
            )
        }
    }

    private data class AttemptResult(
        val succeeded: Boolean,
        val error: Throwable? = null
    )

    private fun runSingleAttempt(
        spec: HardwareCodecSelector.EncoderAttemptSpec,
        selectedFps: Int,
        attemptedPathsSnapshot: List<String>,
        isFallbackAttempt: Boolean,
        previousFallbackNote: String?,
        hasConsumedQueuedFrame: AtomicBoolean
    ): AttemptResult {
        val pipelineStartMs = System.currentTimeMillis()
        var videoCodec: MediaCodec? = null
        var audioCodec: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var inputSurface: Surface? = null
        var eglRenderer: EglTextureRenderer? = null
        var audioProcessor: OfflineAudioProcessor? = null
        var reusableSceneBitmap: Bitmap? = null
        var reusableRgbaBuffer: ByteBuffer? = null

        var videoDrainThread: Thread? = null
        var audioWorkerThread: Thread? = null
        var muxerWriterThread: Thread? = null

        val hasAudio = if (totalAudioSamplesOverride != null) {
            totalAudioSamplesOverride > 0L
        } else {
            audioPcmFile != null && audioPcmFile.exists() && audioPcmFile.length() > 0L
        }

        var selectedCodecName = spec.codecName ?: "unknown"
        var selectedCodecHardware: Boolean? = spec.isHardwareAccelerated
        val codecFallbackReason: String? = previousFallbackNote
            ?: if (!spec.isHardwareAccelerated) "Using software encoder tier (${spec.label})" else null
        var framesEncoded = 0
        var framesRendered = 0
        var skippedDuplicateFrames = 0
        var textureUploads = 0
        var finalizationStartMs = 0L
        val audioDurationMs = AtomicLong(0L)
        val muxDurationMs = AtomicLong(0L)
        val muxerStartedFlag = AtomicBoolean(false)
        val muxerEverStartedFlag = AtomicBoolean(false)
        val pipelineStageRef = AtomicReference("CODEC_SETUP")
        val attemptErrorRef = AtomicReference<Throwable?>(null)
        val expectedAudioSamplesVal = totalAudioSamplesOverride ?: if (audioPcmFile != null && audioPcmFile.exists()) audioPcmFile.length() / 2L else 0L
        val actualPcmBytesVal = if (audioPcmFile != null && audioPcmFile.exists()) audioPcmFile.length() else 0L
        val expectedAudioDurMs = (expectedAudioSamplesVal * 1000L) / 48000L
        val aacInputSamplesCount = AtomicLong(0L)
        val aacOutputSamplesCount = AtomicInteger(0)
        val writtenVideoSamplesCount = AtomicInteger(0)
        val firstAudioPtsUs = AtomicLong(-1L)
        val lastAudioPtsUs = AtomicLong(-1L)
        val lastMuxVideoPtsUs = AtomicLong(-1L)
        val videoTrackRegistered = AtomicBoolean(false)
        val audioTrackRegistered = AtomicBoolean(false)
        val audioErrorMsg = AtomicReference<String?>(null)
        val runtime = Runtime.getRuntime()
        var peakHeapBytes = runtime.totalMemory() - runtime.freeMemory()

        fun sampleMemory() {
            val used = runtime.totalMemory() - runtime.freeMemory()
            if (used > peakHeapBytes) peakHeapBytes = used
        }

        fun failAttempt(t: Throwable) {
            attemptErrorRef.compareAndSet(null, t)
            isAborted.set(true)
        }

        try {
            val codec = HardwareCodecSelector.createCodecForAttempt(spec, MediaFormat.MIMETYPE_VIDEO_AVC)
            videoCodec = codec
            selectedCodecName = try { codec.name } catch (_: Throwable) { spec.codecName ?: "unknown" }
            selectedCodecHardware = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try {
                    codec.codecInfo.isHardwareAccelerated && !codec.codecInfo.isSoftwareOnly
                } catch (_: Throwable) {
                    spec.isHardwareAccelerated
                }
            } else {
                !HardwareCodecSelector.isKnownSoftwareCodecName(selectedCodecName)
            }

            val videoFormat = HardwareCodecSelector.configureVideoFormat(
                spec = spec,
                width = width,
                height = height,
                fps = selectedFps,
                gopSeconds = 2
            )

            QuizLogger.info(
                TAG,
                "Pipeline V2 attempt mode=$mode tier=${spec.tier.name} input=${spec.inputMode.name} codec=$selectedCodecName hw=$selectedCodecHardware ${width}x${height}@${selectedFps}fps frames=$totalFrames"
            )

            codec.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            if (spec.inputMode == HardwareCodecSelector.InputMode.SURFACE) {
                val sfc = codec.createInputSurface()
                inputSurface = sfc
                codec.start()
                eglRenderer = EglTextureRenderer(sfc, width, height)
            } else {
                codec.start()
            }

            if (hasAudio) {
                val pcm = audioPcmFile
                    ?: throw IllegalStateException("PCM file missing: audio expected ($expectedAudioSamplesVal samples) but audioPcmFile is null")
                audioProcessor = OfflineAudioProcessor(
                    pcmFile = pcm,
                    sampleRate = 48000,
                    channels = 1,
                    totalSamplesOverride = totalAudioSamplesOverride
                ).also { it.open() }

                val audioFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, 48000, 1).apply {
                    setInteger(MediaFormat.KEY_BIT_RATE, 192000)
                    setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                    setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
                    setInteger(MediaFormat.KEY_CHANNEL_COUNT, 1)
                    setInteger(MediaFormat.KEY_SAMPLE_RATE, 48000)
                }
                audioCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
                audioCodec.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                audioCodec.start()
            }

            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            // 1. Dedicated MuxerWriterThread
            val mWriter = Thread({
                val mStart = System.currentTimeMillis()
                try {
                    var vTrack = -1
                    var aTrack = -1
                    var started = false
                    var vDone = false
                    var aDone = !hasAudio
                    var lastMuxAudioPts = -1L
                    var lastMuxVideoPts = -1L
                    val pendingV = ArrayList<VideoEncoder.PendingSample>()
                    val pendingA = ArrayList<VideoEncoder.PendingSample>()

                    fun writeSampleSafe(isVideo: Boolean, trk: Int, data: ByteBuffer, info: MediaCodec.BufferInfo) {
                        if (isVideo) {
                            val pts = maxOf(0L, if (lastMuxVideoPts >= 0L && info.presentationTimeUs < lastMuxVideoPts) lastMuxVideoPts else info.presentationTimeUs)
                            if (pts != info.presentationTimeUs) info.presentationTimeUs = pts
                            lastMuxVideoPts = pts
                            lastMuxVideoPtsUs.set(pts)
                            writtenVideoSamplesCount.incrementAndGet()
                            muxer.writeSampleData(trk, data, info)
                        } else {
                            val pts = maxOf(0L, if (lastMuxAudioPts >= 0L && info.presentationTimeUs < lastMuxAudioPts) lastMuxAudioPts else info.presentationTimeUs)
                            if (pts != info.presentationTimeUs) info.presentationTimeUs = pts
                            lastMuxAudioPts = pts
                            if (firstAudioPtsUs.get() < 0L) firstAudioPtsUs.set(pts)
                            lastAudioPtsUs.set(pts)
                            aacOutputSamplesCount.incrementAndGet()
                            muxer.writeSampleData(trk, data, info)
                        }
                    }

                    while (!isAborted.get() && !isUserCancelled.get() && (!vDone || !aDone)) {
                        val ev = muxerQueue.poll(200, TimeUnit.MILLISECONDS) ?: continue
                        when (ev) {
                            is MuxerEvent.TrackFormatReady -> {
                                if (ev.isVideo && vTrack < 0) {
                                    vTrack = muxer.addTrack(ev.format)
                                    if (vTrack >= 0) videoTrackRegistered.set(true)
                                } else if (!ev.isVideo && aTrack < 0) {
                                    aTrack = muxer.addTrack(ev.format)
                                    if (aTrack >= 0) audioTrackRegistered.set(true)
                                }
                                if (!started && vTrack >= 0 && (!hasAudio || aTrack >= 0)) {
                                    muxer.start()
                                    started = true
                                    muxerStartedFlag.set(true)
                                    muxerEverStartedFlag.set(true)
                                    for (s in pendingV) writeSampleSafe(true, vTrack, s.data, s.info)
                                    pendingV.clear()
                                    for (s in pendingA) writeSampleSafe(false, aTrack, s.data, s.info)
                                    pendingA.clear()
                                    QuizLogger.info(TAG, "[$exportJobId] MediaMuxer started async (video=$vTrack, audio=$aTrack)")
                                }
                            }
                            is MuxerEvent.Sample -> {
                                val info = MediaCodec.BufferInfo().apply {
                                    set(0, ev.size, ev.ptsUs, ev.flags)
                                }
                                if (started) {
                                    val trk = if (ev.isVideo) vTrack else aTrack
                                    if (trk >= 0) {
                                        writeSampleSafe(ev.isVideo, trk, ev.data, info)
                                    } else if (!ev.isVideo && hasAudio) {
                                        throw IllegalStateException("Audio sample arrived without registered audio track")
                                    }
                                } else {
                                    val sample = VideoEncoder.PendingSample(ev.data, info)
                                    if (ev.isVideo) pendingV.add(sample) else pendingA.add(sample)
                                }
                            }
                            is MuxerEvent.TrackCompleted -> {
                                if (ev.isVideo) vDone = true else aDone = true
                                if (hasAudio && aDone && aTrack < 0) {
                                    val err = "Audio encoder failed: AAC output produced no audio track format"
                                    audioErrorMsg.set(err)
                                    throw IllegalStateException(err)
                                }
                            }
                        }
                    }

                    if (!isAborted.get() && !isUserCancelled.get() && started && (vTrack >= 0 || aTrack >= 0) &&
                        (writtenVideoSamplesCount.get() > 0 || aacOutputSamplesCount.get() > 0)
                    ) {
                        try {
                            if (muxerStartedFlag.compareAndSet(true, false)) {
                                muxer.stop()
                            }
                        } catch (e: Exception) {
                            QuizLogger.warn(TAG, "[$exportJobId] Muxer stop warning: ${e.message}")
                        }
                    }
                } catch (e: Throwable) {
                    if (!isAborted.get() && !isUserCancelled.get()) {
                        QuizLogger.error(TAG, "MuxerWriterThread error: ${e.message}")
                        failAttempt(e)
                    }
                } finally {
                    muxDurationMs.set(System.currentTimeMillis() - mStart)
                }
            }, "MuxerWriterThread")
            muxerWriterThread = mWriter
            mWriter.start()

            // 2. Concurrent VideoDrainThread
            val vDrain = Thread({
                val vc = codec
                val info = MediaCodec.BufferInfo()
                var eos = false
                try {
                    while (!isAborted.get() && !isUserCancelled.get() && !eos) {
                        val outIndex = vc.dequeueOutputBuffer(info, 10_000L)
                        if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                            pushMuxerEvent(MuxerEvent.TrackFormatReady(true, vc.outputFormat))
                        } else if (outIndex >= 0) {
                            if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                                eos = true
                            }
                            val encodedData = vc.getOutputBuffer(outIndex)
                            if (encodedData != null && info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                                val dupData = ByteBuffer.allocate(info.size)
                                encodedData.position(info.offset)
                                encodedData.limit(info.offset + info.size)
                                dupData.put(encodedData)
                                dupData.flip()
                                pushMuxerEvent(
                                    MuxerEvent.Sample(
                                        isVideo = true,
                                        data = dupData,
                                        size = info.size,
                                        ptsUs = info.presentationTimeUs,
                                        flags = info.flags
                                    )
                                )
                            }
                            vc.releaseOutputBuffer(outIndex, false)
                        }
                    }
                    pushMuxerEvent(MuxerEvent.TrackCompleted(true))
                } catch (e: Throwable) {
                    if (!isAborted.get() && !isUserCancelled.get()) {
                        QuizLogger.error(TAG, "VideoDrainThread error: ${e.message}")
                        failAttempt(e)
                    }
                }
            }, "VideoDrainThread")
            videoDrainThread = vDrain
            vDrain.start()

            // 3. Parallel AudioEncoderThread
            if (hasAudio && audioCodec != null && audioProcessor != null) {
                val aThread = Thread({
                    val aStart = System.currentTimeMillis()
                    val ac = audioCodec
                    val ap = audioProcessor
                    val aInfo = MediaCodec.BufferInfo()
                    var inputEos = false
                    var outputEos = false
                    try {
                        while (!isAborted.get() && !isUserCancelled.get() && !outputEos) {
                            if (!inputEos) {
                                val inIdx = ac.dequeueInputBuffer(5_000L)
                                if (inIdx >= 0) {
                                    val buf = ac.getInputBuffer(inIdx)
                                    if (buf != null) {
                                        val ptsUs = ap.currentPtsUs()
                                        val bytesRead = ap.readNextChunkDirect(buf)
                                        if (bytesRead > 0) {
                                            ac.queueInputBuffer(inIdx, 0, bytesRead, ptsUs, 0)
                                        } else {
                                            if (!ap.verifyCompleteRead()) {
                                                throw IllegalStateException("PCM source read incomplete before EOS: fed ${ap.getSamplesFed()} / ${ap.totalSamples} samples")
                                            }
                                            aacInputSamplesCount.set(ap.getSamplesFed())
                                            ac.queueInputBuffer(inIdx, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                            inputEos = true
                                        }
                                    }
                                }
                            }

                            var keepDraining = true
                            while (keepDraining && !isAborted.get() && !isUserCancelled.get()) {
                                val outIdx = ac.dequeueOutputBuffer(aInfo, 2_000L)
                                if (outIdx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                                    keepDraining = false
                                } else if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                                    val newFormat = ac.outputFormat
                                    val ch = if (newFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                                        val c = newFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                                        if (c in 1..32) c else 1
                                    } else 1
                                    newFormat.setInteger(MediaFormat.KEY_CHANNEL_COUNT, ch)
                                    if (!newFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE) || newFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) <= 0) {
                                        newFormat.setInteger(MediaFormat.KEY_SAMPLE_RATE, 48000)
                                    }
                                    pushMuxerEvent(MuxerEvent.TrackFormatReady(false, newFormat))
                                } else if (outIdx >= 0) {
                                    if ((aInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                                        outputEos = true
                                        keepDraining = false
                                    }
                                    val encoded = ac.getOutputBuffer(outIdx)
                                    if (encoded != null && aInfo.size > 0 && (aInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                                        val dup = ByteBuffer.allocate(aInfo.size)
                                        encoded.position(aInfo.offset)
                                        encoded.limit(aInfo.offset + aInfo.size)
                                        dup.put(encoded)
                                        dup.flip()
                                        pushMuxerEvent(
                                            MuxerEvent.Sample(
                                                isVideo = false,
                                                data = dup,
                                                size = aInfo.size,
                                                ptsUs = maxOf(0L, aInfo.presentationTimeUs),
                                                flags = aInfo.flags
                                            )
                                        )
                                    }
                                    ac.releaseOutputBuffer(outIdx, false)
                                } else {
                                    keepDraining = false
                                }
                            }
                        }
                        aacInputSamplesCount.set(ap.getSamplesFed())
                        pushMuxerEvent(MuxerEvent.TrackCompleted(false))
                    } catch (e: Throwable) {
                        if (!isAborted.get() && !isUserCancelled.get()) {
                            val err = "Audio encoder failed: ${e.message}"
                            audioErrorMsg.set(err)
                            QuizLogger.error(TAG, err)
                            failAttempt(e)
                        }
                    } finally {
                        audioDurationMs.set(System.currentTimeMillis() - aStart)
                    }
                }, "AudioEncoderThread")
                audioWorkerThread = aThread
                aThread.start()
            }

            // 4. Video Producer Loop (Surface EGL or CPU ByteBuffer YUV420)
            pipelineStageRef.set("ENCODING")
            if (spec.inputMode == HardwareCodecSelector.InputMode.SURFACE) {
                val activeEgl = eglRenderer ?: throw IllegalStateException("EGL renderer not initialized for Surface mode")
                if (mode == Mode.NATIVE_SCENE_DIRECT) {
                    val schedule = frameScheduler?.buildSchedule()
                    if (schedule != null && schedule.frames.isNotEmpty()) {
                        skippedDuplicateFrames = schedule.skippedFrames
                        val syncBundle = Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) }
                        val composer = directComposer
                        val rendererCallback = sceneFrameProducer
                        var fallbackBitmap: Bitmap? = null
                        if (composer == null) {
                            rendererCallback ?: throw IllegalStateException("NATIVE_SCENE_DIRECT requires composer or sceneFrameProducer")
                            fallbackBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                            reusableSceneBitmap = fallbackBitmap
                        }

                        for ((idx, item) in schedule.frames.withIndex()) {
                            if (isAborted.get() || isUserCancelled.get()) break
                            if (item.isKeyFrame && item.frameIndex > 0) {
                                try { codec.setParameters(syncBundle) } catch (_: Exception) {}
                            }
                            if (composer != null) {
                                composer.renderAndPresentFrame(activeEgl, item.frameIndex, item.ptsNs, item.reusePreviousRender)
                            } else {
                                val bmp = fallbackBitmap!!
                                if (item.reusePreviousRender && idx > 0) {
                                    activeEgl.swapRepeatedFrame(item.ptsNs)
                                } else {
                                    rendererCallback!!(item.frameIndex, bmp)
                                    activeEgl.drawFrameReusableBitmap(bmp, item.ptsNs)
                                    framesRendered++
                                    textureUploads++
                                }
                            }
                            framesEncoded++
                            if (framesEncoded % 10 == 0 || idx == schedule.frames.lastIndex) {
                                sampleMemory()
                                val pct = 10f + (item.frameIndex.toFloat() / totalFrames.coerceAtLeast(1)) * 82f
                                val tierPrefix = if (isFallbackAttempt) "[${spec.tier.name}] " else ""
                                listener?.onProgress(
                                    item.frameIndex + 1,
                                    totalFrames,
                                    "${tierPrefix}Direct GPU/HW Encode (${framesEncoded}/${schedule.encodedFrames} unique, ${skippedDuplicateFrames} dedup skipped)",
                                    pct
                                )
                            }
                        }
                        if (composer != null) {
                            framesRendered = composer.metrics.directGpuFrames + composer.metrics.bitmapUploadedFrames
                            textureUploads = composer.metrics.textureUploads
                        }
                    } else {
                        val rendererCallback = sceneFrameProducer
                            ?: throw IllegalStateException("NATIVE_SCENE_DIRECT requires sceneFrameProducer")
                        val sceneBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                        reusableSceneBitmap = sceneBitmap
                        for (frameIndex in 0 until totalFrames) {
                            if (isAborted.get() || isUserCancelled.get()) break
                            val ptsNs = computePtsNs(frameIndex, selectedFps)
                            if (directComposer != null) {
                                directComposer.renderAndPresentFrame(activeEgl, frameIndex, ptsNs, reusePreviousRender = false)
                            } else {
                                rendererCallback(frameIndex, sceneBitmap)
                                activeEgl.drawFrameReusableBitmap(sceneBitmap, ptsNs)
                                framesRendered++
                                textureUploads++
                            }
                            framesEncoded++
                            if (framesEncoded % 10 == 0 || framesEncoded == totalFrames) {
                                sampleMemory()
                                val pct = 10f + (framesEncoded.toFloat() / totalFrames.coerceAtLeast(1)) * 82f
                                listener?.onProgress(framesEncoded, totalFrames, "Native Direct Scene Render ($framesEncoded / $totalFrames)", pct)
                            }
                        }
                        if (directComposer != null) {
                            framesRendered = directComposer.metrics.directGpuFrames + directComposer.metrics.bitmapUploadedFrames
                            textureUploads = directComposer.metrics.textureUploads
                        }
                    }
                } else {
                    val rgbaByteCapacity = width * height * 4
                    val directRgbaBuf = ByteBuffer.allocateDirect(rgbaByteCapacity)
                    reusableRgbaBuffer = directRgbaBuf
                    val bOptions = BitmapFactory.Options().apply {
                        inPreferredConfig = Bitmap.Config.RGB_565
                    }
                    while (!isAborted.get() && !isUserCancelled.get()) {
                        val item = frameQueue.poll(200, TimeUnit.MILLISECONDS) ?: continue
                        hasConsumedQueuedFrame.set(true)
                        if (item.isEos) break

                        val ptsNs = item.ptsNsOverride ?: computePtsNs(item.frameIndex, selectedFps)
                        if (item.reusePrevious && framesEncoded > 0) {
                            activeEgl.swapRepeatedFrame(ptsNs)
                        } else if (item.isRgba) {
                            directRgbaBuf.clear()
                            val copyLen = minOf(item.frameBytes.size, rgbaByteCapacity)
                            directRgbaBuf.put(item.frameBytes, 0, copyLen)
                            directRgbaBuf.flip()
                            activeEgl.drawFrameRgba(directRgbaBuf, ptsNs)
                            framesRendered++
                            textureUploads++
                        } else {
                            val bmp = BitmapFactory.decodeByteArray(item.frameBytes, 0, item.frameBytes.size, bOptions)
                            if (bmp != null) {
                                activeEgl.drawFrame(bmp, ptsNs)
                                bmp.recycle()
                                framesRendered++
                                textureUploads++
                            }
                        }
                        framesEncoded++
                        if (framesEncoded % 10 == 0 || item.frameIndex + 1 >= totalFrames) {
                            sampleMemory()
                            val pct = 25f + ((item.frameIndex + 1).toFloat() / totalFrames.coerceAtLeast(1)) * 65f
                            listener?.onProgress(item.frameIndex + 1, totalFrames, "Encoding video frames ($framesEncoded encoded)", pct)
                        }
                    }
                    if (totalFrames > framesEncoded) {
                        skippedDuplicateFrames = (totalFrames - framesEncoded).coerceAtLeast(0)
                    }
                }
            } else {
                // Tier 4: Software / CPU ByteBuffer YUV420 encoding (Zero EGL / Surface dependency)
                val inFmt = try { codec.inputFormat } catch (_: Throwable) { null }
                val actualColorFmt = if (inFmt != null && inFmt.containsKey(MediaFormat.KEY_COLOR_FORMAT)) {
                    inFmt.getInteger(MediaFormat.KEY_COLOR_FORMAT)
                } else {
                    spec.yuvColorFormat ?: MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible
                }
                val negotiatedStride = if (inFmt != null && inFmt.containsKey(MediaFormat.KEY_STRIDE)) {
                    inFmt.getInteger(MediaFormat.KEY_STRIDE).coerceAtLeast(width)
                } else width
                val negotiatedSliceH = if (inFmt != null && inFmt.containsKey(MediaFormat.KEY_SLICE_HEIGHT)) {
                    inFmt.getInteger(MediaFormat.KEY_SLICE_HEIGHT).coerceAtLeast(height)
                } else height

                val argbPixels = IntArray(width * height)
                val chromaSize = (width / 2) * (height / 2)
                val ySize = width * height
                val yuvI420Scratch = ByteArray(ySize + chromaSize * 2)
                var hasCachedYuv = false
                val sceneBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                reusableSceneBitmap = sceneBitmap

                fun submitYuvScratchFrame(ptsUs: Long) {
                    while (!isAborted.get() && !isUserCancelled.get()) {
                        val inIdx = codec.dequeueInputBuffer(10_000L)
                        if (inIdx < 0) continue
                        val image = try {
                            codec.getInputImage(inIdx)
                        } catch (_: Throwable) {
                            null
                        }
                        if (image != null && image.planes.size >= 3) {
                            try {
                                fillMediaImageFromI420(image, width, height, yuvI420Scratch)
                            } finally {
                                image.close()
                            }
                            val cap = try { codec.getInputBuffer(inIdx)?.capacity() } catch (_: Throwable) { null }
                            val queueSize = if (cap != null && cap > 0) minOf(cap, yuvI420Scratch.size) else yuvI420Scratch.size
                            codec.queueInputBuffer(inIdx, 0, queueSize, ptsUs, 0)
                        } else {
                            val buf = codec.getInputBuffer(inIdx)
                                ?: throw IllegalStateException("CPU ByteBuffer encoder returned null input buffer")
                            val written = fillByteBufferFromI420(
                                dst = buf,
                                width = width,
                                height = height,
                                stride = negotiatedStride,
                                sliceHeight = negotiatedSliceH,
                                colorFormat = actualColorFmt,
                                srcI420 = yuvI420Scratch
                            )
                            codec.queueInputBuffer(inIdx, 0, written, ptsUs, 0)
                        }
                        return
                    }
                }

                if (mode == Mode.NATIVE_SCENE_DIRECT) {
                    val schedule = frameScheduler?.buildSchedule()
                    val composer = directComposer
                    val rendererCallback = sceneFrameProducer
                    if (composer == null && rendererCallback == null) {
                        throw IllegalStateException("NATIVE_SCENE_DIRECT requires composer or sceneFrameProducer")
                    }

                    if (schedule != null && schedule.frames.isNotEmpty()) {
                        skippedDuplicateFrames = schedule.skippedFrames
                        val syncBundle = Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) }
                        for ((idx, item) in schedule.frames.withIndex()) {
                            if (isAborted.get() || isUserCancelled.get()) break
                            if (item.isKeyFrame && item.frameIndex > 0) {
                                try { codec.setParameters(syncBundle) } catch (_: Exception) {}
                            }
                            if (item.reusePreviousRender && hasCachedYuv && idx > 0) {
                                composer?.recordRepeatedBitmapFrame()
                            } else {
                                if (composer != null) {
                                    composer.renderBitmapFrame(item.frameIndex, sceneBitmap)
                                } else {
                                    rendererCallback!!(item.frameIndex, sceneBitmap)
                                }
                                sceneBitmap.getPixels(argbPixels, 0, width, 0, 0, width, height)
                                convertArgbToI420(argbPixels, width, height, yuvI420Scratch)
                                hasCachedYuv = true
                                framesRendered++
                            }
                            submitYuvScratchFrame(item.ptsNs / 1000L)
                            framesEncoded++
                            if (framesEncoded % 8 == 0 || idx == schedule.frames.lastIndex) {
                                sampleMemory()
                                val pct = 10f + (item.frameIndex.toFloat() / totalFrames.coerceAtLeast(1)) * 82f
                                listener?.onProgress(
                                    item.frameIndex + 1,
                                    totalFrames,
                                    "[CPU YUV420] Encode (${framesEncoded}/${schedule.encodedFrames} unique, ${skippedDuplicateFrames} dedup skipped)",
                                    pct
                                )
                            }
                        }
                    } else {
                        for (frameIndex in 0 until totalFrames) {
                            if (isAborted.get() || isUserCancelled.get()) break
                            val ptsNs = computePtsNs(frameIndex, selectedFps)
                            if (composer != null) {
                                composer.renderBitmapFrame(frameIndex, sceneBitmap)
                            } else {
                                rendererCallback!!(frameIndex, sceneBitmap)
                            }
                            sceneBitmap.getPixels(argbPixels, 0, width, 0, 0, width, height)
                            convertArgbToI420(argbPixels, width, height, yuvI420Scratch)
                            hasCachedYuv = true
                            framesRendered++
                            submitYuvScratchFrame(ptsNs / 1000L)
                            framesEncoded++
                            if (framesEncoded % 8 == 0 || framesEncoded == totalFrames) {
                                sampleMemory()
                                val pct = 10f + (framesEncoded.toFloat() / totalFrames.coerceAtLeast(1)) * 82f
                                listener?.onProgress(framesEncoded, totalFrames, "[CPU YUV420] Encode ($framesEncoded / $totalFrames)", pct)
                            }
                        }
                    }
                } else {
                    val bOptions = BitmapFactory.Options().apply {
                        inPreferredConfig = Bitmap.Config.ARGB_8888
                    }
                    while (!isAborted.get() && !isUserCancelled.get()) {
                        val item = frameQueue.poll(200, TimeUnit.MILLISECONDS) ?: continue
                        hasConsumedQueuedFrame.set(true)
                        if (item.isEos) break

                        val ptsNs = item.ptsNsOverride ?: computePtsNs(item.frameIndex, selectedFps)
                        if (item.reusePrevious && hasCachedYuv && framesEncoded > 0) {
                            // Reuse last YUV buffer
                        } else if (item.isRgba) {
                            convertRgbaToI420(item.frameBytes, width, height, yuvI420Scratch)
                            hasCachedYuv = true
                            framesRendered++
                        } else {
                            val bmp = BitmapFactory.decodeByteArray(item.frameBytes, 0, item.frameBytes.size, bOptions)
                            if (bmp != null) {
                                if (bmp.width == width && bmp.height == height) {
                                    bmp.getPixels(argbPixels, 0, width, 0, 0, width, height)
                                } else {
                                    val scaled = Bitmap.createScaledBitmap(bmp, width, height, true)
                                    scaled.getPixels(argbPixels, 0, width, 0, 0, width, height)
                                    scaled.recycle()
                                }
                                bmp.recycle()
                                convertArgbToI420(argbPixels, width, height, yuvI420Scratch)
                                hasCachedYuv = true
                                framesRendered++
                            }
                        }
                        if (hasCachedYuv) {
                            submitYuvScratchFrame(ptsNs / 1000L)
                            framesEncoded++
                        }
                        if (framesEncoded % 8 == 0 || item.frameIndex + 1 >= totalFrames) {
                            sampleMemory()
                            val pct = 25f + ((item.frameIndex + 1).toFloat() / totalFrames.coerceAtLeast(1)) * 65f
                            listener?.onProgress(item.frameIndex + 1, totalFrames, "[CPU YUV420] Encoding frames ($framesEncoded encoded)", pct)
                        }
                    }
                    if (totalFrames > framesEncoded) {
                        skippedDuplicateFrames = (totalFrames - framesEncoded).coerceAtLeast(0)
                    }
                }
            }

            if (!isAborted.get() && !isUserCancelled.get()) {
                pipelineStageRef.set("DRAIN_EOS")
                finalizationStartMs = System.currentTimeMillis()
                if (spec.inputMode == HardwareCodecSelector.InputMode.SURFACE) {
                    codec.signalEndOfInputStream()
                } else {
                    val endPtsUs = totalFrames.toLong() * 1_000_000L / selectedFps
                    var sentEos = false
                    while (!sentEos && !isAborted.get() && !isUserCancelled.get()) {
                        val inIdx = codec.dequeueInputBuffer(10_000L)
                        if (inIdx >= 0) {
                            codec.queueInputBuffer(inIdx, 0, 0, endPtsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            sentEos = true
                        }
                    }
                }

                vDrain.join(45_000L)
                audioWorkerThread?.join(45_000L)
                pipelineStageRef.set("MUXER_STOP")
                mWriter.join(30_000L)

                if (vDrain.isAlive || (audioWorkerThread?.isAlive == true) || mWriter.isAlive) {
                    throw IllegalStateException("Async encoder/muxer threads timed out during finalization")
                }
                attemptErrorRef.get()?.let { throw it }

                // Verify final MP4 container audio + video integrity with MediaExtractor
                pipelineStageRef.set("VERIFY_INTEGRITY")
                val integrity = VideoEncoder.inspectMp4Integrity(
                    file = outputFile,
                    expectedAudio = hasAudio,
                    expectedAudioDurationMs = expectedAudioDurMs
                )
                val firstPtsFinal = if (integrity.firstAudioPtsUs >= 0L) integrity.firstAudioPtsUs else firstAudioPtsUs.get()
                val lastPtsFinal = if (integrity.lastAudioPtsUs >= 0L) integrity.lastAudioPtsUs else lastAudioPtsUs.get()
                val actualAudioDurFinal = if (integrity.audioDurationMs > 0L) {
                    integrity.audioDurationMs
                } else if (lastPtsFinal >= firstPtsFinal && firstPtsFinal >= 0L) {
                    (lastPtsFinal - firstPtsFinal + 21_333L) / 1000L
                } else 0L

                val now = System.currentTimeMillis()
                pipelineStageRef.set("COMPLETED")
                lastStats = SessionStats(
                    mode = mode.name,
                    codecName = selectedCodecName,
                    isHardwareCodec = selectedCodecHardware,
                    width = width,
                    height = height,
                    fps = selectedFps,
                    framesProcessed = framesEncoded,
                    expectedFrames = totalFrames,
                    droppedFrames = if (frameScheduler != null) 0 else (totalFrames - framesEncoded).coerceAtLeast(0),
                    encodeDurationMs = now - pipelineStartMs,
                    finalizationMs = if (finalizationStartMs > 0L) now - finalizationStartMs else 0L,
                    outputBytes = if (outputFile.exists()) outputFile.length() else 0L,
                    usedJpegFallback = mode == Mode.COMPATIBILITY_FALLBACK,
                    renderedFrames = framesRendered,
                    skippedDuplicateFrames = skippedDuplicateFrames,
                    directGpuFrames = directComposer?.metrics?.directGpuFrames ?: 0,
                    bitmapFallbackFrames = directComposer?.metrics?.bitmapUploadedFrames ?: framesRendered,
                    textureUploads = textureUploads,
                    audioEncodeMs = audioDurationMs.get(),
                    muxDurationMs = muxDurationMs.get(),
                    peakHeapBytes = peakHeapBytes,
                    fallbackReason = codecFallbackReason,
                    expectedAudioSamples = expectedAudioSamplesVal,
                    actualPcmBytes = actualPcmBytesVal,
                    aacInputSamples = aacInputSamplesCount.get(),
                    aacOutputSamples = maxOf(aacOutputSamplesCount.get(), integrity.audioSampleCount),
                    firstAudioPtsUs = firstPtsFinal,
                    lastAudioPtsUs = lastPtsFinal,
                    audioTrackRegistered = audioTrackRegistered.get() || integrity.audioTrackPresent,
                    expectedAudioDurationMs = expectedAudioDurMs,
                    actualAudioDurationMs = actualAudioDurFinal,
                    mp4DurationMs = integrity.mp4DurationMs,
                    audioError = integrity.error ?: audioErrorMsg.get(),
                    exportJobId = exportJobId,
                    pipelineStage = "COMPLETED",
                    videoTrackRegistered = videoTrackRegistered.get() || integrity.videoTrackPresent,
                    writtenVideoSamples = writtenVideoSamplesCount.get(),
                    lastVideoPtsUs = lastMuxVideoPtsUs.get(),
                    muxerStarted = muxerEverStartedFlag.get(),
                    attemptedPaths = attemptedPathsSnapshot,
                    selectedTier = spec.tier.name
                )

                if (!integrity.ok) {
                    val failMsg = integrity.error ?: "MP4 track integrity verification failed"
                    audioErrorMsg.set(failMsg)
                    QuizLogger.error("AudioIntegrity", "[$exportJobId] MP4 verification FAILED: $failMsg (tier=${spec.tier.name}, expectedSamples=$expectedAudioSamplesVal, actualPcmBytes=$actualPcmBytesVal, aacIn=${aacInputSamplesCount.get()}, aacOut=${aacOutputSamplesCount.get()}, writtenVideoSamples=${writtenVideoSamplesCount.get()}, mp4AudioSamples=${integrity.audioSampleCount}, expectedDur=${expectedAudioDurMs}ms, actualDur=${actualAudioDurFinal}ms)")
                    throw IllegalStateException(failMsg)
                }

                QuizLogger.info(
                    "AudioIntegrity",
                    "[$exportJobId] MP4 verified ok: tier=${spec.tier.name} codec=$selectedCodecName hasAudio=$hasAudio samples=${aacInputSamplesCount.get()}/$expectedAudioSamplesVal pcmBytes=$actualPcmBytesVal videoSamples=${writtenVideoSamplesCount.get()} aacOut=${aacOutputSamplesCount.get()} mp4AudioSamples=${integrity.audioSampleCount} firstPts=${firstPtsFinal}us lastPts=${lastPtsFinal}us expectedDur=${expectedAudioDurMs}ms actualAudioDur=${actualAudioDurFinal}ms mp4Dur=${integrity.mp4DurationMs}ms"
                )
                return AttemptResult(succeeded = true)
            } else {
                pipelineStageRef.set("ABORTED")
                val err = attemptErrorRef.get() ?: IllegalStateException(
                    if (isUserCancelled.get()) "Export cancelled" else "Pipeline aborted at stage=${pipelineStageRef.get()}"
                )
                return AttemptResult(succeeded = false, error = err)
            }
        } catch (e: Throwable) {
            QuizLogger.error(TAG, "[$exportJobId] Attempt error at stage=${pipelineStageRef.get()} (${spec.shortDescriptor()}): ${e.message}")
            failAttempt(e)
            return AttemptResult(succeeded = false, error = e)
        } finally {
            isAborted.set(true)
            muxerQueue.clear()
            try { videoDrainThread?.interrupt() } catch (_: Exception) {}
            try { audioWorkerThread?.interrupt() } catch (_: Exception) {}
            try { muxerWriterThread?.interrupt() } catch (_: Exception) {}
            try { videoDrainThread?.join(1500L) } catch (_: Exception) {}
            try { audioWorkerThread?.join(1500L) } catch (_: Exception) {}
            try { muxerWriterThread?.join(1500L) } catch (_: Exception) {}
            try { reusableSceneBitmap?.recycle() } catch (_: Exception) {}
            try { reusableRgbaBuffer?.clear() } catch (_: Exception) {}
            try { eglRenderer?.release() } catch (_: Exception) {}
            try { videoCodec?.stop() } catch (_: Exception) {}
            try { videoCodec?.release() } catch (_: Exception) {}
            try { audioCodec?.stop() } catch (_: Exception) {}
            try { audioCodec?.release() } catch (_: Exception) {}
            try { inputSurface?.release() } catch (_: Exception) {}
            try {
                if (muxerStartedFlag.compareAndSet(true, false) &&
                    (writtenVideoSamplesCount.get() > 0 || aacOutputSamplesCount.get() > 0)
                ) {
                    muxer?.stop()
                }
            } catch (_: Exception) {}
            try { audioProcessor?.close() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}

            val now = System.currentTimeMillis()
            if (lastStats == null || !isFinished.get()) {
                lastStats = SessionStats(
                    mode = mode.name,
                    codecName = selectedCodecName,
                    isHardwareCodec = selectedCodecHardware,
                    width = width,
                    height = height,
                    fps = selectedFps,
                    framesProcessed = framesEncoded,
                    expectedFrames = totalFrames,
                    droppedFrames = (totalFrames - framesEncoded).coerceAtLeast(0),
                    encodeDurationMs = now - pipelineStartMs,
                    finalizationMs = if (finalizationStartMs > 0L) now - finalizationStartMs else 0L,
                    outputBytes = if (outputFile.exists()) outputFile.length() else 0L,
                    usedJpegFallback = mode == Mode.COMPATIBILITY_FALLBACK,
                    renderedFrames = framesRendered,
                    skippedDuplicateFrames = skippedDuplicateFrames,
                    directGpuFrames = directComposer?.metrics?.directGpuFrames ?: 0,
                    bitmapFallbackFrames = directComposer?.metrics?.bitmapUploadedFrames ?: framesRendered,
                    textureUploads = textureUploads,
                    audioEncodeMs = audioDurationMs.get(),
                    muxDurationMs = muxDurationMs.get(),
                    peakHeapBytes = peakHeapBytes,
                    fallbackReason = codecFallbackReason,
                    expectedAudioSamples = expectedAudioSamplesVal,
                    actualPcmBytes = actualPcmBytesVal,
                    aacInputSamples = aacInputSamplesCount.get(),
                    aacOutputSamples = aacOutputSamplesCount.get(),
                    firstAudioPtsUs = firstAudioPtsUs.get(),
                    lastAudioPtsUs = lastAudioPtsUs.get(),
                    audioTrackRegistered = audioTrackRegistered.get(),
                    expectedAudioDurationMs = expectedAudioDurMs,
                    actualAudioDurationMs = 0L,
                    mp4DurationMs = 0L,
                    audioError = audioErrorMsg.get() ?: attemptErrorRef.get()?.message,
                    exportJobId = exportJobId,
                    pipelineStage = pipelineStageRef.get(),
                    videoTrackRegistered = videoTrackRegistered.get(),
                    writtenVideoSamples = writtenVideoSamplesCount.get(),
                    lastVideoPtsUs = lastMuxVideoPtsUs.get(),
                    muxerStarted = muxerEverStartedFlag.get(),
                    attemptedPaths = attemptedPathsSnapshot,
                    selectedTier = spec.tier.name
                )
            }
        }
    }

    private fun convertArgbToI420(argb: IntArray, width: Int, height: Int, outI420: ByteArray) {
        val frameSize = width * height
        val chromaWidth = width / 2
        var yIdx = 0
        var uIdx = frameSize
        var vIdx = frameSize + chromaWidth * (height / 2)

        for (j in 0 until height) {
            val rowOffset = j * width
            val evenRow = (j and 1) == 0
            for (i in 0 until width) {
                val px = argb[rowOffset + i]
                val r = (px shr 16) and 0xFF
                val g = (px shr 8) and 0xFF
                val b = px and 0xFF
                val y = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
                outI420[yIdx++] = y.coerceIn(0, 255).toByte()
                if (evenRow && (i and 1) == 0 && uIdx < vIdx && vIdx < outI420.size) {
                    val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                    val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
                    outI420[uIdx++] = u.coerceIn(0, 255).toByte()
                    outI420[vIdx++] = v.coerceIn(0, 255).toByte()
                }
            }
        }
    }

    private fun convertRgbaToI420(rgba: ByteArray, width: Int, height: Int, outI420: ByteArray) {
        val frameSize = width * height
        val chromaWidth = width / 2
        var yIdx = 0
        var uIdx = frameSize
        var vIdx = frameSize + chromaWidth * (height / 2)
        val totalPixels = minOf(frameSize, rgba.size / 4)
        var p = 0
        for (j in 0 until height) {
            val evenRow = (j and 1) == 0
            for (i in 0 until width) {
                val pixIdx = j * width + i
                if (pixIdx >= totalPixels) {
                    outI420[yIdx++] = 16
                    if (evenRow && (i and 1) == 0 && uIdx < vIdx && vIdx < outI420.size) {
                        outI420[uIdx++] = (-128).toByte()
                        outI420[vIdx++] = (-128).toByte()
                    }
                    continue
                }
                val r = rgba[p].toInt() and 0xFF
                val g = rgba[p + 1].toInt() and 0xFF
                val b = rgba[p + 2].toInt() and 0xFF
                p += 4
                val y = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
                outI420[yIdx++] = y.coerceIn(0, 255).toByte()
                if (evenRow && (i and 1) == 0 && uIdx < vIdx && vIdx < outI420.size) {
                    val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                    val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
                    outI420[uIdx++] = u.coerceIn(0, 255).toByte()
                    outI420[vIdx++] = v.coerceIn(0, 255).toByte()
                }
            }
        }
    }

    private fun fillMediaImageFromI420(
        image: android.media.Image,
        width: Int,
        height: Int,
        srcI420: ByteArray
    ) {
        val planes = image.planes
        val ySize = width * height
        val chromaW = width / 2
        val chromaH = height / 2
        val chromaSize = chromaW * chromaH

        // Plane 0: Y
        copyPlane(srcI420, 0, width, height, planes[0].buffer, planes[0].rowStride, planes[0].pixelStride)
        // Plane 1: U
        copyPlane(srcI420, ySize, chromaW, chromaH, planes[1].buffer, planes[1].rowStride, planes[1].pixelStride)
        // Plane 2: V
        copyPlane(srcI420, ySize + chromaSize, chromaW, chromaH, planes[2].buffer, planes[2].rowStride, planes[2].pixelStride)
    }

    private fun copyPlane(
        src: ByteArray,
        srcOffset: Int,
        planeW: Int,
        planeH: Int,
        dst: ByteBuffer,
        rowStride: Int,
        pixelStride: Int
    ) {
        dst.clear()
        if (pixelStride == 1 && rowStride == planeW) {
            dst.put(src, srcOffset, minOf(planeW * planeH, dst.remaining()))
            return
        }
        val dstCap = dst.capacity()
        for (row in 0 until planeH) {
            val dstRowStart = row * rowStride
            val srcRowStart = srcOffset + row * planeW
            if (pixelStride == 1) {
                val len = minOf(planeW, dstCap - dstRowStart)
                if (len <= 0) break
                dst.position(dstRowStart)
                dst.put(src, srcRowStart, len)
            } else {
                for (col in 0 until planeW) {
                    val dstPos = dstRowStart + col * pixelStride
                    if (dstPos >= dstCap) break
                    dst.put(dstPos, src[srcRowStart + col])
                }
            }
        }
    }

    private fun fillByteBufferFromI420(
        dst: ByteBuffer,
        width: Int,
        height: Int,
        stride: Int,
        sliceHeight: Int,
        colorFormat: Int,
        srcI420: ByteArray
    ): Int {
        dst.clear()
        val ySize = width * height
        val effStride = stride.coerceAtLeast(width)
        val effSlice = sliceHeight.coerceAtLeast(height)
        val chromaW = width / 2
        val chromaH = height / 2
        val uOffset = ySize
        val vOffset = ySize + chromaW * chromaH

        val isSemiPlanar = colorFormat == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar ||
            colorFormat == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420PackedSemiPlanar

        // Write Y rows
        for (row in 0 until height) {
            val srcRow = row * width
            val dstRow = row * effStride
            if (dstRow + width > dst.capacity()) break
            dst.position(dstRow)
            dst.put(srcI420, srcRow, width)
        }

        val yPlaneAllocated = effStride * effSlice
        if (isSemiPlanar) {
            val uvStride = effStride
            for (row in 0 until chromaH) {
                val dstRow = yPlaneAllocated + row * uvStride
                val srcRow = row * chromaW
                for (col in 0 until chromaW) {
                    val pos = dstRow + col * 2
                    if (pos + 1 >= dst.capacity()) break
                    dst.put(pos, srcI420[uOffset + srcRow + col])
                    dst.put(pos + 1, srcI420[vOffset + srcRow + col])
                }
            }
            val total = minOf(dst.capacity(), yPlaneAllocated + effStride * (effSlice / 2))
            dst.position(0)
            return total
        } else {
            val chromaStride = (effStride / 2).coerceAtLeast(chromaW)
            val chromaPlaneAllocated = chromaStride * (effSlice / 2)
            for (row in 0 until chromaH) {
                val dstRow = yPlaneAllocated + row * chromaStride
                if (dstRow + chromaW > dst.capacity()) break
                dst.position(dstRow)
                dst.put(srcI420, uOffset + row * chromaW, chromaW)
            }
            for (row in 0 until chromaH) {
                val dstRow = yPlaneAllocated + chromaPlaneAllocated + row * chromaStride
                if (dstRow + chromaW > dst.capacity()) break
                dst.position(dstRow)
                dst.put(srcI420, vOffset + row * chromaW, chromaW)
            }
            val total = minOf(dst.capacity(), yPlaneAllocated + chromaPlaneAllocated * 2)
            dst.position(0)
            return total
        }
    }
}
