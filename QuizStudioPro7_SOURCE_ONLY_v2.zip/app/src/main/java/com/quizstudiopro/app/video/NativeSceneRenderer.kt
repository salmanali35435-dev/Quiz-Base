package com.quizstudiopro.app.video

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.Base64
import com.quizstudiopro.app.logging.QuizLogger
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Native Kotlin Canvas renderer for [StreamingVideoEncoderSession.Mode.NATIVE_SCENE_DIRECT].
 *
 * Parses the structured scene, timeline, reveal settings, and transition config once at session
 * start, pre-decodes any image assets once, and renders each requested frame directly into a single
 * reusable ARGB_8888 Bitmap (zero per-frame bridge calls, zero JPEG, zero Base64, zero BitmapFactory
 * inside the frame loop).
 */
class NativeSceneRenderer(
    private val context: Context,
    bundleJson: String,
    private val width: Int,
    private val height: Int,
    private val fps: Int
) {
    companion object {
        private const val TAG = "NativeSceneRenderer"
    }

    private val root = JSONObject(bundleJson)
    private val scene = root.optJSONObject("scene") ?: JSONObject()
    private val sceneMode = scene.optString("mode", "DEFAULT_TEMPLATE_MODE")
    private val theme = mergeTheme(root.optJSONObject("theme"), scene.optJSONObject("theme"))
    private val elements: List<JSONObject> = buildList {
        val arr = scene.optJSONArray("elements") ?: JSONArray()
        for (i in 0 until arr.length()) {
            arr.optJSONObject(i)?.let { add(it) }
        }
    }.sortedBy { it.optInt("layerOrder", 0) }

    private val optTokenRegex = Regex("\\{option_([0-3])\\}", RegexOption.IGNORE_CASE)
    private val optIdRegex = Regex("(?:^|[_-])(?:opt|option)[_-]?([0-3])(?:[_-]|$)", RegexOption.IGNORE_CASE)
    private val resolvedOptionIndices: IntArray = IntArray(elements.size) { -1 }.also { resolved ->
        val optTypes = setOf("option_container", "option_label", "option_text")
        // Pass 1: Explicit 0..3, {option_N} token, or id/groupId suffix
        for (i in elements.indices) {
            val el = elements[i]
            if (el.optString("type") !in optTypes) continue
            val raw = el.optInt("optionIndex", -1)
            if (raw in 0..3) {
                resolved[i] = raw
                continue
            }
            val tok = optTokenRegex.find(el.optString("text", ""))
            if (tok != null) {
                resolved[i] = tok.groupValues[1].toInt()
                continue
            }
            val idAndGrp = "${el.optString("id", "")} ${el.optString("groupId", "")}"
            val idMatch = optIdRegex.find(idAndGrp)
            if (idMatch != null) {
                resolved[i] = idMatch.groupValues[1].toInt()
            }
        }
        // Pass 2: Sibling groupId or bounding-box overlap / proximity
        for (i in elements.indices) {
            val el = elements[i]
            if (el.optString("type") !in optTypes || resolved[i] in 0..3) continue
            val grp = el.optString("groupId", "")
            var matched = -1
            if (grp.isNotBlank()) {
                for (j in elements.indices) {
                    if (j != i && elements[j].optString("groupId", "") == grp && resolved[j] in 0..3) {
                        matched = resolved[j]
                        break
                    }
                }
            }
            if (matched !in 0..3) {
                val ex = el.optDouble("x", 0.0)
                val ey = el.optDouble("y", 0.0)
                val ew = el.optDouble("width", 0.1)
                val eh = el.optDouble("height", 0.1)
                val cx = ex + ew * 0.5
                val cy = ey + eh * 0.5
                var bestOverlap = 0.0
                var bestOverlapIdx = -1
                var bestDist = Double.MAX_VALUE
                var bestDistIdx = -1
                for (j in elements.indices) {
                    if (j == i || resolved[j] !in 0..3) continue
                    val o = elements[j]
                    val ox = o.optDouble("x", 0.0)
                    val oy = o.optDouble("y", 0.0)
                    val ow = o.optDouble("width", 0.1)
                    val oh = o.optDouble("height", 0.1)
                    val overlap = max(0.0, min(ex + ew, ox + ow) - max(ex, ox)) *
                        max(0.0, min(ey + eh, oy + oh) - max(ey, oy))
                    if (overlap > bestOverlap) {
                        bestOverlap = overlap
                        bestOverlapIdx = resolved[j]
                    }
                    val d = hypot(cx - (ox + ow * 0.5), cy - (oy + oh * 0.5))
                    if (d < bestDist) {
                        bestDist = d
                        bestDistIdx = resolved[j]
                    }
                }
                matched = when {
                    bestOverlapIdx in 0..3 -> bestOverlapIdx
                    bestDistIdx in 0..3 && bestDist < 0.25 -> bestDistIdx
                    else -> -1
                }
            }
            // Pass 3: First unused slot for same element type, else reading order
            if (matched !in 0..3) {
                val t = el.optString("type")
                val used = BooleanArray(4)
                for (j in elements.indices) {
                    if (j != i && elements[j].optString("type") == t && resolved[j] in 0..3) {
                        used[resolved[j]] = true
                    }
                }
                val firstFree = (0..3).firstOrNull { !used[it] }
                matched = firstFree ?: (elements.indices
                    .filter { elements[it].optString("type") == t }
                    .sortedWith { a, b ->
                        val ay = elements[a].optDouble("y", 0.0)
                        val by = elements[b].optDouble("y", 0.0)
                        if (kotlin.math.abs(ay - by) < 0.05) {
                            elements[a].optDouble("x", 0.0).compareTo(elements[b].optDouble("x", 0.0))
                        } else {
                            ay.compareTo(by)
                        }
                    }
                    .indexOf(i)
                    .let { pos -> if (pos >= 0) pos % 4 else 0 })
            }
            resolved[i] = matched
        }
    }

    private val hasContainerForOpt: BooleanArray = BooleanArray(4).also { flags ->
        for (i in elements.indices) {
            val el = elements[i]
            if (el.optBoolean("visible", true) && el.optString("type") == "option_container") {
                val idx = resolvedOptionIndices[i]
                if (idx in 0..3) flags[idx] = true
            }
        }
    }

    private val questions: List<JSONObject> = buildList {
        val arr = root.optJSONArray("questions") ?: JSONArray()
        for (i in 0 until arr.length()) {
            arr.optJSONObject(i)?.let { add(it) }
        }
    }

    private data class Segment(val type: String, val qIndex: Int, val start: Double, val dur: Double)
    private val segments: List<Segment> = buildList {
        val tl = root.optJSONObject("timeline") ?: JSONObject()
        val arr = tl.optJSONArray("segs") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val s = arr.optJSONObject(i) ?: continue
            add(Segment(s.optString("type", "voice"), s.optInt("i", 0), s.optDouble("start", 0.0), s.optDouble("dur", 1.0)))
        }
    }

    private val revealConfig = root.optJSONObject("revealConfig") ?: JSONObject()
    private val answerRevealConfig = root.optJSONObject("answerRevealConfig") ?: scene.optJSONObject("answerRevealConfig") ?: JSONObject()
    private val questionNumberConfig = root.optJSONObject("questionNumberConfig") ?: scene.optJSONObject("questionNumberConfig") ?: JSONObject()
    private val transitionConfig = root.optJSONObject("transitionConfig") ?: JSONObject()
    private val timerDuration = root.optDouble("timerDuration", 10.0).coerceAtLeast(1.0)
    private val locale = root.optString("locale", "en-US")
    private val projectTitle = root.optString("projectTitle", "")
    private val channelName = root.optString("channelName", "")
    private val headerText = root.optString("headerText", "GUESS THE ANSWER")

    private val assetBitmaps = HashMap<String, Bitmap>()
    private val typefaceCache = HashMap<String, Typeface>()
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)

    internal data class OptionDrawState(
        val fillColor: Int,
        val alpha: Int,
        val borderColor: Int,
        val hasGlow: Boolean,
        val scaled: Boolean,
        val labelBgColor: Int = Color.TRANSPARENT,
        val labelTextColor: Int = Color.TRANSPARENT,
        val optionTextColor: Int = Color.TRANSPARENT,
        val labelGlyph: String = ""
    )

    internal var lastRenderedQuestionNumber: String = ""
        private set
    internal var lastRenderedAnswerIntro: String = ""
        private set
    internal val lastOptionDrawStates = HashMap<Int, OptionDrawState>()

    private var snapBitmap: Bitmap? = null
    private var snapCanvas: Canvas? = null
    private var snappedQuestionIdx = -99

    private var staticCacheBitmap: Bitmap? = null
    private var staticCacheCanvas: Canvas? = null
    private var staticCacheKey: String? = null
    private var segCursor = 0

    init {
        preloadAssets()
    }

    private fun mergeTheme(base: JSONObject?, overlay: JSONObject?): JSONObject {
        val merged = JSONObject()
        if (base != null) {
            val keys = base.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val v = base.opt(k)
                if (v != null && v !== JSONObject.NULL) merged.put(k, v)
            }
        }
        if (overlay != null) {
            val keys = overlay.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val v = overlay.opt(k)
                if (v != null && v !== JSONObject.NULL && !(v is String && v.isBlank())) {
                    merged.put(k, v)
                }
            }
        }
        return merged
    }

    private fun preloadAssets() {
        val refs = root.optJSONObject("assets") ?: JSONObject()
        val keys = refs.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val dataUrl = refs.optString(k, "")
            if (dataUrl.startsWith("data:image")) {
                decodeDataUrlBitmap(dataUrl)?.let { assetBitmaps[k] = it }
            }
        }
        val bgImg = theme.optString("bgImage", "")
        if (bgImg.startsWith("data:image")) {
            decodeDataUrlBitmap(bgImg)?.let { assetBitmaps["__theme_bg"] = it }
        }
    }

    private fun decodeDataUrlBitmap(dataUrl: String): Bitmap? {
        return try {
            val comma = dataUrl.indexOf(',')
            val b64 = if (comma >= 0) dataUrl.substring(comma + 1) else dataUrl
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (e: Exception) {
            QuizLogger.warn(TAG, "Failed pre-decoding asset bitmap: ${e.message}")
            null
        }
    }

    private fun resolveTypeface(family: String, weight: Int): Typeface {
        val key = "$family|$weight"
        typefaceCache[key]?.let { return it }
        val style = if (weight >= 600) Typeface.BOLD else Typeface.NORMAL
        val norm = family.trim().lowercase()
        val sysFamily = when {
            norm.contains("bebas") || norm.contains("anton") || norm.contains("oswald") -> "sans-serif-condensed"
            weight >= 800 && (norm.contains("spartan") || norm.contains("montserrat") || norm.contains("rubik") || norm.contains("poppins")) -> "sans-serif-black"
            norm.contains("fredoka") || norm.contains("baloo") || norm.contains("lilita") -> "sans-serif-medium"
            else -> "sans-serif"
        }
        val tf = Typeface.create(sysFamily, style)
        typefaceCache[key] = tf
        return tf
    }

    private fun parseColor(hex: String?, fallback: Int = Color.BLACK): Int {
        if (hex.isNullOrBlank()) return fallback
        return try {
            Color.parseColor(hex)
        } catch (_: Exception) {
            fallback
        }
    }

    private fun resolveAnswerIntro(loc: String): String {
        val base = loc.substringBefore('-').lowercase()
        return when (base) {
            "it" -> "La risposta è"
            "es" -> "La respuesta es"
            "fr" -> "La réponse est"
            "de" -> "Die Antwort ist"
            "pt" -> "A resposta é"
            "hi" -> "सही उत्तर है"
            "ur" -> "درست جواب ہے"
            "ar" -> "الإجابة الصحيحة هي"
            else -> "The answer is"
        }
    }

    private fun presetDefaults(presetId: String): Array<Any> {
        return when (presetId) {
            "01_slash_20" -> arrayOf("", true, "/", true)
            "question_1" -> arrayOf("Question ", false, "/", false)
            "question_01" -> arrayOf("Question ", true, "/", false)
            "1_of_20" -> arrayOf("", false, " of ", true)
            "question_1_of_20" -> arrayOf("Question ", false, " of ", true)
            "question_01_of_20" -> arrayOf("Question ", true, " of ", true)
            "q1_slash_20" -> arrayOf("Q", false, " / ", true)
            "01_dash_20" -> arrayOf("", true, " — ", true)
            "custom" -> arrayOf("", false, " / ", true)
            else -> arrayOf("", false, "/", true)
        }
    }

    private fun formatQuestionNumberText(el: JSONObject, qIdx: Int, totalQ: Int): String {
        val raw = el.optString("text", "")
        val hasElFmt = el.has("qNumPreset") || el.has("qNumPrefix") || el.has("qNumLeadingZero") || el.has("qNumSeparator") || el.has("qNumShowTotal")
        if (raw.isNotBlank() && !hasElFmt && Regex("\\{|\\d").containsMatchIn(raw) && raw != "{num}/{total}") {
            val n = qIdx + 1
            return raw.replace("{num2}", n.toString().padStart(2, '0'))
                .replace("{total2}", totalQ.toString().padStart(2, '0'))
                .replace("{num}", n.toString())
                .replace("{total}", totalQ.toString())
        }
        val presetId = el.optString("qNumPreset", "").ifBlank { questionNumberConfig.optString("preset", "1_slash_20") }
        val def = presetDefaults(presetId)
        val defPrefix = def[0] as String
        val defLead = def[1] as Boolean
        val defSep = def[2] as String
        val defShowTotal = def[3] as Boolean
        val prefix = when {
            el.has("qNumPrefix") -> el.optString("qNumPrefix", defPrefix)
            questionNumberConfig.has("prefix") -> questionNumberConfig.optString("prefix", defPrefix)
            else -> defPrefix
        }
        val lead = when {
            el.has("qNumLeadingZero") -> el.optBoolean("qNumLeadingZero", defLead)
            questionNumberConfig.has("leadingZero") -> questionNumberConfig.optBoolean("leadingZero", defLead)
            else -> defLead
        }
        val sep = when {
            el.has("qNumSeparator") -> el.optString("qNumSeparator", defSep)
            questionNumberConfig.has("separator") -> questionNumberConfig.optString("separator", defSep)
            else -> defSep
        }
        val showTotal = when {
            el.has("qNumShowTotal") -> el.optBoolean("qNumShowTotal", defShowTotal)
            questionNumberConfig.has("showTotal") -> questionNumberConfig.optBoolean("showTotal", defShowTotal)
            else -> defShowTotal
        }
        val upper = when {
            el.has("qNumUppercase") -> el.optBoolean("qNumUppercase", false)
            questionNumberConfig.has("uppercase") -> questionNumberConfig.optBoolean("uppercase", false)
            else -> false
        }
        val nStr = (qIdx + 1).let { if (lead) it.toString().padStart(2, '0') else it.toString() }
        val tStr = totalQ.let { if (lead) it.toString().padStart(2, '0') else it.toString() }
        val out = if (showTotal) "$prefix$nStr$sep$tStr" else "$prefix$nStr"
        return if (upper) out.uppercase() else out
    }

    private fun findSegment(gt: Double): Segment? {
        if (segments.isEmpty()) return null
        while (segCursor > 0 && gt < segments[segCursor].start) segCursor--
        while (segCursor < segments.size - 1 && gt >= segments[segCursor].start + segments[segCursor].dur) {
            segCursor++
        }
        return segments[segCursor]
    }

    fun renderFrame(frameIndex: Int, targetBitmap: Bitmap) {
        val canvas = Canvas(targetBitmap)
        if (questions.isEmpty() || segments.isEmpty()) {
            canvas.drawColor(parseColor(theme.optString("bg", "#e6e6e6"), Color.LTGRAY))
            return
        }
        val gt = frameIndex.toDouble() / fps.toDouble()
        val seg = findSegment(gt) ?: return
        val lt = max(0.0, gt - seg.start)
        val qIdx = seg.qIndex.coerceIn(0, questions.size - 1)
        val q = questions[qIdx]

        if (seg.type == "page") {
            val prevIdx = (qIdx - 1).coerceAtLeast(0)
            if (snappedQuestionIdx != prevIdx) {
                val sb = snapBitmap ?: Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also {
                    snapBitmap = it
                    snapCanvas = Canvas(it)
                }
                renderSceneFrame(snapCanvas!!, questions[prevIdx], prevIdx, 0.0, true, 1.0, 1.0)
                snappedQuestionIdx = prevIdx
            }
            val p = (lt / seg.dur.coerceAtLeast(0.001)).coerceIn(0.0, 1.0)
            renderSceneFrame(canvas, q, qIdx, timerDuration, false, p, 0.0)
            drawTransitionOverlay(canvas, p)
            return
        }

        val voiceFrac = when (seg.type) {
            "voice" -> (lt / seg.dur.coerceAtLeast(0.001)).coerceIn(0.0, 1.0)
            else -> 1.0
        }
        val remaining = when (seg.type) {
            "voice" -> timerDuration
            "count" -> max(0.0, seg.dur - lt)
            else -> 0.0
        }
        val reveal = seg.type == "reveal" || seg.type == "answer"
        renderSceneFrame(canvas, q, qIdx, remaining, reveal, 1.0, voiceFrac)
    }

    fun renderSettledQuestionForCache(
        qIdx: Int,
        reveal: Boolean,
        targetBitmap: Bitmap,
        remainingOverride: Double? = null,
        hideTimer: Boolean = false,
        voiceFracOverride: Double = 1.0
    ) {
        val canvas = Canvas(targetBitmap)
        if (questions.isEmpty()) {
            canvas.drawColor(parseColor(theme.optString("bg", "#e6e6e6"), Color.LTGRAY))
            return
        }
        val safeIdx = qIdx.coerceIn(0, questions.size - 1)
        val q = questions[safeIdx]
        val remaining = remainingOverride ?: if (reveal) 0.0 else timerDuration
        renderSceneFrame(canvas, q, safeIdx, remaining, reveal, 1.0, voiceFracOverride, hideTimer)
    }

    private fun primaryVisibleTimerPair(): Pair<Int, JSONObject>? {
        for (i in elements.indices) {
            val el = elements[i]
            if (!el.optBoolean("visible", true)) continue
            if (sceneMode == "IMPORTED_TEMPLATE_MODE" && el.optBoolean("isDefaultTemplateOnly", false)) continue
            if (el.optString("type") == "timer") return i to el
        }
        return null
    }

    fun hasVisibleTimer(): Boolean = primaryVisibleTimerPair() != null || elements.isEmpty()

    fun computeTimerOverlayBoundsPx(): Rect {
        val pair = primaryVisibleTimerPair()
        val el = pair?.second
        val rect = if (el != null) {
            val x = (el.optDouble("x", 0.2) * width).toFloat()
            val y = (el.optDouble("y", 0.5) * height).toFloat()
            val w = (el.optDouble("width", 0.6) * width).toFloat()
            val h = (el.optDouble("height", 0.055) * height).toFloat()
            RectF(x, y, x + w, y + h)
        } else {
            RectF(width * 0.2f, height * 0.50f, width * 0.8f, height * 0.555f)
        }
        val look = resolveTimerLook(el)
        val tH = max(8f, rect.height())
        val cx = rect.centerX()
        val tY = rect.top
        val bounds = when (look) {
            "ring", "neon", "pie", "clock", "stopwatch", "orb", "bold" -> {
                val mul = when (look) {
                    "bold" -> 1.45f
                    "ring", "clock" -> 1.35f
                    "neon", "pie" -> 1.30f
                    "stopwatch" -> 1.25f
                    else -> 1.05f
                }
                val r = tH * mul
                val cy = when (look) {
                    "orb" -> tY + tH - r * 1.2f
                    "bold" -> tY + tH - r + r * 0.12f
                    else -> tY + tH - r
                }
                val padTop = if (look == "stopwatch" || look == "bold") r * 1.48f else if (look == "orb") r * 1.65f else r * 1.28f
                val padSide = if (look == "orb") r * 1.65f else r * 1.28f
                RectF(cx - padSide, cy - padTop, cx + padSide, cy + padSide)
            }
            else -> {
                val maxBarW = if (sceneMode == "IMPORTED_TEMPLATE_MODE" && rect.width() > 0f && rect.width() < width * 0.55f) rect.width() else width * 0.6f
                val halfW = max(rect.width(), maxBarW) * 0.5f + tH * 1.2f
                val padV = tH * 1.25f
                RectF(cx - halfW, rect.top - padV, cx + halfW, rect.bottom + padV)
            }
        }
        val l = bounds.left.toInt().coerceIn(0, width)
        val t = bounds.top.toInt().coerceIn(0, height)
        val r = ceil(bounds.right).toInt().coerceIn(0, width)
        val b = ceil(bounds.bottom).toInt().coerceIn(0, height)
        return Rect(l, t, r, b)
    }

    fun hasVisibleLayerOverTimer(): Boolean {
        val pair = primaryVisibleTimerPair() ?: return false
        val timerIdx = pair.first
        val overlayPx = computeTimerOverlayBoundsPx()
        for (i in (timerIdx + 1) until elements.size) {
            val el = elements[i]
            if (!el.optBoolean("visible", true)) continue
            if (sceneMode == "IMPORTED_TEMPLATE_MODE" && el.optBoolean("isDefaultTemplateOnly", false)) continue
            if (el.optDouble("opacity", 1.0) <= 0.01) continue
            val ex = (el.optDouble("x", 0.0) * width).toInt()
            val ey = (el.optDouble("y", 0.0) * height).toInt()
            val ew = (el.optDouble("width", 0.0) * width).toInt()
            val eh = (el.optDouble("height", 0.0) * height).toInt()
            if (Rect.intersects(overlayPx, Rect(ex, ey, ex + ew, ey + eh))) {
                return true
            }
        }
        return false
    }

    fun renderTimerOverlay(targetBitmap: Bitmap, subRect: Rect, remaining: Double) {
        val pair = primaryVisibleTimerPair()
        val el = pair?.second
        val rect = if (el != null) {
            val x = (el.optDouble("x", 0.2) * width).toFloat()
            val y = (el.optDouble("y", 0.5) * height).toFloat()
            val w = (el.optDouble("width", 0.6) * width).toFloat()
            val h = (el.optDouble("height", 0.055) * height).toFloat()
            RectF(x, y, x + w, y + h)
        } else {
            RectF(width * 0.2f, height * 0.50f, width * 0.8f, height * 0.555f)
        }
        val canvas = Canvas(targetBitmap)
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        canvas.save()
        canvas.translate(-subRect.left.toFloat(), -subRect.top.toFloat())
        drawNativeTimer(canvas, rect, remaining, timerDuration, el)
        canvas.restore()
    }

    private fun renderSceneFrame(
        canvas: Canvas,
        q: JSONObject,
        qIdx: Int,
        remaining: Double,
        reveal: Boolean,
        enter: Double,
        voiceFrac: Double,
        hideTimer: Boolean = false
    ) {
        val cacheKey = "$sceneMode|$qIdx|$reveal|${if (voiceFrac >= 1.0) "full" else "part"}"
        if (!hideTimer && voiceFrac >= 1.0 && sceneMode == "IMPORTED_TEMPLATE_MODE" && elements.none { it.optString("type") == "timer" }) {
            // Static frame cache optimization when scene has no timer movement
            staticCacheBitmap?.let { cached ->
                if (staticCacheKey == cacheKey) {
                    canvas.drawBitmap(cached, 0f, 0f, null)
                    return
                }
            }
        }

        val bgColor = if (sceneMode == "IMPORTED_TEMPLATE_MODE") {
            Color.parseColor("#0A0A0A")
        } else {
            parseColor(theme.optString("bg", "#e6e6e6"), Color.parseColor("#e6e6e6"))
        }
        canvas.drawColor(bgColor)

        if (elements.isNotEmpty()) {
            renderUnifiedElements(canvas, q, qIdx, remaining, reveal, voiceFrac, hideTimer)
        } else {
            renderFallbackDefault(canvas, q, qIdx, remaining, reveal, voiceFrac, hideTimer)
        }
    }

    private fun renderUnifiedElements(
        canvas: Canvas,
        q: JSONObject,
        qIdx: Int,
        remaining: Double,
        reveal: Boolean,
        voiceFrac: Double,
        hideTimer: Boolean = false
    ) {
        val options = q.optJSONArray("options") ?: JSONArray()
        val correctIdx = q.optInt("correct", 0)
        val totalQ = questions.size.coerceAtLeast(1)

        // Compute sequential reveal boundaries synchronized after spoken question number prefix
        val syncEnabled = revealConfig.optBoolean("enabled", true)
        val prefixWords = q.optInt("promptPrefixWords", 0).coerceAtLeast(0)
        val qStart = if (prefixWords > 0) 0.08 else 0.0
        val qWordEnd = 0.42
        val optSlots = arrayOf(
            0.42 to 0.56,
            0.56 to 0.70,
            0.70 to 0.84,
            0.84 to 1.00
        )

        val ansStyle = answerRevealConfig.optString("style", "correct-only")
        val ansHighlightBg = answerRevealConfig.optString("highlightBg", theme.optString("correctFill", "#16a34a")).ifBlank { "#16a34a" }
        val ansBadgeBg = answerRevealConfig.optString("badgeBg", "#22c55e").ifBlank { "#22c55e" }
        val ansBadgeTickColor = answerRevealConfig.optString("badgeTickColor", "#ffffff").ifBlank { "#ffffff" }
        val ansCorrectTextColor = answerRevealConfig.optString("correctTextColor", "#ffffff").ifBlank { "#ffffff" }
        val ansCorrectBorderColor = answerRevealConfig.optString("correctBorderColor", "#ffffff").ifBlank { "#ffffff" }
        val ansCorrectBorderWidth = answerRevealConfig.optDouble("correctBorderWidth", 3.0).toFloat()
        val ansDimBg = answerRevealConfig.optString("dimBg", "#1e293b").ifBlank { "#1e293b" }
        val ansDimTextColor = answerRevealConfig.optString("dimTextColor", "#94a3b8").ifBlank { "#94a3b8" }
        val ansDimBadgeBg = answerRevealConfig.optString("dimBadgeBg", "#334155").ifBlank { "#334155" }
        val ansDimBadgeTextColor = answerRevealConfig.optString("dimBadgeTextColor", "#cbd5e1").ifBlank { "#cbd5e1" }
        val ansDimBorderColor = answerRevealConfig.optString("dimBorderColor", "#475569").ifBlank { "#475569" }
        val ansDimWrongBgEnabled = answerRevealConfig.optBoolean("dimWrongBgEnabled", false)
        val ansDimOpacity = answerRevealConfig.optDouble("dimOpacity", 0.88).coerceIn(0.1, 1.0)
        val ansGlowEnabled = answerRevealConfig.optBoolean("glowEnabled", true)
        val ansGlowColor = answerRevealConfig.optString("glowColor", "#22c55e")
        val ansScaleBoost = answerRevealConfig.optDouble("scaleBoost", 1.03).coerceIn(1.0, 1.15).toFloat()

        for ((elementListIdx, el) in elements.withIndex()) {
            if (!el.optBoolean("visible", true)) continue
            val type = el.optString("type", "shape")
            if (sceneMode == "IMPORTED_TEMPLATE_MODE" && el.optBoolean("isDefaultTemplateOnly", false)) continue

            val x = (el.optDouble("x", 0.0) * width).toFloat()
            val y = (el.optDouble("y", 0.0) * height).toFloat()
            val w = (el.optDouble("width", 0.1) * width).toFloat()
            val h = (el.optDouble("height", 0.1) * height).toFloat()
            val rot = el.optDouble("rotation", 0.0).toFloat()
            val baseAlpha = (el.optDouble("opacity", 1.0).coerceIn(0.0, 1.0) * 255).toInt()
            val optIdx = resolvedOptionIndices[elementListIdx]
            val isCorrectOpt = reveal && optIdx in 0..3 && optIdx == correctIdx
            val isWrongOpt = reveal && optIdx in 0..3 && optIdx != correctIdx
            val dimWrong = isWrongOpt && (ansStyle == "highlight-dim-others" || ansDimWrongBgEnabled)
            val revealTransparentContainer = type == "option_container" && (isCorrectOpt || dimWrong) && baseAlpha < 13
            val effBaseAlpha = if (revealTransparentContainer) 255 else baseAlpha
            val opacity = if (dimWrong) (effBaseAlpha * ansDimOpacity).toInt().coerceIn(0, 255) else effBaseAlpha

            val rect = RectF(x, y, x + w, y + h)
            val radius = max(0f, (el.optDouble("borderRadius", 0.0) * min(w, h)).toFloat())
            val shapeKind = el.optString("shapeKind", "")
            val isCircleShape = shapeKind == "circle"

            fun drawShapeFill(paint: Paint) {
                if (isCircleShape) {
                    canvas.drawOval(rect, paint)
                } else if (radius > 0f) {
                    canvas.drawRoundRect(rect, radius, radius, paint)
                } else {
                    canvas.drawRect(rect, paint)
                }
            }

            fun drawClippedBitmap(bmp: Bitmap, paint: Paint) {
                if (isCircleShape) {
                    canvas.save()
                    val clipPath = Path().apply { addOval(rect, Path.Direction.CW) }
                    canvas.clipPath(clipPath)
                    canvas.drawBitmap(bmp, null, rect, paint)
                    canvas.restore()
                } else if (radius > 0f) {
                    canvas.save()
                    val clipPath = Path().apply { addRoundRect(rect, radius, radius, Path.Direction.CW) }
                    canvas.clipPath(clipPath)
                    canvas.drawBitmap(bmp, null, rect, paint)
                    canvas.restore()
                } else {
                    canvas.drawBitmap(bmp, null, rect, paint)
                }
            }

            canvas.save()
            if (rot != 0f) {
                canvas.rotate(rot, rect.centerX(), rect.centerY())
            }
            if (isCorrectOpt && ansStyle == "strong-highlight" && ansScaleBoost > 1.001f) {
                canvas.scale(ansScaleBoost, ansScaleBoost, rect.centerX(), rect.centerY())
            }

            // For option_container / option_label with sequential reveal, gate entire element visibility identically to JS
            val optSlotVisible = when (type) {
                "option_container" -> !syncEnabled || optIdx !in 0..3 || voiceFrac > optSlots[optIdx].first
                "option_label" -> !syncEnabled || optIdx !in 0..3 || voiceFrac >= optSlots[optIdx].first
                else -> true
            }
            if (!optSlotVisible) {
                canvas.restore()
                continue
            }

            // Shared background / assetRef / border rendering matching scene-renderer.js
            val assetRef = el.optString("assetRef", "")
            val assetBmp = when {
                assetRef.isNotBlank() -> assetBitmaps[assetRef] ?: if (type == "background") assetBitmaps["__theme_bg"] else null
                type == "background" -> assetBitmaps["__theme_bg"]
                else -> null
            }
            val revealOverridesSlotBg = type == "option_container" && (isCorrectOpt || dimWrong)
            val hasOptionContainerSibling = optIdx in 0..3 && hasContainerForOpt[optIdx]
            val rawBgHex = el.optString("backgroundColor", "")
            val drawFallbackTextSlotBg = type == "option_text" && optIdx in 0..3 && !hasOptionContainerSibling &&
                (isCorrectOpt || dimWrong) && (rawBgHex.isBlank() || rawBgHex == "transparent")
            val hasGlow = type == "option_container" && isCorrectOpt && ansStyle == "strong-highlight" && ansGlowEnabled

            var renderedFillColor = Color.TRANSPARENT
            if (type != "timer") {
                if (assetBmp != null && !revealOverridesSlotBg) {
                    fillPaint.alpha = opacity
                    drawClippedBitmap(assetBmp, fillPaint)
                } else {
                    val resolvedBgHex = when {
                        type == "option_container" && isCorrectOpt -> ansHighlightBg
                        type == "option_container" && dimWrong -> ansDimBg
                        type == "option_label" && isCorrectOpt -> ansBadgeBg
                        type == "option_label" && dimWrong -> ansDimBadgeBg
                        type == "option_text" && ((rawBgHex.isNotBlank() && rawBgHex != "transparent") || drawFallbackTextSlotBg) ->
                            if (isCorrectOpt) ansHighlightBg else if (dimWrong) ansDimBg else rawBgHex
                        type == "option_container" && rawBgHex.isBlank() -> "#050505"
                        type == "option_label" && rawBgHex.isBlank() -> "#ffff00"
                        type == "progress_bar" && rawBgHex.isBlank() -> "#303849"
                        else -> rawBgHex
                    }
                    if (resolvedBgHex.isNotBlank() && resolvedBgHex != "transparent") {
                        if (hasGlow) {
                            fillPaint.setShadowLayer(max(10f, height * 0.025f), 0f, 0f, parseColor(ansGlowColor, Color.GREEN))
                        }
                        fillPaint.style = Paint.Style.FILL
                        renderedFillColor = parseColor(resolvedBgHex, Color.TRANSPARENT)
                        fillPaint.color = renderedFillColor
                        fillPaint.alpha = opacity
                        drawShapeFill(fillPaint)
                        if (hasGlow) fillPaint.clearShadowLayer()

                        if (type == "header" && el.optString("headerDesign", "") == "stripe") {
                            val stripeBc = el.optString("borderColor", "")
                            if (stripeBc.isNotBlank() && stripeBc != "transparent") {
                                fillPaint.color = parseColor(stripeBc, Color.YELLOW)
                                fillPaint.alpha = opacity
                                val stripeH = max(3f, height * 0.008f)
                                canvas.drawRect(rect.left, rect.bottom, rect.right, rect.bottom + stripeH, fillPaint)
                            }
                        }
                    }
                }

                // Shared Border Outline
                val useCustomCorrectBorder = type == "option_container" && isCorrectOpt &&
                    ansCorrectBorderWidth > 0f && ansCorrectBorderColor.isNotBlank()
                val effBw = when {
                    useCustomCorrectBorder -> ansCorrectBorderWidth
                    type == "option_container" && dimWrong -> max(1.5f, el.optDouble("borderWidth", 1.5).toFloat())
                    else -> el.optDouble("borderWidth", 0.0).toFloat()
                }
                val effBc = when {
                    useCustomCorrectBorder -> ansCorrectBorderColor
                    type == "option_container" && dimWrong -> ansDimBorderColor
                    type == "option_label" && dimWrong && el.optDouble("borderWidth", 0.0) > 0.0 -> ansDimBorderColor
                    else -> el.optString("borderColor", "")
                }
                val skipLabelBorderOnCorrect = type == "option_label" && isCorrectOpt
                val parsedBc = if (effBw > 0f && effBc.isNotBlank() && effBc != "transparent" && !skipLabelBorderOnCorrect) {
                    parseColor(effBc, Color.WHITE)
                } else Color.TRANSPARENT
                if (parsedBc != Color.TRANSPARENT) {
                    strokePaint.strokeWidth = effBw * (width / 1280f)
                    strokePaint.color = parsedBc
                    strokePaint.alpha = opacity
                    drawShapeFill(strokePaint)
                }

                if (type == "option_container" && optIdx in 0..3) {
                    val prev = lastOptionDrawStates[optIdx]
                    lastOptionDrawStates[optIdx] = OptionDrawState(
                        fillColor = renderedFillColor,
                        alpha = opacity,
                        borderColor = parsedBc,
                        hasGlow = hasGlow,
                        scaled = isCorrectOpt && ansStyle == "strong-highlight" && ansScaleBoost > 1.001f,
                        labelBgColor = prev?.labelBgColor ?: Color.TRANSPARENT,
                        labelTextColor = prev?.labelTextColor ?: Color.TRANSPARENT,
                        optionTextColor = prev?.optionTextColor ?: Color.TRANSPARENT,
                        labelGlyph = prev?.labelGlyph ?: ""
                    )
                }
            }

            when (type) {
                "timer" -> {
                    if (!hideTimer) {
                        drawNativeTimer(canvas, rect, remaining, timerDuration, el)
                    }
                }
                "progress_bar" -> {
                    val progress = ((qIdx + 1).toFloat() / totalQ.toFloat()).coerceIn(0f, 1f)
                    fillPaint.style = Paint.Style.FILL
                    fillPaint.color = parseColor(el.optString("textColor", "#ff4a14"), Color.RED)
                    fillPaint.alpha = opacity
                    val fillW = min(rect.width(), max(rect.height(), rect.width() * progress))
                    val fillRect = RectF(rect.left, rect.top, rect.left + fillW, rect.bottom)
                    canvas.drawRoundRect(fillRect, radius, radius, fillPaint)
                }
                "icon" -> {
                    val glyph = el.optString("iconGlyph", "").ifBlank { el.optString("text", "★") }
                    if (glyph.isNotBlank()) {
                        val iconCol = el.optString("textColor", "#ffd700")
                        textPaint.style = Paint.Style.FILL
                        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                        textPaint.textAlign = Paint.Align.CENTER
                        textPaint.color = parseColor(iconCol, Color.YELLOW)
                        textPaint.alpha = opacity
                        textPaint.textSize = max(8f, min(rect.width(), rect.height()) * 0.72f)
                        val fm = textPaint.fontMetrics
                        val baseline = rect.centerY() - (fm.ascent + fm.descent) / 2f
                        canvas.save()
                        canvas.clipRect(rect)
                        canvas.drawText(glyph, rect.centerX(), baseline, textPaint)
                        canvas.restore()
                    }
                }
                "option_label" -> {
                    val labelStr = if (isCorrectOpt) "✓" else if (optIdx in 0..3) "ABCD"[optIdx].toString() else el.optString("text", "A")
                    val txtCol = when {
                        isCorrectOpt -> ansBadgeTickColor
                        dimWrong -> ansDimBadgeTextColor
                        else -> el.optString("textColor", "#000000")
                    }
                    if (labelStr.isNotEmpty()) {
                        drawElementText(
                            canvas = canvas,
                            rect = rect,
                            text = labelStr,
                            el = el,
                            alpha = opacity,
                            colorOverride = txtCol,
                            allowStroke = !(isCorrectOpt || dimWrong),
                            defaultWeight = 800
                        )
                    }
                    if (optIdx in 0..3) {
                        val parsedTxtCol = parseColor(txtCol, Color.BLACK)
                        val prev = lastOptionDrawStates[optIdx] ?: OptionDrawState(Color.TRANSPARENT, opacity, Color.TRANSPARENT, false, false)
                        lastOptionDrawStates[optIdx] = prev.copy(
                            labelBgColor = renderedFillColor,
                            labelTextColor = parsedTxtCol,
                            labelGlyph = labelStr
                        )
                    }
                }
                "option_text" -> {
                    val fullText = if (optIdx in 0 until options.length()) options.optString(optIdx, "") else el.optString("text", "")
                    val shownText = if (!syncEnabled || optIdx !in 0..3) {
                        fullText
                    } else {
                        val (st, en) = optSlots[optIdx]
                        val frac = ((voiceFrac - st) / (en - st)).coerceIn(0.0, 1.0)
                        progressiveText(fullText, frac, "optionText")
                    }
                    val txtCol = when {
                        isCorrectOpt -> ansCorrectTextColor
                        dimWrong -> ansDimTextColor
                        else -> el.optString("textColor", "#ffffff")
                    }
                    if (shownText.isNotEmpty()) {
                        drawElementText(canvas, rect, shownText.uppercase(), el, opacity, txtCol, allowStroke = !(isCorrectOpt || dimWrong))
                    }
                    if (optIdx in 0..3) {
                        val parsedOptCol = parseColor(txtCol, Color.WHITE)
                        val prev = lastOptionDrawStates[optIdx] ?: OptionDrawState(Color.TRANSPARENT, opacity, Color.TRANSPARENT, false, false)
                        lastOptionDrawStates[optIdx] = prev.copy(
                            fillColor = if (renderedFillColor != Color.TRANSPARENT) renderedFillColor else prev.fillColor,
                            optionTextColor = parsedOptCol
                        )
                    }
                }
                "question_text" -> {
                    val fullText = q.optString("question", el.optString("text", ""))
                    val shownText = if (!syncEnabled) fullText else {
                        val frac = ((voiceFrac - qStart) / max(0.1, qWordEnd - qStart)).coerceIn(0.0, 1.0)
                        progressiveText(fullText, frac, "questionText")
                    }
                    if (shownText.isNotEmpty()) {
                        drawElementText(canvas, rect, shownText.uppercase(), el, opacity)
                    }
                }
                "question_number" -> {
                    val txt = formatQuestionNumberText(el, qIdx, totalQ)
                    lastRenderedQuestionNumber = txt
                    drawElementText(canvas, rect, txt, el, opacity)
                }
                "text" -> {
                    val ansStr = if (correctIdx in 0 until options.length()) options.optString(correctIdx, "").uppercase() else ""
                    val introStr = resolveAnswerIntro(locale)
                    lastRenderedAnswerIntro = introStr
                    val txt = el.optString("text", "")
                        .replace("{header}", headerText.uppercase())
                        .replace("{channel}", (channelName.ifBlank { projectTitle }).uppercase())
                        .replace("{counter}", "${qIdx + 1} / $totalQ")
                        .replace("{num2}", (qIdx + 1).toString().padStart(2, '0'))
                        .replace("{total2}", totalQ.toString().padStart(2, '0'))
                        .replace("{num}", "${qIdx + 1}")
                        .replace("{total}", "$totalQ")
                        .replace("{answer_intro}", introStr)
                        .replace("{correct_answer}", ansStr)
                    drawElementText(canvas, rect, txt, el, opacity)
                }
            }
            canvas.restore()
        }
    }

    private fun progressiveText(fullText: String, frac: Double, roleName: String = "questionText"): String {
        if (frac >= 0.999) return fullText
        if (frac <= 0.0) return ""
        val roleObj = revealConfig.optJSONObject(roleName)
        val mode = roleObj?.optString("style", "")?.ifBlank { null }
            ?: revealConfig.optString("questionStyle", "typewriter-word")
        if (mode == "none" || mode == "fade-in" || mode == "pop-in" || mode == "scale-in" || mode.startsWith("slide-") || mode == "blur-clear" || mode == "mask-reveal" || mode == "wipe-reveal") {
            return fullText
        }
        return if (mode.contains("char") || mode.contains("letter")) {
            val count = ceil(fullText.length * frac).toInt().coerceIn(0, fullText.length)
            fullText.substring(0, count)
        } else {
            val words = fullText.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
            if (words.isEmpty()) return ""
            val count = ceil(words.size * frac).toInt().coerceIn(0, words.size)
            words.take(count).joinToString(" ")
        }
    }

    private fun drawCenteredElementText(canvas: Canvas, rect: RectF, text: String, el: JSONObject, alpha: Int, colorOverride: String? = null) {
        if (text.isBlank()) return
        val maxW = max(6f, rect.width() * 0.88f)
        val maxH = max(6f, rect.height() * 0.88f)
        val minFs = min(10f, max(5f, rect.height() * 0.35f))
        var fs = max(minFs, (el.optDouble("fontSize", 0.04) * height).toFloat())
        textPaint.typeface = resolveTypeface(el.optString("fontFamily", "League Spartan"), el.optInt("fontWeight", 800))
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.style = Paint.Style.FILL
        for (step in 0 until 28) {
            textPaint.textSize = fs
            val fm = textPaint.fontMetrics
            val textH = fm.descent - fm.ascent
            val textW = textPaint.measureText(text)
            if ((textW <= maxW && textH <= maxH) || fs <= minFs) break
            val nextFs = max(minFs, min(fs - 0.5f, fs * 0.86f))
            if (nextFs >= fs - 0.01f) break
            fs = nextFs
        }
        textPaint.color = parseColor(colorOverride ?: el.optString("textColor", "#000000"), Color.BLACK)
        textPaint.alpha = alpha
        textPaint.textSize = fs
        val fm = textPaint.fontMetrics
        val baseline = rect.centerY() - (fm.ascent + fm.descent) / 2f
        canvas.save()
        canvas.clipRect(rect)
        canvas.drawText(text, rect.centerX(), baseline, textPaint)
        canvas.restore()
    }

    private fun drawElementText(
        canvas: Canvas,
        rect: RectF,
        text: String,
        el: JSONObject,
        alpha: Int,
        colorOverride: String? = null,
        allowStroke: Boolean = true,
        defaultWeight: Int = 700
    ) {
        if (text.isBlank()) return
        val availW = max(8f, rect.width() * 0.94f)
        val availWInt = availW.roundToInt().coerceAtLeast(8)
        val availH = max(8f, rect.height() * 0.95f)
        val minFs = min(12f, max(6f, rect.height() * 0.42f))
        var fs = max(minFs, (el.optDouble("fontSize", 0.045) * height).toFloat())

        textPaint.color = parseColor(colorOverride ?: el.optString("textColor", "#000000"), Color.BLACK)
        textPaint.alpha = alpha
        textPaint.typeface = resolveTypeface(el.optString("fontFamily", "League Spartan"), el.optInt("fontWeight", defaultWeight))
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.style = Paint.Style.FILL
        val alignMode = el.optString("alignment", "center")
        val align = when (alignMode) {
            "left" -> Layout.Alignment.ALIGN_NORMAL
            "right" -> Layout.Alignment.ALIGN_OPPOSITE
            else -> Layout.Alignment.ALIGN_CENTER
        }

        val words = text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val isSingleWord = words.size == 1 && !text.contains('\n')
        var layout: StaticLayout? = null
        for (step in 0 until 36) {
            textPaint.textSize = fs
            val maxWordW = if (words.isEmpty()) 0f else words.maxOf { textPaint.measureText(it) }
            val built = StaticLayout.Builder.obtain(text, 0, text.length, textPaint, availWInt)
                .setAlignment(align)
                .setIncludePad(false)
                .build()
            layout = built
            val singleWordSplit = isSingleWord && built.lineCount > 1
            if ((built.height <= availH && maxWordW <= availW * 0.99f && !singleWordSplit) || fs <= minFs) break
            val nextFs = max(minFs, min(fs - 0.5f, fs * 0.86f))
            if (nextFs >= fs - 0.01f) break
            fs = nextFs
        }
        val finalLayout = layout ?: StaticLayout.Builder.obtain(text, 0, text.length, textPaint, availWInt)
            .setAlignment(align)
            .setIncludePad(false)
            .build()

        canvas.save()
        canvas.clipRect(rect)
        val dx = when (alignMode) {
            "left" -> rect.left + rect.width() * 0.03f
            "right" -> rect.right - rect.width() * 0.03f - availWInt
            else -> rect.left + (rect.width() - availWInt) / 2f
        }
        val dy = rect.top + (rect.height() - finalLayout.height) / 2f
        canvas.translate(dx, dy)

        if (allowStroke && el.optBoolean("strokeEnabled", false)) {
            val strokeHex = el.optString("strokeColor", "#000000")
            if (strokeHex.isNotBlank() && strokeHex != "transparent") {
                val savedColor = textPaint.color
                textPaint.style = Paint.Style.STROKE
                textPaint.strokeJoin = Paint.Join.ROUND
                textPaint.strokeWidth = max(1.5f, fs * 0.06f)
                textPaint.color = parseColor(strokeHex, Color.BLACK)
                textPaint.alpha = alpha
                finalLayout.draw(canvas)
                textPaint.style = Paint.Style.FILL
                textPaint.color = savedColor
                textPaint.alpha = alpha
            }
        }

        finalLayout.draw(canvas)
        canvas.restore()
    }

    private fun renderFallbackDefault(
        canvas: Canvas,
        q: JSONObject,
        qIdx: Int,
        remaining: Double,
        reveal: Boolean,
        voiceFrac: Double,
        hideTimer: Boolean = false
    ) {
        val hdrH = height * 0.165f
        fillPaint.style = Paint.Style.FILL
        fillPaint.color = parseColor(theme.optString("headerBg", "#1e1b08"), Color.BLACK)
        canvas.drawRect(0f, 0f, width.toFloat(), hdrH, fillPaint)

        textPaint.color = Color.WHITE
        textPaint.textSize = hdrH * 0.5f
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("${qIdx + 1}/${questions.size}  ${headerText.uppercase()}", width * 0.04f, hdrH * 0.68f, textPaint)

        val qText = progressiveText(q.optString("question", ""), (voiceFrac / 0.45).coerceIn(0.0, 1.0)).uppercase()
        textPaint.color = parseColor(theme.optString("qText", "#000000"), Color.BLACK)
        textPaint.textSize = width * 0.042f
        val layout = StaticLayout.Builder.obtain(qText, 0, qText.length, textPaint, (width * 0.88f).toInt())
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .build()
        canvas.save()
        canvas.translate(width * 0.06f, hdrH + height * 0.08f)
        layout.draw(canvas)
        canvas.restore()

        val opts = q.optJSONArray("options") ?: JSONArray()
        val correct = q.optInt("correct", 0)
        val ansStyle = answerRevealConfig.optString("style", "correct-only")
        val ansHighlightBg = answerRevealConfig.optString("highlightBg", theme.optString("correctFill", "#16a34a")).ifBlank { "#16a34a" }
        val ansCorrectText = answerRevealConfig.optString("correctTextColor", theme.optString("optText", "#ffffff")).ifBlank { "#ffffff" }
        val ansDimBg = answerRevealConfig.optString("dimBg", "#1e293b").ifBlank { "#1e293b" }
        val ansDimText = answerRevealConfig.optString("dimTextColor", "#94a3b8").ifBlank { "#94a3b8" }
        val ansDimOpacity = answerRevealConfig.optDouble("dimOpacity", 0.88).coerceIn(0.1, 1.0)
        val dimWrongEnabled = ansStyle == "highlight-dim-others" || answerRevealConfig.optBoolean("dimWrongBgEnabled", false)
        val boxW = width * 0.43f
        val boxH = height * 0.115f
        for (i in 0 until min(4, opts.length())) {
            val col = i % 2
            val row = i / 2
            val bx = width * 0.05f + col * (boxW + width * 0.04f)
            val by = height * 0.62f + row * (boxH + height * 0.035f)
            val isRight = reveal && i == correct
            val isDimmed = reveal && i != correct && dimWrongEnabled
            val alphaInt = if (isDimmed) (255 * ansDimOpacity).toInt().coerceIn(25, 255) else 255
            fillPaint.color = parseColor(
                when {
                    isRight -> ansHighlightBg
                    isDimmed -> ansDimBg
                    else -> theme.optString("optFill", "#050505")
                },
                Color.BLACK
            )
            fillPaint.alpha = alphaInt
            val r = RectF(bx, by, bx + boxW, by + boxH)
            canvas.drawRoundRect(r, boxH / 2f, boxH / 2f, fillPaint)
            fillPaint.alpha = 255
            textPaint.color = parseColor(
                when {
                    isRight -> ansCorrectText
                    isDimmed -> ansDimText
                    else -> theme.optString("optText", "#ffffff")
                },
                Color.WHITE
            )
            textPaint.alpha = alphaInt
            textPaint.textSize = boxH * 0.36f
            textPaint.textAlign = Paint.Align.LEFT
            canvas.drawText("${"ABCD"[i]}. ${opts.optString(i).uppercase()}", bx + boxH * 0.4f, by + boxH * 0.62f, textPaint)
            textPaint.alpha = 255
        }
        if (!hideTimer) {
            drawNativeTimer(canvas, RectF(width * 0.2f, height * 0.50f, width * 0.8f, height * 0.555f), remaining, timerDuration, null)
        }
    }

    private fun resolveTimerLook(el: JSONObject?): String {
        val elLook = el?.optString("timerLook", "")?.trim().orEmpty()
        if (elLook.isNotEmpty()) return elLook
        return theme.optString("timerLook", "capsule").ifBlank { "capsule" }
    }

    private fun mixColors(c1: Int, c2: Int, t: Float): Int {
        val clamped = t.coerceIn(0f, 1f)
        val r = (Color.red(c1) + (Color.red(c2) - Color.red(c1)) * clamped).roundToInt().coerceIn(0, 255)
        val g = (Color.green(c1) + (Color.green(c2) - Color.green(c1)) * clamped).roundToInt().coerceIn(0, 255)
        val b = (Color.blue(c1) + (Color.blue(c2) - Color.blue(c1)) * clamped).roundToInt().coerceIn(0, 255)
        val a = (Color.alpha(c1) + (Color.alpha(c2) - Color.alpha(c1)) * clamped).roundToInt().coerceIn(0, 255)
        return Color.argb(a, r, g, b)
    }

    private fun metalBorderGradient(topY: Float, botY: Float, borderColor: Int): LinearGradient {
        return LinearGradient(
            0f, topY, 0f, botY,
            intArrayOf(
                mixColors(borderColor, Color.WHITE, 0.35f),
                mixColors(borderColor, Color.BLACK, 0.14f),
                mixColors(borderColor, Color.BLACK, 0.45f)
            ),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    private fun drawCountdownDigit(
        canvas: Canvas,
        txt: String,
        cx: Float,
        cy: Float,
        sizePx: Float,
        color: Int,
        pulse: Float,
        shadowColor: Int = Color.TRANSPARENT
    ) {
        val sc = 1f + 0.14f * pulse
        textPaint.color = color
        textPaint.alpha = 255
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.style = Paint.Style.FILL
        textPaint.textSize = max(8f, sizePx * sc)
        if (shadowColor != Color.TRANSPARENT) {
            textPaint.setShadowLayer(max(2f, sizePx * 0.25f), 0f, 0f, shadowColor)
        }
        val fm = textPaint.fontMetrics
        val baseline = cy - (fm.ascent + fm.descent) / 2f
        canvas.drawText(txt, cx, baseline, textPaint)
        if (shadowColor != Color.TRANSPARENT) {
            textPaint.clearShadowLayer()
        }
    }

    private fun drawNativeTimer(canvas: Canvas, rect: RectF, remaining: Double, total: Double, el: JSONObject? = null) {
        val dur = total.coerceAtLeast(1.0)
        val secLeft = remaining.coerceAtLeast(0.0)
        val frac = (secLeft / dur).toFloat().coerceIn(0f, 1f)
        val durInt = ceil(dur).toInt().coerceAtLeast(1)
        val shown = min(durInt, ceil(secLeft - 1e-6).toInt().coerceAtLeast(0))
        val urgent = secLeft > 0.0 && secLeft <= 3.0
        val pulse = if (urgent) (0.5 + 0.5 * sin(secLeft * PI * 2.0)).toFloat() else 0f
        val look = resolveTimerLook(el)

        val elText = el?.optString("textColor", "")?.trim().orEmpty()
        val elBg = el?.optString("backgroundColor", "")?.trim().orEmpty()
        val elBorder = el?.optString("borderColor", "")?.trim().orEmpty()
        val timerA = parseColor(
            if (elText.isNotEmpty() && !elText.equals("#ffffff", ignoreCase = true)) elText else theme.optString("timerA", "#ff4a14"),
            Color.parseColor("#ff4a14")
        )
        val timerB = parseColor(theme.optString("timerB", "#f02a00"), Color.parseColor("#f02a00"))
        val timerTrack = parseColor(
            if (elBg.isNotEmpty() && !elBg.equals("transparent", ignoreCase = true)) elBg else theme.optString("timerTrack", "#d9d9d9"),
            Color.parseColor("#d9d9d9")
        )
        val timerBorder = parseColor(
            if (elBorder.isNotEmpty() && !elBorder.equals("#000000", ignoreCase = true)) elBorder else theme.optString("timerBorder", "#ffffff"),
            Color.WHITE
        )
        val hotCol = if (urgent) Color.parseColor("#ff2d1a") else timerA
        val colTop = if (urgent) Color.parseColor("#ff6a55") else timerA
        val colBot = if (urgent) Color.parseColor("#d81500") else timerB

        val tY = rect.top
        val tH = max(8f, rect.height())
        val cx = rect.centerX()
        val maxBarW = if (sceneMode == "IMPORTED_TEMPLATE_MODE" && rect.width() > 0f && rect.width() < width * 0.55f) rect.width() else width * 0.6f
        fillPaint.alpha = 255
        fillPaint.shader = null
        strokePaint.alpha = 255
        strokePaint.shader = null

        when (look) {
            "stopwatch" -> {
                val R = tH * 1.25f
                val cy = tY + tH - R
                // Top metallic stem & crown + 45deg side pusher
                fillPaint.style = Paint.Style.FILL
                fillPaint.shader = LinearGradient(cx - R * 0.2f, 0f, cx + R * 0.2f, 0f, intArrayOf(Color.parseColor("#8e8e8e"), Color.parseColor("#f2f2f2"), Color.parseColor("#8e8e8e")), null, Shader.TileMode.CLAMP)
                canvas.drawRoundRect(RectF(cx - R * 0.17f, cy - R - R * 0.30f, cx + R * 0.17f, cy - R), R * 0.06f, R * 0.06f, fillPaint)
                canvas.drawRoundRect(RectF(cx - R * 0.28f, cy - R - R * 0.36f, cx + R * 0.28f, cy - R - R * 0.24f), R * 0.05f, R * 0.05f, fillPaint)
                canvas.save()
                canvas.translate(cx + R * 0.72f, cy - R * 0.72f)
                canvas.rotate(45f)
                canvas.drawRoundRect(RectF(-R * 0.1f, -R * 0.2f, R * 0.1f, 0f), R * 0.04f, R * 0.04f, fillPaint)
                canvas.restore()
                fillPaint.shader = null

                // Outer metallic ring
                if (urgent) {
                    fillPaint.setShadowLayer(R * 0.4f, 0f, 0f, Color.argb((180 * (0.4f + 0.4f * pulse)).toInt(), 255, 40, 20))
                }
                fillPaint.shader = metalBorderGradient(cy - R, cy + R, timerBorder)
                canvas.drawCircle(cx, cy, R, fillPaint)
                fillPaint.shader = null
                fillPaint.clearShadowLayer()

                // Dark dial face
                val dR = R * 0.88f
                fillPaint.shader = RadialGradient(cx, cy - dR * 0.4f, max(1f, dR), Color.parseColor("#383838"), Color.parseColor("#0a0a0a"), Shader.TileMode.CLAMP)
                canvas.drawCircle(cx, cy, dR, fillPaint)
                fillPaint.shader = null

                // Perimeter tick marks
                val n = if (dur <= 30.0) (dur.toInt().coerceAtLeast(1) * 2) else 60
                strokePaint.strokeCap = Paint.Cap.ROUND
                for (i in 0 until n) {
                    val a = (i.toDouble() / n.toDouble()) * PI * 2.0 - PI / 2.0
                    val big = (i % 2 == 0) || (n == 60)
                    val r1 = dR * if (big) 0.80f else 0.86f
                    val r2 = dR * 0.93f
                    val passed = (i.toDouble() / n.toDouble()) < (1.0 - frac.toDouble()) - 1e-6
                    strokePaint.color = when {
                        passed -> Color.argb(64, 255, 255, 255)
                        urgent && (i.toDouble() / n.toDouble()) >= 1.0 - 3.0 / dur -> Color.parseColor("#ff5a40")
                        else -> Color.argb(230, 255, 255, 255)
                    }
                    strokePaint.strokeWidth = max(1f, dR * if (big) 0.045f else 0.025f)
                    canvas.drawLine(
                        cx + (cos(a) * r1).toFloat(),
                        cy + (sin(a) * r1).toFloat(),
                        cx + (cos(a) * r2).toFloat(),
                        cy + (sin(a) * r2).toFloat(),
                        strokePaint
                    )
                }

                // Sweep needle
                val ang = -PI / 2.0 + PI * 2.0 * (1.0 - frac.toDouble())
                canvas.save()
                canvas.translate(cx, cy)
                canvas.rotate(Math.toDegrees(ang + PI / 2.0).toFloat())
                strokePaint.color = hotCol
                strokePaint.strokeWidth = max(1.5f, dR * 0.05f)
                strokePaint.strokeCap = Paint.Cap.ROUND
                canvas.drawLine(0f, dR * 0.16f, 0f, -dR * 0.72f, strokePaint)
                fillPaint.color = hotCol
                canvas.drawCircle(0f, 0f, max(2f, dR * 0.09f), fillPaint)
                canvas.restore()

                drawCountdownDigit(canvas, shown.toString(), cx, cy + dR * 0.42f, dR * 0.44f, Color.WHITE, pulse)
            }
            "ring" -> {
                val R = tH * 1.35f
                val cy = tY + tH - R
                fillPaint.style = Paint.Style.FILL
                fillPaint.shader = metalBorderGradient(cy - R, cy + R, timerBorder)
                canvas.drawCircle(cx, cy, R, fillPaint)
                val dR = R * 0.90f
                fillPaint.shader = RadialGradient(cx, cy - dR * 0.4f, max(1f, dR), Color.parseColor("#3d3d3d"), Color.parseColor("#0b0b0b"), Shader.TileMode.CLAMP)
                canvas.drawCircle(cx, cy, dR, fillPaint)
                fillPaint.shader = null

                val rr = R * 0.70f
                val arcRect = RectF(cx - rr, cy - rr, cx + rr, cy + rr)
                strokePaint.strokeCap = Paint.Cap.ROUND
                strokePaint.strokeWidth = max(2f, R * 0.17f)
                strokePaint.color = Color.argb(32, 255, 255, 255)
                canvas.drawOval(arcRect, strokePaint)
                if (frac > 0f) {
                    strokePaint.shader = LinearGradient(cx - rr, cy - rr, cx + rr, cy + rr, colTop, colBot, Shader.TileMode.CLAMP)
                    canvas.drawArc(arcRect, -90f, 360f * frac, false, strokePaint)
                    strokePaint.shader = null
                }
                drawCountdownDigit(canvas, shown.toString(), cx, cy + R * 0.02f, R * (if (shown >= 10) 0.78f else 0.98f), Color.WHITE, pulse)
                textPaint.color = Color.argb(128, 255, 255, 255)
                textPaint.textSize = max(6f, R * 0.17f)
                textPaint.textAlign = Paint.Align.CENTER
                canvas.drawText("SEC", cx, cy + R * 0.56f, textPaint)
            }
            "neon" -> {
                val R = tH * 1.30f
                val cy = tY + tH - R
                val col = if (urgent) Color.parseColor("#ff3b1f") else timerA
                fillPaint.style = Paint.Style.FILL
                fillPaint.shader = RadialGradient(cx, cy, max(1f, R), Color.argb(232, 10, 12, 20), Color.argb(245, 2, 3, 8), Shader.TileMode.CLAMP)
                canvas.drawCircle(cx, cy, R, fillPaint)
                fillPaint.shader = null
                strokePaint.strokeWidth = max(1.5f, R * 0.05f)
                strokePaint.color = mixColors(timerBorder, Color.TRANSPARENT, 0.25f)
                canvas.drawCircle(cx, cy, R * 0.97f, strokePaint)
                val ringRect = RectF(cx - R * 0.74f, cy - R * 0.74f, cx + R * 0.74f, cy + R * 0.74f)
                strokePaint.strokeWidth = max(2f, R * 0.10f)
                strokePaint.color = Color.argb(22, 255, 255, 255)
                canvas.drawOval(ringRect, strokePaint)
                if (frac > 0f) {
                    strokePaint.strokeCap = Paint.Cap.ROUND
                    strokePaint.strokeWidth = max(2f, R * 0.11f)
                    strokePaint.color = col
                    canvas.drawArc(ringRect, -90f, 360f * frac, false, strokePaint)
                    strokePaint.strokeWidth = max(1f, R * 0.04f)
                    strokePaint.color = Color.WHITE
                    canvas.drawArc(ringRect, -90f, 360f * frac, false, strokePaint)
                }
                drawCountdownDigit(canvas, shown.toString(), cx, cy + R * 0.03f, R * (if (shown >= 10) 0.72f else 0.95f), Color.WHITE, pulse, col)
            }
            "pie" -> {
                val R = tH * 1.30f
                val cy = tY + tH - R
                fillPaint.style = Paint.Style.FILL
                fillPaint.shader = metalBorderGradient(cy - R, cy + R, timerBorder)
                canvas.drawCircle(cx, cy, R, fillPaint)
                fillPaint.shader = null
                val fR = R * 0.88f
                fillPaint.color = timerTrack
                canvas.drawCircle(cx, cy, fR, fillPaint)
                if (frac > 0f) {
                    fillPaint.shader = RadialGradient(cx, cy, max(1f, fR), colTop, colBot, Shader.TileMode.CLAMP)
                    canvas.drawArc(RectF(cx - fR, cy - fR, cx + fR, cy + fR), -90f, max(0.1f, 360f * frac), true, fillPaint)
                    fillPaint.shader = null
                }
                val hR = R * 0.46f
                fillPaint.shader = RadialGradient(cx, cy - hR * 0.4f, max(1f, hR), Color.parseColor("#3d3d3d"), Color.parseColor("#0b0b0b"), Shader.TileMode.CLAMP)
                canvas.drawCircle(cx, cy, hR, fillPaint)
                fillPaint.shader = null
                drawCountdownDigit(canvas, shown.toString(), cx, cy + R * 0.02f, hR * (if (shown >= 10) 0.95f else 1.25f), Color.WHITE, pulse)
            }
            "clock" -> {
                val R = tH * 1.35f
                val cy = tY + tH - R
                fillPaint.style = Paint.Style.FILL
                fillPaint.shader = metalBorderGradient(cy - R, cy + R, timerBorder)
                canvas.drawCircle(cx, cy, R, fillPaint)
                val fR = R * 0.90f
                fillPaint.shader = RadialGradient(cx, cy - fR * 0.3f, max(1f, fR), Color.WHITE, Color.parseColor("#e2e2e2"), Shader.TileMode.CLAMP)
                canvas.drawCircle(cx, cy, fR, fillPaint)
                fillPaint.shader = null
                val ang = -PI / 2.0 + PI * 2.0 * (1.0 - frac.toDouble())
                if (frac > 0f) {
                    fillPaint.color = Color.argb(56, Color.red(hotCol), Color.green(hotCol), Color.blue(hotCol))
                    val startDeg = Math.toDegrees(ang).toFloat()
                    canvas.drawArc(RectF(cx - fR * 0.93f, cy - fR * 0.93f, cx + fR * 0.93f, cy + fR * 0.93f), startDeg, 360f * frac, true, fillPaint)
                }
                strokePaint.color = Color.parseColor("#222222")
                strokePaint.strokeCap = Paint.Cap.ROUND
                for (i in 0 until 60) {
                    val a = (i / 60.0) * PI * 2.0 - PI / 2.0
                    val big = i % 5 == 0
                    val r1 = fR * if (big) 0.76f else 0.84f
                    val r2 = fR * 0.92f
                    strokePaint.strokeWidth = max(1f, fR * if (big) 0.045f else 0.02f)
                    canvas.drawLine(cx + (cos(a) * r1).toFloat(), cy + (sin(a) * r1).toFloat(), cx + (cos(a) * r2).toFloat(), cy + (sin(a) * r2).toFloat(), strokePaint)
                }
                canvas.save()
                canvas.translate(cx, cy)
                canvas.rotate(Math.toDegrees(ang + PI / 2.0).toFloat())
                strokePaint.color = hotCol
                strokePaint.strokeWidth = max(1.5f, fR * 0.055f)
                canvas.drawLine(0f, fR * 0.2f, 0f, -fR * 0.8f, strokePaint)
                fillPaint.color = hotCol
                canvas.drawCircle(0f, 0f, max(2f, fR * 0.1f), fillPaint)
                fillPaint.color = Color.WHITE
                canvas.drawCircle(0f, 0f, max(1f, fR * 0.035f), fillPaint)
                canvas.restore()
                drawCountdownDigit(canvas, shown.toString(), cx, cy + fR * 0.42f, fR * 0.30f, if (urgent) Color.parseColor("#d81500") else Color.parseColor("#222222"), pulse)
            }
            "orb" -> {
                val R = tH * 1.05f
                val cy = tY + tH - R * 1.2f
                val c1 = if (urgent) Color.parseColor("#ff5a40") else timerA
                val c2 = if (urgent) Color.parseColor("#d81500") else timerB
                fillPaint.style = Paint.Style.FILL
                fillPaint.shader = RadialGradient(cx - R * 0.3f, cy - R * 0.35f, max(1f, R), intArrayOf(Color.WHITE, c1, c2), floatArrayOf(0f, 0.25f, 1f), Shader.TileMode.CLAMP)
                canvas.drawCircle(cx, cy, R, fillPaint)
                fillPaint.shader = null
                if (frac > 0f) {
                    strokePaint.strokeCap = Paint.Cap.ROUND
                    strokePaint.strokeWidth = max(2f, R * 0.09f)
                    strokePaint.color = timerBorder
                    canvas.drawArc(RectF(cx - R, cy - R, cx + R, cy + R), -90f, 360f * frac, false, strokePaint)
                }
                drawCountdownDigit(canvas, shown.toString(), cx, cy + R * 0.04f, R * (if (shown >= 10) 0.82f else 1.08f), Color.WHITE, pulse, Color.argb(115, 0, 0, 0))
            }
            "bold" -> {
                val R = tH * 1.45f
                val cy = tY + tH - R + R * 0.12f
                val ink = if (urgent) Color.parseColor("#d81500") else if (timerBorder != Color.WHITE) timerBorder else Color.WHITE
                val inv = if (ink == Color.WHITE) Color.BLACK else Color.WHITE
                fillPaint.style = Paint.Style.FILL
                fillPaint.color = ink
                canvas.drawRect(cx - R * 0.08f, cy - R * 1.12f, cx + R * 0.08f, cy - R * 0.92f, fillPaint)
                canvas.drawRoundRect(RectF(cx - R * 0.26f, cy - R * 1.32f, cx + R * 0.26f, cy - R * 1.10f), R * 0.05f, R * 0.05f, fillPaint)
                strokePaint.strokeWidth = max(2f, R * 0.20f)
                strokePaint.color = ink
                canvas.drawCircle(cx, cy, R * 0.90f, strokePaint)
                val sweep = 360f * (1f - frac)
                val sz = R * (if (shown >= 10) 0.85f else 1.1f)
                drawCountdownDigit(canvas, shown.toString(), cx, cy + R * 0.13f, sz, ink, pulse)
                if (sweep > 0.2f) {
                    val wR = R * 0.70f
                    val wedgePath = Path().apply {
                        moveTo(cx, cy)
                        arcTo(RectF(cx - wR, cy - wR, cx + wR, cy + wR), -90f, sweep, false)
                        close()
                    }
                    fillPaint.color = ink
                    canvas.drawPath(wedgePath, fillPaint)
                    canvas.save()
                    canvas.clipPath(wedgePath)
                    drawCountdownDigit(canvas, shown.toString(), cx, cy + R * 0.13f, sz, inv, pulse)
                    canvas.restore()
                }
            }
            "segments" -> {
                val N = 20
                val boxW = min(tH * 1.7f, maxBarW * 0.28f)
                val gap = tH * 0.45f
                val hW = max(tH * 1.5f, maxBarW - boxW - gap)
                val gX = cx - (hW + gap + boxW) / 2f
                val hH = tH * 1.1f
                val hY = tY + tH / 2f - hH / 2f
                fillPaint.style = Paint.Style.FILL
                fillPaint.shader = LinearGradient(0f, hY, 0f, hY + hH, Color.parseColor("#3a3a3a"), Color.parseColor("#0d0d0d"), Shader.TileMode.CLAMP)
                canvas.drawRoundRect(RectF(gX, hY, gX + hW, hY + hH), hH * 0.3f, hH * 0.3f, fillPaint)
                canvas.drawRoundRect(RectF(gX + hW + gap, hY, gX + hW + gap + boxW, hY + hH), hH * 0.3f, hH * 0.3f, fillPaint)
                fillPaint.shader = null
                strokePaint.strokeWidth = max(1f, tH * 0.05f)
                strokePaint.color = timerBorder
                canvas.drawRoundRect(RectF(gX, hY, gX + hW, hY + hH), hH * 0.3f, hH * 0.3f, strokePaint)
                canvas.drawRoundRect(RectF(gX + hW + gap, hY, gX + hW + gap + boxW, hY + hH), hH * 0.3f, hH * 0.3f, strokePaint)
                val pad = hH * 0.16f
                val sg = hH * 0.07f
                val sw = max(2f, (hW - pad * 2f - sg * (N - 1)) / N)
                val sh = hH - pad * 2f
                val lit = ceil(frac * N - 1e-6).toInt().coerceIn(0, N)
                for (i in 0 until N) {
                    val sx = gX + pad + i * (sw + sg)
                    val rSeg = RectF(sx, hY + pad, sx + sw, hY + pad + sh)
                    if (i < lit) {
                        fillPaint.shader = LinearGradient(0f, rSeg.top, 0f, rSeg.bottom, if (urgent) Color.parseColor("#ff7a66") else timerA, colBot, Shader.TileMode.CLAMP)
                        fillPaint.alpha = if (urgent && i == lit - 1) ((0.55f + 0.45f * pulse) * 255).toInt() else 255
                        canvas.drawRoundRect(rSeg, sw * 0.3f, sw * 0.3f, fillPaint)
                        fillPaint.shader = null
                        fillPaint.alpha = 255
                    } else {
                        fillPaint.color = Color.argb(24, 255, 255, 255)
                        canvas.drawRoundRect(rSeg, sw * 0.3f, sw * 0.3f, fillPaint)
                    }
                }
                drawCountdownDigit(canvas, shown.toString(), gX + hW + gap + boxW / 2f, hY + hH / 2f + hH * 0.04f, hH * 0.72f, if (urgent) Color.parseColor("#ff6a55") else Color.WHITE, pulse)
            }
            "flatbar" -> {
                val tW = maxBarW
                val tX = cx - tW / 2f
                val bw = max(2f, tH * 0.09f)
                fillPaint.style = Paint.Style.FILL
                fillPaint.color = timerBorder
                val rimR = (tH + bw * 2f) / 2f
                canvas.drawRoundRect(RectF(tX - bw, tY - bw, tX + tW + bw, tY + tH + bw), rimR, rimR, fillPaint)
                fillPaint.color = timerTrack
                canvas.drawRoundRect(RectF(tX, tY, tX + tW, tY + tH), tH / 2f, tH / 2f, fillPaint)
                if (frac > 0f) {
                    val fw = min(tW, max(tH, tW * frac))
                    fillPaint.shader = LinearGradient(0f, tY, 0f, tY + tH, if (urgent) Color.parseColor("#ff4a30") else timerA, colBot, Shader.TileMode.CLAMP)
                    canvas.drawRoundRect(RectF(tX, tY, tX + fw, tY + tH), tH / 2f, tH / 2f, fillPaint)
                    fillPaint.shader = null
                }
            }
            else -> {
                // Default rich "capsule" look: metallic rim + inset track + glossy gradient pill + seconds dial badge
                val bR = min(tH * 0.88f, maxBarW * 0.22f)
                val gapB = tH * 0.5f
                val tW = max(tH, maxBarW - bR * 2f - gapB)
                val gW = bR * 2f + gapB + tW
                val gX = cx - gW / 2f
                val bcx = gX + bR
                val bcy = tY + tH / 2f
                val tX = gX + bR * 2f + gapB
                val bw = max(2f, tH * 0.10f)
                val capR = (tH + bw * 2f) / 2f

                fillPaint.style = Paint.Style.FILL
                fillPaint.shader = metalBorderGradient(tY - bw, tY + tH + bw, timerBorder)
                canvas.drawRoundRect(RectF(tX - bw, tY - bw, tX + tW + bw, tY + tH + bw), capR, capR, fillPaint)
                fillPaint.shader = null

                val trackRect = RectF(tX, tY, tX + tW, tY + tH)
                val trackPath = Path().apply { addRoundRect(trackRect, tH / 2f, tH / 2f, Path.Direction.CW) }
                canvas.save()
                canvas.clipPath(trackPath)
                fillPaint.color = timerTrack
                canvas.drawRect(trackRect, fillPaint)
                fillPaint.shader = LinearGradient(0f, tY, 0f, tY + tH, intArrayOf(Color.argb(96, 0, 0, 0), Color.argb(20, 0, 0, 0), Color.argb(46, 255, 255, 255)), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
                canvas.drawRect(trackRect, fillPaint)
                fillPaint.shader = null

                if (frac > 0f) {
                    val fw = min(tW, max(tH, tW * frac))
                    fillPaint.shader = LinearGradient(0f, tY, 0f, tY + tH, colTop, colBot, Shader.TileMode.CLAMP)
                    canvas.drawRoundRect(RectF(tX, tY, tX + fw, tY + tH), tH / 2f, tH / 2f, fillPaint)
                    fillPaint.shader = null
                    fillPaint.shader = LinearGradient(0f, tY, 0f, tY + tH * 0.55f, Color.argb(158, 255, 255, 255), Color.argb(10, 255, 255, 255), Shader.TileMode.CLAMP)
                    if (fw > tH * 0.4f) {
                        canvas.drawRoundRect(RectF(tX + tH * 0.18f, tY + tH * 0.08f, tX + fw - tH * 0.18f, tY + tH * 0.50f), tH * 0.21f, tH * 0.21f, fillPaint)
                    }
                    fillPaint.shader = null
                }
                if (dur > 1.0 && dur <= 30.0) {
                    fillPaint.color = Color.argb(51, 0, 0, 0)
                    val dInt = dur.toInt()
                    val halfTick = max(0.5f, tH * 0.015f)
                    for (k in 1 until dInt) {
                        val tx = tX + tW * (k.toFloat() / dInt.toFloat())
                        canvas.drawRect(tx - halfTick, tY + tH * 0.2f, tx + halfTick, tY + tH * 0.8f, fillPaint)
                    }
                }
                canvas.restore()

                // Seconds badge
                fillPaint.shader = metalBorderGradient(bcy - bR, bcy + bR, timerBorder)
                canvas.drawCircle(bcx, bcy, bR, fillPaint)
                val dR = bR * 0.84f
                fillPaint.shader = RadialGradient(bcx, bcy - dR * 0.35f, max(1f, dR), Color.parseColor("#3a3a3a"), Color.parseColor("#0c0c0c"), Shader.TileMode.CLAMP)
                canvas.drawCircle(bcx, bcy, dR, fillPaint)
                fillPaint.shader = null

                val ringR = dR * 0.82f
                val ringRect = RectF(bcx - ringR, bcy - ringR, bcx + ringR, bcy + ringR)
                strokePaint.strokeCap = Paint.Cap.ROUND
                strokePaint.strokeWidth = max(1.5f, bR * 0.15f)
                strokePaint.color = Color.argb(36, 255, 255, 255)
                canvas.drawOval(ringRect, strokePaint)
                if (frac > 0f) {
                    strokePaint.color = hotCol
                    canvas.drawArc(ringRect, -90f, 360f * frac, false, strokePaint)
                }
                val numSize = bR * (if (shown >= 100) 0.7f else if (shown >= 10) 0.9f else 1.1f)
                drawCountdownDigit(canvas, shown.toString(), bcx, bcy + bR * 0.04f, numSize, Color.WHITE, pulse)
            }
        }
    }

    private fun drawTransitionOverlay(canvas: Canvas, progress: Double) {
        val snap = snapBitmap ?: return
        val style = transitionConfig.optString("style", "classic-page-turn")
        val p = progress.toFloat().coerceIn(0f, 1f)
        val eased = if (p < 0.5f) 2f * p * p else 1f - (-2f * p + 2f).pow(2) / 2f
        if (style == "none" || p >= 1f) return
        when (style) {
            "fade", "crossfade" -> {
                fillPaint.alpha = ((1f - eased) * 255).toInt()
                canvas.drawBitmap(snap, 0f, 0f, fillPaint)
                fillPaint.alpha = 255
            }
            "slide-left", "push" -> {
                canvas.save()
                canvas.translate(-width * eased, 0f)
                canvas.drawBitmap(snap, 0f, 0f, null)
                canvas.restore()
            }
            "slide-right" -> {
                canvas.save()
                canvas.translate(width * eased, 0f)
                canvas.drawBitmap(snap, 0f, 0f, null)
                canvas.restore()
            }
            "reverse-page-turn" -> {
                val left = width * eased
                canvas.save()
                canvas.clipRect(left, 0f, width.toFloat(), height.toFloat())
                canvas.drawBitmap(snap, 0f, 0f, null)
                canvas.restore()
            }
            else -> {
                val pw = width * (1f - eased)
                if (pw > 1f) {
                    canvas.save()
                    canvas.clipRect(0f, 0f, pw, height.toFloat())
                    canvas.scale(pw / width, 1f)
                    canvas.drawBitmap(snap, 0f, 0f, null)
                    canvas.restore()
                    if (p > 0.5f) {
                        fillPaint.color = Color.argb(((p - 0.5f) * 1.4f * 255).toInt().coerceIn(0, 215), 240, 235, 225)
                        canvas.drawRect(0f, 0f, pw, height.toFloat(), fillPaint)
                    }
                }
            }
        }
    }

    fun release() {
        assetBitmaps.values.forEach { try { it.recycle() } catch (_: Exception) {} }
        assetBitmaps.clear()
        try { snapBitmap?.recycle() } catch (_: Exception) {}
        snapBitmap = null
        try { staticCacheBitmap?.recycle() } catch (_: Exception) {}
        staticCacheBitmap = null
    }
}
