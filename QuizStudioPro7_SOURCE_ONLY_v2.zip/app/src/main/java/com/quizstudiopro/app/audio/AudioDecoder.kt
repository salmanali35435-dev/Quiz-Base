package com.quizstudiopro.app.audio

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteOrder
import java.security.MessageDigest

object AudioDecoder {
    private const val TAG = "AudioDecoder"
    private const val DEFAULT_CHUNK_SHORTS = 8192
    private const val MAX_CACHE_ENTRIES = 48

    data class DecodedAudio(
        val pcm: ShortArray,
        val sampleRate: Int,
        val channels: Int,
        val durationSeconds: Float
    )

    /**
     * Zero-boxing primitive short accumulator backed by fixed-size [ShortArray] chunks
     * to avoid millions of boxed [java.lang.Short] allocations during MediaCodec decoding.
     */
    class PrimitiveShortBuffer(private val chunkSize: Int = DEFAULT_CHUNK_SHORTS) {
        private val chunks = ArrayList<ShortArray>()
        private var currentChunk = ShortArray(chunkSize)
        private var currentOffset = 0
        var size: Int = 0
            private set

        fun append(sample: Short) {
            if (currentOffset == chunkSize) {
                chunks.add(currentChunk)
                currentChunk = ShortArray(chunkSize)
                currentOffset = 0
            }
            currentChunk[currentOffset++] = sample
            size++
        }

        fun appendFromShortBuffer(src: java.nio.ShortBuffer) {
            while (src.hasRemaining()) {
                val space = chunkSize - currentOffset
                if (space == 0) {
                    chunks.add(currentChunk)
                    currentChunk = ShortArray(chunkSize)
                    currentOffset = 0
                }
                val toRead = minOf(src.remaining(), chunkSize - currentOffset)
                src.get(currentChunk, currentOffset, toRead)
                currentOffset += toRead
                size += toRead
            }
        }

        fun toShortArray(): ShortArray {
            val out = ShortArray(size)
            var pos = 0
            for (c in chunks) {
                System.arraycopy(c, 0, out, pos, c.size)
                pos += c.size
            }
            if (currentOffset > 0) {
                System.arraycopy(currentChunk, 0, out, pos, currentOffset)
            }
            return out
        }
    }

    private val decodedCacheLock = Any()
    private val decodedCache = object : LinkedHashMap<String, DecodedAudio>(MAX_CACHE_ENTRIES, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, DecodedAudio>?): Boolean {
            return size > MAX_CACHE_ENTRIES
        }
    }

    var cacheHits: Int = 0
        private set
    var cacheMisses: Int = 0
        private set

    fun clearCache() {
        synchronized(decodedCacheLock) {
            decodedCache.clear()
            cacheHits = 0
            cacheMisses = 0
        }
    }

    fun computeCacheKey(bytes: ByteArray, targetSampleRate: Int): String {
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(bytes)
        val hex = StringBuilder(digest.size * 2 + 8)
        for (b in digest) {
            hex.append(String.format("%02x", b))
        }
        hex.append(':').append(targetSampleRate)
        return hex.toString()
    }

    fun decodeMp3ToPcm(mp3Bytes: ByteArray, cacheDir: File, targetSampleRate: Int = 48000): DecodedAudio {
        if (mp3Bytes.isEmpty()) {
            throw IllegalArgumentException("Cannot decode empty MP3 byte array")
        }
        val key = computeCacheKey(mp3Bytes, targetSampleRate)
        synchronized(decodedCacheLock) {
            decodedCache[key]?.let {
                cacheHits++
                return it
            }
        }
        cacheMisses++
        val tempMp3 = File.createTempFile("edge_tts_decode_", ".mp3", cacheDir)
        val decoded = try {
            FileOutputStream(tempMp3).use { it.write(mp3Bytes) }
            decodeMp3File(tempMp3, targetSampleRate)
        } finally {
            tempMp3.delete()
        }
        synchronized(decodedCacheLock) {
            decodedCache[key] = decoded
        }
        return decoded
    }

    fun decodeMp3File(mp3File: File, targetSampleRate: Int = 48000): DecodedAudio {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(mp3File.absolutePath)
            var audioTrackIndex = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val trackFormat = extractor.getTrackFormat(i)
                val mime = trackFormat.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    format = trackFormat
                    break
                }
            }
            if (audioTrackIndex == -1 || format == null) {
                throw IllegalStateException("No audio track found in file ${mp3File.name}")
            }
            extractor.selectTrack(audioTrackIndex)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: "audio/mpeg"
            val srcSampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                val r = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                if (r > 0) r else 24000
            } else 24000
            val channelCount = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                val c = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                if (c in 1..32) c else 1
            } else 1

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            val pcmAccumulator = PrimitiveShortBuffer()
            val bufferInfo = MediaCodec.BufferInfo()
            var isInputEOS = false
            var isOutputEOS = false
            val timeoutUs = 10_000L

            while (!isOutputEOS) {
                if (!isInputEOS) {
                    val inIndex = codec.dequeueInputBuffer(timeoutUs)
                    if (inIndex >= 0) {
                        val inputBuffer = codec.getInputBuffer(inIndex)
                        if (inputBuffer != null) {
                            val sampleSize = extractor.readSampleData(inputBuffer, 0)
                            if (sampleSize < 0) {
                                codec.queueInputBuffer(inIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                isInputEOS = true
                            } else {
                                val sampleTime = extractor.sampleTime
                                codec.queueInputBuffer(inIndex, 0, sampleSize, sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                }
                val outIndex = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
                if (outIndex >= 0) {
                    val outputBuffer = codec.getOutputBuffer(outIndex)
                    if (outputBuffer != null && bufferInfo.size > 0) {
                        outputBuffer.position(bufferInfo.offset)
                        outputBuffer.limit(bufferInfo.offset + bufferInfo.size)
                        val shortBuffer = outputBuffer.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                        pcmAccumulator.appendFromShortBuffer(shortBuffer)
                    }
                    codec.releaseOutputBuffer(outIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        isOutputEOS = true
                    }
                }
            }
            val rawPcm = pcmAccumulator.toShortArray()
            val monoPcm = downmixToMono(rawPcm, channelCount)
            val finalPcm = if (srcSampleRate != targetSampleRate && srcSampleRate > 0) {
                resampleLinear(monoPcm, srcSampleRate, targetSampleRate)
            } else {
                monoPcm
            }
            val durationSec = finalPcm.size.toFloat() / targetSampleRate
            return DecodedAudio(
                pcm = finalPcm,
                sampleRate = targetSampleRate,
                channels = 1,
                durationSeconds = durationSec
            )
        } finally {
            try {
                codec?.stop()
                codec?.release()
                extractor.release()
            } catch (_: Exception) {}
        }
    }

    fun downmixToMono(rawPcm: ShortArray, channelCount: Int): ShortArray {
        if (channelCount <= 1) return rawPcm
        val monoSize = rawPcm.size / channelCount
        val mono = ShortArray(monoSize)
        for (i in 0 until monoSize) {
            var sum = 0
            val base = i * channelCount
            for (ch in 0 until channelCount) {
                sum += rawPcm[base + ch]
            }
            mono[i] = (sum / channelCount).toShort()
        }
        return mono
    }

    fun resampleLinear(input: ShortArray, inRate: Int, outRate: Int): ShortArray {
        if (input.isEmpty() || inRate <= 0 || outRate <= 0 || inRate == outRate) return input
        val outLength = ((input.size.toLong() * outRate) / inRate).toInt().coerceAtLeast(1)
        val output = ShortArray(outLength)
        val ratio = inRate.toDouble() / outRate.toDouble()
        val lastIdx = input.size - 1
        for (i in 0 until outLength) {
            val srcPos = i * ratio
            val srcIndex = srcPos.toInt().coerceIn(0, lastIdx)
            val nextIndex = if (srcIndex < lastIdx) srcIndex + 1 else lastIdx
            val frac = (srcPos - srcIndex).toFloat()
            val s0 = input[srcIndex].toFloat()
            val s1 = input[nextIndex].toFloat()
            val sample = s0 + frac * (s1 - s0)
            output[i] = sample.toInt().coerceIn(-32768, 32767).toShort()
        }
        return output
    }
}
