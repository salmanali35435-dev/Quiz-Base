package com.quizstudiopro.app.video

import android.graphics.Bitmap
import android.graphics.Color
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.opengl.GLUtils
import android.view.Surface
import com.quizstudiopro.app.logging.QuizLogger
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/**
 * OpenGL ES 2.0 + EGL14 Surface Renderer supporting:
 * - Zero-allocation reusable Bitmap / direct ByteBuffer `texSubImage2D` uploads
 * - Zero-upload repeated frame swaps (`swapRepeatedFrame`)
 * - Offscreen texture caching + FBO composition
 * - GLSL shader-accelerated Rounded-Rect Gradient Timer bar + Page/Slide/Fade/Wipe transitions
 */
class EglTextureRenderer(
    private val surface: Surface,
    private val width: Int,
    private val height: Int
) {
    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE

    private var blitProgram = 0
    private var aPositionHandle = 0
    private var aTextureCoordHandle = 0
    private var sTextureHandle = 0
    private var uAlphaHandle = 0

    // GLSL shader for sub-rect sprite overlay (e.g. timer digit badge or UI overlay)
    private var rectOverlayProgram = 0
    private var roPosHandle = 0
    private var roTexHandle = 0
    private var roRectHandle = 0
    private var roSamplerHandle = 0
    private var roAlphaHandle = 0

    // GLSL shader for SDF rounded-rect solid & vertical gradient (timer track + gradient fill)
    private var roundedGradientProgram = 0
    private var rgPosHandle = 0
    private var rgRectPxHandle = 0
    private var rgRadiusPxHandle = 0
    private var rgColorTopHandle = 0
    private var rgColorBottomHandle = 0
    private var rgResolutionHandle = 0

    // GLSL shader for GPU two-texture transitions (fade, slide, wipe, classic/reverse page-turn, center-split)
    private var transitionProgram = 0
    private var trPosHandle = 0
    private var trTexHandle = 0
    private var trPrevSamplerHandle = 0
    private var trNextSamplerHandle = 0
    private var trProgressHandle = 0
    private var trModeHandle = 0
    private var trPageBackColorHandle = 0

    private var primaryTextureId = 0
    private var textureStorageAllocated = false
    private val cachedTextures = HashMap<String, Int>()
    private val vertexBuffer: FloatBuffer
    private val textureBuffer: FloatBuffer

    private val quadVertices = floatArrayOf(
        -1.0f, -1.0f,
         1.0f, -1.0f,
        -1.0f,  1.0f,
         1.0f,  1.0f
    )

    private val textureCoords = floatArrayOf(
        0.0f, 1.0f,
        1.0f, 1.0f,
        0.0f, 0.0f,
        1.0f, 0.0f
    )

    private val unitTexCoords = floatArrayOf(
        0.0f, 1.0f,
        1.0f, 1.0f,
        0.0f, 0.0f,
        1.0f, 0.0f
    )
    private val unitTexBuffer: FloatBuffer

    init {
        vertexBuffer = ByteBuffer.allocateDirect(quadVertices.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .put(quadVertices)
        vertexBuffer.position(0)
        textureBuffer = ByteBuffer.allocateDirect(textureCoords.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .put(textureCoords)
        textureBuffer.position(0)
        unitTexBuffer = ByteBuffer.allocateDirect(unitTexCoords.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .put(unitTexCoords)
        unitTexBuffer.position(0)
        initEgl()
        EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)
        initGl()
    }

    private fun initEgl() {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (eglDisplay == EGL14.EGL_NO_DISPLAY) {
            throw RuntimeException("Unable to get EGL14 display")
        }
        val version = IntArray(2)
        if (!EGL14.eglInitialize(eglDisplay, version, 0, version, 1)) {
            throw RuntimeException("Unable to initialize EGL14")
        }
        val attribList = intArrayOf(
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGLExt.EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val numConfigs = IntArray(1)
        if (!EGL14.eglChooseConfig(eglDisplay, attribList, 0, configs, 0, 1, numConfigs, 0) || numConfigs[0] == 0) {
            throw RuntimeException("Unable to find suitable EGLConfig for MediaCodec surface")
        }
        val eglConfig = configs[0]
        val contextAttribs = intArrayOf(
            EGL14.EGL_CONTEXT_CLIENT_VERSION, 2,
            EGL14.EGL_NONE
        )
        eglContext = EGL14.eglCreateContext(eglDisplay, eglConfig, EGL14.EGL_NO_CONTEXT, contextAttribs, 0)
        if (eglContext == EGL14.EGL_NO_CONTEXT) {
            throw RuntimeException("Failed to create EGL2 context")
        }
        val surfaceAttribs = intArrayOf(EGL14.EGL_NONE)
        eglSurface = EGL14.eglCreateWindowSurface(eglDisplay, eglConfig, surface, surfaceAttribs, 0)
        if (eglSurface == EGL14.EGL_NO_SURFACE) {
            throw RuntimeException("Failed to create EGL window surface from MediaCodec surface")
        }
        if (!EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)) {
            throw RuntimeException("eglMakeCurrent failed")
        }
        QuizLogger.info("EglTextureRenderer", "EGL Context & Surface initialized ($width x $height)")
    }

    private fun initGl() {
        val blitVertex = """
            attribute vec4 aPosition;
            attribute vec2 aTextureCoord;
            varying vec2 vTextureCoord;
            void main() {
                gl_Position = aPosition;
                vTextureCoord = aTextureCoord;
            }
        """.trimIndent()
        val blitFragment = """
            precision mediump float;
            varying vec2 vTextureCoord;
            uniform sampler2D sTexture;
            uniform float uAlpha;
            void main() {
                vec4 c = texture2D(sTexture, vTextureCoord);
                gl_FragColor = vec4(c.rgb, c.a * uAlpha);
            }
        """.trimIndent()
        blitProgram = createProgram(blitVertex, blitFragment)
        aPositionHandle = GLES20.glGetAttribLocation(blitProgram, "aPosition")
        aTextureCoordHandle = GLES20.glGetAttribLocation(blitProgram, "aTextureCoord")
        sTextureHandle = GLES20.glGetUniformLocation(blitProgram, "sTexture")
        uAlphaHandle = GLES20.glGetUniformLocation(blitProgram, "uAlpha")

        val rectOverlayVertex = """
            attribute vec4 aPosition;
            attribute vec2 aTextureCoord;
            uniform vec4 uRectNdc; // (x0, y0, x1, y1) in NDC [-1..1]
            varying vec2 vTextureCoord;
            void main() {
                vec2 t = aPosition.xy * 0.5 + 0.5;
                vec2 pos = vec2(mix(uRectNdc.x, uRectNdc.z, t.x), mix(uRectNdc.y, uRectNdc.w, t.y));
                gl_Position = vec4(pos, 0.0, 1.0);
                vTextureCoord = aTextureCoord;
            }
        """.trimIndent()
        rectOverlayProgram = createProgram(rectOverlayVertex, blitFragment)
        roPosHandle = GLES20.glGetAttribLocation(rectOverlayProgram, "aPosition")
        roTexHandle = GLES20.glGetAttribLocation(rectOverlayProgram, "aTextureCoord")
        roRectHandle = GLES20.glGetUniformLocation(rectOverlayProgram, "uRectNdc")
        roSamplerHandle = GLES20.glGetUniformLocation(rectOverlayProgram, "sTexture")
        roAlphaHandle = GLES20.glGetUniformLocation(rectOverlayProgram, "uAlpha")

        val rgVertex = """
            attribute vec4 aPosition;
            void main() {
                gl_Position = aPosition;
            }
        """.trimIndent()
        val rgFragment = """
            precision highp float;
            uniform vec4 uRectPx;     // (left, top, right, bottom) in top-left pixels
            uniform float uRadiusPx;
            uniform vec4 uColorTop;
            uniform vec4 uColorBottom;
            uniform vec2 uResolution;
            void main() {
                vec2 px = vec2(gl_FragCoord.x, uResolution.y - gl_FragCoord.y);
                vec2 center = 0.5 * (uRectPx.xy + uRectPx.zw);
                vec2 halfSize = 0.5 * (uRectPx.zw - uRectPx.xy);
                vec2 q = abs(px - center) - (halfSize - vec2(uRadiusPx));
                float dist = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - uRadiusPx;
                float aa = 1.0 - smoothstep(-0.75, 0.75, dist);
                if (aa <= 0.001) discard;
                float t = clamp((px.y - uRectPx.y) / max(1.0, uRectPx.w - uRectPx.y), 0.0, 1.0);
                vec4 col = mix(uColorTop, uColorBottom, t);
                gl_FragColor = vec4(col.rgb, col.a * aa);
            }
        """.trimIndent()
        roundedGradientProgram = createProgram(rgVertex, rgFragment)
        rgPosHandle = GLES20.glGetAttribLocation(roundedGradientProgram, "aPosition")
        rgRectPxHandle = GLES20.glGetUniformLocation(roundedGradientProgram, "uRectPx")
        rgRadiusPxHandle = GLES20.glGetUniformLocation(roundedGradientProgram, "uRadiusPx")
        rgColorTopHandle = GLES20.glGetUniformLocation(roundedGradientProgram, "uColorTop")
        rgColorBottomHandle = GLES20.glGetUniformLocation(roundedGradientProgram, "uColorBottom")
        rgResolutionHandle = GLES20.glGetUniformLocation(roundedGradientProgram, "uResolution")

        val transitionFragment = """
            precision mediump float;
            varying vec2 vTextureCoord;
            uniform sampler2D sPrevTexture;
            uniform sampler2D sNextTexture;
            uniform float uProgress;
            uniform int uMode; // 0=fade, 1=slideLeft, 2=slideRight, 3=wipe, 4=classicPageTurn, 5=reversePageTurn, 6=centerSplit
            uniform vec3 uPageBackColor;
            void main() {
                float p = clamp(uProgress, 0.0, 1.0);
                float e = p < 0.5 ? 2.0 * p * p : 1.0 - pow(-2.0 * p + 2.0, 2.0) * 0.5;
                vec2 uv = vTextureCoord;
                vec4 nextCol = texture2D(sNextTexture, uv);
                if (uMode == 0) {
                    vec4 prevCol = texture2D(sPrevTexture, uv);
                    gl_FragColor = mix(prevCol, nextCol, e);
                } else if (uMode == 1) {
                    if (uv.x < 1.0 - e) {
                        gl_FragColor = texture2D(sPrevTexture, vec2(uv.x + e, uv.y));
                    } else {
                        gl_FragColor = nextCol;
                    }
                } else if (uMode == 2) {
                    if (uv.x > e) {
                        gl_FragColor = texture2D(sPrevTexture, vec2(uv.x - e, uv.y));
                    } else {
                        gl_FragColor = nextCol;
                    }
                } else if (uMode == 3) {
                    gl_FragColor = uv.x < e ? nextCol : texture2D(sPrevTexture, uv);
                } else if (uMode == 4) {
                    float pw = 1.0 - e;
                    if (uv.x <= pw && pw > 0.002) {
                        vec4 prevCol = texture2D(sPrevTexture, vec2(uv.x / pw, uv.y));
                        float backAlpha = p > 0.48 ? min(0.85, (p - 0.48) * 1.4) : 0.0;
                        float edgeShadow = smoothstep(max(0.0, pw - 0.06), pw, uv.x) * 0.35;
                        vec3 rgb = mix(prevCol.rgb, uPageBackColor, backAlpha) * (1.0 - edgeShadow);
                        gl_FragColor = vec4(rgb, 1.0);
                    } else {
                        float drop = smoothstep(pw + 0.05, pw, uv.x) * 0.30;
                        gl_FragColor = vec4(nextCol.rgb * (1.0 - drop), 1.0);
                    }
                } else if (uMode == 5) {
                    if (uv.x >= e && (1.0 - e) > 0.002) {
                        vec4 prevCol = texture2D(sPrevTexture, vec2((uv.x - e) / (1.0 - e), uv.y));
                        float backAlpha = p > 0.5 ? min(0.85, (p - 0.5) * 1.4) : 0.0;
                        gl_FragColor = vec4(mix(prevCol.rgb, uPageBackColor, backAlpha), 1.0);
                    } else {
                        gl_FragColor = nextCol;
                    }
                } else {
                    float halfW = 0.5 * (1.0 - e);
                    if (uv.x < halfW) {
                        gl_FragColor = texture2D(sPrevTexture, vec2(uv.x / max(0.002, halfW) * 0.5, uv.y));
                    } else if (uv.x > 1.0 - halfW) {
                        float t = (uv.x - (1.0 - halfW)) / max(0.002, halfW);
                        gl_FragColor = texture2D(sPrevTexture, vec2(0.5 + t * 0.5, uv.y));
                    } else {
                        gl_FragColor = nextCol;
                    }
                }
            }
        """.trimIndent()
        transitionProgram = createProgram(blitVertex, transitionFragment)
        trPosHandle = GLES20.glGetAttribLocation(transitionProgram, "aPosition")
        trTexHandle = GLES20.glGetAttribLocation(transitionProgram, "aTextureCoord")
        trPrevSamplerHandle = GLES20.glGetUniformLocation(transitionProgram, "sPrevTexture")
        trNextSamplerHandle = GLES20.glGetUniformLocation(transitionProgram, "sNextTexture")
        trProgressHandle = GLES20.glGetUniformLocation(transitionProgram, "uProgress")
        trModeHandle = GLES20.glGetUniformLocation(transitionProgram, "uMode")
        trPageBackColorHandle = GLES20.glGetUniformLocation(transitionProgram, "uPageBackColor")

        primaryTextureId = allocateRgbaTexture(width, height)
        GLES20.glViewport(0, 0, width, height)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
    }

    private fun allocateRgbaTexture(w: Int, h: Int): Int {
        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        val id = textures[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexImage2D(
            GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0,
            GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null
        )
        textureStorageAllocated = true
        return id
    }

    private fun createProgram(vert: String, frag: String): Int {
        val vs = loadShader(GLES20.GL_VERTEX_SHADER, vert)
        val fs = loadShader(GLES20.GL_FRAGMENT_SHADER, frag)
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, vs)
        GLES20.glAttachShader(p, fs)
        GLES20.glLinkProgram(p)
        GLES20.glDeleteShader(vs)
        GLES20.glDeleteShader(fs)
        return p
    }

    private fun loadShader(type: Int, shaderCode: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, shaderCode)
        GLES20.glCompileShader(shader)
        return shader
    }

    private fun blitTexture(texId: Int, alpha: Float = 1f) {
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texId)
        GLES20.glUseProgram(blitProgram)
        GLES20.glEnableVertexAttribArray(aPositionHandle)
        GLES20.glVertexAttribPointer(aPositionHandle, 2, GLES20.GL_FLOAT, false, 8, vertexBuffer)
        GLES20.glEnableVertexAttribArray(aTextureCoordHandle)
        GLES20.glVertexAttribPointer(aTextureCoordHandle, 2, GLES20.GL_FLOAT, false, 8, textureBuffer)
        GLES20.glUniform1i(sTextureHandle, 0)
        GLES20.glUniform1f(uAlphaHandle, alpha)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPositionHandle)
        GLES20.glDisableVertexAttribArray(aTextureCoordHandle)
    }

    private fun present(ptsNs: Long) {
        EGLExt.eglPresentationTimeANDROID(eglDisplay, eglSurface, ptsNs)
        EGL14.eglSwapBuffers(eglDisplay, eglSurface)
    }

    fun makeCurrent() {
        EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)
    }

    /**
     * Uploads a Bitmap once into a named cached GPU texture slot (replacing prior texture in slot without leak).
     */
    fun uploadCachedBitmap(cacheKey: String, bitmap: Bitmap): Int {
        makeCurrent()
        val existing = cachedTextures[cacheKey]
        val texId = if (existing != null && existing != 0) {
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, existing)
            GLUtils.texSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, bitmap)
            existing
        } else {
            val textures = IntArray(1)
            GLES20.glGenTextures(1, textures, 0)
            val id = textures[0]
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
            cachedTextures[cacheKey] = id
            id
        }
        return texId
    }

    fun hasCachedTexture(cacheKey: String): Boolean = cachedTextures.containsKey(cacheKey)

    fun getCachedTextureId(cacheKey: String): Int? = cachedTextures[cacheKey]

    fun uploadCachedBitmapIfAbsentId(cacheKey: String, bitmap: Bitmap): Int {
        return cachedTextures[cacheKey] ?: uploadCachedBitmap(cacheKey, bitmap)
    }

    fun drawCachedTexture(cacheKey: String, ptsNs: Long): Boolean {
        val texId = cachedTextures[cacheKey] ?: return false
        makeCurrent()
        blitTexture(texId, 1f)
        present(ptsNs)
        return true
    }

    /**
     * Zero-upload repeated presentation of the current GPU primary texture with a new PTS.
     */
    fun swapRepeatedFrame(ptsNs: Long) {
        makeCurrent()
        blitTexture(primaryTextureId, 1f)
        present(ptsNs)
    }

    /**
     * Composites a cached base GPU texture + GLSL SDF rounded gradient timer track/fill + optional
     * small cached digit badge texture completely on the GPU (zero full-frame CPU redraw/upload).
     */
    fun drawBaseTextureWithGpuTimer(
        baseTexId: Int,
        trackLeftPx: Float,
        trackTopPx: Float,
        trackRightPx: Float,
        trackBottomPx: Float,
        radiusPx: Float,
        fillFrac: Float,
        trackColorArgb: Int,
        gradTopArgb: Int,
        gradBottomArgb: Int,
        digitBadgeTexId: Int?,
        badgeLeftPx: Float,
        badgeTopPx: Float,
        badgeRightPx: Float,
        badgeBottomPx: Float,
        ptsNs: Long
    ) {
        makeCurrent()
        blitTexture(baseTexId, 1f)

        // Draw track rounded rect via SDF shader
        drawRoundedGradientRect(
            trackLeftPx, trackTopPx, trackRightPx, trackBottomPx,
            radiusPx, trackColorArgb, trackColorArgb
        )

        // Draw active countdown bar with gradient
        val clamped = fillFrac.coerceIn(0f, 1f)
        if (clamped > 0f) {
            val barW = trackRightPx - trackLeftPx
            val minW = (trackBottomPx - trackTopPx).coerceAtMost(barW)
            val fillRight = trackLeftPx + maxOf(minW, barW * clamped)
            drawRoundedGradientRect(
                trackLeftPx, trackTopPx, fillRight, trackBottomPx,
                radiusPx, gradTopArgb, gradBottomArgb
            )
        }

        // Draw small pre-uploaded countdown number sprite if provided
        if (digitBadgeTexId != null && digitBadgeTexId != 0) {
            drawSubRectTexture(digitBadgeTexId, badgeLeftPx, badgeTopPx, badgeRightPx, badgeBottomPx, 1f)
        }

        present(ptsNs)
    }

    /**
     * Composites a cached static base GPU texture + small premultiplied ARGB_8888 timer overlay
     * texture (supporting all 10 rich timer looks) directly on the GPU without re-rendering or
     * re-uploading the static background/header/question/options.
     */
    fun drawBaseWithOverlayTexture(
        baseTexId: Int,
        overlayTexId: Int,
        leftPx: Float,
        topPx: Float,
        rightPx: Float,
        bottomPx: Float,
        ptsNs: Long
    ) {
        makeCurrent()
        blitTexture(baseTexId, 1f)
        if (overlayTexId != 0 && rightPx > leftPx && bottomPx > topPx) {
            GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
            drawSubRectTexture(overlayTexId, leftPx, topPx, rightPx, bottomPx, 1f)
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        }
        present(ptsNs)
    }

    private fun drawRoundedGradientRect(
        left: Float,
        top: Float,
        right: Float,
        bottom: Float,
        radiusPx: Float,
        topColor: Int,
        bottomColor: Int
    ) {
        GLES20.glUseProgram(roundedGradientProgram)
        GLES20.glEnableVertexAttribArray(rgPosHandle)
        GLES20.glVertexAttribPointer(rgPosHandle, 2, GLES20.GL_FLOAT, false, 8, vertexBuffer)
        GLES20.glUniform4f(rgRectPxHandle, left, top, right, bottom)
        GLES20.glUniform1f(rgRadiusPxHandle, radiusPx)
        GLES20.glUniform4f(
            rgColorTopHandle,
            Color.red(topColor) / 255f,
            Color.green(topColor) / 255f,
            Color.blue(topColor) / 255f,
            Color.alpha(topColor) / 255f
        )
        GLES20.glUniform4f(
            rgColorBottomHandle,
            Color.red(bottomColor) / 255f,
            Color.green(bottomColor) / 255f,
            Color.blue(bottomColor) / 255f,
            Color.alpha(bottomColor) / 255f
        )
        GLES20.glUniform2f(rgResolutionHandle, width.toFloat(), height.toFloat())
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(rgPosHandle)
    }

    private fun drawSubRectTexture(texId: Int, leftPx: Float, topPx: Float, rightPx: Float, bottomPx: Float, alpha: Float) {
        val x0 = (leftPx / width) * 2f - 1f
        val x1 = (rightPx / width) * 2f - 1f
        val yTop = 1f - (topPx / height) * 2f
        val yBot = 1f - (bottomPx / height) * 2f
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texId)
        GLES20.glUseProgram(rectOverlayProgram)
        GLES20.glEnableVertexAttribArray(roPosHandle)
        GLES20.glVertexAttribPointer(roPosHandle, 2, GLES20.GL_FLOAT, false, 8, vertexBuffer)
        GLES20.glEnableVertexAttribArray(roTexHandle)
        GLES20.glVertexAttribPointer(roTexHandle, 2, GLES20.GL_FLOAT, false, 8, unitTexBuffer)
        GLES20.glUniform4f(roRectHandle, x0, yBot, x1, yTop)
        GLES20.glUniform1i(roSamplerHandle, 0)
        GLES20.glUniform1f(roAlphaHandle, alpha)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(roPosHandle)
        GLES20.glDisableVertexAttribArray(roTexHandle)
    }

    /**
     * Executes GPU two-texture page/question transitions directly in GLSL fragment shaders.
     */
    fun drawGpuTransition(
        prevTexId: Int,
        nextTexId: Int,
        progress: Float,
        modeCode: Int,
        pageBackColorArgb: Int,
        ptsNs: Long
    ) {
        makeCurrent()
        GLES20.glUseProgram(transitionProgram)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, prevTexId)
        GLES20.glUniform1i(trPrevSamplerHandle, 0)

        GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, nextTexId)
        GLES20.glUniform1i(trNextSamplerHandle, 1)

        GLES20.glUniform1f(trProgressHandle, progress.coerceIn(0f, 1f))
        GLES20.glUniform1i(trModeHandle, modeCode)
        GLES20.glUniform3f(
            trPageBackColorHandle,
            Color.red(pageBackColorArgb) / 255f,
            Color.green(pageBackColorArgb) / 255f,
            Color.blue(pageBackColorArgb) / 255f
        )

        GLES20.glEnableVertexAttribArray(trPosHandle)
        GLES20.glVertexAttribPointer(trPosHandle, 2, GLES20.GL_FLOAT, false, 8, vertexBuffer)
        GLES20.glEnableVertexAttribArray(trTexHandle)
        GLES20.glVertexAttribPointer(trTexHandle, 2, GLES20.GL_FLOAT, false, 8, textureBuffer)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(trPosHandle)
        GLES20.glDisableVertexAttribArray(trTexHandle)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        present(ptsNs)
    }

    /**
     * Uploads pixels from a single pre-allocated reusable ARGB_8888 Bitmap using texSubImage2D
     * so GPU texture memory is never reallocated per frame.
     */
    fun drawFrameReusableBitmap(bitmap: Bitmap, ptsNs: Long) {
        makeCurrent()
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, primaryTextureId)
        if (textureStorageAllocated && bitmap.width == width && bitmap.height == height) {
            GLUtils.texSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, bitmap)
        } else {
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
        }
        blitTexture(primaryTextureId, 1f)
        present(ptsNs)
    }

    fun drawFrame(bitmap: Bitmap, ptsNs: Long) {
        drawFrameReusableBitmap(bitmap, ptsNs)
    }

    fun drawFrameRgba(buffer: ByteBuffer, ptsNs: Long) {
        makeCurrent()
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, primaryTextureId)
        buffer.position(0)
        if (textureStorageAllocated) {
            GLES20.glTexSubImage2D(
                GLES20.GL_TEXTURE_2D, 0, 0, 0, width, height,
                GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buffer
            )
        } else {
            GLES20.glTexImage2D(
                GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, width, height, 0,
                GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buffer
            )
            textureStorageAllocated = true
        }
        blitTexture(primaryTextureId, 1f)
        present(ptsNs)
    }

    fun release() {
        if (eglDisplay != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)
            if (primaryTextureId != 0) {
                GLES20.glDeleteTextures(1, intArrayOf(primaryTextureId), 0)
                primaryTextureId = 0
            }
            if (cachedTextures.isNotEmpty()) {
                val ids = cachedTextures.values.toIntArray()
                GLES20.glDeleteTextures(ids.size, ids, 0)
                cachedTextures.clear()
            }
            if (blitProgram != 0) GLES20.glDeleteProgram(blitProgram)
            if (rectOverlayProgram != 0) GLES20.glDeleteProgram(rectOverlayProgram)
            if (roundedGradientProgram != 0) GLES20.glDeleteProgram(roundedGradientProgram)
            if (transitionProgram != 0) GLES20.glDeleteProgram(transitionProgram)
            blitProgram = 0
            rectOverlayProgram = 0
            roundedGradientProgram = 0
            transitionProgram = 0
            EGL14.eglMakeCurrent(eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(eglDisplay, eglSurface)
            if (eglContext != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(eglDisplay, eglContext)
            EGL14.eglReleaseThread()
            EGL14.eglTerminate(eglDisplay)
        }
        eglDisplay = EGL14.EGL_NO_DISPLAY
        eglContext = EGL14.EGL_NO_CONTEXT
        eglSurface = EGL14.EGL_NO_SURFACE
        textureStorageAllocated = false
    }
}
