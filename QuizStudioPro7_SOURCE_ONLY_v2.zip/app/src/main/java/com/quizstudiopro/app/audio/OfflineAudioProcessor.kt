package com.quizstudiopro.app.audio

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

/**
 * High-speed chunked offline audio reader & direct-ByteBuffer feeder for AAC MediaCodec.
 * Eliminates repeated per-chunk ByteArray copies and guarantees exact AAC presentation timestamps.
 */
class OfflineAudioProcessor(
    private val pcmFile: File,
    private val sampleRate: Int = 48000,
    private val channels: Int = 1,
    private val totalSamplesOverride: Long? = null
) {
    val totalSamples: Long = totalSamplesOverride ?: (if (pcmFile.exists()) pcmFile.length() / (2L * channels) else 0L)
    val expectedBytes: Long = totalSamples * 2L * channels
    val actualFileBytes: Long = if (pcmFile.exists()) pcmFile.length() else 0L
    private var raf: RandomAccessFile? = null
    private var channel: FileChannel? = null
    private var samplesFed: Long = 0L
    private var bytesReadTotal: Long = 0L

    fun open() {
        if (channel != null) return
        if (expectedBytes <= 0L) return
        if (!pcmFile.exists()) {
            throw IllegalStateException("PCM file missing: ${pcmFile.absolutePath} (expected $expectedBytes bytes)")
        }
        val len = pcmFile.length()
        if (len == 0L) {
            throw IllegalStateException("PCM file is empty (expected $expectedBytes bytes)")
        }
        val frameAlign = (2L * channels)
        if ((len % frameAlign) != 0L) {
            throw IllegalStateException("PCM file unaligned: $len bytes is not a multiple of $frameAlign")
        }
        if (len != expectedBytes) {
            throw IllegalStateException("PCM file size mismatch: expected=$expectedBytes bytes ($totalSamples samples), actual=$len bytes")
        }
        val r = RandomAccessFile(pcmFile, "r")
        raf = r
        channel = r.channel
    }

    /**
     * Reads directly from the PCM FileChannel into [target] MediaCodec input ByteBuffer without an
     * intermediate Java ByteArray allocation. Returns bytes read (-1 means valid EOF).
     * Throws IllegalStateException if the file terminates before [expectedBytes] have been read.
     */
    fun readNextChunkDirect(target: ByteBuffer): Int {
        val ch = channel ?: run {
            if (expectedBytes > 0L && bytesReadTotal < expectedBytes) {
                throw IllegalStateException("PCM channel not open (read $bytesReadTotal / $expectedBytes bytes)")
            }
            return -1
        }
        val remainingExpected = expectedBytes - bytesReadTotal
        if (remainingExpected <= 0L) {
            return -1
        }
        target.clear()
        val align = 2 * channels
        val maxAlignedBytes = (target.remaining() / align) * align
        if (maxAlignedBytes <= 0) return 0
        val cappedBytes = minOf(maxAlignedBytes.toLong(), remainingExpected).toInt()
        if (target.limit() > cappedBytes) {
            target.limit(target.position() + cappedBytes)
        }
        val bytesRead = ch.read(target)
        if (bytesRead > 0) {
            bytesReadTotal += bytesRead
            samplesFed += bytesRead / (2L * channels)
        } else if (bytesRead < 0 && bytesReadTotal < expectedBytes) {
            throw IllegalStateException("PCM truncated during read: fed $bytesReadTotal of $expectedBytes bytes ($samplesFed / $totalSamples samples)")
        }
        return bytesRead
    }

    fun currentPtsUs(): Long = (samplesFed * 1_000_000L) / sampleRate.toLong()

    fun isAtEnd(): Boolean = totalSamples > 0L && samplesFed >= totalSamples

    fun getSamplesFed(): Long = samplesFed

    fun getBytesReadTotal(): Long = bytesReadTotal

    fun verifyCompleteRead(): Boolean = bytesReadTotal == expectedBytes && samplesFed == totalSamples

    fun close() {
        try { channel?.close() } catch (_: Exception) {}
        try { raf?.close() } catch (_: Exception) {}
        channel = null
        raf = null
    }

    companion object {
        fun convertFloatToPcm16Le(src: FloatArray, dst: ByteBuffer) {
            dst.clear()
            dst.order(ByteOrder.LITTLE_ENDIAN)
            for (s in src) {
                val clamped = when {
                    s > 1f -> 1f
                    s < -1f -> -1f
                    else -> s
                }
                val shortVal = if (clamped < 0f) (clamped * 32768f).toInt() else (clamped * 32767f).toInt()
                dst.putShort(shortVal.coerceIn(-32768, 32767).toShort())
            }
            dst.flip()
        }
    }
}
