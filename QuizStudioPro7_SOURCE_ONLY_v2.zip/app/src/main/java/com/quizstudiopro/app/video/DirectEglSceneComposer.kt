package com.quizstudiopro.app.video

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/**
 * Direct GPU / OpenGL ES Scene Compositor combining:
 * - Static question-layer GPU texture caching (renders non-timer base layer once per question)
 * - GLSL rounded-rect gradient timer rendering for countdown segments (0 CPU full-frame redraws)
 * - GLSL two-texture transition rendering for page turns & slides (0 per-frame Bitmap compositing)
 * - Automatic safe fallback to reusable-Bitmap [NativeSceneRenderer] for progressive reveal
 *   or specialized transition effects.
 */
class DirectEglSceneComposer(
    private val context: Context,
    bundleJson: String,
    private val width: Int,
    private val height: Int,
    private val fps: Int
) {
    data class Metrics(
        var directGpuFrames: Int = 0,
        var bitmapUploadedFrames: Int = 0,
        var repeatedSwapFrames: Int = 0,
        var textureUploads: Int = 0,
        var cacheHits: Int = 0
    )

    private data class Segment(val type: String, val qIndex: Int, val start: Double, val dur: Double)

    val metrics = Metrics()

    private val root = JSONObject(bundleJson)
    private val scene = root.optJSONObject("scene") ?: JSONObject()
    private val transitionConfig = root.optJSONObject("transitionConfig") ?: JSONObject()

    private val segments: List<Segment> = buildList {
        val tl = root.optJSONObject("timeline") ?: JSONObject()
        val arr = tl.optJSONArray("segs") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val s = arr.optJSONObject(i) ?: continue
            add(Segment(s.optString("type", "voice"), s.optInt("i", 0), s.optDouble("start", 0.0), s.optDouble("dur", 1.0)))
        }
    }

    private val bitmapRenderer = NativeSceneRenderer(context, bundleJson, width, height, fps)
    private var reusableBitmap: Bitmap? = null
    private var timerOverlayBitmap: Bitmap? = null
    private var segCursor = 0

    private val hasVisibleTimer = bitmapRenderer.hasVisibleTimer()
    private val canUseGpuTimerOverlay = hasVisibleTimer && !bitmapRenderer.hasVisibleLayerOverTimer()
    private val timerOverlayBounds = if (canUseGpuTimerOverlay) bitmapRenderer.computeTimerOverlayBoundsPx() else android.graphics.Rect()
    private val pageBackColorArgb = parseColor(transitionConfig.optString("pageBackColor", "#f0ebe1"), Color.rgb(240, 235, 225))

    private fun parseColor(hex: String?, fallback: Int): Int {
        if (hex.isNullOrBlank()) return fallback
        return try {
            Color.parseColor(hex)
        } catch (_: Exception) {
            fallback
        }
    }

    private fun findSegment(gt: Double): Segment? {
        if (segments.isEmpty()) return null
        while (segCursor > 0 && gt < segments[segCursor].start) segCursor--
        while (segCursor < segments.size - 1 && gt >= segments[segCursor].start + segments[segCursor].dur) {
            segCursor++
        }
        return segments[segCursor]
    }

    private fun transitionStyleToShaderMode(style: String): Int? = when (style) {
        "fade", "crossfade" -> 0
        "slide-left", "push" -> 1
        "slide-right" -> 2
        "wipe" -> 3
        "classic-page-turn" -> 4
        "reverse-page-turn" -> 5
        "center-split" -> 6
        else -> null
    }

    private fun ensureBitmap(): Bitmap {
        val b = reusableBitmap
        if (b != null && !b.isRecycled) return b
        return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also { reusableBitmap = it }
    }

    private fun ensureTimerOverlayBitmap(w: Int, h: Int): Bitmap {
        val b = timerOverlayBitmap
        if (b != null && !b.isRecycled && b.width == w && b.height == h) return b
        try { b?.recycle() } catch (_: Exception) {}
        return Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { timerOverlayBitmap = it }
    }

    /**
     * Renders [frameIndex] directly via OpenGL ES shaders/FBOs when possible, falling back cleanly
     * to reusable-Bitmap upload only when needed, and skips redraw/upload when [reusePreviousRender]
     * is true.
     */
    fun renderAndPresentFrame(
        egl: EglTextureRenderer,
        frameIndex: Int,
        ptsNs: Long,
        reusePreviousRender: Boolean
    ) {
        if (reusePreviousRender) {
            egl.swapRepeatedFrame(ptsNs)
            metrics.repeatedSwapFrames++
            return
        }

        val safeFps = fps.coerceIn(10, 60)
        val gt = frameIndex.toDouble() / safeFps.toDouble()
        val seg = findSegment(gt)
        val lt = if (seg != null) max(0.0, gt - seg.start) else 0.0

        // Fast GPU Path 1: Page transitions via GLSL two-texture transition shader
        if (seg != null && seg.type == "page") {
            val style = transitionConfig.optString("style", "classic-page-turn")
            val shaderMode = transitionStyleToShaderMode(style)
            val prevQIdx = (seg.qIndex - 1).coerceAtLeast(0)
            val nextQIdx = seg.qIndex.coerceAtLeast(0)
            if (shaderMode != null) {
                val prevKey = "page_prev_$prevQIdx"
                val nextKey = "page_next_$nextQIdx"
                val bmp = ensureBitmap()
                val prevTexId = if (egl.hasCachedTexture(prevKey)) {
                    metrics.cacheHits++
                    egl.uploadCachedBitmapIfAbsentId(prevKey, bmp)
                } else {
                    bitmapRenderer.renderSettledQuestionForCache(prevQIdx, reveal = true, targetBitmap = bmp)
                    metrics.textureUploads++
                    egl.uploadCachedBitmap(prevKey, bmp)
                }
                val nextTexId = if (egl.hasCachedTexture(nextKey)) {
                    metrics.cacheHits++
                    egl.uploadCachedBitmapIfAbsentId(nextKey, bmp)
                } else {
                    bitmapRenderer.renderSettledQuestionForCache(nextQIdx, reveal = false, targetBitmap = bmp, voiceFracOverride = 0.0)
                    metrics.textureUploads++
                    egl.uploadCachedBitmap(nextKey, bmp)
                }
                val p = (lt / seg.dur.coerceAtLeast(0.001)).toFloat().coerceIn(0f, 1f)
                egl.drawGpuTransition(prevTexId, nextTexId, p, shaderMode, pageBackColorArgb, ptsNs)
                metrics.directGpuFrames++
                return
            }
        }

        // Fast GPU Path 2: Countdown timer frames via cached static question base texture + small 10-style timer overlay texture
        if (seg != null && seg.type == "count" && (!hasVisibleTimer || (canUseGpuTimerOverlay && timerOverlayBounds.width() > 0 && timerOverlayBounds.height() > 0))) {
            val baseKey = "q_base_${seg.qIndex}"
            val bmp = ensureBitmap()
            val baseTexId = if (egl.hasCachedTexture(baseKey)) {
                metrics.cacheHits++
                egl.uploadCachedBitmapIfAbsentId(baseKey, bmp)
            } else {
                // Render static question base once WITHOUT timer so cached layer never leaves stale timer artifacts underneath
                bitmapRenderer.renderSettledQuestionForCache(seg.qIndex, reveal = false, targetBitmap = bmp, hideTimer = true)
                metrics.textureUploads++
                egl.uploadCachedBitmap(baseKey, bmp)
            }

            if (!hasVisibleTimer) {
                egl.drawBaseWithOverlayTexture(baseTexId, 0, 0f, 0f, 0f, 0f, ptsNs)
                metrics.directGpuFrames++
                return
            }

            val rem = max(0.0, seg.dur - lt)
            val overlayBmp = ensureTimerOverlayBitmap(timerOverlayBounds.width(), timerOverlayBounds.height())
            bitmapRenderer.renderTimerOverlay(overlayBmp, timerOverlayBounds, rem)
            val overlayTexId = egl.uploadCachedBitmap("timer_overlay", overlayBmp)
            metrics.textureUploads++
            egl.drawBaseWithOverlayTexture(
                baseTexId = baseTexId,
                overlayTexId = overlayTexId,
                leftPx = timerOverlayBounds.left.toFloat(),
                topPx = timerOverlayBounds.top.toFloat(),
                rightPx = timerOverlayBounds.right.toFloat(),
                bottomPx = timerOverlayBounds.bottom.toFloat(),
                ptsNs = ptsNs
            )
            metrics.directGpuFrames++
            return
        }

        // Standard Reusable-Bitmap Path (used for unique voice word/char reveals, reveal keyframes, or timer under overlapping top layer)
        val bmp = ensureBitmap()
        bitmapRenderer.renderFrame(frameIndex, bmp)
        egl.drawFrameReusableBitmap(bmp, ptsNs)
        metrics.bitmapUploadedFrames++
        metrics.textureUploads++
    }

    /**
     * Renders [frameIndex] into a caller-supplied Bitmap for non-EGL CPU YUV420 ByteBuffer encoding.
     */
    fun renderBitmapFrame(frameIndex: Int, targetBitmap: Bitmap) {
        bitmapRenderer.renderFrame(frameIndex, targetBitmap)
        metrics.bitmapUploadedFrames++
    }

    fun recordRepeatedBitmapFrame() {
        metrics.repeatedSwapFrames++
    }

    fun release() {
        bitmapRenderer.release()
        try {
            reusableBitmap?.recycle()
        } catch (_: Exception) {}
        reusableBitmap = null
        try {
            timerOverlayBitmap?.recycle()
        } catch (_: Exception) {}
        timerOverlayBitmap = null
    }
}
