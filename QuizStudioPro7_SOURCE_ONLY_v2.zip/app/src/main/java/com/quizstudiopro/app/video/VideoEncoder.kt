package com.quizstudiopro.app.video

import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.view.Surface
import com.quizstudiopro.app.logging.QuizLogger
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer

object VideoEncoder {
    private const val TAG = "VideoEncoder"

    interface ProgressListener {
        fun onProgress(currentFrame: Int, totalFrames: Int, stage: String, explicitProgressPercent: Float? = null)
    }

    fun encodeVideo(
        outputFile: File,
        width: Int,
        height: Int,
        fps: Int,
        totalFrames: Int,
        frameProvider: (frameIndex: Int) -> Bitmap?,
        audioPcmFile: File? = null,
        totalAudioSamplesOverride: Long? = null,
        listener: ProgressListener? = null
    ): Boolean {
        var videoCodec: MediaCodec? = null
        var audioCodec: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var inputSurface: Surface? = null
        var eglRenderer: EglTextureRenderer? = null
        var audioFileInputStream: FileInputStream? = null

        val selectedFps = if (fps in 10..60) fps else 24

        var muxerStarted = false
        var muxerStopInvoked = false
        var videoTrackIndex = -1
        var audioTrackIndex = -1

        val pendingVideoBuffers = ArrayList<PendingSample>()
        val pendingAudioBuffers = ArrayList<PendingSample>()

        var videoEOSReceived = false
        var audioOutputEosReceived = false
        var audioEOSInputSent = false

        val hasAudio = (totalAudioSamplesOverride != null && totalAudioSamplesOverride > 0L) ||
            (audioPcmFile != null && audioPcmFile.exists() && audioPcmFile.length() > 0L)
        var totalPcmSamples = 0L
        var pcmSampleOffset = 0L

        var totalVideoFramesWritten = 0
        var totalAudioSamplesWritten = 0L
        var lastVideoPtsUs = -1L
        var lastAudioPtsUs = -1L

        return try {
            if (outputFile.exists()) {
                outputFile.delete()
            }

            // 1. Setup Video Codec via verified HardwareCodecSelector
            val codecSelection = HardwareCodecSelector.selectAndCreateEncoder(
                mimeType = MediaFormat.MIMETYPE_VIDEO_AVC,
                width = width,
                height = height,
                fps = selectedFps
            )
            videoCodec = codecSelection.codec
            val videoFormat = HardwareCodecSelector.configureVideoFormat(
                width = width,
                height = height,
                fps = selectedFps,
                candidate = codecSelection.candidate,
                gopSeconds = 2
            )
            videoCodec.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = videoCodec.createInputSurface()
            videoCodec.start()
            eglRenderer = EglTextureRenderer(inputSurface, width, height)

            // 2. Setup Audio Codec if PCM file present
            if (hasAudio) {
                audioFileInputStream = FileInputStream(audioPcmFile)
                totalPcmSamples = totalAudioSamplesOverride ?: (audioPcmFile?.length()?.div(2) ?: 0L)
                val audioFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, 48000, 1).apply {
                    setInteger(MediaFormat.KEY_BIT_RATE, 192000)
                    setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                    setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
                }
                audioCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
                audioCodec.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                audioCodec.start()
            }

            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            fun checkStartMuxer() {
                if (!muxerStarted && videoTrackIndex >= 0 && (!hasAudio || audioTrackIndex >= 0)) {
                    muxer?.start()
                    muxerStarted = true
                    val m = muxer ?: return

                    for (s in pendingVideoBuffers) {
                        m.writeSampleData(videoTrackIndex, s.data, s.info)
                    }
                    pendingVideoBuffers.clear()

                    for (s in pendingAudioBuffers) {
                        m.writeSampleData(audioTrackIndex, s.data, s.info)
                    }
                    pendingAudioBuffers.clear()
                }
            }

            fun feedAudioInput() {
                val ac = audioCodec ?: return
                val stream = audioFileInputStream ?: return
                if (audioEOSInputSent) return

                var inIndex = ac.dequeueInputBuffer(0)
                while (inIndex >= 0 && !audioEOSInputSent) {
                    val buf = ac.getInputBuffer(inIndex)
                    if (buf != null) {
                        buf.clear()
                        val bytesToRead = minOf(buf.capacity(), 4096)
                        val tempBytes = ByteArray(bytesToRead)
                        val readBytes = stream.read(tempBytes)

                        if (readBytes > 0) {
                            buf.put(tempBytes, 0, readBytes)
                            val samplesRead = readBytes / 2
                            val ptsUs = pcmSampleOffset * 1_000_000L / 48000L
                            ac.queueInputBuffer(inIndex, 0, readBytes, ptsUs, 0)
                            pcmSampleOffset += samplesRead
                        } else {
                            val ptsUs = pcmSampleOffset * 1_000_000L / 48000L
                            ac.queueInputBuffer(inIndex, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            audioEOSInputSent = true
                        }
                    }
                    if (!audioEOSInputSent) {
                        inIndex = ac.dequeueInputBuffer(0)
                    }
                }
            }

            fun drainAudioOutput() {
                val ac = audioCodec ?: return
                val audioBufferInfo = MediaCodec.BufferInfo()

                while (true) {
                    val outIndex = ac.dequeueOutputBuffer(audioBufferInfo, 0)
                    if (outIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        break
                    }
                    if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        if (audioTrackIndex < 0) {
                            val format = ac.outputFormat
                            val ch = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                                format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                            } else 1
                            val safeCh = if (ch in 1..32) ch else 1
                            format.setInteger(MediaFormat.KEY_CHANNEL_COUNT, safeCh)
                            audioTrackIndex = muxer?.addTrack(format) ?: -1
                            QuizLogger.info(TAG, "Audio output format configured: $format, audioTrackIndex=$audioTrackIndex, safeCh=$safeCh")
                            checkStartMuxer()
                        }
                        continue
                    }
                    if (outIndex < 0) {
                        continue
                    }

                    val encodedData = ac.getOutputBuffer(outIndex)
                    if (encodedData != null && audioBufferInfo.size > 0) {
                        if ((audioBufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                            audioBufferInfo.size = 0
                        }
                        if (audioBufferInfo.size > 0) {
                            val dupData = ByteBuffer.allocate(audioBufferInfo.size)
                            encodedData.position(audioBufferInfo.offset)
                            encodedData.limit(audioBufferInfo.offset + audioBufferInfo.size)
                            dupData.put(encodedData)
                            dupData.flip()

                            val copyInfo = MediaCodec.BufferInfo().apply {
                                set(0, audioBufferInfo.size, audioBufferInfo.presentationTimeUs, audioBufferInfo.flags)
                            }

                            if (muxerStarted && audioTrackIndex >= 0) {
                                muxer?.writeSampleData(audioTrackIndex, dupData, copyInfo)
                            } else {
                                pendingAudioBuffers.add(PendingSample(dupData, copyInfo))
                            }
                            totalAudioSamplesWritten++
                            lastAudioPtsUs = audioBufferInfo.presentationTimeUs
                        }
                    }
                    if ((audioBufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        audioOutputEosReceived = true
                    }
                    ac.releaseOutputBuffer(outIndex, false)
                }
            }

            fun drainVideoOutput() {
                val vc = videoCodec ?: return
                val videoBufferInfo = MediaCodec.BufferInfo()

                while (true) {
                    val outIndex = vc.dequeueOutputBuffer(videoBufferInfo, 0)
                    if (outIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        break
                    }
                    if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        if (videoTrackIndex < 0) {
                            videoTrackIndex = muxer?.addTrack(vc.outputFormat) ?: -1
                            QuizLogger.info(TAG, "Video output format configured: ${vc.outputFormat}, videoTrackIndex=$videoTrackIndex")
                            checkStartMuxer()
                        }
                        continue
                    }
                    if (outIndex < 0) {
                        continue
                    }

                    if ((videoBufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        videoEOSReceived = true
                    }
                    val encodedData = vc.getOutputBuffer(outIndex)
                    if (encodedData != null && videoBufferInfo.size > 0) {
                        if ((videoBufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                            videoBufferInfo.size = 0
                        }
                        if (videoBufferInfo.size > 0) {
                            val dupData = ByteBuffer.allocate(videoBufferInfo.size)
                            encodedData.position(videoBufferInfo.offset)
                            encodedData.limit(videoBufferInfo.offset + videoBufferInfo.size)
                            dupData.put(encodedData)
                            dupData.flip()

                            val copyInfo = MediaCodec.BufferInfo().apply {
                                set(0, videoBufferInfo.size, videoBufferInfo.presentationTimeUs, videoBufferInfo.flags)
                            }

                            if (muxerStarted && videoTrackIndex >= 0) {
                                muxer?.writeSampleData(videoTrackIndex, dupData, copyInfo)
                            } else {
                                pendingVideoBuffers.add(PendingSample(dupData, copyInfo))
                            }
                            totalVideoFramesWritten++
                            lastVideoPtsUs = videoBufferInfo.presentationTimeUs
                        }
                    }
                    vc.releaseOutputBuffer(outIndex, false)
                }
            }

            // 3. Main Frame Loop
            var frameIdx = 0
            while (frameIdx < totalFrames) {
                val bmp = frameProvider(frameIdx)
                if (bmp != null) {
                    val ptsNs = frameIdx.toLong() * 1_000_000_000L / selectedFps
                    eglRenderer?.drawFrame(bmp, ptsNs)
                    bmp.recycle()
                }
                drainVideoOutput()
                if (hasAudio) {
                    feedAudioInput()
                    drainAudioOutput()
                }
                frameIdx++
                if (frameIdx % 10 == 0 || frameIdx == totalFrames) {
                    val p = 25f + (frameIdx.toFloat() / totalFrames) * 65f
                    listener?.onProgress(frameIdx, totalFrames, "Rendering & encoding video frames ($frameIdx / $totalFrames)", p)
                }
            }

            // 4. Video EOS
            videoCodec.signalEndOfInputStream()

            // 5. Submit Audio EOS
            if (hasAudio && !audioEOSInputSent) {
                feedAudioInput()
            }

            // 6. Finalization Loop
            val startTime = System.currentTimeMillis()
            val deadline = startTime + 20_000L
            while ((!videoEOSReceived || (hasAudio && !audioOutputEosReceived)) && System.currentTimeMillis() < deadline) {
                drainVideoOutput()
                if (hasAudio && !audioOutputEosReceived) {
                    feedAudioInput()
                    drainAudioOutput()
                }
                if (!videoEOSReceived || (hasAudio && !audioOutputEosReceived)) {
                    Thread.sleep(10)
                }
            }

            if (!videoEOSReceived) {
                throw IllegalStateException("Video encoder finalization timeout: Video EOS flag not received.")
            }

            // 7. Finalize MediaMuxer
            if (muxerStarted && !muxerStopInvoked) {
                muxerStopInvoked = true
                try {
                    muxer?.stop()
                } catch (e: Exception) {
                    QuizLogger.warn(TAG, "Muxer stop warning: ${e.message}")
                }
            }
            true
        } catch (e: Exception) {
            QuizLogger.error(TAG, "Fatal error during video encoding: ${e.message}")
            false
        } finally {
            try { eglRenderer?.release() } catch (_: Exception) {}
            try { videoCodec?.stop() } catch (_: Exception) {}
            try { videoCodec?.release() } catch (_: Exception) {}
            try { audioCodec?.stop() } catch (_: Exception) {}
            try { audioCodec?.release() } catch (_: Exception) {}
            try { inputSurface?.release() } catch (_: Exception) {}
            try {
                if (muxerStarted && !muxerStopInvoked) {
                    muxerStopInvoked = true
                    muxer?.stop()
                }
            } catch (_: Exception) {}
            try { audioFileInputStream?.close() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
        }
    }

    data class Mp4IntegrityReport(
        val ok: Boolean,
        val videoTrackPresent: Boolean,
        val videoDurationMs: Long,
        val audioTrackPresent: Boolean,
        val audioSampleCount: Int,
        val audioDurationMs: Long,
        val firstAudioPtsUs: Long,
        val lastAudioPtsUs: Long,
        val mp4DurationMs: Long,
        val error: String? = null
    )

    fun evaluateAudioDurationIntegrity(
        expectedAudio: Boolean,
        expectedAudioDurationMs: Long,
        audioTrackPresent: Boolean,
        audioSampleCount: Int,
        actualAudioDurationMs: Long
    ): String? {
        if (!expectedAudio) return null
        if (!audioTrackPresent) {
            return "MP4 audio track missing (expected ${expectedAudioDurationMs}ms audio)"
        }
        if (audioSampleCount <= 0) {
            return "AAC output incomplete: 0 audio samples in MP4 (expected ${expectedAudioDurationMs}ms)"
        }
        // Documented AAC priming/frame rounding tolerance: max(600ms, 5% of expected duration)
        val toleranceMs = maxOf(600L, (expectedAudioDurationMs * 0.05).toLong())
        if (expectedAudioDurationMs > 1000L && actualAudioDurationMs + toleranceMs < expectedAudioDurationMs) {
            return "Audio duration mismatch: expected=${expectedAudioDurationMs}ms, actual=${actualAudioDurationMs}ms (tolerance=${toleranceMs}ms, samples=$audioSampleCount)"
        }
        return null
    }

    fun inspectMp4Integrity(
        file: File,
        expectedAudio: Boolean,
        expectedAudioDurationMs: Long
    ): Mp4IntegrityReport {
        if (!file.exists() || file.length() == 0L) {
            return Mp4IntegrityReport(
                ok = false, videoTrackPresent = false, videoDurationMs = 0L,
                audioTrackPresent = false, audioSampleCount = 0, audioDurationMs = 0L,
                firstAudioPtsUs = -1L, lastAudioPtsUs = -1L, mp4DurationMs = 0L,
                error = "MP4 output file missing or empty"
            )
        }
        val extractor = MediaExtractor()
        return try {
            extractor.setDataSource(file.absolutePath)
            var videoTrackIdx = -1
            var audioTrackIdx = -1
            var videoFormatDurUs = 0L
            var audioFormatDurUs = 0L

            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                val durUs = if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) else 0L
                if (mime.startsWith("video/") && videoTrackIdx < 0) {
                    videoTrackIdx = i
                    videoFormatDurUs = durUs
                } else if (mime.startsWith("audio/") && audioTrackIdx < 0) {
                    audioTrackIdx = i
                    audioFormatDurUs = durUs
                }
            }

            var audioSampleCount = 0
            var firstAudioPtsUs = -1L
            var lastAudioPtsUs = -1L
            if (audioTrackIdx >= 0) {
                extractor.selectTrack(audioTrackIdx)
                val buf = ByteBuffer.allocate(65536)
                while (true) {
                    val sampleSize = extractor.readSampleData(buf, 0)
                    if (sampleSize < 0) break
                    val ptsUs = extractor.sampleTime
                    if (firstAudioPtsUs < 0L) firstAudioPtsUs = ptsUs
                    if (ptsUs >= 0L) lastAudioPtsUs = ptsUs
                    audioSampleCount++
                    buf.clear()
                    if (!extractor.advance()) break
                }
            }

            val videoDurMs = videoFormatDurUs / 1000L
            val spanAudioDurUs = if (firstAudioPtsUs >= 0L && lastAudioPtsUs >= firstAudioPtsUs) {
                (lastAudioPtsUs - firstAudioPtsUs) + 21_333L
            } else 0L
            val audioDurMs = maxOf(audioFormatDurUs, spanAudioDurUs) / 1000L
            val mp4DurMs = maxOf(videoDurMs, audioDurMs)

            val err = if (videoTrackIdx < 0) {
                "MP4 video track missing"
            } else {
                evaluateAudioDurationIntegrity(
                    expectedAudio = expectedAudio,
                    expectedAudioDurationMs = expectedAudioDurationMs,
                    audioTrackPresent = audioTrackIdx >= 0,
                    audioSampleCount = audioSampleCount,
                    actualAudioDurationMs = audioDurMs
                )
            }

            Mp4IntegrityReport(
                ok = err == null,
                videoTrackPresent = videoTrackIdx >= 0,
                videoDurationMs = videoDurMs,
                audioTrackPresent = audioTrackIdx >= 0,
                audioSampleCount = audioSampleCount,
                audioDurationMs = audioDurMs,
                firstAudioPtsUs = firstAudioPtsUs,
                lastAudioPtsUs = lastAudioPtsUs,
                mp4DurationMs = mp4DurMs,
                error = err
            )
        } catch (e: Throwable) {
            Mp4IntegrityReport(
                ok = false, videoTrackPresent = false, videoDurationMs = 0L,
                audioTrackPresent = false, audioSampleCount = 0, audioDurationMs = 0L,
                firstAudioPtsUs = -1L, lastAudioPtsUs = -1L, mp4DurationMs = 0L,
                error = "MP4 inspection error: ${e.message}"
            )
        } finally {
            try { extractor.release() } catch (_: Exception) {}
        }
    }

    fun verifyMp4AudioTrack(file: File): Boolean {
        if (!file.exists() || file.length() == 0L) return false
        val extractor = MediaExtractor()
        return try {
            extractor.setDataSource(file.absolutePath)
            var hasAudio = false
            var sampleCount = 0
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                val duration = if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) else 0L
                if (mime.startsWith("audio/") && duration > 0) {
                    hasAudio = true
                    extractor.selectTrack(i)
                    val buf = ByteBuffer.allocate(65536)
                    while (extractor.readSampleData(buf, 0) >= 0) {
                        sampleCount++
                        buf.clear()
                        if (!extractor.advance()) break
                    }
                    break
                }
            }
            hasAudio && sampleCount > 0
        } catch (_: Exception) {
            false
        } finally {
            try { extractor.release() } catch (_: Exception) {}
        }
    }

    data class PendingSample(
        val data: ByteBuffer,
        val info: MediaCodec.BufferInfo
    )
}
