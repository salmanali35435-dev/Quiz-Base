package com.quizstudiopro.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebMessagePortCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.quizstudiopro.app.audio.PcmTransferCoordinator
import com.quizstudiopro.app.audio.VoiceEngine
import com.quizstudiopro.app.logging.QuizLogger
import com.quizstudiopro.app.service.QuizEncodingService
import com.quizstudiopro.app.storage.MediaStoreVideoStorage
import com.quizstudiopro.app.storage.RecentVideosStore
import com.quizstudiopro.app.video.DirectEglSceneComposer
import com.quizstudiopro.app.video.HardwareCodecSelector
import com.quizstudiopro.app.video.IntelligentFrameScheduler
import com.quizstudiopro.app.video.NativeSceneRenderer
import com.quizstudiopro.app.video.StreamingVideoEncoderSession
import com.quizstudiopro.app.video.VideoEncoder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private var pendingFileCallback: ValueCallback<Array<Uri>>? = null
    private var output: OutputStream? = null
    private var pendingUri: Uri? = null
    private var pendingName: String = "quiz-video.mp4"
    private var saveChunkTempFile: File? = null
    private var lastSavedUri: Uri? = null
    private var lastPreviewUrl: String? = null
    private var lastSaveErrorMessage: String? = null
    private val pickFileRequest = 4102

    private val activityScope = CoroutineScope(Dispatchers.Main)
    private val asyncTtsScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val asyncTtsJobs = ConcurrentHashMap<String, Job>()

    // Export Session variables
    private var exportWidth = 1280
    private var exportHeight = 720
    private var exportFps = 24
    private var exportTotalFrames = 0
    private var exportTotalAudioSamples = 0L
    private var pcmTempFile: File? = null
    private val pcmCoordinator = PcmTransferCoordinator()
    private val sessionTokenCounter = AtomicInteger(1)
    private var activeExportSessionId: String = ""
    private var activeSessionToken: Int = 0
    private var streamingSession: StreamingVideoEncoderSession? = null
    private var nativeSceneRenderer: NativeSceneRenderer? = null
    private var directSceneComposer: DirectEglSceneComposer? = null
    private var currentExportOutputFile: File? = null
    private var nativeSessionMode: StreamingVideoEncoderSession.Mode = StreamingVideoEncoderSession.Mode.COMPATIBILITY_FALLBACK
    private var pendingSceneBundleJson: String? = null

    @Volatile private var asyncExportState: String = "idle"
    @Volatile private var asyncExportProgressPct: Int = 25
    @Volatile private var asyncExportStageMsg: String = ""
    @Volatile private var asyncExportResultJson: String? = null
    @Volatile private var asyncExportThread: Thread? = null

    // Binary WebMessage channel (Phase 2 zero-Base64/zero-JPEG transfer)
    private var nativeBinaryPort: WebMessagePortCompat? = null
    private var binaryPortThread: HandlerThread? = null
    private var binaryPortHandler: Handler? = null

    // Canva OAuth callback cache
    private var pendingCanvaCallbackJson: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binaryPortThread = HandlerThread("QspBinaryPort").apply { start() }
        binaryPortHandler = Handler(binaryPortThread!!.looper)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        captureCanvaIntent(intent)

        // Clean any legacy duplicate preview cache files left from older builds
        try { File(cacheDir, "exported_preview").deleteRecursively() } catch (_: Exception) {}

        // Restore latest verified export so Open / Share / Recent History survive app restarts
        RecentVideosStore.latestVerified(this)?.let { latest ->
            lastSavedUri = Uri.parse(latest.uri)
            lastPreviewUrl = latest.previewUrl()
        }

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/exported/", WebViewAssetLoader.PathHandler { path ->
                val rawFileName = Uri.decode(path.substringAfterLast('/'))
                val targetUri = RecentVideosStore.findAuthorizedUri(this, null, rawFileName) ?: lastSavedUri
                if (targetUri != null) serveContentUriRange(targetUri, null) else null
            })
            .build()

        webView = WebView(this)
        webView.setBackgroundColor(android.graphics.Color.rgb(10, 10, 12))
        ViewCompat.setOnApplyWindowInsetsListener(webView) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            mediaPlaybackRequiresUserGesture = true
            loadsImagesAutomatically = true
            builtInZoomControls = false
            displayZoomControls = false
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }

        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val url = request?.url ?: return null
                val path = url.path ?: ""
                if (path.startsWith("/exported/")) {
                    val rawFileName = Uri.decode(path.removePrefix("/exported/"))
                    val requestedUri = url.getQueryParameter("uri")
                    val targetUri = RecentVideosStore.findAuthorizedUri(this@MainActivity, requestedUri, rawFileName)
                        ?: lastSavedUri?.takeIf { requestedUri.isNullOrBlank() || it.toString() == requestedUri }
                    if (targetUri != null) {
                        serveContentUriRange(targetUri, request.requestHeaders["Range"])?.let { return it }
                    }
                    return WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", null, ByteArrayInputStream(ByteArray(0)))
                }
                if (path.startsWith("/assets/")) {
                    val assetPath = path.removePrefix("/assets/")
                    try {
                        assets.open(assetPath).close()
                    } catch (_: Exception) {
                        return WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", null, ByteArrayInputStream(ByteArray(0)))
                    }
                }
                return assetLoader.shouldInterceptRequest(url)
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url ?: return true
                if (url.scheme == "quizstudiopro") {
                    captureCanvaUri(url)
                    return true
                }
                val host = url.host ?: return true
                return host != "appassets.androidplatform.net"
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                setupBinaryWebMessageChannel()
                flushPendingCanvaCallback()
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                pendingFileCallback?.onReceiveValue(null)
                pendingFileCallback = filePathCallback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(
                        Intent.EXTRA_MIME_TYPES,
                        arrayOf("audio/*", "image/*", "video/*", "application/json", "text/csv", "text/plain")
                    )
                }
                return try {
                    startActivityForResult(intent, pickFileRequest)
                    true
                } catch (_: Exception) {
                    pendingFileCallback?.onReceiveValue(null)
                    pendingFileCallback = null
                    false
                }
            }
        }
        setContentView(webView)
        webView.loadUrl("https://appassets.androidplatform.net/assets/www/login.html")
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        captureCanvaIntent(intent)
        flushPendingCanvaCallback()
    }

    private fun captureCanvaIntent(intent: Intent?) {
        val data = intent?.data ?: return
        if (data.scheme == "quizstudiopro" && data.host == "canva") {
            captureCanvaUri(data)
        }
    }

    private fun captureCanvaUri(uri: Uri) {
        val payload = JSONObject().apply {
            put("code", uri.getQueryParameter("code") ?: "")
            put("state", uri.getQueryParameter("state") ?: "")
            put("error", uri.getQueryParameter("error") ?: "")
            put("errorDescription", uri.getQueryParameter("error_description") ?: "")
        }.toString()
        pendingCanvaCallbackJson = payload
    }

    private fun flushPendingCanvaCallback() {
        val payload = pendingCanvaCallbackJson ?: return
        if (!::webView.isInitialized) return
        webView.post {
            webView.evaluateJavascript(
                "window.onCanvaAuthCallback && window.onCanvaAuthCallback($payload)",
                null
            )
            pendingCanvaCallbackJson = null
        }
    }

    private fun setupBinaryWebMessageChannel() {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.CREATE_WEB_MESSAGE_CHANNEL)) return
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_ARRAY_BUFFER)) return
        try {
            val channel = WebViewCompat.createWebMessageChannel(webView)
            nativeBinaryPort?.close()
            nativeBinaryPort = channel[0]
            val callback = object : WebMessagePortCompat.WebMessageCallbackCompat() {
                override fun onMessage(port: WebMessagePortCompat, message: WebMessageCompat?) {
                    if (message != null && message.type == WebMessageCompat.TYPE_ARRAY_BUFFER) {
                        handleBinaryWebMessage(port, message.arrayBuffer)
                    }
                }
            }
            val handler = binaryPortHandler
            if (handler != null) {
                channel[0].setWebMessageCallback(handler, callback)
            } else {
                channel[0].setWebMessageCallback(callback)
            }
            WebViewCompat.postWebMessage(
                webView,
                WebMessageCompat("__QSP_BINARY_PORT__", arrayOf(channel[1])),
                Uri.parse("https://appassets.androidplatform.net")
            )
            QuizLogger.info("AndroidBridge", "Binary WebMessage ArrayBuffer channel ready (off-UI handler=${handler != null})")
        } catch (e: Exception) {
            QuizLogger.warn("AndroidBridge", "Binary WebMessage setup skipped: ${e.message}")
        }
    }

    /**
     * Binary packet framing from JS ArrayBuffer:
     * - "PCM1" (32B header + payload): tracked, session-isolated PCM16 chunk with delivery ACK back over port
     * - "PCMD" (32B header): explicit PCM transfer completion verification request with PCM_COMPLETE_ACK
     * - "PCM0" (8B header + payload): legacy untracked PCM16 chunk (guarded against closed streams)
     * - "RGBA" (8B header + payload): video frame pixel buffer
     */
    private fun handleBinaryWebMessage(port: WebMessagePortCompat?, bytes: ByteArray) {
        if (bytes.size < 8) return
        val m0 = bytes[0].toInt().toChar()
        val m1 = bytes[1].toInt().toChar()
        val m2 = bytes[2].toInt().toChar()
        val m3 = bytes[3].toInt().toChar()
        val tag = "$m0$m1$m2$m3"
        when (tag) {
            PcmTransferCoordinator.MAGIC_PCM1 -> {
                val acks = pcmCoordinator.handlePcm1Packet(bytes)
                for (ack in acks) {
                    sendPortJson(port, ack.toJsonString())
                }
            }
            PcmTransferCoordinator.MAGIC_PCMD -> {
                val res = pcmCoordinator.handlePcmdPacket(bytes)
                sendPortJson(port, res.toJsonString())
            }
            PcmTransferCoordinator.MAGIC_PCM0 -> {
                val payload = bytes.copyOfRange(8, bytes.size)
                pcmCoordinator.handleLegacyPcm0Packet(payload)
            }
            PcmTransferCoordinator.MAGIC_RGBA -> {
                val payload = bytes.copyOfRange(8, bytes.size)
                val frameIdx = ByteBuffer.wrap(bytes, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
                val session = streamingSession ?: return
                session.submitFrameRaw(frameIdx, payload, isRgba = true)
            }
        }
    }

    private fun sendPortJson(port: WebMessagePortCompat?, json: String) {
        val p = port ?: nativeBinaryPort ?: return
        try {
            p.postMessage(WebMessageCompat(json))
        } catch (e: Exception) {
            QuizLogger.warn("AndroidBridge", "WebMessage ACK post failed: ${e.message}")
        }
    }

    private fun serveContentUriRange(uri: Uri, rangeHeader: String?): WebResourceResponse? {
        return try {
            val afd = contentResolver.openAssetFileDescriptor(uri, "r")
            val totalLen = afd?.length?.takeIf { it > 0L } ?: -1L
            val rawStream: InputStream = afd?.createInputStream() ?: contentResolver.openInputStream(uri) ?: return null

            if (rangeHeader != null && rangeHeader.startsWith("bytes=") && totalLen > 0L) {
                val parts = rangeHeader.removePrefix("bytes=").split("-")
                val start = (parts.getOrNull(0)?.toLongOrNull() ?: 0L).coerceIn(0L, totalLen - 1)
                val requestedEnd = parts.getOrNull(1)?.toLongOrNull() ?: (totalLen - 1)
                val end = requestedEnd.coerceIn(start, totalLen - 1)
                val contentLen = (end - start + 1).coerceAtLeast(0L)

                var skipped = 0L
                while (skipped < start) {
                    val step = rawStream.skip(start - skipped)
                    if (step <= 0L) {
                        if (rawStream.read() < 0) break
                        skipped++
                    } else {
                        skipped += step
                    }
                }

                val boundedStream = object : InputStream() {
                    private var remaining = contentLen
                    override fun read(): Int {
                        if (remaining <= 0L) return -1
                        val b = rawStream.read()
                        if (b >= 0) remaining--
                        return b
                    }
                    override fun read(b: ByteArray, off: Int, len: Int): Int {
                        if (remaining <= 0L) return -1
                        val toRead = minOf(len.toLong(), remaining).toInt()
                        val r = rawStream.read(b, off, toRead)
                        if (r > 0) remaining -= r
                        return r
                    }
                    override fun close() {
                        try { rawStream.close() } catch (_: Exception) {}
                        try { afd?.close() } catch (_: Exception) {}
                    }
                }

                val headers = mapOf(
                    "Accept-Ranges" to "bytes",
                    "Content-Range" to "bytes $start-$end/$totalLen",
                    "Content-Length" to contentLen.toString()
                )
                return WebResourceResponse("video/mp4", null, 206, "Partial Content", headers, boundedStream)
            }

            val fullStream = object : InputStream() {
                override fun read(): Int = rawStream.read()
                override fun read(b: ByteArray, off: Int, len: Int): Int = rawStream.read(b, off, len)
                override fun close() {
                    try { rawStream.close() } catch (_: Exception) {}
                    try { afd?.close() } catch (_: Exception) {}
                }
            }
            val headers = HashMap<String, String>().apply {
                put("Accept-Ranges", "bytes")
                if (totalLen > 0L) put("Content-Length", totalLen.toString())
            }
            WebResourceResponse("video/mp4", null, 200, "OK", headers, fullStream)
        } catch (e: Throwable) {
            QuizLogger.warn("PreviewStream", "Failed serving preview from $uri: ${e.message}")
            null
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun deviceId(): String = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown-device"

        @JavascriptInterface
        fun deviceName(): String = "${Build.MANUFACTURER} ${Build.MODEL}".trim()

        @JavascriptInterface
        fun getCapabilities(): String {
            return JSONObject().apply {
                put("supportsNativeSceneDirect", true)
                put("supportsDirectEglComposer", true)
                put("supportsFrameDeduplication", true)
                put("supportsBinaryArrayBuffer", WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_ARRAY_BUFFER))
                put("supportsCompatJpegFallback", true)
                put("sdkInt", Build.VERSION.SDK_INT)
                put("hardwareVideoReport", HardwareCodecSelector.getCapabilityReportJson(1920, 1080, 24))
            }.toString()
        }

        @JavascriptInterface
        fun setKeepScreenOn(enabled: Boolean) {
            runOnUiThread {
                if (enabled) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        @JavascriptInterface
        fun notifyExportStarted(status: String) {
            QuizEncodingService.start(this@MainActivity, status)
        }

        @JavascriptInterface
        fun notifyExportProgress(progress: Int, status: String) {
            QuizEncodingService.updateProgress(this@MainActivity, progress, status)
        }

        @JavascriptInterface
        fun notifyExportCompleted(message: String) {
            QuizEncodingService.notifyComplete(this@MainActivity, message)
        }

        @JavascriptInterface
        fun notifyExportFailed(error: String) {
            QuizEncodingService.notifyFailed(this@MainActivity, error)
        }

        // --- Edge TTS Bridge APIs ---
        @JavascriptInterface
        fun fetchVoiceInventory(): String = fetchVoiceInventory(false)

        @JavascriptInterface
        fun fetchVoiceInventory(forceRefresh: Boolean): String {
            return try {
                runBlocking(Dispatchers.IO) {
                    val res = VoiceEngine.fetchVoiceInventoryResult(this@MainActivity, forceRefresh)
                    val jsonArray = JSONArray()
                    for (v in res.voices) {
                        val obj = JSONObject().apply {
                            put("shortName", v.shortName)
                            put("friendlyName", v.friendlyName)
                            put("locale", v.locale)
                            put("language", v.language)
                            put("gender", v.gender)
                            put("isOfflineCached", v.isOfflineCached)
                        }
                        jsonArray.put(obj)
                    }
                    JSONObject().apply {
                        put("ok", res.voices.isNotEmpty())
                        put("isLive", res.isLive)
                        put("error", res.error ?: "")
                        put("voices", jsonArray)
                    }.toString()
                }
            } catch (e: Exception) {
                QuizLogger.error("AndroidBridge", "fetchVoiceInventory error: ${e.message}")
                JSONObject().apply {
                    put("ok", false)
                    put("isLive", false)
                    put("error", e.message ?: "Failed to fetch voices")
                    put("voices", JSONArray())
                }.toString()
            }
        }

        @JavascriptInterface
        fun synthesizeSpeech(text: String, voiceShortName: String, speedPercent: Int): String {
            return try {
                runBlocking(Dispatchers.IO) {
                    val res = VoiceEngine.synthesizeToMp3WithTimings(this@MainActivity, text, voiceShortName, speedPercent)
                    val b64 = Base64.encodeToString(res.mp3Bytes, Base64.NO_WRAP)
                    val wbArr = JSONArray()
                    for (wb in res.wordBoundaries) {
                        wbArr.put(JSONObject().apply {
                            put("text", wb.text)
                            put("offsetMs", wb.offsetMs)
                            put("durationMs", wb.durationMs)
                        })
                    }
                    JSONObject().apply {
                        put("ok", true)
                        put("mp3Base64", "data:audio/mp3;base64,$b64")
                        put("wordBoundaries", wbArr)
                    }.toString()
                }
            } catch (e: Exception) {
                QuizLogger.error("AndroidBridge", "synthesizeSpeech error: ${e.message}")
                JSONObject().apply {
                    put("ok", false)
                    put("error", e.message ?: "Edge TTS synthesis failed")
                }.toString()
            }
        }

        @JavascriptInterface
        fun synthesizeSpeechAsync(requestId: String, text: String, voiceShortName: String, speedPercent: Int) {
            asyncTtsJobs.remove(requestId)?.cancel()
            val job = asyncTtsScope.launch {
                val payload = try {
                    val res = VoiceEngine.synthesizeToMp3WithTimings(this@MainActivity, text, voiceShortName, speedPercent)
                    val b64 = Base64.encodeToString(res.mp3Bytes, Base64.NO_WRAP)
                    val wbArr = JSONArray()
                    for (wb in res.wordBoundaries) {
                        wbArr.put(JSONObject().apply {
                            put("text", wb.text)
                            put("offsetMs", wb.offsetMs)
                            put("durationMs", wb.durationMs)
                        })
                    }
                    JSONObject().apply {
                        put("ok", true)
                        put("requestId", requestId)
                        put("mp3Base64", "data:audio/mp3;base64,$b64")
                        put("wordBoundaries", wbArr)
                    }.toString()
                } catch (_: CancellationException) {
                    JSONObject().apply {
                        put("ok", false)
                        put("cancelled", true)
                        put("requestId", requestId)
                        put("error", "Speech generation cancelled")
                    }.toString()
                } catch (e: Throwable) {
                    QuizLogger.error("AndroidBridge", "synthesizeSpeechAsync error ($requestId): ${e.message}")
                    JSONObject().apply {
                        put("ok", false)
                        put("requestId", requestId)
                        put("error", e.message ?: "Edge TTS synthesis failed")
                    }.toString()
                } finally {
                    asyncTtsJobs.remove(requestId)
                }

                if (::webView.isInitialized && !isDestroyed && !isFinishing) {
                    runOnUiThread {
                        if (::webView.isInitialized) {
                            webView.evaluateJavascript(
                                "window.__onNativeTtsResult && window.__onNativeTtsResult(${JSONObject.quote(requestId)}, ${JSONObject.quote(payload)})",
                                null
                            )
                        }
                    }
                }
            }
            asyncTtsJobs[requestId] = job
        }

        @JavascriptInterface
        fun cancelSpeechRequests() {
            val keys = asyncTtsJobs.keys.toList()
            for (k in keys) {
                asyncTtsJobs.remove(k)?.cancel()
            }
        }

        @JavascriptInterface
        fun playPreviewAudio(text: String, voiceShortName: String, speedPercent: Int) {
            activityScope.launch {
                try {
                    runOnUiThread {
                        webView.evaluateJavascript("window.onQuizLog && window.onQuizLog('Edge TTS connection started for voice $voiceShortName', 'info')", null)
                    }
                    VoiceEngine.playPreviewAudio(this@MainActivity, text, voiceShortName, speedPercent) {
                        runOnUiThread {
                            webView.evaluateJavascript("window.onPreviewFinished && window.onPreviewFinished()", null)
                        }
                    }
                    runOnUiThread {
                        webView.evaluateJavascript("window.onQuizLog && window.onQuizLog('Audio decoding completed. Playing preview.', 'success')", null)
                    }
                } catch (e: Exception) {
                    val err = e.message ?: "Voice preview error"
                    QuizLogger.error("AndroidBridge", "Voice preview failed: $err")
                    runOnUiThread {
                        webView.evaluateJavascript("window.onQuizLog && window.onQuizLog('Voice preview failed: $err', 'error')", null)
                        webView.evaluateJavascript("window.onPreviewError && window.onPreviewError(${JSONObject.quote(err)})", null)
                        toast("Voice preview error: $err")
                    }
                }
            }
        }

        @JavascriptInterface
        fun stopPlayback() {
            VoiceEngine.stopPlayback()
        }

        @JavascriptInterface
        fun logLiveEvent(event: String, type: String) {
            QuizLogger.info("LiveEvent", event)
            runOnUiThread {
                webView.evaluateJavascript("window.onQuizLog && window.onQuizLog(${JSONObject.quote(event)}, ${JSONObject.quote(type)})", null)
            }
        }

        // --- Phase 2 Fast Native Scene Direct Path (ZERO per-frame bridge pixels, ZERO JPEG, ZERO Base64) ---
        @JavascriptInterface
        fun prepareNativeSceneExport(width: Int, height: Int, fps: Int, totalFrames: Int, totalAudioSamples: Long, sceneBundleJson: String): Boolean {
            return try {
                cleanupExportTemp()
                exportWidth = width
                exportHeight = height
                exportFps = fps
                exportTotalFrames = totalFrames
                exportTotalAudioSamples = totalAudioSamples
                nativeSessionMode = StreamingVideoEncoderSession.Mode.NATIVE_SCENE_DIRECT
                pendingSceneBundleJson = sceneBundleJson

                val token = sessionTokenCounter.incrementAndGet()
                val sessionId = "qsp_${System.currentTimeMillis()}_$token"
                activeSessionToken = token
                activeExportSessionId = sessionId

                val cacheDirTemp = File(cacheDir, "export_pcm_temp").apply { mkdirs() }
                val pcmFile = File(cacheDirTemp, "audio_track_${token}_${System.currentTimeMillis()}.pcm")
                pcmTempFile = pcmFile
                pcmCoordinator.prepareSession(sessionId, token, pcmFile, totalAudioSamples)

                val safeName = "quiz_export_${token}_${System.currentTimeMillis()}.mp4"
                currentExportOutputFile = File(cacheDirTemp, safeName)
                QuizEncodingService.start(this@MainActivity, "Preparing Native Direct Scene MP4 ($width x $height @ ${fps}fps)...")
                QuizLogger.info("QuizStudioPro-Encoder", "NATIVE_SCENE_DIRECT prepared session=$sessionId token=$token: ${width}x${height} @ ${fps}fps ($totalFrames frames, expectedAudioSamples=$totalAudioSamples)")
                true
            } catch (e: Throwable) {
                QuizLogger.error("QuizStudioPro-Encoder", "prepareNativeSceneExport error: ${e.message}")
                false
            }
        }

        @JavascriptInterface
        fun getActivePcmSessionJson(): String {
            return JSONObject().apply {
                put("sessionId", activeExportSessionId)
                put("sessionToken", activeSessionToken)
                put("expectedSamples", exportTotalAudioSamples)
                put("expectedBytes", exportTotalAudioSamples * 2L)
            }.toString()
        }

        @JavascriptInterface
        fun beginPcmTransfer(sessionId: String, sessionToken: Int, expectedSamples: Long, expectedPackets: Int): String {
            return pcmCoordinator.bindTransferMetadata(sessionId, sessionToken, expectedSamples, expectedPackets).toJsonString()
        }

        @JavascriptInterface
        fun writePcmChunkTracked(
            sessionId: String,
            sessionToken: Int,
            seq: Int,
            payloadByteLen: Int,
            expectedBytes: Long,
            expectedSamples: Long,
            base64Pcm: String
        ): String {
            return try {
                val bytes = Base64.decode(base64Pcm, Base64.DEFAULT)
                val acks = pcmCoordinator.acceptChunk(sessionToken, seq, payloadByteLen, expectedBytes, expectedSamples, bytes)
                val last = acks.lastOrNull()
                    ?: PcmTransferCoordinator.AckResult(
                        ok = true,
                        sessionId = sessionId,
                        sessionToken = sessionToken,
                        seq = seq,
                        writtenBytes = 0,
                        cumulativeBytes = pcmCoordinator.getTelemetrySnapshot().cumulativeWrittenBytes,
                        expectedBytes = expectedBytes,
                        ackedPackets = pcmCoordinator.getTelemetrySnapshot().packetsAcked
                    )
                last.toJsonString()
            } catch (e: Throwable) {
                PcmTransferCoordinator.AckResult(
                    ok = false,
                    sessionId = sessionId,
                    sessionToken = sessionToken,
                    seq = seq,
                    writtenBytes = 0,
                    cumulativeBytes = pcmCoordinator.getTelemetrySnapshot().cumulativeWrittenBytes,
                    expectedBytes = expectedBytes,
                    ackedPackets = pcmCoordinator.getTelemetrySnapshot().packetsAcked,
                    error = "writePcmChunkTracked error: ${e.message}"
                ).toJsonString()
            }
        }

        @JavascriptInterface
        fun finishPcmTransfer(sessionId: String, sessionToken: Int, expectedPackets: Int, expectedBytes: Long, expectedSamples: Long): String {
            return pcmCoordinator.completeTransfer(sessionId, sessionToken, expectedPackets, expectedBytes, expectedSamples).toJsonString()
        }

        @JavascriptInterface
        fun runPreparedNativeSceneExport(filename: String): String {
            return executePreparedNativeSceneExport(filename)
        }

        @JavascriptInterface
        fun startPreparedNativeSceneExportAsync(filename: String): String {
            return try {
                asyncExportResultJson = null
                asyncExportProgressPct = 28
                asyncExportStageMsg = "Starting native encoder..."
                asyncExportState = "running"

                val t = Thread({
                    val jsonResult = executePreparedNativeSceneExport(filename)
                    synchronized(this@MainActivity) {
                        if (asyncExportState == "cancelled") {
                            asyncExportResultJson = JSONObject().apply {
                                put("ok", false)
                                put("cancelled", true)
                                put("error", "Export cancelled")
                            }.toString()
                        } else {
                            asyncExportResultJson = jsonResult
                            val parsedOk = try { JSONObject(jsonResult).optBoolean("ok", false) } catch (_: Exception) { false }
                            asyncExportProgressPct = if (parsedOk) 100 else asyncExportProgressPct
                            asyncExportState = if (parsedOk) "completed" else "failed"
                        }
                    }
                }, "QspNativeExportRunner")
                asyncExportThread = t
                t.start()

                JSONObject().apply {
                    put("ok", true)
                    put("started", true)
                    put("jobId", activeExportSessionId)
                }.toString()
            } catch (e: Throwable) {
                asyncExportState = "failed"
                JSONObject().apply {
                    put("ok", false)
                    put("error", e.message ?: "Failed to launch async native export")
                }.toString()
            }
        }

        @JavascriptInterface
        fun getNativeExportStatusJson(): String {
            return synchronized(this@MainActivity) {
                JSONObject().apply {
                    put("state", asyncExportState)
                    put("progressPct", asyncExportProgressPct)
                    put("stage", asyncExportStageMsg)
                    put("jobId", activeExportSessionId)
                    if (asyncExportResultJson != null) {
                        put("resultJson", asyncExportResultJson)
                    }
                }.toString()
            }
        }

        private fun executePreparedNativeSceneExport(filename: String): String {
            return try {
                val verification = pcmCoordinator.verifyReadyForEncoding(exportTotalAudioSamples)
                if (verification.isFailure) {
                    val err = verification.exceptionOrNull()?.message ?: "PCM verification failed before encoding"
                    QuizLogger.error("AudioIntegrity", "[$activeExportSessionId] Aborted executePreparedNativeSceneExport: $err")
                    QuizEncodingService.stop(this@MainActivity)
                    val snap = pcmCoordinator.getTelemetrySnapshot()
                    cleanupExportTemp()
                    return JSONObject().apply {
                        put("ok", false)
                        put("jobId", activeExportSessionId)
                        put("stage", "PCM_VERIFY")
                        put("error", err)
                        put("pcmTelemetry", buildPcmTelemetryJson(snap))
                    }.toString()
                }
                val pcmSnap = verification.getOrThrow()

                val bundleJson = pendingSceneBundleJson ?: throw IllegalStateException("Scene bundle missing")
                val targetFile = currentExportOutputFile ?: throw IllegalStateException("Target output file missing")
                val composer = DirectEglSceneComposer(this@MainActivity, bundleJson, exportWidth, exportHeight, exportFps)
                directSceneComposer = composer
                val scheduler = IntelligentFrameScheduler(bundleJson, exportWidth, exportHeight, exportFps, exportTotalFrames)

                val session = StreamingVideoEncoderSession(
                    outputFile = targetFile,
                    width = exportWidth,
                    height = exportHeight,
                    fps = exportFps,
                    totalFrames = exportTotalFrames,
                    audioPcmFile = pcmTempFile,
                    totalAudioSamplesOverride = exportTotalAudioSamples,
                    listener = object : VideoEncoder.ProgressListener {
                        override fun onProgress(currentFrame: Int, totalFrames: Int, stage: String, explicitProgressPercent: Float?) {
                            val pct = (explicitProgressPercent ?: (15f + (currentFrame.toFloat() / totalFrames.coerceAtLeast(1)) * 75f)).toInt()
                            asyncExportProgressPct = pct
                            asyncExportStageMsg = stage
                            QuizEncodingService.updateProgress(this@MainActivity, pct, stage)
                            runOnUiThread {
                                webView.evaluateJavascript("window.onExportProgress && window.onExportProgress($pct, ${JSONObject.quote(stage)})", null)
                            }
                        }
                    },
                    mode = StreamingVideoEncoderSession.Mode.NATIVE_SCENE_DIRECT,
                    frameScheduler = scheduler,
                    directComposer = composer,
                    exportJobId = activeExportSessionId.ifBlank { "qsp_${System.currentTimeMillis()}" }
                )
                streamingSession = session
                session.start()
                val ok = session.finishAndAwait(timeoutMs = 300_000L)
                val stats = session.getStats()
                finalizeOutputFileResult(ok, filename, targetFile, stats, pcmSnap)
            } catch (e: Throwable) {
                val failMsg = e.message ?: "Native direct scene export failed"
                QuizLogger.error("QuizStudioPro-Encoder", "[$activeExportSessionId] executePreparedNativeSceneExport error: $failMsg")
                val snap = pcmCoordinator.getTelemetrySnapshot()
                val stats = streamingSession?.getStats()
                QuizEncodingService.notifyFailed(this@MainActivity, failMsg)
                cleanupExportTemp()
                JSONObject().apply {
                    put("ok", false)
                    put("jobId", activeExportSessionId)
                    put("stage", stats?.pipelineStage ?: "NATIVE_ENCODE")
                    put("error", failMsg)
                    if (!stats?.selectedTier.isNullOrBlank()) put("selectedTier", stats?.selectedTier)
                    if (!stats?.attemptedPaths.isNullOrEmpty()) put("attemptedPaths", JSONArray(stats?.attemptedPaths))
                    put("pcmTelemetry", buildPcmTelemetryJson(snap))
                }.toString()
            }
        }

        // --- Phase 2 Binary RGBA Stream Fast Path (Zero JPEG, Zero Base64, Zero BitmapFactory) ---
        @JavascriptInterface
        fun initNativeRgbaExport(width: Int, height: Int, fps: Int, totalFrames: Int, totalAudioSamples: Long): Boolean {
            return initSessionInternal(
                width, height, fps, totalFrames, totalAudioSamples,
                StreamingVideoEncoderSession.Mode.NATIVE_RGBA_STREAM
            )
        }

        // --- Legacy Compatibility Fallback (JPEG/Base64 — used ONLY when fast paths fail) ---
        @JavascriptInterface
        fun initNativeExport(width: Int, height: Int, fps: Int, totalFrames: Int, totalAudioSamples: Long): Boolean {
            QuizLogger.warn("QuizStudioPro-Encoder", "[COMPATIBILITY_FALLBACK] Legacy JPEG/Base64 native export initialized")
            return initSessionInternal(
                width, height, fps, totalFrames, totalAudioSamples,
                StreamingVideoEncoderSession.Mode.COMPATIBILITY_FALLBACK
            )
        }

        private fun initSessionInternal(
            width: Int,
            height: Int,
            fps: Int,
            totalFrames: Int,
            totalAudioSamples: Long,
            mode: StreamingVideoEncoderSession.Mode
        ): Boolean {
            return try {
                cleanupExportTemp()
                exportWidth = width
                exportHeight = height
                exportFps = fps
                exportTotalFrames = totalFrames
                exportTotalAudioSamples = totalAudioSamples
                nativeSessionMode = mode

                val token = sessionTokenCounter.incrementAndGet()
                val sessionId = "qsp_${System.currentTimeMillis()}_$token"
                activeSessionToken = token
                activeExportSessionId = sessionId

                QuizEncodingService.start(this@MainActivity, "Preparing native MP4 export ($width x $height @ ${fps}fps)...")
                val cacheDirTemp = File(cacheDir, "export_pcm_temp").apply { mkdirs() }
                val pcmFile = File(cacheDirTemp, "audio_track_${token}_${System.currentTimeMillis()}.pcm")
                pcmTempFile = pcmFile
                pcmCoordinator.prepareSession(sessionId, token, pcmFile, totalAudioSamples)

                val safeName = "quiz_export_${token}_${System.currentTimeMillis()}.mp4"
                val targetFile = File(cacheDirTemp, safeName)
                currentExportOutputFile = targetFile

                val session = StreamingVideoEncoderSession(
                    outputFile = targetFile,
                    width = width,
                    height = height,
                    fps = fps,
                    totalFrames = totalFrames,
                    audioPcmFile = pcmTempFile,
                    totalAudioSamplesOverride = totalAudioSamples,
                    listener = object : VideoEncoder.ProgressListener {
                        override fun onProgress(currentFrame: Int, totalFrames: Int, stage: String, explicitProgressPercent: Float?) {
                            val pct = (explicitProgressPercent ?: (25f + (currentFrame.toFloat() / totalFrames.coerceAtLeast(1)) * 65f)).toInt()
                            QuizEncodingService.updateProgress(this@MainActivity, pct, stage)
                            runOnUiThread {
                                webView.evaluateJavascript("window.onExportProgress && window.onExportProgress($pct, ${JSONObject.quote(stage)})", null)
                            }
                        }
                    },
                    mode = mode,
                    exportJobId = sessionId
                )
                // Do NOT call session.start() here: AudioEncoderThread must wait until PCM transfer is 100% verified!
                streamingSession = session

                QuizLogger.info("QuizStudioPro-Encoder", "Native export pipeline prepared mode=$mode session=$sessionId token=$token: ${width}x${height} @ ${fps}fps ($totalFrames frames, expectedAudioSamples=$totalAudioSamples)")
                true
            } catch (e: Throwable) {
                QuizLogger.error("QuizStudioPro-Encoder", "initSessionInternal error: ${e.message}")
                false
            }
        }

        @JavascriptInterface
        fun startPreparedNativeSession(): String {
            return try {
                val verification = pcmCoordinator.verifyReadyForEncoding(exportTotalAudioSamples)
                if (verification.isFailure) {
                    val err = verification.exceptionOrNull()?.message ?: "PCM verification failed before starting encoder"
                    QuizLogger.error("AudioIntegrity", "Aborted startPreparedNativeSession: $err")
                    return JSONObject().apply {
                        put("ok", false)
                        put("error", err)
                    }.toString()
                }
                val session = streamingSession ?: throw IllegalStateException("Streaming encoder session not prepared")
                session.start()
                JSONObject().apply { put("ok", true) }.toString()
            } catch (e: Throwable) {
                JSONObject().apply {
                    put("ok", false)
                    put("error", e.message ?: "Failed to start prepared native session")
                }.toString()
            }
        }

        @JavascriptInterface
        fun writePcmChunk(base64Pcm: String): Boolean {
            return try {
                val bytes = Base64.decode(base64Pcm, Base64.DEFAULT)
                pcmCoordinator.handleLegacyPcm0Packet(bytes)
                true
            } catch (e: Throwable) {
                QuizLogger.error("QuizStudioPro-Encoder", "writePcmChunk error: ${e.message}")
                false
            }
        }

        @JavascriptInterface
        fun submitFrame(frameIndex: Int, base64Image: String): Boolean {
            return try {
                val session = streamingSession ?: throw IllegalStateException("Streaming encoder session not initialized")
                val clean = if (base64Image.contains(",")) base64Image.split(",")[1] else base64Image
                val jpegBytes = Base64.decode(clean, Base64.DEFAULT)
                session.submitFrameBytes(frameIndex, jpegBytes)
            } catch (e: Throwable) {
                val msg = "submitFrame [COMPATIBILITY_FALLBACK] failed frame $frameIndex: ${e.message}"
                QuizLogger.error("QuizStudioPro-Encoder", msg)
                throw RuntimeException(msg, e)
            }
        }

        @JavascriptInterface
        fun submitFrameRaw(frameIndex: Int, base64Rgba: String): Boolean {
            return try {
                val session = streamingSession ?: throw IllegalStateException("Streaming encoder session not initialized")
                val clean = if (base64Rgba.contains(",")) base64Rgba.split(",")[1] else base64Rgba
                val rawBytes = Base64.decode(clean, Base64.DEFAULT)
                session.submitFrameRaw(frameIndex, rawBytes, isRgba = true)
            } catch (e: Throwable) {
                throw RuntimeException("submitFrameRaw failed frame $frameIndex: ${e.message}", e)
            }
        }

        @JavascriptInterface
        fun finalizeNativeExport(filename: String): String {
            return try {
                val verification = pcmCoordinator.verifyReadyForEncoding(exportTotalAudioSamples)
                if (verification.isFailure) {
                    val err = verification.exceptionOrNull()?.message ?: "PCM verification failed before finalize"
                    val snap = pcmCoordinator.getTelemetrySnapshot()
                    QuizEncodingService.stop(this@MainActivity)
                    cleanupExportTemp()
                    return JSONObject().apply {
                        put("ok", false)
                        put("error", err)
                        put("pcmTelemetry", buildPcmTelemetryJson(snap))
                    }.toString()
                }
                val pcmSnap = verification.getOrThrow()

                val session = streamingSession ?: throw IllegalStateException("Streaming encoder session is null")
                val targetFile = currentExportOutputFile ?: File(cacheDir, "quiz-video.mp4")

                QuizEncodingService.updateProgress(this@MainActivity, 92, "Finalizing MediaMuxer MP4 container...")
                val success = session.finishAndAwait(timeoutMs = 120_000L)
                val stats = session.getStats()
                finalizeOutputFileResult(success, filename, targetFile, stats, pcmSnap)
            } catch (e: Throwable) {
                QuizLogger.error("QuizStudioPro-Encoder", "finalizeNativeExport error: ${e.message}")
                val snap = pcmCoordinator.getTelemetrySnapshot()
                QuizEncodingService.stop(this@MainActivity)
                cleanupExportTemp()
                JSONObject().apply {
                    put("ok", false)
                    put("error", e.message ?: "Native MP4 export failed.")
                    put("pcmTelemetry", buildPcmTelemetryJson(snap))
                }.toString()
            }
        }

        private fun buildPcmTelemetryJson(snap: PcmTransferCoordinator.TelemetrySnapshot?): JSONObject {
            return JSONObject().apply {
                if (snap != null) {
                    put("sessionId", snap.sessionId)
                    put("sessionToken", snap.sessionToken)
                    put("expectedSamples", snap.expectedSamples)
                    put("expectedBytes", snap.expectedBytes)
                    put("expectedPackets", snap.expectedPackets)
                    put("packetsReceived", snap.packetsReceived)
                    put("packetsAcked", snap.packetsAcked)
                    put("duplicatePackets", snap.duplicatePackets)
                    put("outOfOrderPackets", snap.outOfOrderPackets)
                    put("staleOrRejectedPackets", snap.staleOrRejectedPackets)
                    put("missingPackets", snap.missingPackets)
                    put("cumulativeWrittenBytes", snap.cumulativeWrittenBytes)
                    put("actualFileBytes", snap.actualFileBytes)
                    put("transferDurationMs", snap.transferDurationMs)
                    put("completedAndVerified", snap.completedAndVerified)
                    if (snap.lastError != null) put("lastError", snap.lastError)
                }
            }
        }

        private fun finalizeOutputFileResult(
            success: Boolean,
            filename: String,
            targetFile: File,
            stats: StreamingVideoEncoderSession.SessionStats?,
            pcmSnap: PcmTransferCoordinator.TelemetrySnapshot? = null
        ): String {
            val jobId = activeExportSessionId.ifBlank { stats?.exportJobId ?: "qsp_${System.currentTimeMillis()}" }
            val audioIntegrityErr = stats?.audioError
            val encoderSummary = "mode=${stats?.mode} codec=${stats?.codecName} hw=${stats?.isHardwareCodec} vTrack=${stats?.videoTrackRegistered} vSamples=${stats?.writtenVideoSamples} aTrack=${stats?.audioTrackRegistered} aSamples=${stats?.aacOutputSamples}"

            return if (success && audioIntegrityErr == null && targetFile.exists() && targetFile.length() > 0) {
                asyncExportStageMsg = "Saving & verifying MP4 in Movies/QuizStudioPro…"
                asyncExportProgressPct = 95
                val saveResult = try {
                    MediaStoreVideoStorage.saveVideoFile(
                        context = this@MainActivity,
                        sourceFile = targetFile,
                        requestedFileName = filename,
                        jobId = jobId,
                        encoderSummary = encoderSummary
                    )
                } catch (e: MediaStoreVideoStorage.MediaStoreSaveException) {
                    QuizLogger.error("MediaStoreExport", "[$jobId] finalizeOutputFileResult MediaStoreSaveException: ${e.diagnosticDetails}")
                    QuizEncodingService.notifyFailed(this@MainActivity, e.userMessage)
                    cleanupExportTemp()
                    return JSONObject().apply {
                        put("ok", false)
                        put("jobId", jobId)
                        put("stage", e.stage?.name ?: "MEDIASTORE_SAVE")
                        put("error", e.userMessage)
                        put("pcmTelemetry", buildPcmTelemetryJson(pcmSnap))
                    }.toString()
                } catch (e: Throwable) {
                    QuizLogger.error("MediaStoreExport", "[$jobId] finalizeOutputFileResult unexpected save error: ${e::class.java.name}: ${e.message}")
                    val friendly = "Unable to save exported MP4 video to Movies/QuizStudioPro. Please check available device storage and try again."
                    QuizEncodingService.notifyFailed(this@MainActivity, friendly)
                    cleanupExportTemp()
                    return JSONObject().apply {
                        put("ok", false)
                        put("jobId", jobId)
                        put("stage", "MEDIASTORE_SAVE")
                        put("error", friendly)
                        put("pcmTelemetry", buildPcmTelemetryJson(pcmSnap))
                    }.toString()
                }

                // Temporary encoded cache file is no longer needed once published and verified in MediaStore
                try { targetFile.delete() } catch (_: Exception) {}

                val recentEntry = RecentVideosStore.RecentVideoEntry(
                    jobId = jobId,
                    uri = saveResult.uri.toString(),
                    fileName = saveResult.fileName,
                    relativePath = saveResult.relativePath,
                    sizeBytes = saveResult.bytesWritten,
                    width = stats?.width ?: exportWidth,
                    height = stats?.height ?: exportHeight,
                    fps = stats?.fps ?: exportFps,
                    durationMs = stats?.mp4DurationMs ?: 0L,
                    createdAtMs = System.currentTimeMillis()
                )
                val registered = RecentVideosStore.recordVerifiedExport(this@MainActivity, recentEntry, verifyReadable = true)
                if (!registered) {
                    val verifyErr = "Saved MP4 entry could not be opened for playback verification."
                    QuizLogger.error("MediaStoreExport", "[$jobId] $verifyErr uri=${saveResult.uri}")
                    QuizEncodingService.notifyFailed(this@MainActivity, verifyErr)
                    cleanupExportTemp()
                    return JSONObject().apply {
                        put("ok", false)
                        put("jobId", jobId)
                        put("stage", "VERIFY_PLAYABLE")
                        put("error", verifyErr)
                        put("pcmTelemetry", buildPcmTelemetryJson(pcmSnap))
                    }.toString()
                }

                val savedName = saveResult.fileName
                val savedRelPath = saveResult.relativePath
                val previewUrl = recentEntry.previewUrl()
                lastSavedUri = saveResult.uri
                lastPreviewUrl = previewUrl

                QuizEncodingService.notifyComplete(this@MainActivity, "Video saved to $savedRelPath/$savedName")
                cleanupExportTemp()
                JSONObject().apply {
                    put("ok", true)
                    put("jobId", jobId)
                    put("savedFileName", savedName)
                    put("relativePath", savedRelPath)
                    put("outputUri", saveResult.uri.toString())
                    put("bytesWritten", saveResult.bytesWritten)
                    put("message", "Saved to $savedRelPath/$savedName")
                    put("previewUrl", previewUrl)
                    put("pcmTelemetry", buildPcmTelemetryJson(pcmSnap))
                    put("stats", JSONObject().apply {
                        put("exportJobId", stats?.exportJobId ?: jobId)
                        put("pipelineStage", stats?.pipelineStage ?: "COMPLETED")
                        put("mode", stats?.mode ?: nativeSessionMode.name)
                        put("codecName", stats?.codecName ?: "")
                        put("isHardwareCodec", stats?.isHardwareCodec)
                        put("width", stats?.width ?: exportWidth)
                        put("height", stats?.height ?: exportHeight)
                        put("fps", stats?.fps ?: exportFps)
                        put("framesProcessed", stats?.framesProcessed ?: exportTotalFrames)
                        put("expectedFrames", stats?.expectedFrames ?: exportTotalFrames)
                        put("droppedFrames", stats?.droppedFrames ?: 0)
                        put("encodeDurationMs", stats?.encodeDurationMs ?: 0L)
                        put("finalizationMs", stats?.finalizationMs ?: 0L)
                        put("outputBytes", saveResult.bytesWritten)
                        put("usedJpegFallback", stats?.usedJpegFallback ?: false)
                        put("renderedFrames", stats?.renderedFrames ?: exportTotalFrames)
                        put("skippedDuplicateFrames", stats?.skippedDuplicateFrames ?: 0)
                        put("directGpuFrames", stats?.directGpuFrames ?: 0)
                        put("bitmapFallbackFrames", stats?.bitmapFallbackFrames ?: 0)
                        put("textureUploads", stats?.textureUploads ?: 0)
                        put("audioEncodeMs", stats?.audioEncodeMs ?: 0L)
                        put("muxDurationMs", stats?.muxDurationMs ?: 0L)
                        put("peakHeapBytes", stats?.peakHeapBytes ?: 0L)
                        put("videoTrackRegistered", stats?.videoTrackRegistered ?: false)
                        put("writtenVideoSamples", stats?.writtenVideoSamples ?: 0)
                        put("lastVideoPtsUs", stats?.lastVideoPtsUs ?: -1L)
                        put("muxerStarted", stats?.muxerStarted ?: false)
                        put("expectedAudioSamples", stats?.expectedAudioSamples ?: exportTotalAudioSamples)
                        put("actualPcmBytes", stats?.actualPcmBytes ?: (pcmSnap?.actualFileBytes ?: 0L))
                        put("aacInputSamples", stats?.aacInputSamples ?: 0L)
                        put("aacOutputSamples", stats?.aacOutputSamples ?: 0)
                        put("firstAudioPtsUs", stats?.firstAudioPtsUs ?: -1L)
                        put("lastAudioPtsUs", stats?.lastAudioPtsUs ?: -1L)
                        put("audioTrackRegistered", stats?.audioTrackRegistered ?: false)
                        put("expectedAudioDurationMs", stats?.expectedAudioDurationMs ?: 0L)
                        put("actualAudioDurationMs", stats?.actualAudioDurationMs ?: 0L)
                        put("mp4DurationMs", stats?.mp4DurationMs ?: 0L)
                        put("selectedTier", stats?.selectedTier ?: "")
                        put("attemptedPaths", JSONArray(stats?.attemptedPaths ?: emptyList<String>()))
                        if (stats?.fallbackReason != null) put("fallbackReason", stats.fallbackReason)
                    })
                }.toString()
            } else {
                val attemptedList = stats?.attemptedPaths ?: emptyList()
                val attemptedSummary = if (attemptedList.isNotEmpty()) {
                    " Attempted: ${attemptedList.joinToString(" -> ")}. If all encoders fail on this device at ${exportHeight}p, try 720p."
                } else ""
                val errReason = if (!audioIntegrityErr.isNullOrBlank()) {
                    audioIntegrityErr
                } else {
                    "Video encoder failed to produce valid MP4 output at ${exportWidth}x${exportHeight}@${exportFps}fps.$attemptedSummary"
                }
                QuizLogger.error("MediaStoreExport", "[$jobId] Export failed before MediaStore save: stage=${stats?.pipelineStage} tier=${stats?.selectedTier} $encoderSummary attempted=$attemptedList err=$errReason")
                QuizEncodingService.notifyFailed(this@MainActivity, errReason)
                cleanupExportTemp()
                JSONObject().apply {
                    put("ok", false)
                    put("jobId", jobId)
                    put("stage", stats?.pipelineStage ?: "ENCODE")
                    put("error", errReason)
                    put("selectedTier", stats?.selectedTier ?: "")
                    put("attemptedPaths", JSONArray(attemptedList))
                    put("pcmTelemetry", buildPcmTelemetryJson(pcmSnap))
                }.toString()
            }
        }

        @JavascriptInterface
        fun cancelNativeExport() {
            asyncExportState = "cancelled"
            QuizEncodingService.stop(this@MainActivity)
            cleanupExportTemp()
        }

        @JavascriptInterface
        fun getRecentVideosJson(): String {
            return try {
                val list = RecentVideosStore.listVerified(this@MainActivity, pruneMissing = true)
                val arr = JSONArray()
                for (item in list) {
                    arr.put(item.toJson())
                }
                arr.toString()
            } catch (e: Throwable) {
                QuizLogger.warn("RecentVideosStore", "getRecentVideosJson error: ${e.message}")
                "[]"
            }
        }

        @JavascriptInterface
        fun openVideoByUri(uriStr: String): Boolean {
            val uri = RecentVideosStore.findAuthorizedUri(this@MainActivity, uriStr, null)
                ?: lastSavedUri?.takeIf { it.toString() == uriStr }
                ?: return false
            return try {
                runOnUiThread {
                    startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                }
                true
            } catch (_: Exception) {
                false
            }
        }

        @JavascriptInterface
        fun shareVideoByUri(uriStr: String): Boolean {
            val uri = RecentVideosStore.findAuthorizedUri(this@MainActivity, uriStr, null)
                ?: lastSavedUri?.takeIf { it.toString() == uriStr }
                ?: return false
            return try {
                runOnUiThread {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "video/mp4"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(intent, "Share quiz video"))
                }
                true
            } catch (_: Exception) {
                false
            }
        }

        // --- WebView Document Save Bridge (JSON / CSV / Templates) ---
        @JavascriptInterface
        fun saveDocumentFile(filename: String, mimeType: String, content: String, isBase64: Boolean): String {
            return try {
                val bytes = if (isBase64) Base64.decode(content, Base64.DEFAULT) else content.toByteArray(Charsets.UTF_8)
                val saved = MediaStoreVideoStorage.saveDocumentBytes(
                    context = this@MainActivity,
                    requestedFileName = filename,
                    mimeType = mimeType,
                    bytes = bytes
                )
                JSONObject().apply {
                    put("ok", true)
                    put("path", "${saved.relativePath}/${saved.fileName}")
                }.toString()
            } catch (e: MediaStoreVideoStorage.MediaStoreSaveException) {
                QuizLogger.error("AndroidBridge", "saveDocumentFile failed: ${e.diagnosticDetails}")
                JSONObject().apply {
                    put("ok", false)
                    put("error", e.userMessage)
                }.toString()
            } catch (e: Throwable) {
                QuizLogger.error("AndroidBridge", "saveDocumentFile error: ${e.message}")
                JSONObject().apply {
                    put("ok", false)
                    put("error", "Document save failed")
                }.toString()
            }
        }

        // --- Canva Connect OAuth PKCE Helpers ---
        @JavascriptInterface
        fun getCanvaConfig(): String {
            val clientId = try {
                val field = BuildConfig::class.java.getField("CANVA_CLIENT_ID")
                (field.get(null) as? String)?.trim() ?: ""
            } catch (_: Exception) {
                ""
            }
            return JSONObject().apply {
                put("clientId", clientId)
                put("redirectUri", "quizstudiopro://canva/callback")
            }.toString()
        }

        @JavascriptInterface
        fun launchCanvaAuth(authUrl: String): Boolean {
            return try {
                val uri = Uri.parse(authUrl)
                if (uri.scheme != "https" || uri.host?.endsWith("canva.com") != true) return false
                runOnUiThread {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                }
                true
            } catch (e: Exception) {
                QuizLogger.error("AndroidBridge", "launchCanvaAuth failed: ${e.message}")
                false
            }
        }

        @JavascriptInterface
        fun consumePendingCanvaCallback(): String {
            val out = pendingCanvaCallbackJson ?: ""
            pendingCanvaCallbackJson = null
            return out
        }

        // --- Save / File bridge methods (Route 2 atomic staged write -> MediaStore + RecentVideosStore) ---
        @JavascriptInterface
        fun saveBegin(name: String): Boolean {
            return try {
                synchronized(this@MainActivity) {
                    closePending(false)
                    lastSaveErrorMessage = null
                    val tempDir = File(cacheDir, "export_pcm_temp").apply { mkdirs() }
                    val stageFile = File(tempDir, "webcodecs_stage_${System.currentTimeMillis()}.mp4")
                    saveChunkTempFile = stageFile
                    pendingName = name
                    pendingUri = null
                    output = BufferedOutputStream(FileOutputStream(stageFile), 64 * 1024)
                    true
                }
            } catch (e: Throwable) {
                lastSaveErrorMessage = "Could not prepare temporary MP4 staging file."
                QuizLogger.error("MediaStoreExport", "saveBegin unexpected error: ${e::class.java.name}: ${e.message}")
                closePending(false)
                false
            }
        }

        @JavascriptInterface
        fun saveChunk(base64: String): Boolean {
            return try {
                synchronized(this@MainActivity) {
                    val stream = output ?: return false
                    val bytes = Base64.decode(base64, Base64.DEFAULT)
                    stream.write(bytes)
                    true
                }
            } catch (e: Throwable) {
                lastSaveErrorMessage = "Failed while writing MP4 chunk to temporary staging storage."
                QuizLogger.error("MediaStoreExport", "saveChunk error: ${e::class.java.name}: ${e.message}")
                false
            }
        }

        @JavascriptInterface
        fun saveEnd(): Boolean {
            return try {
                synchronized(this@MainActivity) {
                    output?.flush()
                    output?.close()
                    output = null
                    val staged = saveChunkTempFile ?: return false
                    val saveResult = MediaStoreVideoStorage.saveVideoFile(
                        context = this@MainActivity,
                        sourceFile = staged,
                        requestedFileName = pendingName,
                        jobId = "wc_${System.currentTimeMillis()}"
                    )
                    try { staged.delete() } catch (_: Exception) {}
                    saveChunkTempFile = null

                    val entry = RecentVideosStore.RecentVideoEntry(
                        jobId = saveResult.jobId,
                        uri = saveResult.uri.toString(),
                        fileName = saveResult.fileName,
                        relativePath = saveResult.relativePath,
                        sizeBytes = saveResult.bytesWritten,
                        width = exportWidth,
                        height = exportHeight,
                        fps = exportFps,
                        createdAtMs = System.currentTimeMillis()
                    )
                    RecentVideosStore.recordVerifiedExport(this@MainActivity, entry, verifyReadable = true)
                    lastSavedUri = saveResult.uri
                    lastPreviewUrl = entry.previewUrl()
                    pendingUri = null
                    lastSaveErrorMessage = null
                    val savedMsg = "Video successfully saved to ${saveResult.relativePath}/${saveResult.fileName}"
                    QuizEncodingService.notifyComplete(this@MainActivity, savedMsg)
                    runOnUiThread {
                        webView.evaluateJavascript(
                            "window.onFileSaved && window.onFileSaved(${JSONObject.quote(savedMsg)}, ${JSONObject.quote(entry.previewUrl())})",
                            null
                        )
                    }
                    true
                }
            } catch (e: MediaStoreVideoStorage.MediaStoreSaveException) {
                lastSaveErrorMessage = e.userMessage
                QuizLogger.error("MediaStoreExport", "saveEnd MediaStoreSaveException: ${e.diagnosticDetails}")
                closePending(false)
                false
            } catch (e: Throwable) {
                lastSaveErrorMessage = "Could not finalize MP4 video in Movies/QuizStudioPro."
                QuizLogger.error("MediaStoreExport", "saveEnd error: ${e::class.java.name}: ${e.message}")
                closePending(false)
                false
            }
        }

        @JavascriptInterface
        fun getLastSaveError(): String = lastSaveErrorMessage ?: ""

        @JavascriptInterface
        fun saveFailed(message: String) {
            synchronized(this@MainActivity) { closePending(false) }
            val cleanMsg = lastSaveErrorMessage?.takeIf { it.isNotBlank() } ?: message
            QuizEncodingService.notifyFailed(this@MainActivity, "Video save failed: $cleanMsg")
            runOnUiThread {
                webView.evaluateJavascript("window.onFileSaved && window.onFileSaved('')", null)
                Toast.makeText(this@MainActivity, "Video save failed: $cleanMsg", Toast.LENGTH_LONG).show()
            }
        }

        @JavascriptInterface fun hasSavedVideo(): Boolean = lastSavedUri != null
        @JavascriptInterface fun getLastPreviewUrl(): String = lastPreviewUrl ?: ""

        @JavascriptInterface
        fun openSavedVideo(): Boolean {
            val uri = lastSavedUri ?: RecentVideosStore.latestVerified(this@MainActivity)?.let { Uri.parse(it.uri) } ?: return false
            return openVideoByUri(uri.toString())
        }

        @JavascriptInterface
        fun shareSavedVideo(): Boolean {
            val uri = lastSavedUri ?: RecentVideosStore.latestVerified(this@MainActivity)?.let { Uri.parse(it.uri) } ?: return false
            return shareVideoByUri(uri.toString())
        }

        @JavascriptInterface
        fun toast(message: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, message.take(180), Toast.LENGTH_SHORT).show() }
        }
    }

    private fun cleanupExportTemp() {
        activeSessionToken = 0
        activeExportSessionId = ""
        pcmCoordinator.cancelAndReset(deleteFile = true)
        pcmTempFile = null
        try {
            streamingSession?.abortAndAwait(1500L)
        } catch (_: Exception) {}
        streamingSession = null
        try {
            nativeSceneRenderer?.release()
        } catch (_: Exception) {}
        nativeSceneRenderer = null
        try {
            directSceneComposer?.release()
        } catch (_: Exception) {}
        directSceneComposer = null
        pendingSceneBundleJson = null
        try {
            currentExportOutputFile?.delete()
        } catch (_: Exception) {}
        currentExportOutputFile = null
    }

    private fun closePending(publish: Boolean) {
        try {
            output?.flush()
            output?.close()
        } catch (_: Exception) {}
        output = null
        try {
            saveChunkTempFile?.delete()
        } catch (_: Exception) {}
        saveChunkTempFile = null
        val uri = pendingUri
        if (uri != null && !publish) try {
            contentResolver.delete(uri, null, null)
        } catch (_: Exception) {}
        pendingUri = null
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickFileRequest) {
            val result = if (resultCode == RESULT_OK) data?.data?.let { arrayOf(it) } else null
            pendingFileCallback?.onReceiveValue(result)
            pendingFileCallback = null
        }
    }

    @SuppressLint("GestureBackNavigation")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        for (job in asyncTtsJobs.values) {
            try { job.cancel() } catch (_: Exception) {}
        }
        asyncTtsJobs.clear()
        try { asyncTtsScope.cancel() } catch (_: Exception) {}
        cleanupExportTemp()
        closePending(false)
        try { nativeBinaryPort?.close() } catch (_: Exception) {}
        nativeBinaryPort = null
        try { binaryPortThread?.quitSafely() } catch (_: Exception) {}
        binaryPortThread = null
        binaryPortHandler = null
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("AndroidBridge")
            webView.destroy()
        }
        super.onDestroy()
    }
}
