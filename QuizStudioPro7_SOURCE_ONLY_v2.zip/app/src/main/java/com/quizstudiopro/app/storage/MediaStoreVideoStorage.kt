package com.quizstudiopro.app.storage

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.util.Log
import com.quizstudiopro.app.logging.QuizLogger
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.io.SyncFailedException
import java.util.Locale

/**
 * Reliable, scoped-storage-compliant MediaStore file creation, verification, and publishing helper
 * for Quiz Studio Pro.
 *
 * Guarantees atomic MediaStore publishing lifecycle per export attempt:
 * 1. Pre-flight available-space validation (`SPACE_CHECK`).
 * 2. Sanitizes display name, queries existing entries across trailing-slash/pending variants, and
 *    generates deterministic unique `_1`, `_2`, ... + timestamp fallback candidates.
 * 3. Wraps `CREATE_ENTRY -> OPEN_STREAM -> COPY_BYTES -> VERIFY_COPIED_SIZE -> PUBLISH_PENDING ->
 *    VERIFY_PLAYABLE` inside a candidate retry loop so MediaProvider collisions during either
 *    `insert(IS_PENDING=1)` OR `update(IS_PENDING=0)` ("Failed to build unique file") roll back ONLY
 *    the newly created temporary URI and automatically recover with `_1.mp4`, etc.
 * 4. Verifies the published MediaStore `content://` URI is readable and non-empty before reporting
 *    export success to the UI.
 * 5. Never deletes or modifies pre-existing user files.
 */
object MediaStoreVideoStorage {

    private const val TAG = "MediaStoreExport"
    const val VIDEO_RELATIVE_PATH = "Movies/QuizStudioPro"
    const val DOWNLOADS_RELATIVE_PATH = "Download/QuizStudioPro"
    private const val MAX_COLLISION_ATTEMPTS = 50
    private const val MAX_WRITE_PUBLISH_RETRIES = 6

    enum class ExportStage {
        SPACE_CHECK,
        CREATE_ENTRY,
        OPEN_STREAM,
        COPY_BYTES,
        VERIFY_COPIED_SIZE,
        PUBLISH_PENDING,
        VERIFY_PLAYABLE
    }

    data class SanitizedFileName(
        val base: String,
        val extension: String
    ) {
        val fullName: String get() = "$base$extension"
    }

    data class PendingVideoEntry(
        val uri: Uri,
        val fileName: String,
        val relativePath: String,
        val collectionUri: Uri,
        val outputStream: OutputStream
    )

    data class SavedVideoResult(
        val uri: Uri,
        val fileName: String,
        val relativePath: String,
        val bytesWritten: Long,
        val jobId: String = "",
        val attemptsUsed: Int = 1
    )

    data class SavedDocumentResult(
        val uri: Uri,
        val fileName: String,
        val relativePath: String,
        val bytesWritten: Long
    )

    class MediaStoreSaveException(
        val userMessage: String,
        val diagnosticDetails: String,
        cause: Throwable? = null,
        val stage: ExportStage? = null,
        val jobId: String? = null
    ) : RuntimeException(userMessage, cause)

    fun sanitizeFileName(
        rawName: String?,
        defaultBase: String = "quiz-video",
        forcedExtension: String = ".mp4",
        maxBaseLength: Int = 64
    ): SanitizedFileName {
        val normalizedExt = if (forcedExtension.startsWith(".")) forcedExtension else ".$forcedExtension"
        val leaf = (rawName ?: "")
            .trim()
            .substringAfterLast('/')
            .substringAfterLast('\\')
            .trim()

        val withoutExt = if (normalizedExt.isNotEmpty() &&
            leaf.lowercase(Locale.US).endsWith(normalizedExt.lowercase(Locale.US))
        ) {
            leaf.substring(0, leaf.length - normalizedExt.length)
        } else {
            val dotIdx = leaf.lastIndexOf('.')
            if (normalizedExt.isEmpty() && dotIdx > 0) {
                leaf.substring(0, dotIdx)
            } else {
                leaf
            }
        }

        val cleanedBase = withoutExt
            .replace(Regex("[^A-Za-z0-9._-]"), "_")
            .replace(Regex("_{2,}"), "_")
            .trim('_', '.')
            .take(maxBaseLength)
            .trim('_', '.')
            .ifBlank { defaultBase }

        return SanitizedFileName(base = cleanedBase, extension = normalizedExt)
    }

    fun candidateFileName(base: String, extension: String, suffixIndex: Int): String {
        return if (suffixIndex <= 0) {
            "$base$extension"
        } else {
            "${base}_$suffixIndex$extension"
        }
    }

    fun defaultVideoCollectionUris(sdkInt: Int = Build.VERSION.SDK_INT): List<Uri> {
        val list = ArrayList<Uri>(2)
        if (sdkInt >= Build.VERSION_CODES.Q) {
            try {
                list.add(MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY))
            } catch (_: Throwable) {
            }
        }
        val externalUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        if (!list.contains(externalUri)) {
            list.add(externalUri)
        }
        return list
    }

    fun defaultDownloadCollectionUris(sdkInt: Int = Build.VERSION.SDK_INT): List<Uri> {
        val list = ArrayList<Uri>(2)
        if (sdkInt >= Build.VERSION_CODES.Q) {
            try {
                list.add(MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY))
            } catch (_: Throwable) {
            }
            val externalUri = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            if (!list.contains(externalUri)) {
                list.add(externalUri)
            }
        }
        return list
    }

    fun checkAvailableStorageBytes(context: Context): Long? {
        return try {
            val probeDir = Environment.getExternalStorageDirectory()
                ?.takeIf { it.exists() }
                ?: context.filesDir
            val stat = StatFs(probeDir.absolutePath)
            // Ignore unmocked Robolectric StatFs returning totalBytes == 0
            if (stat.totalBytes > 0L) stat.availableBytes else null
        } catch (_: Throwable) {
            null
        }
    }

    fun queryExistingDisplayNames(
        contentResolver: ContentResolver,
        collectionUris: List<Uri>,
        relativePath: String,
        sdkInt: Int = Build.VERSION.SDK_INT
    ): Set<String> {
        val existing = HashSet<String>()
        val trimmedPath = relativePath.trimEnd('/')
        val slashedPath = "$trimmedPath/"
        val projection = arrayOf(MediaStore.MediaColumns.DISPLAY_NAME)

        for (collectionUri in collectionUris) {
            try {
                val cursor = if (sdkInt >= Build.VERSION_CODES.R) {
                    val args = Bundle().apply {
                        putString(
                            ContentResolver.QUERY_ARG_SQL_SELECTION,
                            "${MediaStore.MediaColumns.RELATIVE_PATH} IN (?, ?)"
                        )
                        putStringArray(
                            ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS,
                            arrayOf(trimmedPath, slashedPath)
                        )
                        putInt(MediaStore.QUERY_ARG_MATCH_PENDING, MediaStore.MATCH_INCLUDE)
                    }
                    contentResolver.query(collectionUri, projection, args, null)
                } else if (sdkInt >= Build.VERSION_CODES.Q) {
                    val queryUri = try {
                        MediaStore.setIncludePending(collectionUri)
                    } catch (_: Throwable) {
                        collectionUri
                    }
                    contentResolver.query(
                        queryUri,
                        projection,
                        "${MediaStore.MediaColumns.RELATIVE_PATH} IN (?, ?)",
                        arrayOf(trimmedPath, slashedPath),
                        null
                    )
                } else {
                    contentResolver.query(collectionUri, projection, null, null, null)
                }

                cursor?.use { c ->
                    val nameIdx = c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
                    if (nameIdx >= 0) {
                        while (c.moveToNext()) {
                            val name = c.getString(nameIdx)?.trim()
                            if (!name.isNullOrEmpty()) {
                                existing.add(name.lowercase(Locale.US))
                            }
                        }
                    }
                }
            } catch (e: Throwable) {
                QuizLogger.warn(
                    TAG,
                    "Pre-insert MediaStore query skipped for $collectionUri: ${e::class.java.simpleName}: ${e.message}"
                )
            }
        }
        return existing
    }

    private fun buildCandidateNames(
        sanitized: SanitizedFileName,
        knownExisting: Set<String>
    ): List<String> {
        val candidates = ArrayList<String>(MAX_COLLISION_ATTEMPTS + 1)
        var suffix = 0
        var scanned = 0
        while (candidates.size < MAX_COLLISION_ATTEMPTS && scanned < MAX_COLLISION_ATTEMPTS * 4) {
            val candidate = candidateFileName(sanitized.base, sanitized.extension, suffix)
            if (!knownExisting.contains(candidate.lowercase(Locale.US))) {
                candidates.add(candidate)
            }
            suffix++
            scanned++
        }
        candidates.add("${sanitized.base}_${System.currentTimeMillis()}${sanitized.extension}")
        return candidates
    }

    fun createPendingVideoEntry(
        context: Context,
        requestedFileName: String,
        contentResolver: ContentResolver = context.contentResolver,
        collectionUris: List<Uri> = defaultVideoCollectionUris(),
        relativePath: String = "${Environment.DIRECTORY_MOVIES}/QuizStudioPro",
        sdkInt: Int = Build.VERSION.SDK_INT
    ): PendingVideoEntry {
        val sanitized = sanitizeFileName(requestedFileName, defaultBase = "quiz-video", forcedExtension = ".mp4")
        val normalizedRelPath = relativePath.trimEnd('/')
        val targetSdk = try {
            context.applicationInfo.targetSdkVersion
        } catch (_: Throwable) {
            -1
        }
        val knownExisting = queryExistingDisplayNames(contentResolver, collectionUris, normalizedRelPath, sdkInt)
        val candidates = buildCandidateNames(sanitized, knownExisting)

        var lastThrowable: Throwable? = null
        var lastCandidate: String = sanitized.fullName
        var lastCollectionUri: Uri? = collectionUris.firstOrNull()
        var lastInsertUri: Uri? = null
        var lastStage = ExportStage.CREATE_ENTRY

        for (collectionUri in collectionUris) {
            lastCollectionUri = collectionUri
            for (candidateName in candidates) {
                lastCandidate = candidateName
                var insertedUri: Uri? = null
                lastStage = ExportStage.CREATE_ENTRY
                try {
                    val values = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, candidateName)
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        if (sdkInt >= Build.VERSION_CODES.Q) {
                            put(MediaStore.Video.Media.RELATIVE_PATH, normalizedRelPath)
                            put(MediaStore.Video.Media.IS_PENDING, 1)
                        }
                    }

                    insertedUri = contentResolver.insert(collectionUri, values)
                    lastInsertUri = insertedUri
                    if (insertedUri == null) {
                        QuizLogger.warn(
                            TAG,
                            "MediaStore insert returned null (sdk=$sdkInt, targetSdk=$targetSdk, collection=$collectionUri, relPath=$normalizedRelPath, candidate=$candidateName)"
                        )
                        continue
                    }

                    lastStage = ExportStage.OPEN_STREAM
                    val stream = contentResolver.openOutputStream(insertedUri, "w")
                        ?: contentResolver.openOutputStream(insertedUri)
                    if (stream == null) {
                        QuizLogger.warn(
                            TAG,
                            "openOutputStream returned null for $insertedUri; deleting pending entry and retrying next candidate"
                        )
                        safeDeleteUri(contentResolver, insertedUri)
                        lastInsertUri = null
                        continue
                    }

                    QuizLogger.info(
                        TAG,
                        "Allocated unique MediaStore video entry",
                        "sdk=$sdkInt targetSdk=$targetSdk requested=${sanitized.fullName} actual=$candidateName collection=$collectionUri uri=$insertedUri relPath=$normalizedRelPath"
                    )
                    return PendingVideoEntry(
                        uri = insertedUri,
                        fileName = candidateName,
                        relativePath = normalizedRelPath,
                        collectionUri = collectionUri,
                        outputStream = stream
                    )
                } catch (e: Throwable) {
                    lastThrowable = e
                    if (insertedUri != null) {
                        safeDeleteUri(contentResolver, insertedUri)
                    }
                    val diag = buildDiagnostics(
                        jobId = "pending_alloc",
                        stage = lastStage,
                        sdkInt = sdkInt,
                        targetSdk = targetSdk,
                        requestedFileName = requestedFileName,
                        candidateFileName = candidateName,
                        collectionUri = collectionUri,
                        relativePath = normalizedRelPath,
                        insertUri = insertedUri,
                        throwable = e
                    )
                    QuizLogger.warn(TAG, "MediaStore entry attempt failed ($candidateName on $collectionUri, stage=$lastStage): ${e::class.java.simpleName}: ${e.message}")
                    if (isOutOfSpaceError(e)) {
                        QuizLogger.error(TAG, "Storage full during MediaStore video creation\n$diag")
                        throw MediaStoreSaveException(
                            userMessage = "Not enough device storage space to save the exported MP4 video.",
                            diagnosticDetails = diag,
                            cause = e,
                            stage = lastStage
                        )
                    }
                    if (!isRetryableCollectionOrCollisionError(e)) {
                        if (collectionUri != collectionUris.last()) {
                            break
                        }
                        QuizLogger.error(TAG, "Non-retryable MediaStore failure\n$diag")
                        throw MediaStoreSaveException(
                            userMessage = "Could not create the output MP4 file in $normalizedRelPath. Please check storage permissions and available space.",
                            diagnosticDetails = diag,
                            cause = e,
                            stage = lastStage
                        )
                    }
                }
            }
        }

        val finalDiag = buildDiagnostics(
            jobId = "pending_alloc",
            stage = lastStage,
            sdkInt = sdkInt,
            targetSdk = targetSdk,
            requestedFileName = requestedFileName,
            candidateFileName = lastCandidate,
            collectionUri = lastCollectionUri,
            relativePath = normalizedRelPath,
            insertUri = lastInsertUri,
            throwable = lastThrowable
        )
        QuizLogger.error(TAG, "Exhausted all unique filename candidates for MediaStore video export\n$finalDiag")
        throw MediaStoreSaveException(
            userMessage = "Unable to create output MP4 file in $normalizedRelPath after multiple attempts. Please check storage and try again.",
            diagnosticDetails = finalDiag,
            cause = lastThrowable,
            stage = lastStage
        )
    }

    fun publishPendingEntry(
        contentResolver: ContentResolver,
        uri: Uri,
        sdkInt: Int = Build.VERSION.SDK_INT
    ) {
        if (sdkInt >= Build.VERSION_CODES.Q) {
            val updateValues = ContentValues().apply {
                put(MediaStore.Video.Media.IS_PENDING, 0)
            }
            val updatedRows = contentResolver.update(uri, updateValues, null, null)
            if (updatedRows <= 0) {
                throw IllegalStateException("MediaStore IS_PENDING=0 update affected 0 rows for $uri")
            }
        }
    }

    fun verifyPublishedUriReadable(
        contentResolver: ContentResolver,
        uri: Uri,
        expectedMinBytes: Long = 1L
    ): Long {
        var verifiedBytes = -1L
        var openErr: Throwable? = null
        try {
            contentResolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                val declaredLen = afd.length
                afd.createInputStream().use { ins ->
                    val head = ByteArray(16)
                    val n = ins.read(head)
                    if (n <= 0) {
                        throw IOException("Published MediaStore URI stream returned 0 readable bytes: $uri")
                    }
                    verifiedBytes = if (declaredLen > 0L) declaredLen else n.toLong()
                }
            }
        } catch (e: IOException) {
            throw e
        } catch (t: Throwable) {
            openErr = t
        }

        if (verifiedBytes < 0L) {
            val fallbackStream = try {
                contentResolver.openInputStream(uri)
            } catch (t: Throwable) {
                openErr = openErr ?: t
                null
            }
            fallbackStream?.use { ins ->
                val head = ByteArray(16)
                val n = ins.read(head)
                if (n <= 0) {
                    throw IOException("Published MediaStore URI openInputStream returned 0 bytes: $uri")
                }
                verifiedBytes = n.toLong()
            } ?: throw IOException(
                "Unable to open published MediaStore URI for verification: $uri (${openErr?.message ?: "null stream"})",
                openErr
            )
        }

        if (expectedMinBytes > 0L && verifiedBytes in 0L until minOf(8L, expectedMinBytes)) {
            throw IOException("Published MediaStore URI truncated ($verifiedBytes bytes < $expectedMinBytes): $uri")
        }
        return verifiedBytes
    }

    fun saveVideoFile(
        context: Context,
        sourceFile: File,
        requestedFileName: String,
        contentResolver: ContentResolver = context.contentResolver,
        collectionUris: List<Uri> = defaultVideoCollectionUris(),
        relativePath: String = "${Environment.DIRECTORY_MOVIES}/QuizStudioPro",
        sdkInt: Int = Build.VERSION.SDK_INT,
        jobId: String = "save_${System.currentTimeMillis()}",
        encoderSummary: String = "",
        availableSpaceBytesProvider: (() -> Long?)? = null,
        verifyPublishedReadable: Boolean = true
    ): SavedVideoResult {
        val targetSdk = try {
            context.applicationInfo.targetSdkVersion
        } catch (_: Throwable) {
            -1
        }
        val normalizedRelPath = relativePath.trimEnd('/')

        if (!sourceFile.exists() || sourceFile.length() <= 0L) {
            throw MediaStoreSaveException(
                userMessage = "Encoded temporary MP4 video is missing or empty.",
                diagnosticDetails = buildDiagnostics(
                    jobId = jobId,
                    stage = ExportStage.VERIFY_COPIED_SIZE,
                    sdkInt = sdkInt,
                    targetSdk = targetSdk,
                    requestedFileName = requestedFileName,
                    candidateFileName = requestedFileName,
                    collectionUri = collectionUris.firstOrNull(),
                    relativePath = normalizedRelPath,
                    insertUri = null,
                    sourceSizeBytes = sourceFile.length(),
                    encoderSummary = encoderSummary,
                    throwable = IOException("Missing or empty sourceFile ${sourceFile.absolutePath}")
                ),
                stage = ExportStage.VERIFY_COPIED_SIZE,
                jobId = jobId
            )
        }

        val sourceSize = sourceFile.length()
        val availBytes = availableSpaceBytesProvider?.invoke() ?: checkAvailableStorageBytes(context)
        val requiredWithMargin = sourceSize + minOf(sourceSize, 4L * 1024L * 1024L)
        if (availBytes != null && availBytes < requiredWithMargin) {
            val freeMb = availBytes / (1024L * 1024L)
            val needMb = (requiredWithMargin + (1024L * 1024L - 1)) / (1024L * 1024L)
            val diag = buildDiagnostics(
                jobId = jobId,
                stage = ExportStage.SPACE_CHECK,
                sdkInt = sdkInt,
                targetSdk = targetSdk,
                requestedFileName = requestedFileName,
                candidateFileName = requestedFileName,
                collectionUri = collectionUris.firstOrNull(),
                relativePath = normalizedRelPath,
                insertUri = null,
                availableSpaceBytes = availBytes,
                sourceSizeBytes = sourceSize,
                encoderSummary = encoderSummary,
                throwable = IOException("Insufficient storage: free=$availBytes needed=$requiredWithMargin")
            )
            QuizLogger.error(TAG, "[$jobId] Storage space check failed\n$diag")
            throw MediaStoreSaveException(
                userMessage = "Not enough free storage space (${freeMb} MB available, need ~${needMb} MB) to save the MP4 video.",
                diagnosticDetails = diag,
                stage = ExportStage.SPACE_CHECK,
                jobId = jobId
            )
        }

        val sanitized = sanitizeFileName(requestedFileName, defaultBase = "quiz-video", forcedExtension = ".mp4")
        val knownExisting = queryExistingDisplayNames(contentResolver, collectionUris, normalizedRelPath, sdkInt)
        val candidates = buildCandidateNames(sanitized, knownExisting)

        var lastThrowable: Throwable? = null
        var lastStage = ExportStage.CREATE_ENTRY
        var lastCandidate = sanitized.fullName
        var lastCollectionUri: Uri? = collectionUris.firstOrNull()
        var lastInsertUri: Uri? = null
        var lastCopiedBytes = 0L
        var lastVerifiedBytes = -1L
        var writeAttempts = 0

        collectionLoop@ for (collectionUri in collectionUris) {
            lastCollectionUri = collectionUri
            for (candidateName in candidates) {
                lastCandidate = candidateName
                var insertedUri: Uri? = null
                var attemptStage = ExportStage.CREATE_ENTRY
                var totalWritten = 0L
                var verifiedReadableBytes = -1L

                try {
                    val values = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, candidateName)
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        if (sdkInt >= Build.VERSION_CODES.Q) {
                            put(MediaStore.Video.Media.RELATIVE_PATH, normalizedRelPath)
                            put(MediaStore.Video.Media.IS_PENDING, 1)
                        }
                    }

                    insertedUri = contentResolver.insert(collectionUri, values)
                    lastInsertUri = insertedUri
                    if (insertedUri == null) {
                        QuizLogger.warn(TAG, "[$jobId] CREATE_ENTRY returned null for $candidateName on $collectionUri")
                        continue
                    }

                    attemptStage = ExportStage.OPEN_STREAM
                    val outStream = contentResolver.openOutputStream(insertedUri, "w")
                        ?: contentResolver.openOutputStream(insertedUri)
                    if (outStream == null) {
                        QuizLogger.warn(TAG, "[$jobId] OPEN_STREAM returned null for $insertedUri; deleting pending URI and retrying")
                        safeDeleteUri(contentResolver, insertedUri)
                        lastInsertUri = null
                        continue
                    }

                    writeAttempts++
                    attemptStage = ExportStage.COPY_BYTES
                    outStream.use { out ->
                        sourceFile.inputStream().use { input ->
                            val buffer = ByteArray(64 * 1024)
                            while (true) {
                                val read = input.read(buffer)
                                if (read <= 0) break
                                out.write(buffer, 0, read)
                                totalWritten += read
                            }
                        }
                        out.flush()
                        if (out is FileOutputStream) {
                            try {
                                out.fd.sync()
                            } catch (_: SyncFailedException) {
                                // FUSE / virtual MediaProvider FDs may ignore fsync; flush + close suffice
                            } catch (_: Throwable) {
                            }
                        }
                    }
                    lastCopiedBytes = totalWritten

                    attemptStage = ExportStage.VERIFY_COPIED_SIZE
                    if (totalWritten <= 0L || totalWritten != sourceSize) {
                        throw IOException("Incomplete write to MediaStore URI $insertedUri: copied=$totalWritten expected=$sourceSize")
                    }

                    attemptStage = ExportStage.PUBLISH_PENDING
                    publishPendingEntry(contentResolver, insertedUri, sdkInt)

                    if (verifyPublishedReadable) {
                        attemptStage = ExportStage.VERIFY_PLAYABLE
                        verifiedReadableBytes = verifyPublishedUriReadable(contentResolver, insertedUri, totalWritten)
                        lastVerifiedBytes = verifiedReadableBytes
                    }

                    QuizLogger.success(
                        TAG,
                        "[$jobId] Exported & verified MP4: path=$normalizedRelPath/$candidateName bytes=$totalWritten verifiedBytes=$verifiedReadableBytes attempts=$writeAttempts uri=$insertedUri"
                    )
                    return SavedVideoResult(
                        uri = insertedUri,
                        fileName = candidateName,
                        relativePath = normalizedRelPath,
                        bytesWritten = totalWritten,
                        jobId = jobId,
                        attemptsUsed = writeAttempts
                    )
                } catch (e: Throwable) {
                    lastThrowable = e
                    lastStage = attemptStage
                    lastCopiedBytes = totalWritten
                    safeDeleteUri(contentResolver, insertedUri)

                    val diag = buildDiagnostics(
                        jobId = jobId,
                        stage = attemptStage,
                        sdkInt = sdkInt,
                        targetSdk = targetSdk,
                        requestedFileName = requestedFileName,
                        candidateFileName = candidateName,
                        collectionUri = collectionUri,
                        relativePath = normalizedRelPath,
                        insertUri = insertedUri,
                        availableSpaceBytes = availBytes,
                        sourceSizeBytes = sourceSize,
                        copiedBytes = totalWritten,
                        verifiedStreamBytes = verifiedReadableBytes,
                        encoderSummary = encoderSummary,
                        throwable = e
                    )
                    QuizLogger.warn(
                        TAG,
                        "[$jobId] Save attempt failed at stage=$attemptStage ($candidateName on $collectionUri, writeAttempts=$writeAttempts): ${e::class.java.simpleName}: ${e.message}"
                    )

                    if (isOutOfSpaceError(e)) {
                        QuizLogger.error(TAG, "[$jobId] Out of storage space at stage=$attemptStage\n$diag")
                        throw MediaStoreSaveException(
                            userMessage = "Not enough device storage space to finish saving the MP4 video.",
                            diagnosticDetails = diag,
                            cause = e,
                            stage = attemptStage,
                            jobId = jobId
                        )
                    }

                    val canRetryWriteOrCollision =
                        attemptStage == ExportStage.CREATE_ENTRY && isRetryableCollectionOrCollisionError(e) ||
                            (writeAttempts < MAX_WRITE_PUBLISH_RETRIES && (
                                isRetryableCollectionOrCollisionError(e) ||
                                    attemptStage == ExportStage.PUBLISH_PENDING ||
                                    attemptStage == ExportStage.OPEN_STREAM
                                ))

                    if (!canRetryWriteOrCollision) {
                        if (collectionUri != collectionUris.last() && writeAttempts < MAX_WRITE_PUBLISH_RETRIES) {
                            continue@collectionLoop
                        }
                        QuizLogger.error(TAG, "[$jobId] Non-retryable save failure at stage=$attemptStage\n$diag")
                        throw MediaStoreSaveException(
                            userMessage = buildUserFriendlyFailureMessage(attemptStage, normalizedRelPath, totalWritten, sourceSize),
                            diagnosticDetails = diag,
                            cause = e,
                            stage = attemptStage,
                            jobId = jobId
                        )
                    }
                }
            }
        }

        val finalDiag = buildDiagnostics(
            jobId = jobId,
            stage = lastStage,
            sdkInt = sdkInt,
            targetSdk = targetSdk,
            requestedFileName = requestedFileName,
            candidateFileName = lastCandidate,
            collectionUri = lastCollectionUri,
            relativePath = normalizedRelPath,
            insertUri = lastInsertUri,
            availableSpaceBytes = availBytes,
            sourceSizeBytes = sourceSize,
            copiedBytes = lastCopiedBytes,
            verifiedStreamBytes = lastVerifiedBytes,
            encoderSummary = encoderSummary,
            throwable = lastThrowable
        )
        QuizLogger.error(TAG, "[$jobId] Exhausted save retry attempts at stage=$lastStage\n$finalDiag")
        throw MediaStoreSaveException(
            userMessage = buildUserFriendlyFailureMessage(lastStage, normalizedRelPath, lastCopiedBytes, sourceSize),
            diagnosticDetails = finalDiag,
            cause = lastThrowable,
            stage = lastStage,
            jobId = jobId
        )
    }

    private fun buildUserFriendlyFailureMessage(
        stage: ExportStage,
        relativePath: String,
        copiedBytes: Long,
        expectedBytes: Long
    ): String = when (stage) {
        ExportStage.SPACE_CHECK ->
            "Not enough device storage space to save the exported MP4 video."
        ExportStage.CREATE_ENTRY, ExportStage.OPEN_STREAM ->
            "Could not create or open the MP4 file in $relativePath. Please check storage space and try again."
        ExportStage.COPY_BYTES, ExportStage.VERIFY_COPIED_SIZE ->
            "Failed to finish writing MP4 bytes to $relativePath ($copiedBytes/$expectedBytes bytes). Please try again."
        ExportStage.PUBLISH_PENDING ->
            "Could not finalize the MP4 video entry in $relativePath. Please try again."
        ExportStage.VERIFY_PLAYABLE ->
            "Saved MP4 file in $relativePath could not be verified as readable. Please try again."
    }

    fun saveDocumentBytes(
        context: Context,
        requestedFileName: String,
        mimeType: String,
        bytes: ByteArray,
        contentResolver: ContentResolver = context.contentResolver,
        collectionUris: List<Uri> = defaultDownloadCollectionUris(),
        relativePath: String = "${Environment.DIRECTORY_DOWNLOADS}/QuizStudioPro",
        sdkInt: Int = Build.VERSION.SDK_INT
    ): SavedDocumentResult {
        val rawLeaf = requestedFileName.trim().substringAfterLast('/').substringAfterLast('\\')
        val ext = rawLeaf.substringAfterLast('.', "").let {
            val clean = it.replace(Regex("[^A-Za-z0-9]"), "").take(10)
            if (clean.isNotEmpty()) ".$clean" else ".json"
        }
        val sanitized = sanitizeFileName(rawLeaf, defaultBase = "export", forcedExtension = ext, maxBaseLength = 72)
        val normalizedRelPath = relativePath.trimEnd('/')
        val knownExisting = queryExistingDisplayNames(contentResolver, collectionUris, normalizedRelPath, sdkInt)
        val candidates = buildCandidateNames(sanitized, knownExisting)

        var lastThrowable: Throwable? = null
        for (collectionUri in collectionUris) {
            for (candidateName in candidates) {
                var insertedUri: Uri? = null
                try {
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, candidateName)
                        put(MediaStore.Downloads.MIME_TYPE, mimeType.ifBlank { "application/octet-stream" })
                        if (sdkInt >= Build.VERSION_CODES.Q) {
                            put(MediaStore.Downloads.RELATIVE_PATH, normalizedRelPath)
                            put(MediaStore.Downloads.IS_PENDING, 1)
                        }
                    }
                    insertedUri = contentResolver.insert(collectionUri, values) ?: continue
                    val stream = contentResolver.openOutputStream(insertedUri, "w")
                        ?: contentResolver.openOutputStream(insertedUri)
                    if (stream == null) {
                        safeDeleteUri(contentResolver, insertedUri)
                        continue
                    }
                    stream.use { out ->
                        out.write(bytes)
                        out.flush()
                    }
                    if (sdkInt >= Build.VERSION_CODES.Q) {
                        val updated = contentResolver.update(
                            insertedUri,
                            ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) },
                            null,
                            null
                        )
                        if (updated <= 0) {
                            throw IllegalStateException("Download IS_PENDING=0 update returned 0 rows")
                        }
                    }
                    return SavedDocumentResult(
                        uri = insertedUri,
                        fileName = candidateName,
                        relativePath = normalizedRelPath,
                        bytesWritten = bytes.size.toLong()
                    )
                } catch (e: Throwable) {
                    lastThrowable = e
                    if (insertedUri != null) {
                        safeDeleteUri(contentResolver, insertedUri)
                    }
                    if (!isRetryableCollectionOrCollisionError(e)) {
                        break
                    }
                }
            }
        }
        throw MediaStoreSaveException(
            userMessage = "Could not save document file to $normalizedRelPath.",
            diagnosticDetails = lastThrowable?.stackTraceToString() ?: "Unknown document MediaStore error",
            cause = lastThrowable
        )
    }

    fun safeDeleteUri(contentResolver: ContentResolver, uri: Uri?) {
        if (uri == null) return
        try {
            contentResolver.delete(uri, null, null)
        } catch (e: Throwable) {
            QuizLogger.warn(TAG, "Cleanup delete skipped for $uri: ${e.message}")
        }
    }

    internal fun isRetryableCollectionOrCollisionError(t: Throwable): Boolean {
        if (t is IllegalStateException || t is SQLiteConstraintException || t is IllegalArgumentException) {
            return true
        }
        val msg = (t.message ?: "").lowercase(Locale.US)
        return msg.contains("unique") ||
            msg.contains("exist") ||
            msg.contains("eexist") ||
            msg.contains("duplicate") ||
            msg.contains("pending") ||
            msg.contains("constraint") ||
            msg.contains("build") ||
            msg.contains("collision") ||
            msg.contains("rename") ||
            msg.contains("0 rows")
    }

    private fun isOutOfSpaceError(t: Throwable): Boolean {
        var cur: Throwable? = t
        while (cur != null) {
            val msg = (cur.message ?: "").lowercase(Locale.US)
            if (msg.contains("enospc") || msg.contains("no space left")) return true
            cur = cur.cause
        }
        return false
    }

    private fun buildDiagnostics(
        jobId: String,
        stage: ExportStage,
        sdkInt: Int,
        targetSdk: Int,
        requestedFileName: String,
        candidateFileName: String,
        collectionUri: Uri?,
        relativePath: String,
        insertUri: Uri?,
        availableSpaceBytes: Long? = null,
        sourceSizeBytes: Long = -1L,
        copiedBytes: Long = -1L,
        verifiedStreamBytes: Long = -1L,
        encoderSummary: String = "",
        throwable: Throwable?
    ): String {
        val trace = throwable?.let { Log.getStackTraceString(it).ifBlank { it.stackTraceToString() } } ?: "none"
        return buildString {
            append("jobId=").append(jobId)
            append(" stage=").append(stage.name)
            append(" androidSdk=").append(sdkInt)
            append(" release=").append(Build.VERSION.RELEASE ?: "unknown")
            append(" targetSdk=").append(targetSdk)
            append(" requestedFileName=").append(requestedFileName)
            append(" candidateFileName=").append(candidateFileName)
            append(" collectionUri=").append(collectionUri)
            append(" relativePath=").append(relativePath)
            append(" insertUri=").append(insertUri)
            append(" availableSpaceBytes=").append(availableSpaceBytes ?: -1L)
            append(" sourceSizeBytes=").append(sourceSizeBytes)
            append(" copiedBytes=").append(copiedBytes)
            append(" verifiedStreamBytes=").append(verifiedStreamBytes)
            if (encoderSummary.isNotBlank()) {
                append(" encoder=").append(encoderSummary)
            }
            append(" exceptionClass=").append(throwable?.javaClass?.name ?: "none")
            append(" exceptionMessage=").append(throwable?.message ?: "none")
            append("\nstackTrace=").append(trace)
        }
    }
}
