package com.quizstudiopro.app.video

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.os.Build
import com.quizstudiopro.app.logging.QuizLogger
import org.json.JSONArray
import org.json.JSONObject

/**
 * Hardware-verified MediaCodec selector and capability probe.
 *
 * Inspects [MediaCodecList] (`isHardwareAccelerated`, `isSoftwareOnly`, `CodecCapabilities`,
 * resolution/fps limits, bitrate bounds, and AVC profiles), prioritizes verified hardware
 * encoders, supports up to 1440p without silently downgrading user-selected quality, and
 * provides structured JSON diagnostics + HW vs SW benchmark utility.
 */
object HardwareCodecSelector {
    private const val TAG = "HardwareCodecSelector"

    data class CodecCandidate(
        val name: String,
        val mimeType: String,
        val isHardwareAccelerated: Boolean,
        val isSoftwareOnly: Boolean,
        val isVendor: Boolean,
        val supportsSurfaceInput: Boolean,
        val supportsSizeAndRate: Boolean,
        val minBitrate: Int,
        val maxBitrate: Int,
        val maxSupportedWidth: Int,
        val maxSupportedHeight: Int,
        val selectedBitrate: Int,
        val avcProfile: Int?
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("name", name)
            put("mimeType", mimeType)
            put("isHardwareAccelerated", isHardwareAccelerated)
            put("isSoftwareOnly", isSoftwareOnly)
            put("isVendor", isVendor)
            put("supportsSurfaceInput", supportsSurfaceInput)
            put("supportsSizeAndRate", supportsSizeAndRate)
            put("minBitrate", minBitrate)
            put("maxBitrate", maxBitrate)
            put("maxSupportedWidth", maxSupportedWidth)
            put("maxSupportedHeight", maxSupportedHeight)
            put("selectedBitrate", selectedBitrate)
            if (avcProfile != null) put("avcProfile", avcProfile)
        }
    }

    data class EncoderCreationResult(
        val codec: MediaCodec,
        val candidate: CodecCandidate?,
        val name: String,
        val isHardwareAccelerated: Boolean?,
        val fallbackReason: String?
    )

    fun computeTargetBitrate(width: Int, height: Int): Int {
        val longEdge = maxOf(width, height)
        val shortEdge = minOf(width, height)
        return when {
            shortEdge >= 1440 || longEdge >= 2560 -> 16_000_000
            shortEdge >= 1080 || longEdge >= 1920 -> 10_000_000
            shortEdge >= 720 || longEdge >= 1280 -> 6_000_000
            else -> 3_500_000
        }
    }

    fun isKnownSoftwareCodecName(name: String): Boolean {
        val lower = name.lowercase()
        return lower.startsWith("omx.google.") ||
            lower.startsWith("c2.android.") ||
            lower.contains(".sw.") ||
            lower.contains("ffmpeg")
    }

    enum class InputMode {
        SURFACE,
        BYTE_BUFFER_YUV420
    }

    enum class CodecTier {
        HW_SURFACE_PRIMARY,
        HW_SURFACE_ALT_PROFILE,
        SW_SURFACE,
        SW_BYTEBUFFER_YUV420
    }

    data class EncoderAttemptSpec(
        val tier: CodecTier,
        val codecName: String?,
        val isHardwareAccelerated: Boolean,
        val inputMode: InputMode,
        val bitrate: Int,
        val avcProfile: Int?,
        val includeProfileKey: Boolean,
        val yuvColorFormat: Int? = null,
        val label: String
    ) {
        fun shortDescriptor(): String = buildString {
            append(tier.name)
            append("(")
            append(codecName ?: "default")
            append(", ")
            append(inputMode.name)
            if (includeProfileKey && avcProfile != null) {
                append(", profile=").append(avcProfile)
            } else {
                append(", profile=auto")
            }
            if (yuvColorFormat != null) {
                append(", fmt=").append(yuvColorFormat)
            }
            append(", br=").append(bitrate / 1000).append("kbps)")
        }
    }

    private data class RawCodecMeta(
        val candidate: CodecCandidate,
        val colorFormats: IntArray,
        val profiles: List<Int>
    )

    private fun inspectRawEncoders(
        mimeType: String = MediaFormat.MIMETYPE_VIDEO_AVC,
        width: Int = 1920,
        height: Int = 1080,
        fps: Int = 24
    ): List<RawCodecMeta> {
        val out = ArrayList<RawCodecMeta>()
        val targetBitrate = computeTargetBitrate(width, height)
        val codecList = try {
            MediaCodecList(MediaCodecList.REGULAR_CODECS)
        } catch (_: Throwable) {
            return out
        }

        for (info in codecList.codecInfos) {
            if (!info.isEncoder) continue
            if (!info.supportedTypes.any { it.equals(mimeType, ignoreCase = true) }) continue

            val isHw = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                info.isHardwareAccelerated
            } else {
                !isKnownSoftwareCodecName(info.name)
            }
            val isSw = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                info.isSoftwareOnly
            } else {
                isKnownSoftwareCodecName(info.name)
            }
            val isVendor = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) info.isVendor else !isSw

            val caps = try {
                info.getCapabilitiesForType(mimeType)
            } catch (_: Throwable) {
                null
            }

            val colorFormats = caps?.colorFormats ?: intArrayOf(MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            val supportsSurface = colorFormats.contains(MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)

            val vCaps = caps?.videoCapabilities
            val sizeAndRateOk = if (vCaps != null) {
                try {
                    vCaps.isSizeSupported(width, height) && vCaps.areSizeAndRateSupported(width, height, fps.toDouble())
                } catch (_: Throwable) {
                    true
                }
            } else {
                true
            }

            val bitrateRange = vCaps?.bitrateRange
            val minB = bitrateRange?.lower ?: 250_000
            val maxB = bitrateRange?.upper ?: 40_000_000
            val clampedBitrate = targetBitrate.coerceIn(minB, maxB)
            val maxW = vCaps?.supportedWidths?.upper ?: 3840
            val maxH = vCaps?.supportedHeights?.upper ?: 2160
            val profs = caps?.profileLevels?.map { it.profile }?.distinct() ?: emptyList()

            val profile = when {
                profs.contains(MediaCodecInfo.CodecProfileLevel.AVCProfileHigh) -> MediaCodecInfo.CodecProfileLevel.AVCProfileHigh
                profs.contains(MediaCodecInfo.CodecProfileLevel.AVCProfileMain) -> MediaCodecInfo.CodecProfileLevel.AVCProfileMain
                profs.contains(MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline) -> MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline
                else -> profs.firstOrNull()
            }

            out.add(
                RawCodecMeta(
                    candidate = CodecCandidate(
                        name = info.name,
                        mimeType = mimeType,
                        isHardwareAccelerated = isHw && !isSw,
                        isSoftwareOnly = isSw,
                        isVendor = isVendor,
                        supportsSurfaceInput = supportsSurface,
                        supportsSizeAndRate = sizeAndRateOk,
                        minBitrate = minB,
                        maxBitrate = maxB,
                        maxSupportedWidth = maxW,
                        maxSupportedHeight = maxH,
                        selectedBitrate = clampedBitrate,
                        avcProfile = profile
                    ),
                    colorFormats = colorFormats,
                    profiles = profs
                )
            )
        }

        return out.sortedWith(
            compareByDescending<RawCodecMeta> { it.candidate.isHardwareAccelerated && !it.candidate.isSoftwareOnly }
                .thenByDescending { it.candidate.supportsSurfaceInput && it.candidate.supportsSizeAndRate }
                .thenByDescending { it.candidate.isVendor }
                .thenBy { it.candidate.isSoftwareOnly }
        )
    }

    /**
     * Inspects all encoders matching [mimeType] against target [width], [height], and [fps].
     */
    fun inspectEncoders(
        mimeType: String = MediaFormat.MIMETYPE_VIDEO_AVC,
        width: Int = 1920,
        height: Int = 1080,
        fps: Int = 24
    ): List<CodecCandidate> = inspectRawEncoders(mimeType, width, height, fps).map { it.candidate }

    /**
     * Builds a bounded, ordered encoder attempt ladder at the exact requested [width], [height],
     * and [fps] (never downscaling resolution):
     * 1. Preferred HW Surface encoder + caps-preferred profile
     * 2. HW Surface alternate profile/bitrate fallbacks (Main, Baseline, unset profile, alternate HW codecs)
     * 3. Software Surface encoders (isSoftwareOnly / c2.android.avc.encoder / OMX.google.h264.encoder)
     * 4. CPU ByteBuffer YUV420 encoders (no EGL Surface required)
     */
    fun buildEncoderAttemptLadder(
        width: Int,
        height: Int,
        fps: Int,
        mimeType: String = MediaFormat.MIMETYPE_VIDEO_AVC
    ): List<EncoderAttemptSpec> {
        val rawList = inspectRawEncoders(mimeType, width, height, fps)
        val targetBitrate = computeTargetBitrate(width, height)
        val conservativeBitrate = (targetBitrate * 0.72).toInt().coerceAtLeast(1_500_000)
        val attempts = ArrayList<EncoderAttemptSpec>()
        val seenKeys = HashSet<String>()

        fun addAttempt(spec: EncoderAttemptSpec) {
            val key = "${spec.tier.name}|${spec.codecName ?: "*"}|${spec.inputMode.name}|${spec.includeProfileKey}|${spec.avcProfile ?: -1}|${spec.yuvColorFormat ?: -1}|${spec.bitrate}"
            if (seenKeys.add(key)) {
                attempts.add(spec)
            }
        }

        val hwSurfaceMetas = rawList.filter { it.candidate.isHardwareAccelerated && it.candidate.supportsSurfaceInput }
        val swSurfaceMetas = rawList.filter { it.candidate.isSoftwareOnly && it.candidate.supportsSurfaceInput }

        // Tier 1: Primary HW Surface encoder with preferred profile & bitrate
        hwSurfaceMetas.firstOrNull()?.let { primary ->
            val c = primary.candidate
            addAttempt(
                EncoderAttemptSpec(
                    tier = CodecTier.HW_SURFACE_PRIMARY,
                    codecName = c.name,
                    isHardwareAccelerated = true,
                    inputMode = InputMode.SURFACE,
                    bitrate = c.selectedBitrate,
                    avcProfile = c.avcProfile,
                    includeProfileKey = c.avcProfile != null,
                    label = "Tier 1: Hardware Surface (${c.name})"
                )
            )
        }

        // Tier 2: HW Surface profile & conservative bitrate fallbacks + alternate HW encoders
        for (meta in hwSurfaceMetas) {
            val c = meta.candidate
            val consB = conservativeBitrate.coerceIn(c.minBitrate, c.maxBitrate)
            // Omit KEY_PROFILE (safest fallback on vendor drivers that reject explicit profile+level combos at 1080p)
            addAttempt(
                EncoderAttemptSpec(
                    tier = CodecTier.HW_SURFACE_ALT_PROFILE,
                    codecName = c.name,
                    isHardwareAccelerated = true,
                    inputMode = InputMode.SURFACE,
                    bitrate = consB,
                    avcProfile = null,
                    includeProfileKey = false,
                    label = "Tier 2: Hardware Surface Auto-Profile (${c.name})"
                )
            )
            if (meta.profiles.contains(MediaCodecInfo.CodecProfileLevel.AVCProfileMain)) {
                addAttempt(
                    EncoderAttemptSpec(
                        tier = CodecTier.HW_SURFACE_ALT_PROFILE,
                        codecName = c.name,
                        isHardwareAccelerated = true,
                        inputMode = InputMode.SURFACE,
                        bitrate = consB,
                        avcProfile = MediaCodecInfo.CodecProfileLevel.AVCProfileMain,
                        includeProfileKey = true,
                        label = "Tier 2: Hardware Surface Main Profile (${c.name})"
                    )
                )
            }
            if (meta.profiles.contains(MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline)) {
                addAttempt(
                    EncoderAttemptSpec(
                        tier = CodecTier.HW_SURFACE_ALT_PROFILE,
                        codecName = c.name,
                        isHardwareAccelerated = true,
                        inputMode = InputMode.SURFACE,
                        bitrate = consB,
                        avcProfile = MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline,
                        includeProfileKey = true,
                        label = "Tier 2: Hardware Surface Baseline Profile (${c.name})"
                    )
                )
            }
        }

        // Tier 3: Software Surface encoders
        for (meta in swSurfaceMetas) {
            val c = meta.candidate
            val consB = conservativeBitrate.coerceIn(c.minBitrate, c.maxBitrate)
            addAttempt(
                EncoderAttemptSpec(
                    tier = CodecTier.SW_SURFACE,
                    codecName = c.name,
                    isHardwareAccelerated = false,
                    inputMode = InputMode.SURFACE,
                    bitrate = consB,
                    avcProfile = null,
                    includeProfileKey = false,
                    label = "Tier 3: Software Surface (${c.name})"
                )
            )
        }
        // Always include well-known Android SW Surface names as safety net if absent from MediaCodecList scan
        for (swName in listOf("c2.android.avc.encoder", "OMX.google.h264.encoder")) {
            if (swSurfaceMetas.none { it.candidate.name.equals(swName, ignoreCase = true) }) {
                addAttempt(
                    EncoderAttemptSpec(
                        tier = CodecTier.SW_SURFACE,
                        codecName = swName,
                        isHardwareAccelerated = false,
                        inputMode = InputMode.SURFACE,
                        bitrate = conservativeBitrate,
                        avcProfile = null,
                        includeProfileKey = false,
                        label = "Tier 3: Software Surface ($swName)"
                    )
                )
            }
        }

        // Tier 4: Software / CPU ByteBuffer YUV420 encoders (zero EGL Surface dependency)
        val yuvPriority = intArrayOf(
            MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible,
            MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar,
            MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar
        )
        val swAllMetas = rawList.filter { it.candidate.isSoftwareOnly }
        for (meta in swAllMetas) {
            val c = meta.candidate
            val consB = conservativeBitrate.coerceIn(c.minBitrate, c.maxBitrate)
            val matchedFmt = yuvPriority.firstOrNull { meta.colorFormats.contains(it) }
                ?: MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible
            addAttempt(
                EncoderAttemptSpec(
                    tier = CodecTier.SW_BYTEBUFFER_YUV420,
                    codecName = c.name,
                    isHardwareAccelerated = false,
                    inputMode = InputMode.BYTE_BUFFER_YUV420,
                    bitrate = consB,
                    avcProfile = null,
                    includeProfileKey = false,
                    yuvColorFormat = matchedFmt,
                    label = "Tier 4: CPU ByteBuffer YUV420 (${c.name})"
                )
            )
        }
        // Fallback explicit SW ByteBuffer specs if MediaCodecList omitted them
        addAttempt(
            EncoderAttemptSpec(
                tier = CodecTier.SW_BYTEBUFFER_YUV420,
                codecName = "c2.android.avc.encoder",
                isHardwareAccelerated = false,
                inputMode = InputMode.BYTE_BUFFER_YUV420,
                bitrate = conservativeBitrate,
                avcProfile = null,
                includeProfileKey = false,
                yuvColorFormat = MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible,
                label = "Tier 4: CPU ByteBuffer YUV420 (c2.android.avc.encoder)"
            )
        )
        addAttempt(
            EncoderAttemptSpec(
                tier = CodecTier.SW_BYTEBUFFER_YUV420,
                codecName = "OMX.google.h264.encoder",
                isHardwareAccelerated = false,
                inputMode = InputMode.BYTE_BUFFER_YUV420,
                bitrate = conservativeBitrate,
                avcProfile = null,
                includeProfileKey = false,
                yuvColorFormat = MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar,
                label = "Tier 4: CPU ByteBuffer YUV420 (OMX.google.h264.encoder)"
            )
        )

        // Bound total native retry attempts to prevent runaway waits
        return if (attempts.size <= 10) attempts else attempts.take(10)
    }

    fun createCodecForAttempt(
        spec: EncoderAttemptSpec,
        mimeType: String = MediaFormat.MIMETYPE_VIDEO_AVC
    ): MediaCodec {
        return if (!spec.codecName.isNullOrBlank()) {
            MediaCodec.createByCodecName(spec.codecName)
        } else {
            MediaCodec.createEncoderByType(mimeType)
        }
    }

    fun configureVideoFormat(
        spec: EncoderAttemptSpec,
        width: Int,
        height: Int,
        fps: Int,
        gopSeconds: Int = 2
    ): MediaFormat {
        val colorFormat = when (spec.inputMode) {
            InputMode.SURFACE -> MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
            InputMode.BYTE_BUFFER_YUV420 -> spec.yuvColorFormat
                ?: MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible
        }
        return MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, colorFormat)
            setInteger(MediaFormat.KEY_BIT_RATE, spec.bitrate.coerceAtLeast(500_000))
            setInteger(MediaFormat.KEY_FRAME_RATE, fps.coerceIn(10, 60))
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, gopSeconds.coerceIn(1, 5))
            if (spec.includeProfileKey && spec.avcProfile != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                setInteger(MediaFormat.KEY_PROFILE, spec.avcProfile)
            }
        }
    }

    fun selectAndCreateEncoder(
        mimeType: String = MediaFormat.MIMETYPE_VIDEO_AVC,
        width: Int = 1920,
        height: Int = 1080,
        fps: Int = 24
    ): EncoderCreationResult {
        val candidates = inspectEncoders(mimeType, width, height, fps)
        var fallbackReason: String? = null

        for (c in candidates) {
            if (!c.supportsSurfaceInput) continue
            try {
                val codec = MediaCodec.createByCodecName(c.name)
                if (!c.isHardwareAccelerated) {
                    fallbackReason = "No hardware surface-capable encoder accepted creation; using ${c.name}"
                }
                return EncoderCreationResult(
                    codec = codec,
                    candidate = c,
                    name = c.name,
                    isHardwareAccelerated = c.isHardwareAccelerated,
                    fallbackReason = fallbackReason
                )
            } catch (e: Throwable) {
                QuizLogger.warn(TAG, "Encoder ${c.name} create failed: ${e.message}")
            }
        }

        val codec = MediaCodec.createEncoderByType(mimeType)
        val isHw = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            codec.codecInfo.isHardwareAccelerated && !codec.codecInfo.isSoftwareOnly
        } else {
            !isKnownSoftwareCodecName(codec.name)
        }
        return EncoderCreationResult(
            codec = codec,
            candidate = null,
            name = codec.name,
            isHardwareAccelerated = isHw,
            fallbackReason = if (isHw) null else "Selected system default encoder (${codec.name})"
        )
    }

    fun configureVideoFormat(
        width: Int,
        height: Int,
        fps: Int,
        candidate: CodecCandidate?,
        gopSeconds: Int = 2
    ): MediaFormat {
        val bitRate = candidate?.selectedBitrate ?: computeTargetBitrate(width, height)
        return MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps.coerceIn(10, 60))
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, gopSeconds.coerceIn(1, 5))
            if (candidate?.avcProfile != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                setInteger(MediaFormat.KEY_PROFILE, candidate.avcProfile)
            }
        }
    }

    fun getCapabilityReportJson(
        width: Int = 1920,
        height: Int = 1080,
        fps: Int = 24
    ): JSONObject {
        val candidates = inspectEncoders(MediaFormat.MIMETYPE_VIDEO_AVC, width, height, fps)
        val ladder = buildEncoderAttemptLadder(width, height, fps, MediaFormat.MIMETYPE_VIDEO_AVC)
        val hwBest = candidates.firstOrNull { it.isHardwareAccelerated && it.supportsSurfaceInput && it.supportsSizeAndRate }
            ?: candidates.firstOrNull { it.isHardwareAccelerated && it.supportsSurfaceInput }
        val swBest = candidates.firstOrNull { it.isSoftwareOnly && it.supportsSurfaceInput }

        return JSONObject().apply {
            put("requestedWidth", width)
            put("requestedHeight", height)
            put("requestedFps", fps)
            put("hardwareEncoderAvailable", hwBest != null)
            put("preferredHardwareCodec", hwBest?.name ?: JSONObject.NULL)
            put("fallbackSoftwareCodec", swBest?.name ?: JSONObject.NULL)
            put("supports1440p", candidates.any { it.maxSupportedHeight >= 1440 || it.maxSupportedWidth >= 2560 })
            put("attemptLadderCount", ladder.size)
            put("candidates", JSONArray().apply {
                candidates.forEach { put(it.toJson()) }
            })
        }
    }
}
