package com.quizstudiopro.app.video

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/**
 * Intelligent Frame Deduplication & Variable-Frame-Rate (VFR) Scheduler for Native Video Export.
 *
 * Implements static/dynamic scene state signature analysis (`isDyn`, `sigAt`, `prevDyn`, `prevSig`,
 * `lastSub`) so static holds (settled answer reveals, pauses between word/char reveals,
 * revealEnabled=false intervals, post-animation plateaus, and static countdown states) are skipped
 * while keeping exact MP4 PTS/stts duration parity, GOP keyframe bounds, and anchor frames before
 * resuming motion.
 */
class IntelligentFrameScheduler(
    bundleJson: String,
    private val width: Int,
    private val height: Int,
    private val fps: Int,
    private val totalFrames: Int,
    private val gopSeconds: Int = 2
) {
    data class ScheduledFrame(
        val frameIndex: Int,
        val ptsNs: Long,
        val durationFrames: Int,
        val isKeyFrame: Boolean,
        val reusePreviousRender: Boolean,
        val isDynamic: Boolean,
        val signature: String
    )

    data class ScheduleSummary(
        val totalTimelineFrames: Int,
        val renderedFrames: Int,
        val encodedFrames: Int,
        val skippedFrames: Int,
        val dedupAnchorFrames: Int,
        val skipRatioPercent: Double,
        val frames: List<ScheduledFrame>
    )

    private data class Segment(
        val type: String,
        val qIndex: Int,
        val start: Double,
        val dur: Double
    )

    private val root = JSONObject(bundleJson)
    private val scene = root.optJSONObject("scene") ?: JSONObject()
    private val sceneMode = scene.optString("mode", "DEFAULT_TEMPLATE_MODE")
    private val elements: List<JSONObject> = buildList {
        val arr = scene.optJSONArray("elements") ?: JSONArray()
        for (i in 0 until arr.length()) {
            arr.optJSONObject(i)?.let { add(it) }
        }
    }
    private val hasTimerElement: Boolean = sceneMode != "IMPORTED_TEMPLATE_MODE" ||
        elements.any { it.optBoolean("visible", true) && it.optString("type") == "timer" }

    private val timerDuration: Double = root.optDouble("timerDuration", 10.0).coerceAtLeast(1.0)
    private val revealConfig = root.optJSONObject("revealConfig") ?: JSONObject()
    private val answerRevealConfig = root.optJSONObject("answerRevealConfig") ?: scene.optJSONObject("answerRevealConfig") ?: JSONObject()
    private val transitionConfig = root.optJSONObject("transitionConfig") ?: JSONObject()

    private val questions: List<JSONObject> = buildList {
        val arr = root.optJSONArray("questions") ?: JSONArray()
        for (i in 0 until arr.length()) {
            arr.optJSONObject(i)?.let { add(it) }
        }
    }

    private val segments: List<Segment> = buildList {
        val tl = root.optJSONObject("timeline") ?: JSONObject()
        val arr = tl.optJSONArray("segs") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val s = arr.optJSONObject(i) ?: continue
            add(
                Segment(
                    type = s.optString("type", "voice"),
                    qIndex = s.optInt("i", 0),
                    start = s.optDouble("start", 0.0),
                    dur = s.optDouble("dur", 1.0)
                )
            )
        }
    }

    private var segCursor = 0

    private fun findSegmentAt(gt: Double): Segment? {
        if (segments.isEmpty()) return null
        while (segCursor > 0 && gt < segments[segCursor].start) segCursor--
        while (segCursor < segments.size - 1 && gt >= segments[segCursor].start + segments[segCursor].dur) {
            segCursor++
        }
        return segments[segCursor]
    }

    private fun progressiveCountSignature(fullText: String, frac: Double, style: String): Int {
        if (fullText.isEmpty() || frac <= 0.0) return 0
        if (frac >= 0.999) return fullText.length
        return if (style.contains("char") || style.contains("letter")) {
            ceil(fullText.length * frac).toInt().coerceIn(0, fullText.length)
        } else {
            val words = fullText.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
            if (words.isEmpty()) 0 else ceil(words.size * frac).toInt().coerceIn(0, words.size)
        }
    }

    /**
     * Returns true when `frameIndex` lies inside an actively changing visual interval
     * (page transition, timer movement, active reveal animation, etc.).
     */
    fun isDynamicAt(frameIndex: Int): Boolean {
        if (segments.isEmpty() || questions.isEmpty()) return false
        val safeFps = fps.coerceIn(10, 60)
        val gt = frameIndex.toDouble() / safeFps.toDouble()
        val seg = findSegmentAt(gt) ?: return false
        val lt = max(0.0, gt - seg.start)

        return when (seg.type) {
            "page" -> transitionConfig.optString("style", "classic-page-turn") != "none"
            "count" -> hasTimerElement
            "reveal" -> {
                val ansStyle = answerRevealConfig.optString("style", "correct-only")
                val revRole = revealConfig.optJSONObject("answerReveal")
                val revEnabled = revealConfig.optBoolean("enabled", true)
                val animStyle = answerRevealConfig.optString("animationStyle", revRole?.optString("style", "pop-in") ?: "pop-in")
                val animDur = answerRevealConfig.optDouble("durationSec", revRole?.optDouble("durationSec", 0.38) ?: 0.38)
                revEnabled && animStyle != "none" && lt <= animDur + (1.0 / safeFps)
            }
            "answer" -> {
                val revEnabled = revealConfig.optBoolean("enabled", true)
                val introDur = revealConfig.optJSONObject("answerIntro")?.optDouble("durationSec", 0.35) ?: 0.35
                val introStyle = revealConfig.optJSONObject("answerIntro")?.optString("style", "fade-in") ?: "fade-in"
                // Answer holds stay static once reveal finishes; only dynamic during early answer-intro if present
                revEnabled && introStyle != "none" && lt < 0.05 && introDur > 0.05
            }
            "voice" -> revealConfig.optBoolean("enabled", true)
            else -> false
        }
    }

    /**
     * Computes a deterministic visual state signature at `frameIndex`.
     * Consecutive frames with identical signatures render bit-identical images and can be safely
     * deduplicated when emitting to MediaCodec/MediaMuxer.
     */
    fun signatureAt(frameIndex: Int): String {
        if (segments.isEmpty() || questions.isEmpty()) return "empty"
        val safeFps = fps.coerceIn(10, 60)
        val gt = frameIndex.toDouble() / safeFps.toDouble()
        val seg = findSegmentAt(gt) ?: return "empty"
        val lt = max(0.0, gt - seg.start)
        val qIdx = seg.qIndex.coerceIn(0, questions.size - 1)
        val q = questions[qIdx]

        return when (seg.type) {
            "page" -> {
                val style = transitionConfig.optString("style", "classic-page-turn")
                if (style == "none") {
                    "page_cut|$qIdx"
                } else {
                    val p = (lt / seg.dur.coerceAtLeast(0.001)).coerceIn(0.0, 1.0)
                    val pBucket = (p * width).toInt()
                    "page|$qIdx|$style|$pBucket"
                }
            }
            "count" -> {
                if (!hasTimerElement) {
                    "count_static|$qIdx"
                } else {
                    val rem = max(0.0, seg.dur - lt)
                    // Quantize smoothly to visible bar pixels + integer tick so 1px changes or numeric tick changes always render
                    val frac = (rem / timerDuration.coerceAtLeast(1.0)).coerceIn(0.0, 1.0)
                    val barPx = (frac * (width * 0.6)).toInt()
                    val secCeil = ceil(rem - 1e-5).toInt()
                    "count|$qIdx|$barPx|$secCeil"
                }
            }
            "reveal" -> {
                val revEnabled = revealConfig.optBoolean("enabled", true)
                val revRole = revealConfig.optJSONObject("answerReveal")
                val animStyle = answerRevealConfig.optString("animationStyle", revRole?.optString("style", "pop-in") ?: "pop-in")
                val animDur = answerRevealConfig.optDouble("durationSec", revRole?.optDouble("durationSec", 0.38) ?: 0.38)
                val settle = !revEnabled || animStyle == "none" || lt >= animDur
                if (settle) {
                    "reveal_settled|$qIdx"
                } else {
                    val step = ((lt / animDur.coerceAtLeast(0.05)) * 60.0).toInt()
                    "reveal_anim|$qIdx|$step"
                }
            }
            "answer" -> "reveal_settled|$qIdx"
            "voice" -> {
                val syncEnabled = revealConfig.optBoolean("enabled", true)
                if (!syncEnabled) {
                    "voice_instant|$qIdx"
                } else {
                    val vf = (lt / seg.dur.coerceAtLeast(0.001)).coerceIn(0.0, 1.0)
                    val prefixWords = q.optInt("promptPrefixWords", 0).coerceAtLeast(0)
                    val qStart = if (prefixWords > 0) 0.08 else 0.0
                    val qEnd = 0.42
                    val qStyle = revealConfig.optJSONObject("questionText")?.optString("style", "")
                        ?.ifBlank { null } ?: revealConfig.optString("questionStyle", "typewriter-word")
                    val oStyle = revealConfig.optJSONObject("optionText")?.optString("style", "")
                        ?.ifBlank { null } ?: revealConfig.optString("questionStyle", "typewriter-word")

                    val qFrac = ((vf - qStart) / max(0.1, qEnd - qStart)).coerceIn(0.0, 1.0)
                    val qSig = if (qStyle == "none" || qStyle.startsWith("fade") || qStyle.startsWith("pop") || qStyle.startsWith("scale") || qStyle.startsWith("slide")) {
                        if (qStyle == "none") "full" else (qFrac * 30).toInt().toString()
                    } else {
                        progressiveCountSignature(q.optString("question", ""), qFrac, qStyle).toString()
                    }

                    val opts = q.optJSONArray("options") ?: JSONArray()
                    val optSlots = arrayOf(0.42 to 0.56, 0.56 to 0.70, 0.70 to 0.84, 0.84 to 1.00)
                    val optSigs = IntArray(4) { oi ->
                        val (st, en) = optSlots[oi]
                        val of = ((vf - st) / (en - st)).coerceIn(0.0, 1.0)
                        if (of <= 0.0) -1 else progressiveCountSignature(opts.optString(oi, ""), of, oStyle)
                    }
                    "voice|$qIdx|$qSig|${optSigs[0]}|${optSigs[1]}|${optSigs[2]}|${optSigs[3]}"
                }
            }
            else -> "seg|${seg.type}|$qIdx"
        }
    }

    /**
     * Generates the deduplicated list of frames to encode with valid PTS timestamps, GOP keyframes,
     * pre-motion anchor frames (`lastSub = f - 1`), and closing end-of-timeline frame.
     */
    fun buildSchedule(): ScheduleSummary {
        if (totalFrames <= 0) {
            return ScheduleSummary(0, 0, 0, 0, 0, 0.0, emptyList())
        }
        val safeFps = fps.coerceIn(10, 60)
        val maxHoldFrames = max(safeFps, gopSeconds.coerceIn(1, 5) * safeFps)
        val rawEmit = ArrayList<RawEmission>(totalFrames / 2 + 4)

        var prevDyn = true
        var prevSig = ""
        var lastEmitted = -1
        var lastKeyCandidate = 0

        for (f in 0 until totalFrames) {
            val dyn = isDynamicAt(f)
            val sig = signatureAt(f)
            val isFirst = f == 0
            val isLast = f == totalFrames - 1
            val sigChanged = sig != prevSig
            val holdExpired = (f - lastKeyCandidate) >= maxHoldFrames

            if (isFirst) {
                rawEmit.add(RawEmission(f, reuse = false, dyn = dyn, sig = sig, isAnchor = false))
                lastEmitted = f
                lastKeyCandidate = f
                prevDyn = dyn
                prevSig = sig
                continue
            }

            if (dyn || sigChanged) {
                // Before resuming dynamics or transitioning after a static skip, emit lastSub = f - 1
                // reusing the previous GPU FBO so MediaMuxer preserves exact sample duration for the held period.
                val lastSub = f - 1
                if (lastSub > lastEmitted && (!prevDyn || sigChanged)) {
                    rawEmit.add(RawEmission(lastSub, reuse = true, dyn = false, sig = prevSig, isAnchor = true))
                    lastEmitted = lastSub
                    if ((lastSub - lastKeyCandidate) >= maxHoldFrames) lastKeyCandidate = lastSub
                }
                rawEmit.add(
                    RawEmission(
                        f,
                        reuse = !sigChanged,
                        dyn = dyn,
                        sig = sig,
                        isAnchor = false
                    )
                )
                lastEmitted = f
                if ((f - lastKeyCandidate) >= maxHoldFrames) lastKeyCandidate = f
            } else if (holdExpired || isLast) {
                // GOP keep-alive or closing final frame: reuse previous GPU FBO directly (0 re-render!)
                rawEmit.add(RawEmission(f, reuse = true, dyn = false, sig = sig, isAnchor = isLast && !sigChanged))
                lastEmitted = f
                if (holdExpired) lastKeyCandidate = f
            }

            prevDyn = dyn
            prevSig = sig
        }

        // Convert to ScheduledFrame with durationFrames and GOP keyframe hints
        val out = ArrayList<ScheduledFrame>(rawEmit.size)
        var rendered = 0
        var anchors = 0
        var lastKeyFrameIdx = -maxHoldFrames

        for (idx in rawEmit.indices) {
            val cur = rawEmit[idx]
            val nextFrame = if (idx + 1 < rawEmit.size) rawEmit[idx + 1].frameIndex else totalFrames
            val durFrames = max(1, nextFrame - cur.frameIndex)
            val needKey = cur.frameIndex == 0 || (cur.frameIndex - lastKeyFrameIdx) >= maxHoldFrames
            if (needKey) lastKeyFrameIdx = cur.frameIndex
            if (!cur.reuse) rendered++
            if (cur.isAnchor) anchors++

            out.add(
                ScheduledFrame(
                    frameIndex = cur.frameIndex,
                    ptsNs = cur.frameIndex.toLong() * 1_000_000_000L / safeFps,
                    durationFrames = durFrames,
                    isKeyFrame = needKey,
                    reusePreviousRender = cur.reuse,
                    isDynamic = cur.dyn,
                    signature = cur.sig
                )
            )
        }

        val skipped = (totalFrames - out.size).coerceAtLeast(0)
        val ratio = if (totalFrames > 0) (skipped.toDouble() / totalFrames.toDouble()) * 100.0 else 0.0
        return ScheduleSummary(
            totalTimelineFrames = totalFrames,
            renderedFrames = rendered,
            encodedFrames = out.size,
            skippedFrames = skipped,
            dedupAnchorFrames = anchors,
            skipRatioPercent = kotlin.math.round(ratio * 100.0) / 100.0,
            frames = out
        )
    }

    private data class RawEmission(
        val frameIndex: Int,
        val reuse: Boolean,
        val dyn: Boolean,
        val sig: String,
        val isAnchor: Boolean
    )
}
