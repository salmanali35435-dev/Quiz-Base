package com.quizstudiopro.app.audio

import com.quizstudiopro.app.logging.QuizLogger
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Reliable, bounded-window, session-isolated PCM16 delivery coordinator between WebView JS and Android.
 *
 * Packet layout ("PCM1" = 32-byte little-endian header + PCM16 mono payload):
 *   [0..3]   Magic ASCII ("PCM1")
 *   [4..7]   Int32LE sessionToken
 *   [8..11]  Int32LE packetSeq (0-based)
 *   [12..15] Int32LE payloadByteLength
 *   [16..23] Int64LE expectedTotalBytes
 *   [24..31] Int64LE expectedTotalSamples
 *   [32..N]  Raw PCM16 mono little-endian samples
 *
 * Completion control packet ("PCMD" = 32-byte little-endian header):
 *   [0..3]   Magic ASCII ("PCMD")
 *   [4..7]   Int32LE sessionToken
 *   [8..11]  Int32LE expectedPacketCount
 *   [12..15] Int32LE reserved (0)
 *   [16..23] Int64LE expectedTotalBytes
 *   [24..31] Int64LE expectedTotalSamples
 */
class PcmTransferCoordinator {

    companion object {
        private const val TAG = "PcmTransfer"
        const val MAGIC_PCM0 = "PCM0"
        const val MAGIC_PCM1 = "PCM1"
        const val MAGIC_PCMD = "PCMD"
        const val MAGIC_RGBA = "RGBA"
        const val HEADER_SIZE_PCM1 = 32
        const val MAX_REORDER_BUFFER_PACKETS = 16
    }

    data class AckResult(
        val type: String = "PCM_ACK",
        val ok: Boolean,
        val sessionId: String,
        val sessionToken: Int,
        val seq: Int,
        val writtenBytes: Int,
        val cumulativeBytes: Long,
        val expectedBytes: Long,
        val ackedPackets: Int,
        val duplicate: Boolean = false,
        val error: String? = null
    ) {
        fun toJsonString(): String {
            val sb = StringBuilder(220)
            sb.append('{')
            sb.append("\"type\":\"").append(escapeJson(type)).append("\",")
            sb.append("\"ok\":").append(ok).append(',')
            sb.append("\"sessionId\":\"").append(escapeJson(sessionId)).append("\",")
            sb.append("\"sessionToken\":").append(sessionToken).append(',')
            sb.append("\"seq\":").append(seq).append(',')
            sb.append("\"writtenBytes\":").append(writtenBytes).append(',')
            sb.append("\"cumulativeBytes\":").append(cumulativeBytes).append(',')
            sb.append("\"expectedBytes\":").append(expectedBytes).append(',')
            sb.append("\"ackedPackets\":").append(ackedPackets).append(',')
            sb.append("\"duplicate\":").append(duplicate).append(',')
            if (error != null) {
                sb.append("\"error\":\"").append(escapeJson(error)).append("\"")
            } else {
                sb.append("\"error\":null")
            }
            sb.append('}')
            return sb.toString()
        }
    }

    data class CompleteResult(
        val type: String = "PCM_COMPLETE_ACK",
        val ok: Boolean,
        val sessionId: String,
        val sessionToken: Int,
        val expectedPackets: Int,
        val ackedPackets: Int,
        val expectedBytes: Long,
        val actualBytes: Long,
        val expectedSamples: Long,
        val missingPackets: Int,
        val duplicatePackets: Int,
        val transferDurationMs: Long,
        val error: String? = null
    ) {
        fun toJsonString(): String {
            val sb = StringBuilder(320)
            sb.append('{')
            sb.append("\"type\":\"").append(escapeJson(type)).append("\",")
            sb.append("\"ok\":").append(ok).append(',')
            sb.append("\"sessionId\":\"").append(escapeJson(sessionId)).append("\",")
            sb.append("\"sessionToken\":").append(sessionToken).append(',')
            sb.append("\"expectedPackets\":").append(expectedPackets).append(',')
            sb.append("\"ackedPackets\":").append(ackedPackets).append(',')
            sb.append("\"expectedBytes\":").append(expectedBytes).append(',')
            sb.append("\"actualBytes\":").append(actualBytes).append(',')
            sb.append("\"expectedSamples\":").append(expectedSamples).append(',')
            sb.append("\"missingPackets\":").append(missingPackets).append(',')
            sb.append("\"duplicatePackets\":").append(duplicatePackets).append(',')
            sb.append("\"transferDurationMs\":").append(transferDurationMs).append(',')
            if (error != null) {
                sb.append("\"error\":\"").append(escapeJson(error)).append("\"")
            } else {
                sb.append("\"error\":null")
            }
            sb.append('}')
            return sb.toString()
        }
    }

    data class TelemetrySnapshot(
        val sessionId: String,
        val sessionToken: Int,
        val expectedSamples: Long,
        val expectedBytes: Long,
        val expectedPackets: Int,
        val packetsReceived: Int,
        val packetsAcked: Int,
        val duplicatePackets: Int,
        val outOfOrderPackets: Int,
        val staleOrRejectedPackets: Int,
        val missingPackets: Int,
        val cumulativeWrittenBytes: Long,
        val actualFileBytes: Long,
        val transferDurationMs: Long,
        val completedAndVerified: Boolean,
        val lastError: String?
    )

    private val lock = Any()
    private var sessionId: String = ""
    private var sessionToken: Int = 0
    private var pcmFile: File? = null
    private var outputStream: FileOutputStream? = null
    private var expectedSamples: Long = 0L
    private var expectedBytes: Long = 0L
    private var expectedPackets: Int = 0
    private var packetsReceived: Int = 0
    private var packetsAcked: Int = 0
    private var duplicatePackets: Int = 0
    private var outOfOrderPackets: Int = 0
    private var staleOrRejectedPackets: Int = 0
    private var cumulativeWrittenBytes: Long = 0L
    private var nextExpectedSeq: Int = 0
    private val pendingReorder = HashMap<Int, ByteArray>()
    private var completedAndVerified: Boolean = false
    private var cancelled: Boolean = false
    private var transferStartMs: Long = 0L
    private var transferEndMs: Long = 0L
    private var lastError: String? = null

    fun prepareSession(
        sessionId: String,
        sessionToken: Int,
        pcmFile: File,
        expectedSamples: Long,
        expectedPackets: Int = -1
    ) {
        synchronized(lock) {
            closeStreamLocked()
            pendingReorder.clear()

            this.sessionId = sessionId
            this.sessionToken = sessionToken
            this.pcmFile = pcmFile
            this.expectedSamples = expectedSamples.coerceAtLeast(0L)
            this.expectedBytes = this.expectedSamples * 2L
            this.expectedPackets = expectedPackets
            this.packetsReceived = 0
            this.packetsAcked = 0
            this.duplicatePackets = 0
            this.outOfOrderPackets = 0
            this.staleOrRejectedPackets = 0
            this.cumulativeWrittenBytes = 0L
            this.nextExpectedSeq = 0
            this.completedAndVerified = false
            this.cancelled = false
            this.transferStartMs = System.currentTimeMillis()
            this.transferEndMs = 0L
            this.lastError = null

            pcmFile.parentFile?.mkdirs()
            this.outputStream = FileOutputStream(pcmFile, false)
        }
    }

    fun bindTransferMetadata(
        sessionId: String,
        sessionToken: Int,
        expectedSamples: Long,
        expectedPackets: Int
    ): AckResult {
        synchronized(lock) {
            if (cancelled) {
                return AckResult(
                    type = "PCM_BEGIN_ACK",
                    ok = false,
                    sessionId = sessionId,
                    sessionToken = sessionToken,
                    seq = -1,
                    writtenBytes = 0,
                    cumulativeBytes = cumulativeWrittenBytes,
                    expectedBytes = expectedBytes,
                    ackedPackets = packetsAcked,
                    error = "PCM session was cancelled before transfer started"
                )
            }
            if (this.expectedSamples > 0L && expectedSamples != this.expectedSamples) {
                val err = "PCM sample count mismatch at begin: prepared=${this.expectedSamples}, transfer=$expectedSamples"
                lastError = err
                return AckResult(
                    type = "PCM_BEGIN_ACK",
                    ok = false,
                    sessionId = sessionId,
                    sessionToken = sessionToken,
                    seq = -1,
                    writtenBytes = 0,
                    cumulativeBytes = cumulativeWrittenBytes,
                    expectedBytes = expectedBytes,
                    ackedPackets = packetsAcked,
                    error = err
                )
            }
            this.sessionId = sessionId
            this.sessionToken = sessionToken
            this.expectedSamples = expectedSamples.coerceAtLeast(0L)
            this.expectedBytes = this.expectedSamples * 2L
            this.expectedPackets = expectedPackets
            this.transferStartMs = System.currentTimeMillis()
            QuizLogger.info(
                TAG,
                "PCM transfer initialized session=$sessionId token=$sessionToken expectedSamples=${this.expectedSamples} expectedBytes=${this.expectedBytes} expectedPackets=$expectedPackets"
            )
            return AckResult(
                type = "PCM_BEGIN_ACK",
                ok = true,
                sessionId = this.sessionId,
                sessionToken = this.sessionToken,
                seq = -1,
                writtenBytes = 0,
                cumulativeBytes = cumulativeWrittenBytes,
                expectedBytes = this.expectedBytes,
                ackedPackets = packetsAcked
            )
        }
    }

    fun handlePcm1Packet(rawBytes: ByteArray): List<AckResult> {
        if (rawBytes.size < HEADER_SIZE_PCM1) {
            return listOf(
                AckResult(
                    ok = false,
                    sessionId = sessionId,
                    sessionToken = 0,
                    seq = -1,
                    writtenBytes = 0,
                    cumulativeBytes = cumulativeWrittenBytes,
                    expectedBytes = expectedBytes,
                    ackedPackets = packetsAcked,
                    error = "Truncated PCM1 header (${rawBytes.size} bytes)"
                )
            )
        }
        val bb = ByteBuffer.wrap(rawBytes).order(ByteOrder.LITTLE_ENDIAN)
        val pktToken = bb.getInt(4)
        val pktSeq = bb.getInt(8)
        val pktPayloadLen = bb.getInt(12)
        val pktExpectedBytes = bb.getLong(16)
        val pktExpectedSamples = bb.getLong(24)

        val actualPayloadLen = rawBytes.size - HEADER_SIZE_PCM1
        if (pktPayloadLen < 0 || pktPayloadLen != actualPayloadLen || (pktPayloadLen % 2) != 0) {
            synchronized(lock) {
                staleOrRejectedPackets++
                val err = "Malformed PCM1 packet seq=$pktSeq declaredLen=$pktPayloadLen actualLen=$actualPayloadLen"
                lastError = err
                return listOf(
                    AckResult(
                        ok = false,
                        sessionId = sessionId,
                        sessionToken = pktToken,
                        seq = pktSeq,
                        writtenBytes = 0,
                        cumulativeBytes = cumulativeWrittenBytes,
                        expectedBytes = expectedBytes,
                        ackedPackets = packetsAcked,
                        error = err
                    )
                )
            }
        }
        val payload = rawBytes.copyOfRange(HEADER_SIZE_PCM1, rawBytes.size)
        return acceptChunk(pktToken, pktSeq, pktPayloadLen, pktExpectedBytes, pktExpectedSamples, payload)
    }

    fun handlePcmdPacket(rawBytes: ByteArray): CompleteResult {
        if (rawBytes.size < HEADER_SIZE_PCM1) {
            return CompleteResult(
                ok = false,
                sessionId = sessionId,
                sessionToken = 0,
                expectedPackets = -1,
                ackedPackets = packetsAcked,
                expectedBytes = expectedBytes,
                actualBytes = cumulativeWrittenBytes,
                expectedSamples = expectedSamples,
                missingPackets = 0,
                duplicatePackets = duplicatePackets,
                transferDurationMs = 0L,
                error = "Truncated PCMD completion header (${rawBytes.size} bytes)"
            )
        }
        val bb = ByteBuffer.wrap(rawBytes).order(ByteOrder.LITTLE_ENDIAN)
        val pktToken = bb.getInt(4)
        val pktExpectedPackets = bb.getInt(8)
        val pktExpectedBytes = bb.getLong(16)
        val pktExpectedSamples = bb.getLong(24)
        return completeTransfer(
            sessionId = null,
            sessionToken = pktToken,
            expectedPackets = pktExpectedPackets,
            expectedBytes = pktExpectedBytes,
            expectedSamples = pktExpectedSamples
        )
    }

    fun handleLegacyPcm0Packet(payload: ByteArray) {
        synchronized(lock) {
            val os = outputStream
            if (cancelled || completedAndVerified || os == null) {
                staleOrRejectedPackets++
                val err = "PCM0 packet rejected because PCM stream is inactive/closed (bytes=${payload.size}, session=$sessionId)"
                lastError = err
                QuizLogger.error(TAG, err)
                return
            }
            os.write(payload)
            cumulativeWrittenBytes += payload.size
            packetsReceived++
            packetsAcked++
        }
    }

    fun acceptChunk(
        pktToken: Int,
        pktSeq: Int,
        pktPayloadLen: Int,
        pktExpectedBytes: Long,
        pktExpectedSamples: Long,
        payload: ByteArray
    ): List<AckResult> {
        synchronized(lock) {
            val os = outputStream
            if (cancelled || os == null || completedAndVerified) {
                staleOrRejectedPackets++
                val reason = when {
                    cancelled -> "cancelled"
                    completedAndVerified -> "already completed"
                    else -> "stream closed/null"
                }
                val err = "PCM packet rejected ($reason): session=$sessionId token=$pktToken activeToken=$sessionToken seq=$pktSeq bytes=${payload.size}"
                QuizLogger.warn(TAG, err)
                return listOf(
                    AckResult(
                        ok = false,
                        sessionId = sessionId,
                        sessionToken = pktToken,
                        seq = pktSeq,
                        writtenBytes = 0,
                        cumulativeBytes = cumulativeWrittenBytes,
                        expectedBytes = expectedBytes,
                        ackedPackets = packetsAcked,
                        error = err
                    )
                )
            }
            if (pktToken != sessionToken || sessionToken == 0) {
                staleOrRejectedPackets++
                val err = "PCM session token mismatch: packetToken=$pktToken activeToken=$sessionToken seq=$pktSeq"
                QuizLogger.warn(TAG, err)
                return listOf(
                    AckResult(
                        ok = false,
                        sessionId = sessionId,
                        sessionToken = pktToken,
                        seq = pktSeq,
                        writtenBytes = 0,
                        cumulativeBytes = cumulativeWrittenBytes,
                        expectedBytes = expectedBytes,
                        ackedPackets = packetsAcked,
                        error = err
                    )
                )
            }
            if (pktPayloadLen != payload.size || (payload.size % 2) != 0) {
                staleOrRejectedPackets++
                val err = "PCM payload length mismatch seq=$pktSeq declared=$pktPayloadLen actual=${payload.size}"
                lastError = err
                return listOf(
                    AckResult(
                        ok = false,
                        sessionId = sessionId,
                        sessionToken = sessionToken,
                        seq = pktSeq,
                        writtenBytes = 0,
                        cumulativeBytes = cumulativeWrittenBytes,
                        expectedBytes = expectedBytes,
                        ackedPackets = packetsAcked,
                        error = err
                    )
                )
            }
            if (pktExpectedSamples != expectedSamples || pktExpectedBytes != expectedBytes) {
                staleOrRejectedPackets++
                val err = "PCM total mismatch seq=$pktSeq packetExpected=${pktExpectedBytes}B/${pktExpectedSamples}s activeExpected=${expectedBytes}B/${expectedSamples}s"
                lastError = err
                return listOf(
                    AckResult(
                        ok = false,
                        sessionId = sessionId,
                        sessionToken = sessionToken,
                        seq = pktSeq,
                        writtenBytes = 0,
                        cumulativeBytes = cumulativeWrittenBytes,
                        expectedBytes = expectedBytes,
                        ackedPackets = packetsAcked,
                        error = err
                    )
                )
            }
            if (pktSeq < 0) {
                staleOrRejectedPackets++
                val err = "Negative PCM sequence number: $pktSeq"
                lastError = err
                return listOf(
                    AckResult(
                        ok = false,
                        sessionId = sessionId,
                        sessionToken = sessionToken,
                        seq = pktSeq,
                        writtenBytes = 0,
                        cumulativeBytes = cumulativeWrittenBytes,
                        expectedBytes = expectedBytes,
                        ackedPackets = packetsAcked,
                        error = err
                    )
                )
            }

            packetsReceived++

            if (pktSeq < nextExpectedSeq) {
                duplicatePackets++
                return listOf(
                    AckResult(
                        ok = true,
                        sessionId = sessionId,
                        sessionToken = sessionToken,
                        seq = pktSeq,
                        writtenBytes = 0,
                        cumulativeBytes = cumulativeWrittenBytes,
                        expectedBytes = expectedBytes,
                        ackedPackets = packetsAcked,
                        duplicate = true
                    )
                )
            }

            if (pktSeq > nextExpectedSeq) {
                if (pendingReorder.containsKey(pktSeq)) {
                    duplicatePackets++
                    return emptyList()
                }
                if (pendingReorder.size >= MAX_REORDER_BUFFER_PACKETS) {
                    val err = "PCM reorder buffer overflow (seq=$pktSeq nextExpected=$nextExpectedSeq queued=${pendingReorder.size})"
                    lastError = err
                    return listOf(
                        AckResult(
                            ok = false,
                            sessionId = sessionId,
                            sessionToken = sessionToken,
                            seq = pktSeq,
                            writtenBytes = 0,
                            cumulativeBytes = cumulativeWrittenBytes,
                            expectedBytes = expectedBytes,
                            ackedPackets = packetsAcked,
                            error = err
                        )
                    )
                }
                outOfOrderPackets++
                pendingReorder[pktSeq] = payload
                return emptyList()
            }

            // pktSeq == nextExpectedSeq: write immediately, then drain contiguous buffered packets
            val acks = ArrayList<AckResult>(1 + pendingReorder.size)
            writeOrderedChunkLocked(os, pktSeq, payload, acks)
            while (pendingReorder.containsKey(nextExpectedSeq)) {
                val queued = pendingReorder.remove(nextExpectedSeq)!!
                writeOrderedChunkLocked(os, nextExpectedSeq, queued, acks)
            }
            return acks
        }
    }

    private fun writeOrderedChunkLocked(
        os: FileOutputStream,
        seq: Int,
        payload: ByteArray,
        outAcks: MutableList<AckResult>
    ) {
        if (cumulativeWrittenBytes + payload.size > expectedBytes && expectedBytes > 0L) {
            val err = "PCM overflow: writing ${payload.size}B at $cumulativeWrittenBytes exceeds expectedBytes=$expectedBytes"
            lastError = err
            outAcks.add(
                AckResult(
                    ok = false,
                    sessionId = sessionId,
                    sessionToken = sessionToken,
                    seq = seq,
                    writtenBytes = 0,
                    cumulativeBytes = cumulativeWrittenBytes,
                    expectedBytes = expectedBytes,
                    ackedPackets = packetsAcked,
                    error = err
                )
            )
            return
        }
        os.write(payload)
        cumulativeWrittenBytes += payload.size
        packetsAcked++
        nextExpectedSeq++
        outAcks.add(
            AckResult(
                ok = true,
                sessionId = sessionId,
                sessionToken = sessionToken,
                seq = seq,
                writtenBytes = payload.size,
                cumulativeBytes = cumulativeWrittenBytes,
                expectedBytes = expectedBytes,
                ackedPackets = packetsAcked,
                duplicate = false
            )
        )
    }

    fun completeTransfer(
        sessionId: String?,
        sessionToken: Int,
        expectedPackets: Int,
        expectedBytes: Long,
        expectedSamples: Long
    ): CompleteResult {
        synchronized(lock) {
            if (cancelled) {
                val err = "PCM transfer incomplete: session was cancelled"
                lastError = err
                return buildCompleteFailure(expectedPackets, err)
            }
            if (sessionToken != this.sessionToken || this.sessionToken == 0) {
                val err = "PCM transfer session mismatch: token=$sessionToken activeToken=${this.sessionToken}"
                lastError = err
                return buildCompleteFailure(expectedPackets, err)
            }
            if (sessionId != null && sessionId.isNotEmpty() && sessionId != this.sessionId) {
                val err = "PCM transfer session ID mismatch: got=$sessionId active=${this.sessionId}"
                lastError = err
                return buildCompleteFailure(expectedPackets, err)
            }
            if (expectedSamples != this.expectedSamples || expectedBytes != this.expectedBytes) {
                val err = "PCM transfer expected size mismatch: expected=${this.expectedBytes}B (${this.expectedSamples}s), reported=${expectedBytes}B (${expectedSamples}s)"
                lastError = err
                return buildCompleteFailure(expectedPackets, err)
            }
            if (this.expectedPackets >= 0 && expectedPackets >= 0 && expectedPackets != this.expectedPackets) {
                val err = "PCM packet count mismatch: expected=${this.expectedPackets}, reported=$expectedPackets"
                lastError = err
                return buildCompleteFailure(expectedPackets, err)
            }
            this.expectedPackets = expectedPackets

            if (pendingReorder.isNotEmpty() || (expectedPackets >= 0 && nextExpectedSeq != expectedPackets)) {
                val missing = if (expectedPackets >= 0) (expectedPackets - packetsAcked).coerceAtLeast(0) else pendingReorder.size
                val err = "PCM transfer incomplete: missing $missing packet(s) (acked=$packetsAcked/$expectedPackets, nextExpected=$nextExpectedSeq, outOfOrderPending=${pendingReorder.size})"
                lastError = err
                return buildCompleteFailure(expectedPackets, err)
            }

            // Flush & close stream ONLY after every packet is written in order
            try {
                outputStream?.flush()
                outputStream?.close()
            } catch (e: Exception) {
                val err = "PCM stream flush/close failed: ${e.message}"
                lastError = err
                return buildCompleteFailure(expectedPackets, err)
            } finally {
                outputStream = null
            }

            val file = pcmFile
            val actualFileLen = if (file != null && file.exists()) file.length() else 0L
            if (this.expectedBytes > 0L) {
                if (file == null || !file.exists()) {
                    val err = "PCM file missing after transfer (expected=${this.expectedBytes} bytes)"
                    lastError = err
                    return buildCompleteFailure(expectedPackets, err, actualFileLen)
                }
                if (actualFileLen == 0L) {
                    val err = "PCM file is empty (expected=${this.expectedBytes} bytes, actual=0 bytes)"
                    lastError = err
                    return buildCompleteFailure(expectedPackets, err, actualFileLen)
                }
                if ((actualFileLen % 2L) != 0L) {
                    val err = "PCM file byte length unaligned to 16-bit samples (actual=$actualFileLen bytes)"
                    lastError = err
                    return buildCompleteFailure(expectedPackets, err, actualFileLen)
                }
                if (actualFileLen != this.expectedBytes || cumulativeWrittenBytes != this.expectedBytes) {
                    val err = "PCM file size mismatch: expected=${this.expectedBytes} bytes, actual=$actualFileLen bytes (written=$cumulativeWrittenBytes bytes)"
                    lastError = err
                    return buildCompleteFailure(expectedPackets, err, actualFileLen)
                }
            }

            completedAndVerified = true
            transferEndMs = System.currentTimeMillis()
            val durMs = (transferEndMs - transferStartMs).coerceAtLeast(0L)
            QuizLogger.info(
                TAG,
                "PCM transfer verified session=${this.sessionId} packets=$packetsAcked/$expectedPackets bytes=$actualFileLen/${this.expectedBytes} dur=${durMs}ms dups=$duplicatePackets ooo=$outOfOrderPackets"
            )
            return CompleteResult(
                ok = true,
                sessionId = this.sessionId,
                sessionToken = this.sessionToken,
                expectedPackets = expectedPackets,
                ackedPackets = packetsAcked,
                expectedBytes = this.expectedBytes,
                actualBytes = actualFileLen,
                expectedSamples = this.expectedSamples,
                missingPackets = 0,
                duplicatePackets = duplicatePackets,
                transferDurationMs = durMs,
                error = null
            )
        }
    }

    fun verifyReadyForEncoding(requiredSamples: Long): Result<TelemetrySnapshot> {
        synchronized(lock) {
            val snap = snapshotLocked()
            if (requiredSamples <= 0L) {
                return Result.success(snap)
            }
            val reqBytes = requiredSamples * 2L
            if (cancelled) {
                return Result.failure(IllegalStateException("PCM transfer was cancelled"))
            }
            if (!completedAndVerified) {
                return Result.failure(
                    IllegalStateException(
                        lastError ?: "PCM transfer incomplete: completion handshake not confirmed (written=${snap.cumulativeWrittenBytes}/$reqBytes bytes, packets=${snap.packetsAcked}/${snap.expectedPackets})"
                    )
                )
            }
            val file = pcmFile
            val actualBytes = if (file != null && file.exists()) file.length() else 0L
            if (file == null || !file.exists() || actualBytes == 0L) {
                return Result.failure(
                    IllegalStateException("PCM file missing or empty before encoding (expected=$reqBytes bytes, actual=$actualBytes bytes)")
                )
            }
            if ((actualBytes % 2L) != 0L) {
                return Result.failure(
                    IllegalStateException("PCM file unaligned to 16-bit mono samples (actual=$actualBytes bytes)")
                )
            }
            if (actualBytes != reqBytes || snap.expectedBytes != reqBytes) {
                return Result.failure(
                    IllegalStateException("PCM file size mismatch before encoding: expected=$reqBytes bytes, actual=$actualBytes bytes")
                )
            }
            if (snap.missingPackets > 0 || pendingReorder.isNotEmpty()) {
                return Result.failure(
                    IllegalStateException("PCM transfer incomplete: missing=${snap.missingPackets} outOfOrder=${pendingReorder.size}")
                )
            }
            return Result.success(snap)
        }
    }

    fun getTelemetrySnapshot(): TelemetrySnapshot {
        synchronized(lock) {
            return snapshotLocked()
        }
    }

    fun isActiveSession(token: Int): Boolean {
        synchronized(lock) {
            return !cancelled && token != 0 && token == sessionToken && outputStream != null
        }
    }

    fun cancelAndReset(deleteFile: Boolean = true) {
        synchronized(lock) {
            cancelled = true
            sessionToken = 0
            pendingReorder.clear()
            closeStreamLocked()
            if (deleteFile) {
                try { pcmFile?.delete() } catch (_: Exception) {}
                pcmFile = null
            }
        }
    }

    private fun buildCompleteFailure(expectedPackets: Int, error: String, actualFileLen: Long = cumulativeWrittenBytes): CompleteResult {
        val missing = if (expectedPackets >= 0) (expectedPackets - packetsAcked).coerceAtLeast(0) else pendingReorder.size
        val now = System.currentTimeMillis()
        val dur = if (transferStartMs > 0L) (now - transferStartMs).coerceAtLeast(0L) else 0L
        QuizLogger.error(TAG, error)
        return CompleteResult(
            ok = false,
            sessionId = sessionId,
            sessionToken = sessionToken,
            expectedPackets = expectedPackets,
            ackedPackets = packetsAcked,
            expectedBytes = expectedBytes,
            actualBytes = actualFileLen,
            expectedSamples = expectedSamples,
            missingPackets = missing,
            duplicatePackets = duplicatePackets,
            transferDurationMs = dur,
            error = error
        )
    }

    private fun snapshotLocked(): TelemetrySnapshot {
        val actualFileLen = if (pcmFile != null && pcmFile!!.exists()) pcmFile!!.length() else cumulativeWrittenBytes
        val missing = if (expectedPackets >= 0) (expectedPackets - packetsAcked).coerceAtLeast(0) else 0
        val endMs = if (transferEndMs > 0L) transferEndMs else if (transferStartMs > 0L) System.currentTimeMillis() else 0L
        return TelemetrySnapshot(
            sessionId = sessionId,
            sessionToken = sessionToken,
            expectedSamples = expectedSamples,
            expectedBytes = expectedBytes,
            expectedPackets = expectedPackets,
            packetsReceived = packetsReceived,
            packetsAcked = packetsAcked,
            duplicatePackets = duplicatePackets,
            outOfOrderPackets = outOfOrderPackets,
            staleOrRejectedPackets = staleOrRejectedPackets,
            missingPackets = missing,
            cumulativeWrittenBytes = cumulativeWrittenBytes,
            actualFileBytes = actualFileLen,
            transferDurationMs = if (transferStartMs > 0L) (endMs - transferStartMs).coerceAtLeast(0L) else 0L,
            completedAndVerified = completedAndVerified,
            lastError = lastError
        )
    }

    private fun closeStreamLocked() {
        try { outputStream?.flush() } catch (_: Exception) {}
        try { outputStream?.close() } catch (_: Exception) {}
        outputStream = null
    }
}

private fun escapeJson(s: String): String {
    val sb = StringBuilder(s.length + 8)
    for (ch in s) {
        when (ch) {
            '\\' -> sb.append("\\\\")
            '"' -> sb.append("\\\"")
            '\n' -> sb.append("\\n")
            '\r' -> sb.append("\\r")
            '\t' -> sb.append("\\t")
            else -> sb.append(ch)
        }
    }
    return sb.toString()
}
